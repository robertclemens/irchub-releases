#include "hub_uhist.h"
#include "hub_console.h"
#include "hub_reply.h"
#include "cfg_delta.h"
#include "sync_digest.h"
#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <openssl/crypto.h>
#include <openssl/rand.h>
#include <stdarg.h>
#include <strings.h>
#include <sys/select.h>

static void cfg_hold_release(hub_state_t *state, hub_client_t *client);
static void send_config_to_bot(hub_state_t *state, hub_client_t *client,
                               bool force);
static void hub_broadcast_config_to_bots(hub_state_t *state, const char *config_line);
static void roster_evict_moved(hub_state_t *state, const char *bot_uuid,
                               const char *keep_hub, time_t since, uint64_t link_ord);

/* ==========================================================================
 * '|'-delimited wire fields
 *
 * sscanf's "%[^|]" cannot match an EMPTY field: the conversion fails there
 * and every field after it is left untouched.  A frame with an optional
 * middle field — "id|2.99.0|||*|file://…", which is exactly what an upgrade
 * run that names neither a variant nor an artifact kind looks like — was
 * therefore parsed as two fields, silently dropping the manifest base.  Every
 * '|'-framed field is read through these instead; they are the C counterpart
 * of split('|') on the Rust side, so both hubs read a frame identically.
 * ========================================================================== */

/* Field `idx` of `s`, NUL-terminated into `dst`.  An over-long field is a
 * malformed frame, not something to truncate silently: false, `dst` empty. */
hub_stats_t g_hub_stats;

static bool bot_takes_cfg_deltas(const hub_client_t *c);
static int cfg_resync_local(hub_state_t *state, const char *target);
/* `server rebalance force` (server order plan §7): the waves this hub drives. */
typedef struct {
  bool active;
  int waves, moved;
  char wave[REBALANCE_WAVE_MAX][64];
  int wn;
  time_t wave_at;
  char by[64];
  char done[MAX_BOTS][64]; /* moved once already: never again this run */
  int ndone;
} rebalance_t;
static rebalance_t g_rebal;
static bool rebalance_off_first(const hub_state_t *state, const char *uuid, char *cur, size_t ccap,
                                char *first, size_t fcap);
static int cfg_resync_flood(hub_state_t *state, hub_client_t *skip, const char *payload);
static void process_peer_cfg_resync(hub_state_t *state, hub_client_t *peer, const char *payload);
static void process_sync_digest(hub_state_t *state, hub_client_t *peer, const char *payload);
static void cfg_hex(const unsigned char h[32], char out[CFGD_HASH_HEX + 1]);

/* Some bot's config frame was lost since the last flush (cfg_owed). */
static bool g_cfg_owed;
/* Bots whose first config is held for their presence (CFG_FIRST_HOLD). */
static int g_cfg_holds;

/* A config push that never reaches its bot must not stand as "sent", or the
 * next identical broadcast would be skipped and the bot left behind.  Nor may
 * it wait for the next change: the bot still holds S, which the keepalive's
 * c| vouches for, so nothing else would notice (proto/cfgdelta model, seed
 * 82) — it is owed, and the next flush sends it. */
static void cfg_push_lost(hub_client_t *c, const queued_msg_t *m) {
  if (m->cmd == CMD_BOT_TREE || m->cmd == CMD_BOT_TREE_DELTA)
    c->tree_sent_valid = false; /* a tree or delta that never landed: resend whole */
  if (m->cmd != CMD_CONFIG_DATA && m->cmd != CMD_CONFIG_DELTA) return;
  c->cfg_sent_valid = false;
  g_hub_stats.cfg_lost++;
  if (!m->cfg_frame) return;
  if (c->cfg_next) {
    secure_wipe(c->cfg_next, c->cfg_next_len);
    free(c->cfg_next);
    c->cfg_next = NULL;
    c->cfg_next_len = 0;
  }
  c->cfg_queued = false;
  c->cfg_owed = true;
  g_cfg_owed = true;
}

/* The queued config frame went to the socket: the bot will hold its text. */
static void cfg_frame_written(hub_client_t *c) {
  if (!c->cfg_queued || !c->cfg_next) return;
  if (c->cfg_base) {
    secure_wipe(c->cfg_base, c->cfg_base_len);
    free(c->cfg_base);
  }
  c->cfg_base = c->cfg_next;
  c->cfg_base_len = c->cfg_next_len;
  unsigned int olen = 0;
  if (EVP_Digest(c->cfg_base, c->cfg_base_len, c->cfg_base_hash, &olen, EVP_sha256(), NULL) != 1 ||
      olen != 32) {
    /* No hash, no vouching for it: forget S, the next push goes out full. */
    secure_wipe(c->cfg_base, c->cfg_base_len);
    free(c->cfg_base);
    c->cfg_base = NULL;
    c->cfg_base_len = 0;
  }
  c->cfg_next = NULL;
  c->cfg_next_len = 0;
  c->cfg_queued = false;
}

void hub_cfg_delta_release(hub_client_t *c) {
  if (!c) return;
  if (c->cfg_base) {
    secure_wipe(c->cfg_base, c->cfg_base_len);
    free(c->cfg_base);
  }
  if (c->cfg_next) {
    secure_wipe(c->cfg_next, c->cfg_next_len);
    free(c->cfg_next);
  }
  c->cfg_base = c->cfg_next = NULL;
  c->cfg_base_len = c->cfg_next_len = 0;
  c->cfg_queued = c->cfg_owed = false;
}

/* Max-merge one activity time (last_seen / last_used) outside LWW.  A rise
 * is persisted but is never a config update: nothing forwarded or pushed. */
static bool activity_raise(hub_state_t *state, time_t *slot, time_t ts) {
  if (ts <= *slot || ts > time(NULL) + ACTIVITY_MAX_FUTURE) return false;
  *slot = ts;
  state->config_dirty = true;
  return true;
}

static bool wire_field(const char *s, int idx, char *dst, size_t cap) {
  if (!dst || cap == 0) return false;
  dst[0] = '\0';
  if (!s) return false;
  for (int i = 0; i < idx; i++) {
    const char *bar = strchr(s, '|');
    if (!bar) return false;
    s = bar + 1;
  }
  const char *bar = strchr(s, '|');
  size_t len = bar ? (size_t)(bar - s) : strcspn(s, "\r\n");
  if (len >= cap) return false;
  memcpy(dst, s, len);
  dst[len] = '\0';
  return true;
}

/* Field `idx` and everything after it, minus any trailing CR/LF.  The last
 * field of a frame is free text (a reason, a base URL) and may contain '|';
 * display text is clamped to the buffer rather than rejected. */
static bool wire_tail(const char *s, int idx, char *dst, size_t cap) {
  if (!dst || cap == 0) return false;
  dst[0] = '\0';
  if (!s) return false;
  for (int i = 0; i < idx; i++) {
    const char *bar = strchr(s, '|');
    if (!bar) return false;
    s = bar + 1;
  }
  size_t len = strcspn(s, "\r\n");
  if (len >= cap) len = cap - 1;
  memcpy(dst, s, len);
  dst[len] = '\0';
  return true;
}

/* ==========================================================================
 * Mesh transport — per-peer outbound queue (docs/mesh.md Phase 1)
 *
 * Replaces the old "build packet → encrypt → send-or-drop on EAGAIN" model
 * with a per-client queue drained on POLLOUT.  Encryption happens at drain
 * time (so we can use the up-to-date session_key) and partial writes are
 * tracked via writing_buf/writing_offset.  Three priority lanes: URGENT
 * (op flow), DELTA (small per-key updates), BULK (anti-entropy/full sync).
 * ========================================================================== */

queued_msg_t *queued_msg_new(uint8_t cmd, lane_t lane,
                             const unsigned char *payload, int payload_len) {
  /* Change 5: bulk lanes (CONFIG_DATA / PEER_SYNC full-state) may be far larger
   * than MAX_BUFFER; bound by the bulk-payload ceiling instead. */
  if (payload_len < 0 || payload_len > MAX_BULK_PAYLOAD)
    return NULL;
  queued_msg_t *m = calloc(1, sizeof(*m));
  if (!m) return NULL;
  m->cmd = cmd;
  m->lane = lane;
  if (payload_len > 0) {
    m->payload = malloc((size_t)payload_len);
    if (!m->payload) { free(m); return NULL; }
    memcpy(m->payload, payload, (size_t)payload_len);
  }
  m->payload_len = payload_len;
  return m;
}

void queued_msg_set_coalesce(queued_msg_t *m, const char *origin_hub_uuid,
                             uint64_t lamport_seq, const char *coalesce_key) {
  if (origin_hub_uuid)
    snprintf(m->origin_hub_uuid, sizeof(m->origin_hub_uuid), "%s", origin_hub_uuid);
  m->lamport_seq = lamport_seq;
  if (coalesce_key)
    snprintf(m->coalesce_key, sizeof(m->coalesce_key), "%s", coalesce_key);
}

void queued_msg_free(queued_msg_t *m) {
  if (!m) return;
  if (m->payload) {
    /* Defensively wipe payload — it can carry hostmask / op-flow material. */
    secure_wipe(m->payload, (size_t)m->payload_len);
    free(m->payload);
  }
  free(m);
}

/* Atomically replace dst's payload/seq with src's (dst stays in place at the
 * same FIFO position). Used by coalescing.  Both lanes' byte counters must
 * be adjusted by the caller. */
static void queued_msg_replace_payload(queued_msg_t *dst, queued_msg_t *src) {
  if (dst->payload) { secure_wipe(dst->payload, (size_t)dst->payload_len); free(dst->payload); }
  dst->payload     = src->payload;
  dst->payload_len = src->payload_len;
  dst->lamport_seq = src->lamport_seq;
  /* The newer frame wins whole: a queued full config may be replaced by a
   * delta or the other way round (same per-bot key). */
  dst->cmd         = src->cmd;
  dst->cfg_frame   = src->cfg_frame;
  /* Origin hub may differ if a peer's update overwrote a local-origin one;
   * the new origin "wins" because newer seq belongs to it. */
  snprintf(dst->origin_hub_uuid, sizeof(dst->origin_hub_uuid),
           "%s", src->origin_hub_uuid);
  src->payload = NULL;
  src->payload_len = 0;
  free(src);
}

bool peer_enqueue(hub_client_t *peer, queued_msg_t *m) {
  if (!peer || !m) return false;
  if (peer->fd < 0) { queued_msg_free(m); return false; }

  /* The lane index is taken from m->lane (populated by queued_msg_new). */
  int li = (int)m->lane;
  if (li < 0 || li >= LANE_COUNT) li = LANE_BULK;
  queue_lane_t *lane = &peer->out_lanes[li];

  /* ---- Coalescing (Phase 5; harmless in earlier phases when coalesce_key
   * is empty).  Walk the lane FIFO; if we find a same-key entry, replace its
   * payload in place and free the new msg. ---- */
  if (m->coalesce_key[0] != '\0') {
    for (queued_msg_t *cur = lane->head; cur; cur = cur->next) {
      if (cur->coalesce_key[0] != '\0' &&
          strcmp(cur->coalesce_key, m->coalesce_key) == 0) {
        int old_bytes = cur->payload_len;
        int new_bytes = m->payload_len;
        queued_msg_replace_payload(cur, m);
        lane->bytes        += (new_bytes - old_bytes);
        peer->out_total_bytes += (new_bytes - old_bytes);
        return true;
      }
    }
  }

  /* ---- Overflow handling.  URGENT must never be dropped; treat full
   * URGENT as a fatal peer condition (caller will disconnect). DELTA can
   * drop oldest non-coalesced entries. BULK drops oldest. ---- */
  if (lane->count >= MAX_QUEUE_PER_LANE ||
      peer->out_total_bytes + m->payload_len > MAX_QUEUED_BYTES_PER_PEER) {
    if (li == LANE_URGENT) {
      /* Caller will see false and decide whether to disconnect. */
      queued_msg_free(m);
      return false;
    }
    /* Drop oldest in this lane to make room.  For DELTA we lose one update
     * (the next anti-entropy will reconcile); for BULK we lose a full sync
     * (next anti-entropy fires within MESH_ANTI_ENTROPY_INTERVAL). */
    queued_msg_t *old = lane->head;
    if (old) {
      lane->head = old->next;
      if (!lane->head) lane->tail = NULL;
      lane->count--;
      lane->bytes        -= old->payload_len;
      peer->out_total_bytes -= old->payload_len;
      time_t now = time(NULL);
      if (now - peer->drop_logged >= QUEUE_DROP_LOG_EVERY) {
        if (peer->drop_unlogged > 0)
          hub_log_warning("[MESH] queue %s lane full — dropping oldest (peer fd=%d); "
                          "%d more dropped in the last %ds\n",
                          li == LANE_DELTA ? "DELTA" : "BULK", peer->fd,
                          peer->drop_unlogged, (int)(now - peer->drop_logged));
        else
          hub_log_warning("[MESH] queue %s lane full — dropping oldest (peer fd=%d)\n",
                          li == LANE_DELTA ? "DELTA" : "BULK", peer->fd);
        peer->drop_logged = now;
        peer->drop_unlogged = 0;
      } else {
        peer->drop_unlogged++;
      }
      cfg_push_lost(peer, old);
      queued_msg_free(old);
    }
  }

  /* Append.  Output waiting where none was: the write-stall clock starts. */
  if (!peer_has_pending_writes(peer)) peer->write_wait_since = time(NULL);
  m->next = NULL;
  if (lane->tail) lane->tail->next = m;
  else            lane->head       = m;
  lane->tail = m;
  lane->count++;
  lane->bytes        += m->payload_len;
  peer->out_total_bytes += m->payload_len;
  return true;
}

bool peer_has_pending_writes(hub_client_t *peer) {
  if (!peer) return false;
  if (peer->internal) return hub_console_has_pending(peer);
  if (peer->writing_len > peer->writing_offset) return true;
  for (int i = 0; i < LANE_COUNT; i++)
    if (peer->out_lanes[i].count > 0) return true;
  return false;
}

bool hub_client_has_buffered_frame(const hub_client_t *c) {
  if (!c || c->fd <= 0 || !c->recv_buf || c->recv_len - c->recv_off < 4) return false;
  uint32_t net_len;
  memcpy(&net_len, c->recv_buf + c->recv_off, 4);
  int packet_len = (int)ntohl(net_len);
  /* An out-of-range prefix counts: the pump refuses it and drops the client
   * rather than leaving it parked on a length that can never complete. */
  if (packet_len < 0 || packet_len > c->recv_cap - 4) return true;
  return c->recv_len - c->recv_off >= 4 + packet_len;
}

void peer_queue_destroy(hub_client_t *peer) {
  if (!peer) return;
  for (int i = 0; i < LANE_COUNT; i++) {
    queued_msg_t *cur = peer->out_lanes[i].head;
    while (cur) {
      queued_msg_t *next = cur->next;
      queued_msg_free(cur);
      cur = next;
    }
    peer->out_lanes[i].head  = NULL;
    peer->out_lanes[i].tail  = NULL;
    peer->out_lanes[i].count = 0;
    peer->out_lanes[i].bytes = 0;
  }
  peer->out_total_bytes = 0;
  /* Also wipe any partially-written ciphertext. */
  secure_wipe(peer->writing_buf, (size_t)peer->writing_len);
  peer->writing_len    = 0;
  peer->writing_offset = 0;
}

/* Encrypt `m` using peer->session_key into peer->writing_buf.  Returns the
 * total wire length (4-byte length prefix + ciphertext + tag) or 0 on
 * failure. */
/* Review 6: the AAD of frame number `ctr` sent with direction byte `dir` on a
 * sequenced link (CMD_LINK_SEQ). */
static void link_aad(char dir, uint64_t ctr, unsigned char out[HUB_LINK_AAD_LEN]) {
  memcpy(out, "LNK1", 4);
  out[4] = (unsigned char)dir;
  for (int i = 0; i < 8; i++) out[5 + i] = (unsigned char)(ctr >> (56 - 8 * i));
}

static int peer_encrypt_into_writing(hub_client_t *peer, queued_msg_t *m) {
  /* Change 5: heap the plaintext scratch — a bulk CONFIG_DATA/PEER_SYNC frame
   * (up to MAX_BULK_PAYLOAD) is far too large for the stack. */
  if (m->payload_len < 0 || m->payload_len > MAX_BULK_PAYLOAD) return 0;
  unsigned char *plain = malloc((size_t)m->payload_len + 5);
  if (!plain) return 0;
  size_t plain_alloc = (size_t)m->payload_len + 5;
  /* Wire envelope per existing protocol:
   *   plain[0]    = cmd
   *   plain[1..4] = (uint32_t) inner_len in HOST byte order (matches hub_logic
   *                 callers; bot side likewise).  This preserves wire
   *                 compatibility with all existing peers and bots.
   *   plain[5..]  = payload bytes
   *
   * Note: send_config_to_bot historically used network byte order for the
   * inner length to match bot's parser.  We honor that by stamping the
   * inner length here in HOST order for peer/admin packets and in NETWORK
   * order for CMD_CONFIG_DATA bot frames (the only opcode that requires it).
   */
  plain[0] = m->cmd;
  uint32_t inner_len_field;
  /* The bot's frame parser ntohl()s this field unconditionally, so every
   * BOT-destined opcode must be stamped in network order -- peers and admins
   * keep host order for wire compatibility.  CMD_BOT_TREE joined that list;
   * without it the bot computed a garbage length, failed its bounds check and
   * silently dropped every tree push.  CMD_CHAN_DO is queued behind a config
   * push (send_cmd_to_bot_after_config). */
  if (peer->type == CLIENT_BOT || m->cmd == CMD_CONFIG_DATA || m->cmd == CMD_BOT_TREE ||
      m->cmd == CMD_ACTIVITY_REPLY || m->cmd == CMD_CHAN_DO) {
    inner_len_field = htonl((uint32_t)m->payload_len);
  } else {
    inner_len_field = (uint32_t)m->payload_len;
  }
  memcpy(&plain[1], &inner_len_field, 4);
  if (m->payload_len > 0)
    memcpy(&plain[5], m->payload, (size_t)m->payload_len);
  int total_plain = 5 + m->payload_len;

  /* D2: writing_buf may be the small pre-auth buffer. Refuse to encrypt a
   * frame that would not fit (4-byte length prefix + IV + ciphertext + tag:
   * aes_gcm_encrypt writes the IV first).  AES-GCM ciphertext length equals
   * the plaintext length. */
  if (4 + GCM_IV_LEN + total_plain + GCM_TAG_LEN > peer->writing_cap) {
    secure_wipe(plain, plain_alloc);
    free(plain);
    return 0;
  }

  unsigned char tag[GCM_TAG_LEN];
  unsigned char aad[HUB_LINK_AAD_LEN];
  bool seq = peer->link_tx_seq;
  if (seq) link_aad(peer->link_dir_tx, peer->link_tx_ctr, aad);
  int cipher_len = aes_gcm_encrypt_aad(plain, total_plain, seq ? aad : NULL,
                                       seq ? HUB_LINK_AAD_LEN : 0, peer->session_key,
                                       peer->writing_buf + 4, tag);
  /* Wipe plaintext copy ASAP. */
  secure_wipe(plain, plain_alloc);
  free(plain);
  if (cipher_len <= 0) return 0;
  /* Review 6: every frame sealed after our "go" is sequenced. */
  if (seq)
    peer->link_tx_ctr++;
  else if (m->cmd == CMD_LINK_SEQ && m->payload_len == 2 && memcmp(m->payload, "go", 2) == 0)
    peer->link_tx_seq = true;
  memcpy(peer->writing_buf + 4 + cipher_len, tag, GCM_TAG_LEN);
  int packet_len = cipher_len + GCM_TAG_LEN;
  uint32_t nl = htonl((uint32_t)packet_len);
  memcpy(peer->writing_buf, &nl, 4);
  return 4 + packet_len;
}

void peer_drain_writable(hub_state_t *state, hub_client_t *peer) {
  if (!peer || peer->fd < 0) return;
  if (peer->internal) {
    hub_console_drain(state, peer);
    return;
  }

  /* Step 1: finish any in-flight ciphertext. */
  while (peer->writing_offset < peer->writing_len) {
    int remain = peer->writing_len - peer->writing_offset;
    ssize_t s = send(peer->fd, peer->writing_buf + peer->writing_offset,
                     (size_t)remain, MSG_DONTWAIT | MSG_NOSIGNAL);
    if (s > 0) {
      peer->writing_offset += (int)s;
      /* Account against bandwidth window. */
      time_t now = time(NULL);
      peer->write_wait_since = now;
      if (peer->bw_window_start != now) {
        peer->bw_window_start = now;
        peer->bw_bytes_in_window = 0;
      }
      peer->bw_bytes_in_window += (int)s;
      continue;
    }
    if (s < 0 && (IO_WOULD_BLOCK(errno) || errno == EINTR))
      return;  /* try again next POLLOUT */
    /* Hard send error — caller should disconnect.  We cannot do it here
     * safely (caller iterates the client list); signal by clearing fd. */
    hub_log_warning("[MESH] send error to %s (fd=%d): %s\n", peer->ip, peer->fd,
            strerror(errno));
    /* Clear the in-flight buffer so next iteration of main loop will see
     * peer_has_pending_writes()==false and the recv side will reap on EOF. */
    peer->writing_len = peer->writing_offset = 0;
    return;
  }
  /* In-flight buffer fully sent; reset for reuse. */
  peer->writing_len = peer->writing_offset = 0;

  /* Step 2: drain lanes in priority order until we run out of messages or
   * the socket goes EAGAIN. */
  for (int li = 0; li < LANE_COUNT; li++) {
    queue_lane_t *lane = &peer->out_lanes[li];
    while (lane->count > 0) {
      /* Bandwidth budget enforcement (Phase 5; defaults are generous). */
      time_t now = time(NULL);
      if (peer->bw_window_start != now) {
        peer->bw_window_start = now;
        peer->bw_bytes_in_window = 0;
      }
      if (li == LANE_BULK &&
          peer->bw_bytes_in_window > BULK_SOFT_BUDGET_BPS) {
        return;  /* defer remaining BULK to next second */
      }
      if (li == LANE_DELTA &&
          peer->bw_bytes_in_window > DELTA_HARD_BUDGET_BPS) {
        return;  /* extreme case — let coalescing catch up */
      }

      queued_msg_t *m = lane->head;
      if (!m) { lane->count = 0; break; }  /* count/head desync guard: never deref a NULL head */
      lane->head = m->next;
      if (!lane->head) lane->tail = NULL;
      lane->count--;
      lane->bytes        -= m->payload_len;
      peer->out_total_bytes -= m->payload_len;

      int wire_len = peer_encrypt_into_writing(peer, m);
      if (wire_len <= 0) {
        hub_log_error("[MESH] encrypt failed for peer %s lane %d\n", peer->ip, li);
        cfg_push_lost(peer, m);
        queued_msg_free(m);
        continue;  /* drop and move on */
      }
      g_hub_stats.tx_frames[m->cmd]++;
      g_hub_stats.tx_bytes[m->cmd] += (uint64_t)wire_len;
      if (m->cfg_frame) cfg_frame_written(peer);
      queued_msg_free(m);
      peer->writing_len    = wire_len;
      peer->writing_offset = 0;

      /* Try to send immediately. */
      while (peer->writing_offset < peer->writing_len) {
        int remain = peer->writing_len - peer->writing_offset;
        ssize_t s = send(peer->fd, peer->writing_buf + peer->writing_offset,
                         (size_t)remain, MSG_DONTWAIT | MSG_NOSIGNAL);
        if (s > 0) {
          peer->writing_offset    += (int)s;
          peer->bw_bytes_in_window += (int)s;
          peer->write_wait_since = now;
          continue;
        }
        if (s < 0 && (IO_WOULD_BLOCK(errno) || errno == EINTR))
          return;  /* socket buffer full — main loop will resume on POLLOUT */
        hub_log_warning("[MESH] send error to %s (fd=%d): %s\n", peer->ip, peer->fd,
                strerror(errno));
        peer->writing_len = peer->writing_offset = 0;
        return;
      }
      peer->writing_len = peer->writing_offset = 0;
    }
  }
}

/* Convenience: enqueue a small hub→hub URGENT message.  Returns true on
 * success; false if the peer's URGENT queue is full (caller should
 * disconnect that peer).  `payload` is the raw string after the cmd byte
 * (plain[5..]).  Uses host byte order for inner_len (hub receivers ignore
 * it; only bots use ntohl which is handled separately). */
static bool peer_send_urgent(hub_state_t *state, hub_client_t *peer,
                              uint8_t cmd, const char *payload) {
  (void)state;
  int plen = payload ? (int)strlen(payload) : 0;
  queued_msg_t *m = queued_msg_new(cmd, LANE_URGENT,
                                   (const unsigned char *)payload, plen);
  if (!m) return false;
  if (!peer_enqueue(peer, m)) {
    hub_log_warning("[URGENT] Queue full for peer %s — disconnecting\n", peer->ip);
    return false;  /* caller must hub_disconnect_client */
  }
  return true;
}

/* Every frame to a linked bot or peer after the handshake goes through its
 * queue.  A direct write() blocked the whole loop on a client that stopped
 * reading, and could land inside a part-sent queued frame (the receiver's
 * GCM check then failed and it dropped the link).  LANE_URGENT keeps the old
 * order -- ahead of queued deltas and bulk frames, behind the frame already
 * in flight -- and the drain right after sends it at once when the socket
 * has room.  false = not queued (no socket, URGENT full, no memory). */
bool hub_client_send(hub_state_t *state, hub_client_t *c, uint8_t cmd,
                     const char *payload) {
  if (!c || c->fd < 0 || c->internal) return false;
  if (!peer_send_urgent(state, c, cmd, payload)) return false;
  peer_drain_writable(state, c);
  return true;
}

/* Review 6: start the sequenced framing on a link that just authenticated
 * (a bot, or a peer whose uuid is `peer_uuid`): fix the direction bytes and
 * send "offer".  A 2.5.1 node ignores it and the link stays as it is. */
void hub_link_offer(hub_state_t *state, hub_client_t *c, const char *peer_uuid) {
  if (c->type == CLIENT_HUB) {
    bool lower = peer_uuid && strcmp(state->hub_uuid, peer_uuid) < 0;
    c->link_dir_tx = lower ? 'L' : 'G';
    c->link_dir_rx = lower ? 'G' : 'L';
  } else {
    c->link_dir_tx = 'H';
    c->link_dir_rx = 'B';
  }
  peer_send_urgent(state, c, CMD_LINK_SEQ, "offer");
}

/* Review 6: CMD_LINK_SEQ from the other end.  Its "offer" is answered with
 * our "go" (our frames after it are sequenced, see peer_encrypt_into_writing);
 * its "go" says every frame it sends after it is. */
static void link_seq_recv(hub_state_t *state, hub_client_t *c, const char *what) {
  if (strcmp(what, "offer") == 0 && !c->link_offered) {
    c->link_offered = true;
    if (!c->link_go_queued) {
      c->link_go_queued = true;
      peer_send_urgent(state, c, CMD_LINK_SEQ, "go");
    }
  } else if (strcmp(what, "go") == 0 && c->link_offered && !c->link_rx_seq) {
    c->link_rx_seq = true;
    c->link_rx_ctr = 0;
    hub_log_debug("[HUB] %s: sequenced link framing on\n", hub_who_client(state, c));
  }
}

uint64_t hub_next_lamport_seq(hub_state_t *state) {
  /* Bump-then-return so first issued seq is 1, not 0. */
  state->next_lamport_seq++;
  return state->next_lamport_seq;
}

/* ========================================================================== */


/* Read and process any immediately available data from connected peer sockets
 * for up to timeout_ms milliseconds. Used to collect fresh gossip before
 * building a peer-list response so the admin sees current mesh state. */

// --- Forward Declarations ---
static bool send_response(hub_state_t *state, hub_client_t *client,
                          const char *msg);
static bool send_pong(hub_state_t *state, hub_client_t *c);
static bool send_cmd_to_bot(hub_state_t *state, hub_client_t *bot, uint8_t cmd,
                            const char *payload);
static void process_mesh_state(hub_state_t *state, hub_client_t *c,
                               char *payload);
static void process_peer_sync(hub_state_t *state, char *payload, int origin_fd,
                              bool bcast);
/* payload is NUL-terminated for the text opcodes; payload_len is the byte
 * count the frame carried, for the binary ones (a log level of 0 or a log size
 * with a zero byte has strlen < its real length). */
static bool handle_admin_command(hub_state_t *state, hub_client_t *client,
                                 int cmd, char *payload, int payload_len);
static void process_bot_command(hub_state_t *state, hub_client_t *client,
                                int cmd, char *payload);

/* Network upgrade orchestration (definitions live next to
 * process_bot_command, after send_cmd_to_bot). */
static bool hub_upgrade_start(hub_state_t *state, hub_client_t *admin,
                              const char *target_ver, const char *variant,
                              const char *kind, const char *min_from,
                              const char *hub_ver, const char *sel,
                              char *msg, size_t msg_size);
static void hub_upgrade_status(hub_state_t *state, reply_t *r);
static const config_entry_t *bot_entry_rec(const bot_config_t *b, const char *key);
static bot_config_t *bot_by_uuid(hub_state_t *state, const char *uuid);
static const char *upgrade_node_state_name(upgrade_node_state_t s);
static const char *upgrade_phase_name(upgrade_phase_t p);
static const char *upgrade_node_variant(const pending_upgrade_t *u,
                                        const upgrade_node_t *n);
static bool upgrade_sel_lookup(const char *sel, const char *uuid, char *variant,
                               size_t variant_size);
static void hub_upgrade_releases(hub_state_t *state, const char *payload,
                                 reply_t *r);
enum { HUBS_MAX = MAX_MESH_HUBS + MAX_PEERS };
static int upgrade_hubs_missing(hub_state_t *state, char *names, size_t size);
static int hub_reached(hub_state_t *state, const char *reached[HUBS_MAX]);
static int rollcall_begin(hub_state_t *state, rollcall_purpose_t purpose, char *id_out);
static bool admin_upgrade_start(hub_state_t *state, hub_client_t *client, const char *payload,
                                bool roll_called);
static bool hub_upgrade_plan_begin(hub_state_t *state, hub_client_t *admin,
                                   const char *target_ver, const char *variant,
                                   const char *kind, const char *min_from,
                                   const char *hub_ver, const char *sel,
                                   char *msg, size_t msg_size);
static void plan_note_run_end(hub_state_t *state, upgrade_phase_t phase);
static void plan_stop(hub_state_t *state, const char *summary);
static int upgrade_cancel_flood(hub_state_t *state);
static int plan_steps(const upgrade_plan_t *pl);
static void plan_path_csv(const char *path, int n, char *out, size_t cap);
static void hub_upgrade_note_ready(hub_state_t *state, const char *payload,
                                   hub_client_t *from_peer);
static hub_client_t *upgrade_find_client(hub_state_t *state, const char *uuid,
                                         client_type_t type);
static hub_client_t *upgrade_find_peer(hub_state_t *state, const char *uuid);
static const char *upgrade_peer_uuid(const hub_state_t *state,
                                     const hub_client_t *c);
static void hub_upgrade_note_result(hub_state_t *state, const char *payload);
static void hub_upgrade_abort(hub_state_t *state, const char *reason);
static void hub_plan_process(hub_state_t *state, hub_client_t *peer, const char *payload);
static void hub_upgrade_note_progress(hub_state_t *state, const char *payload);
static void process_peer_upgrade_stage(hub_state_t *state, hub_client_t *peer, const char *payload);
static bool hub_rollup_note_progress(hub_state_t *state, const char *payload);
static void plan_publish(hub_state_t *state);
static void plan_continue(hub_state_t *state, bool by_admin);
static void plan_send_all(hub_state_t *state, const char *frame, const hub_client_t *skip);
static void hub_plan_send_digest(hub_state_t *state, hub_client_t *c);
static void hub_plan_single_start(hub_state_t *state);
static void hub_plan_single_end(hub_state_t *state);
static void hub_plan_cancelled(hub_state_t *state, time_t issued);
static void hub_upgrade_prepare_late(hub_state_t *state, hub_client_t *client,
                                     const char *version);
static void plan_hold(hub_state_t *state, const char *why, bool rerun, const char *uuid,
                      const char *ver);
static void process_peer_upgrade_prepare(hub_state_t *state,
                                         hub_client_t *peer,
                                         const char *payload);
static void process_peer_upgrade_commit(hub_state_t *state, hub_client_t *peer,
                                        const char *payload);
static void process_peer_upgrade_abort(hub_state_t *state, hub_client_t *peer,
                                       const char *payload);
static void hub_upgrade_note_presence(hub_state_t *state, const char *uuid,
                                      const char *version,
                                      const char *variant);
static void hub_rollup_note_presence(hub_state_t *state, const char *uuid,
                                     char node_kind, const char *version);
static bool hub_rollup_note_ready(hub_state_t *state, const char *payload);
static bool hub_rollup_note_result(hub_state_t *state, const char *payload);
static bool hub_upgrade_result_relay(hub_state_t *state, hub_client_t *from,
                                     const char *payload);
static bool hub_rollup_forget(hub_state_t *state, const char *why);
static bool ce_batch_join(hub_state_t *state, hub_client_t *client, const char *channel,
                          const char *nick, const char *hostmask, const char *rid);
static bool ce_batch_ok(hub_state_t *state);
static int ce_in_flight(const hub_state_t *state);
static chan_elect_t *ce_start(hub_state_t *state, const char *kind, const char *channel,
                              const char *requester, const char *nick, const char *hostmask,
                              const hub_client_t *admin);
static int broadcast_chan_action(hub_state_t *state, const char *request_id,
                                 const char *requester_uuid, const char *kind,
                                 const char *channel, const char *nick,
                                 const char *hostmask);
static void forward_chan_request_to_peers(hub_state_t *state,
                                          const char *request_id,
                                          const char *requester_uuid,
                                          const char *kind, const char *channel,
                                          const char *nick,
                                          const char *hostmask, int exclude_fd);
static void hub_request_sync_from_peers(hub_state_t *state);
static void process_peer_upgrade_forget(hub_state_t *state, hub_client_t *peer,
                                        const char *payload);
static bool hub_config_frozen(const hub_state_t *state);
static bool hub_admin_cmd_mutates_config(int cmd);

// OP Request Forwarding Forward Decls
static void generate_request_id(char *out_id, size_t len);
static int add_pending_op_request(hub_state_t *state, const char *request_id,
                                   const char *requester_uuid,
                                   const char *target_uuid,
                                   const char *channel, int origin_fd);
static pending_op_request_t *find_pending_op_request(hub_state_t *state,
                                                      const char *request_id);
static void remove_pending_op_request(hub_state_t *state,
                                       const char *request_id);
static bool op_forward_seen_check_and_add(hub_state_t *state,
                                           const char *request_id);
/* The peer link to the hub the roster places bot `target_uuid` on, or NULL
 * (flood) when it is on no direct peer, on more than one hub (mid-move), or
 * unknown.  Never the peer on `exclude_fd`: that is where it came from. */
static hub_client_t *op_route_peer(hub_state_t *state, const char *target_uuid,
                                   int exclude_fd) {
  const char *home = NULL;
  for (int r = 0; r < state->roster_count; r++) {
    if (strcmp(state->roster[r].bot_uuid, target_uuid) != 0) continue;
    if (home && strcmp(home, state->roster[r].hub_uuid) != 0) return NULL;
    home = state->roster[r].hub_uuid;
  }
  if (!home) return NULL;
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type == CLIENT_HUB && c->authenticated && c->fd != exclude_fd &&
        strcmp(upgrade_peer_uuid(state, c), home) == 0)
      return c;
  }
  return NULL;
}

static void forward_op_request_to_peers(hub_state_t *state,
                                         const char *request_id,
                                         const char *requester_uuid,
                                         const char *target_uuid,
                                         const char *channel,
                                         const char *requester_hostmask,
                                         int exclude_fd,
                                         time_t origin_ts, bool split);
static void process_forward_op_request(hub_state_t *state,
                                        hub_client_t *client, char *payload);
static void process_forward_op_grant(hub_state_t *state, hub_client_t *client,
                                      char *payload);
static void process_forward_op_failed(hub_state_t *state, hub_client_t *client,
                                       char *payload);

// --- Helper Functions ---

/* PURGE deduplication.  A purge is known by its cutoff plus the random id its
 * origin hub gave it.  Keyed on the cutoff alone, every "immediate" purge
 * (cutoff 0) looked like the previous one for PURGE_DEDUP_WINDOW seconds, and
 * peers skipped a second purge sent inside that window. */
static bool is_purge_recent(hub_state_t *state, time_t cutoff, const char *id) {
  time_t now = time(NULL);
  for (int i = 0; i < state->recent_purge_count; i++) {
    if (state->recent_purges[i].cutoff == cutoff &&
        strcmp(state->recent_purges[i].id, id) == 0 &&
        now - state->recent_purges[i].received_at < PURGE_DEDUP_WINDOW)
      return true;
  }
  return false;
}

// Record a recently processed PURGE
static void record_recent_purge(hub_state_t *state, time_t cutoff, const char *id) {
  time_t now = time(NULL);
  int slot = -1;

  for (int i = 0; i < state->recent_purge_count; i++) {
    if (state->recent_purges[i].cutoff == cutoff &&
        strcmp(state->recent_purges[i].id, id) == 0) {
      slot = i;
      break;
    }
  }
  if (slot < 0 && state->recent_purge_count < MAX_RECENT_PURGES)
    slot = state->recent_purge_count++;
  if (slot < 0) {
    // Full: overwrite the oldest entry (slot 0 used to be overwritten always)
    slot = 0;
    for (int i = 1; i < state->recent_purge_count; i++)
      if (state->recent_purges[i].received_at <
          state->recent_purges[slot].received_at)
        slot = i;
  }
  state->recent_purges[slot].cutoff = cutoff;
  snprintf(state->recent_purges[slot].id, sizeof(state->recent_purges[slot].id),
           "%s", id);
  state->recent_purges[slot].received_at = now;
}

/* "PURGE|<cutoff>" or "PURGE|<cutoff>|<id>", id 1..PURGE_ID_HEX hex digits.
 * False on anything else (the line is dropped, not forwarded). */
static bool parse_purge_line(const char *line, time_t *cutoff,
                             char id[PURGE_ID_HEX + 1]) {
  const char *p = line + 6; /* past "PURGE|" */
  char *end = NULL;
  if (*p < '0' || *p > '9')
    return false;
  errno = 0;
  long long v = strtoll(p, &end, 10);
  if (errno || v < 0)
    return false;
  id[0] = '\0';
  if (*end == '|') {
    const char *h = end + 1;
    size_t n = strspn(h, "0123456789abcdefABCDEF");
    if (n == 0 || n > PURGE_ID_HEX || h[n] != '\0')
      return false;
    memcpy(id, h, n);
    id[n] = '\0';
  } else if (*end != '\0') {
    return false;
  }
  *cutoff = (time_t)v;
  return true;
}

bool hub_broadcast_purge(hub_state_t *state, time_t cutoff) {
  unsigned char rnd[PURGE_ID_HEX / 2];
  char id[PURGE_ID_HEX + 1];
  if (RAND_bytes(rnd, sizeof(rnd)) != 1) {
    hub_log_error("[PURGE] no random bytes for a purge id; purge not broadcast\n");
    return false;
  }
  for (size_t i = 0; i < sizeof(rnd); i++)
    snprintf(id + 2 * i, 3, "%02x", rnd[i]);
  /* Seen here too: the copies peers forward back are not run again. */
  record_recent_purge(state, cutoff, id);

  char msg[64];
  snprintf(msg, sizeof(msg), "PURGE|%lld|%s\n", (long long)cutoff, id);
  hub_broadcast_sync_to_peers(state, msg, -1);
  return true;
}

// Check if this hub should initiate scheduled purges (leader election)
// Strategy: The hub with the lexicographically smallest UUID leads
bool hub_should_initiate_scheduled_purge(hub_state_t *state) {
  for (int i = 0; i < state->client_count; i++) {
    if (state->clients[i]->type == CLIENT_HUB && state->clients[i]->authenticated) {
      // If any peer has a UUID less than ours, they should lead
      if (strcmp(state->clients[i]->id, state->hub_uuid) < 0) {
        return false;
      }
    }
  }
  // Either no peers, or we have the smallest UUID
  return true;
}

// ============ RATE LIMITING FUNCTIONS ============

/* The slot an address would take in the rate-limit table: its own entry,
 * a free one, or the entry idle longest (no connection open, not blocked).
 * -1 when every entry is open or blocked.  *fresh: the slot is not yet
 * this address's. */
static int ip_limit_slot(const hub_state_t *state, const char *ip, time_t now, bool *fresh) {
    *fresh = false;
    for (int i = 0; i < state->ip_limits_count; i++) {
        if (strcmp(state->ip_limits[i].ip, ip) == 0) {
            return i;
        }
    }

    *fresh = true;
    if (state->ip_limits_count < MAX_IP_RATE_LIMITS) return state->ip_limits_count;
    /* Full: reuse the entry idle longest.  Without this, MAX_IP_RATE_LIMITS
     * addresses inside the hourly prune left every new one untracked. */
    int slot = -1;
    time_t oldest = 0;
    for (int i = 0; i < state->ip_limits_count; i++) {
        const ip_rate_limit_t *e = &state->ip_limits[i];
        if (e->active_connections > 0 || (e->blocked_until > 0 && now < e->blocked_until))
            continue;
        time_t last = e->first_seen;
        if (e->last_failed_auth > last) last = e->last_failed_auth;
        if (e->churn_window_start > last) last = e->churn_window_start;
        if (slot < 0 || last < oldest) { slot = i; oldest = last; }
    }
    return slot;
}

static ip_rate_limit_t* find_or_create_ip_limit(hub_state_t *state, const char *ip) {
    time_t now = time(NULL);
    bool fresh;
    int slot = ip_limit_slot(state, ip, now, &fresh);
    if (slot < 0) return NULL;  /* every entry open or blocked */
    ip_rate_limit_t *entry = &state->ip_limits[slot];
    if (!fresh) return entry;
    if (slot == state->ip_limits_count) state->ip_limits_count++;
    memset(entry, 0, sizeof(*entry));
    snprintf(entry->ip, sizeof(entry->ip), "%s", ip);
    entry->first_seen = now;
    entry->churn_window_start = now;
    return entry;
}

/* 13b: a bot or peer authenticated from `ip`. */
void hub_known_ip_note(hub_state_t *state, const char *ip) {
    if (!ip || !*ip) return;
    time_t now = time(NULL);
    int slot = -1;
    for (int i = 0; i < state->known_ip_count; i++) {
        if (strcmp(state->known_ips[i].ip, ip) == 0) { slot = i; break; }
        if (slot < 0 || state->known_ips[i].last_ok < state->known_ips[slot].last_ok) slot = i;
    }
    if (slot < 0 || (state->known_ip_count < MAX_KNOWN_IPS &&
                     strcmp(state->known_ips[slot].ip, ip) != 0))
        slot = state->known_ip_count++;
    snprintf(state->known_ips[slot].ip, sizeof(state->known_ips[slot].ip), "%s", ip);
    state->known_ips[slot].last_ok = now;
}

/* An address this hub has reason to trust: a configured peer, a bot in the
 * roster (any hub's), a bot or peer that authenticated here lately, or a
 * console login within SSH_SUCCESS_MEMORY. */
static bool ip_known(const hub_state_t *state, const char *ip, time_t now) {
    for (int i = 0; i < state->peer_count; i++)
        if (strcmp(state->peers[i].ip, ip) == 0 || strcmp(state->peers[i].remote_ip, ip) == 0)
            return true;
    for (int i = 0; i < state->known_ip_count; i++)
        if (strcmp(state->known_ips[i].ip, ip) == 0)
            return now - state->known_ips[i].last_ok < KNOWN_IP_MEMORY;
    for (int i = 0; i < state->roster_count; i++)
        if (strcmp(state->roster[i].ip, ip) == 0) return true;
    return hub_ssh_table_recent_ok(state->ssh_ips, state->ssh_ip_count, ip, now);
}

static void startup_refused(hub_state_t *state, time_t now, const char *ip, const char *why) {
    if (now - state->startup_logged >= STARTUP_LOG_EVERY) {
        if (state->startup_unlogged > 0)
            hub_log_warning("[RATE_LIMIT] Connection from %s refused (%s); %d more refused "
                            "in the last %ds\n", ip, why, state->startup_unlogged,
                            (int)(now - state->startup_logged));
        else
            hub_log_warning("[RATE_LIMIT] Connection from %s refused (%s)\n", ip, why);
        state->startup_logged = now;
        state->startup_unlogged = 0;
    } else {
        state->startup_unlogged++;
    }
}

/* 13b: the gate before is_ip_allowed.  Known addresses always pass; an
 * unknown one is refused while the rate-limit table has no room for it
 * (rather than let through untracked), and otherwise goes through a random
 * early drop on the connections not yet authenticated (hub set conn
 * startups), so a flood of stalled handshakes cannot hold every slot. */
bool hub_startup_admit(hub_state_t *state, const char *ip) {
    if (state->trust_loopback &&
        (strcmp(ip, "127.0.0.1") == 0 || strcmp(ip, "::1") == 0)) return true;
    time_t now = time(NULL);
    if (ip_known(state, ip, now)) return true;

    bool fresh;
    if (ip_limit_slot(state, ip, now, &fresh) < 0) {
        startup_refused(state, now, ip, "unknown address, rate-limit table full");
        return false;
    }

    int open = 0;
    for (int i = 0; i < state->client_count; i++) {
        const hub_client_t *c = state->clients[i];
        if (c->inbound && !c->authenticated) open++;
    }
    const hub_conn_cfg_t *cc = &state->conn_cfg;
    int start = cc->startups_start;
    int full = cc->startups_full > start ? cc->startups_full : start;
    if (open < start) return true;
    bool drop = true;
    if (open < full) {
        int p = cc->startups_rate + (100 - cc->startups_rate) * (open - start) / (full - start);
        uint32_t r;
        if (RAND_bytes((unsigned char *)&r, sizeof(r)) == 1) drop = (int)(r % 100) < p;
    }
    if (drop) {
        char why[96];
        snprintf(why, sizeof(why), "unknown address, %d connections not yet authenticated", open);
        startup_refused(state, now, ip, why);
    }
    return !drop;
}

/* D2: allocate a client's recv/writing buffers. recv_buf is `size`; writing_buf
 * is `size + 64` to hold the 4-byte length prefix + GCM tag overhead. */
bool hub_client_alloc_buffers(hub_client_t *c, int size) {
    if (!c || size <= 0) return false;
    c->recv_buf    = malloc((size_t)size);
    c->writing_buf = malloc((size_t)size + 64);
    if (!c->recv_buf || !c->writing_buf) {
        free(c->recv_buf);    c->recv_buf = NULL;
        free(c->writing_buf); c->writing_buf = NULL;
        return false;
    }
    c->recv_cap    = size;
    c->writing_cap = size + 64;
    return true;
}

/* D2: grow a client's buffers on successful auth. Idempotent. realloc preserves
 * any already-buffered bytes (e.g. data pipelined behind the final handshake
 * frame). On OOM the existing buffers are left intact and the caller should
 * disconnect.
 *
 * Change 5: size by client type so bulk lanes never truncate.  Peers exchange
 * full-state anti-entropy sync both directions (MAX_SYNC_PAYLOAD); a bot
 * receives its full config on the hub->bot (writing) side (MAX_CONFIG_PAYLOAD)
 * but only ever pushes small config/deltas up (recv stays MAX_BUFFER).  Must be
 * called after c->type is set. */
bool hub_client_promote_buffers(hub_client_t *c) {
    if (!c) return false;

    int recv_target, write_target;
    if (c->type == CLIENT_HUB) {
        recv_target  = MAX_SYNC_PAYLOAD;
        write_target = MAX_SYNC_PAYLOAD;
    } else if (c->type == CLIENT_BOT) {
        recv_target  = MAX_BUFFER;          /* bot->hub pushes are small */
        write_target = MAX_CONFIG_PAYLOAD;  /* hub->bot full config */
    } else {
        recv_target  = MAX_BUFFER;          /* admin */
        write_target = MAX_BUFFER;
    }

    if (c->recv_cap < recv_target) {
        unsigned char *nr = realloc(c->recv_buf, (size_t)recv_target);
        if (!nr) return false;
        c->recv_buf = nr;
        c->recv_cap = recv_target;
    }
    if (c->writing_cap < write_target + 64) {
        unsigned char *nw = realloc(c->writing_buf, (size_t)write_target + 64);
        if (!nw) return false;  /* recv already grown; caller drops on failure */
        c->writing_buf = nw;
        c->writing_cap = write_target + 64;
    }
    return true;
}

bool is_ip_allowed(hub_state_t *state, const char *ip) {
    /* D3: loopback is exempt only when explicitly trusted. Default is to treat
     * 127.0.0.1/::1 like any other IP, so a local/SSRF/co-tenant source cannot
     * bypass per-IP limits. */
    if (state->trust_loopback &&
        (strcmp(ip, "127.0.0.1") == 0 || strcmp(ip, "::1") == 0)) return true;

    ip_rate_limit_t *entry = find_or_create_ip_limit(state, ip);
    if (!entry) return true;  /* untracked: only a known address gets here (13b) */

    time_t now = time(NULL);

    // Check if temporarily blocked
    if (entry->blocked_until > 0 && now < entry->blocked_until) {
        hub_log_warning("[RATE_LIMIT] IP %s is blocked until %ld\n",
                ip, (long)entry->blocked_until);
        return false;
    }

    // Reset block if expired
    if (entry->blocked_until > 0 && now >= entry->blocked_until) {
        entry->blocked_until = 0;
        entry->failed_auth_count = 0;
    }

    /* D1: churn-based throttle. is_ip_allowed() is the single per-accept gate,
     * so each call is exactly one new connection attempt. Count attempts in a
     * sliding window; a connect/close flood trips a temporary block here even
     * though it never exceeds the concurrency limit or fails auth. */
    const hub_conn_cfg_t *cc = &state->conn_cfg;   /* hub set conn */
    /* An address with a console login in the last 24 h is not held to the churn
     * limit (a tightened limit must not lock its admin out); the block above
     * (authfail, or a churn block from before) still applies. */
    if (hub_ssh_table_recent_ok(state->ssh_ips, state->ssh_ip_count, ip, now))
        return entry->active_connections < cc->perip;
    if (now - entry->churn_window_start >= cc->churn_s) {
        entry->churn_window_start = now;
        entry->churn_count = 0;
    }
    entry->churn_count++;
    if (entry->churn_count > cc->churn_n) {
        entry->blocked_until = now + cc->churn_block;
        hub_log_warning("[RATE_LIMIT] IP %s connection churn flood (%d conns/%ds) — "
                "blocked %ds\n", ip, entry->churn_count, cc->churn_s,
                cc->churn_block);
        return false;
    }

    // Check connection limit
    if (entry->active_connections >= cc->perip) {
        hub_log_warning("[RATE_LIMIT] IP %s exceeded connection limit (%d/%d)\n",
                ip, entry->active_connections, cc->perip);
        return false;
    }

    return true;
}

void increment_active_connections(hub_state_t *state, const char *ip) {
    ip_rate_limit_t *entry = find_or_create_ip_limit(state, ip);
    if (entry) {
        entry->active_connections++;
    }
}

void decrement_active_connections(hub_state_t *state, const char *ip) {
    for (int i = 0; i < state->ip_limits_count; i++) {
        if (strcmp(state->ip_limits[i].ip, ip) == 0) {
            if (state->ip_limits[i].active_connections > 0) {
                state->ip_limits[i].active_connections--;
            }
            break;
        }
    }
}

static void record_failed_auth(hub_state_t *state, const char *ip) {
    /* D3: only skip failed-auth tracking for loopback when it is trusted. */
    if (state->trust_loopback &&
        (strcmp(ip, "127.0.0.1") == 0 || strcmp(ip, "::1") == 0)) return;
    ip_rate_limit_t *entry = find_or_create_ip_limit(state, ip);
    if (!entry) return;

    time_t now = time(NULL);

    const hub_conn_cfg_t *cc = &state->conn_cfg;   /* hub set conn */
    // Reset counter if last failure was over the window ago
    if (now - entry->last_failed_auth > cc->fail_s) {
        entry->failed_auth_count = 0;
    }

    entry->failed_auth_count++;
    entry->last_failed_auth = now;

    hub_log_warning("[AUTH_FAIL] IP %s failed auth (attempt %d/%d)\n",
            ip, entry->failed_auth_count, cc->fail_n);

    // Block if exceeded max attempts
    if (entry->failed_auth_count >= cc->fail_n) {
        entry->blocked_until = now + cc->fail_block;
        hub_log_warning("[AUTH_BLOCK] IP %s blocked for %d seconds (too many failed attempts)\n",
                ip, cc->fail_block);
    }
}

void cleanup_old_ip_limits(hub_state_t *state) {
    time_t now = time(NULL);
    int i = 0;

    while (i < state->ip_limits_count) {
        ip_rate_limit_t *entry = &state->ip_limits[i];

        // Remove if no active connections and not blocked and old (1 hour+)
        if (entry->active_connections == 0 &&
            entry->blocked_until == 0 &&
            now - entry->first_seen > 3600) {

            // Swap with last and decrement count
            state->ip_limits[i] = state->ip_limits[--state->ip_limits_count];
            continue;  // Don't increment i, check swapped entry
        }
        i++;
    }
}

// ============ IP ACCESS CONTROL FUNCTIONS ============

bool hub_name_valid(const char *name) {
  if (!name) return false;
  size_t n = strnlen(name, 64);
  if (n == 0 || n > 63) return false;
  for (size_t i = 0; i < n; i++) {
    unsigned char ch = (unsigned char)name[i];
    if (!((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z') ||
          (ch >= '0' && ch <= '9') || ch == '.' || ch == '_' || ch == '-'))
      return false;
  }
  return true;
}

bool hub_parse_uint(const char *s, unsigned long max, unsigned long *out) {
    if (!s || !out) return false;
    size_t n = strnlen(s, 11);
    if (n == 0 || n > 10) return false;
    unsigned long v = 0;
    for (size_t i = 0; i < n; i++) {
        if (s[i] < '0' || s[i] > '9') return false;
        unsigned long d = (unsigned long)(s[i] - '0');
        if (v > (max - d) / 10) return false;  /* v*10 + d would pass max */
        v = v * 10 + d;
    }
    *out = v;
    return true;
}

bool hub_ip_acl_parse(const char *in, hub_ip_acl_t *out) {
    if (!in || !out) return false;
    size_t n = strnlen(in, IP_ACL_PATTERN_MAX);
    if (n == 0 || n >= IP_ACL_PATTERN_MAX) return false;

    char addr[IP_ACL_PATTERN_MAX];
    memcpy(addr, in, n + 1);
    int prefix = 32;
    char *slash = strchr(addr, '/');
    if (slash) {
        /* 1-2 decimal digits, no sign/space/leading zero: atoi() used to turn
         * "10.0.0.0/" or "/x" into prefix 0, which matches every address. */
        const char *p = slash + 1;
        size_t plen = strlen(p);
        bool d0 = plen >= 1 && p[0] >= '0' && p[0] <= '9';
        bool d1 = plen == 2 && p[1] >= '0' && p[1] <= '9';
        if (!d0 || plen > 2 || (plen == 2 && (!d1 || p[0] == '0')))
            return false;
        prefix = plen == 2 ? (p[0] - '0') * 10 + (p[1] - '0') : p[0] - '0';
        if (prefix > 32) return false;
        *slash = '\0';
    }

    struct in_addr a;  /* strict dotted quad: no short forms, octal or spaces */
    if (inet_pton(AF_INET, addr, &a) != 1) return false;

    uint32_t mask = prefix ? 0xFFFFFFFFu << (32 - prefix) : 0;
    out->net = ntohl(a.s_addr) & mask;
    out->mask = mask;
    out->added = 0;
    out->console = false;

    char buf[INET_ADDRSTRLEN];
    struct in_addr na = { .s_addr = htonl(out->net) };
    if (!inet_ntop(AF_INET, &na, buf, sizeof(buf))) return false;
    int w = prefix == 32
          ? snprintf(out->pattern, sizeof(out->pattern), "%s", buf)
          : snprintf(out->pattern, sizeof(out->pattern), "%s/%d", buf, prefix);
    return w > 0 && w < (int)sizeof(out->pattern);
}

/* Entries of one scope: console (D27, applies once the first bytes say SSH)
 * or not (every inbound connection).  The two scopes never mix: an allowlist
 * with only console entries leaves bots and peers unrestricted. */
static bool ip_acl_match(const hub_ip_acl_t *list, int count, uint32_t addr, bool console) {
    for (int i = 0; i < count; i++)
        if (list[i].console == console && (addr & list[i].mask) == list[i].net) return true;
    return false;
}

static int ip_acl_scope_count(const hub_ip_acl_t *list, int count, bool console) {
    int n = 0;
    for (int i = 0; i < count; i++)
        if (list[i].console == console) n++;
    return n;
}

/* 0 = permitted, 1 = on the denylist, 2 = not on a non-empty allowlist. */
static int ip_acl_verdict(const hub_state_t *state, const char *ip, bool console) {
    struct in_addr a;
    bool parsed = ip && inet_pton(AF_INET, ip, &a) == 1;
    uint32_t addr = parsed ? ntohl(a.s_addr) : 0;

    if (ip_acl_scope_count(state->ip_deny, state->ip_deny_count, console) > 0 &&
        (!parsed || ip_acl_match(state->ip_deny, state->ip_deny_count, addr, console)))
        return 1;
    if (ip_acl_scope_count(state->ip_allow, state->ip_allow_count, console) > 0 &&
        (!parsed || !ip_acl_match(state->ip_allow, state->ip_allow_count, addr, console)))
        return 2;
    return 0;
}

bool hub_ip_acl_permits(const hub_state_t *state, const char *ip) {
    return ip_acl_verdict(state, ip, false) == 0;
}

bool hub_ip_acl_permits_console(const hub_state_t *state, const char *ip) {
    return ip_acl_verdict(state, ip, true) == 0;
}

bool check_ip_access_lists(hub_state_t *state, const char *ip) {
    int verdict = ip_acl_verdict(state, ip, false);
    if (verdict == 0) return true;
    hub_log_warning("[ACCESS_CONTROL] IP %s denied (%s)\n", ip,
            verdict == 1 ? "denylist" : "not in allowlist");
    return false;
}

static hub_ip_acl_t *ip_acl_list(hub_state_t *state, char list, int **count) {
    if (list == 'w') { *count = &state->ip_allow_count; return state->ip_allow; }
    if (list == 'x') { *count = &state->ip_deny_count;  return state->ip_deny; }
    return NULL;
}

static int ip_acl_find(const hub_ip_acl_t *list, int count, const hub_ip_acl_t *e) {
    for (int i = 0; i < count; i++)
        if (list[i].net == e->net && list[i].mask == e->mask &&
            list[i].console == e->console) return i;
    return -1;
}

ip_acl_add_t hub_ip_acl_add(hub_state_t *state, char list, const hub_ip_acl_t *e) {
    int *count;
    hub_ip_acl_t *l = ip_acl_list(state, list, &count);
    if (!l) return IP_ACL_BAD_LIST;
    if (ip_acl_find(l, *count, e) >= 0) return IP_ACL_DUPLICATE;
    if (*count >= MAX_IP_ACL_ENTRIES) return IP_ACL_FULL;
    l[(*count)++] = *e;
    return IP_ACL_ADDED;
}

bool hub_ip_acl_remove(hub_state_t *state, char list, const hub_ip_acl_t *e) {
    int *count;
    hub_ip_acl_t *l = ip_acl_list(state, list, &count);
    if (!l) return false;
    int i = ip_acl_find(l, *count, e);
    if (i < 0) return false;
    memmove(&l[i], &l[i + 1], sizeof(*l) * (size_t)(*count - i - 1));
    (*count)--;
    memset(&l[*count], 0, sizeof(*l));
    return true;
}

// Load bot's combined 64-byte public key from hub config
static bool load_bot_combined_pub(hub_state_t *state, const char *uuid,
                                  unsigned char out[64]) {
  for (int i = 0; i < state->bot_count; i++) {
    if (strcmp(state->bots[i].uuid, uuid) != 0) continue;
    for (int j = 0; j < state->bots[i].entry_count; j++) {
      if (strcmp(state->bots[i].entries[j].key, "pub") != 0) continue;
      int dec_len = 0;
      unsigned char *dec = base64_decode(state->bots[i].entries[j].value, &dec_len);
      if (!dec) return false;
      if (dec_len != 64) { secure_wipe(dec, (size_t)dec_len); free(dec); return false; }
      memcpy(out, dec, 64);
      secure_wipe(dec, 64);
      free(dec);
      return true;
    }
  }
  return false;
}

/* The key a revoked bot must prove (hub_revoke.c). */
static bool load_revoked_pub(hub_state_t *state, const char *uuid, unsigned char out[64]) {
  const hub_revoked_t *r = hub_revoke_find(state, uuid);
  if (!r) return false;
  int n = 0;
  unsigned char *d = base64_decode(r->pub, &n);
  bool ok = d && n == 64;
  if (ok) memcpy(out, d, 64);
  if (d) { secure_wipe(d, (size_t)(n > 0 ? n : 0)); free(d); }
  return ok;
}

/* A revoked bot's CMD_BOT_RETIRE_ACK (quarantine or in session): stamp it
 * wiped and tell the mesh.  The caller closes the connection. */
static void retire_ack_apply(hub_state_t *state, hub_client_t *client, const char *payload) {
  bool wiped = payload && payload[0] == '1';
  char line[RV_LINE_MAX];
  if (hub_revoke_mark_wiped(state, client->id, time(NULL), line, sizeof(line)))
    hub_broadcast_sync_to_peers(state, line, -1);
  if (wiped)
    hub_log_info("[REVOKE] Revoked %s wiped its config and is exiting\n",
                 hub_who_client(state, client));
  else
    hub_log_warning("[REVOKE] Revoked %s could not wipe its config; it exits, and "
                    "is told again if it ever connects\n", hub_who_client(state, client));
}

/* bot del, here or on another hub: every connected bot this hub holds that is
 * on the revoke list is told CMD_BOT_RETIRE.  hub_main closes the ones that
 * never answer after RETIRE_GRACE_SEC.  Returns how many were told. */
int hub_retire_revoked_bots(hub_state_t *state) {
  int n = 0;
  time_t now = time(NULL);
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type != CLIENT_BOT || !c->authenticated || c->retiring ||
        !hub_revoke_find(state, c->id))
      continue;
    queued_msg_t *m = queued_msg_new(CMD_BOT_RETIRE, LANE_URGENT, NULL, 0);
    if (!m || !peer_enqueue(c, m)) {
      hub_log_warning("[REVOKE] Could not queue CMD_BOT_RETIRE for %s\n", hub_who_client(state, c));
      continue;
    }
    c->retiring = true;
    c->retire_sent = now;
    hub_log_info("[REVOKE] Deleted %s is connected here: told to wipe its config\n",
                 hub_who_client(state, c));
    n++;
  }
  /* Its row in the tree goes now, on every hub, rather than when the gossip
   * TTL runs out: roster_upsert refuses to bring it back. */
  for (int i = 0; i < state->roster_count;) {
    if (hub_revoke_find(state, state->roster[i].bot_uuid)) {
      state->roster[i] = state->roster[--state->roster_count];
      state->tree_dirty = true;
      continue;
    }
    i++;
  }
  return n;
}


/* Review 7b: true when a HUBv3 hello with this ephemeral key was accepted in
 * the last HELLO_SEEN_SECS -- a replay, which would otherwise take over the
 * live link -- else it is remembered.  Only verified, fresh hellos get here,
 * so the ring holds real peers' hellos only. */
static bool hello_replayed(hub_state_t *state, const unsigned char eph[32]) {
  time_t now = time(NULL);
  for (int i = 0; i < HELLO_SEEN_MAX; i++)
    if (state->hello_seen_at[i] && now - state->hello_seen_at[i] <= HELLO_SEEN_SECS &&
        CRYPTO_memcmp(state->hello_seen[i], eph, 32) == 0)
      return true;
  memcpy(state->hello_seen[state->hello_seen_next], eph, 32);
  state->hello_seen_at[state->hello_seen_next] = now;
  state->hello_seen_next = (state->hello_seen_next + 1) % HELLO_SEEN_MAX;
  return false;
}

/* Review 7a: peer `p` already has a live link when `newc`, a link it dialled,
 * authenticates.  Both dialled by it: the new one is a reconnect and replaces
 * the old.  One dialled each way (both hubs dialled at once): the link the
 * lower uuid dialled stays, so the two hubs keep the same one without
 * talking.  True when `newc` stays; the old link is then shut down and
 * reaped on its EOF, as in supersede_bot_sessions. */
static bool peer_link_tie(hub_state_t *state, int p, hub_client_t *newc) {
  const hub_peer_config_t *peer = &state->peers[p];
  hub_client_t *old = NULL;
  for (int i = 0; peer->connected && i < state->client_count && !old; i++) {
    hub_client_t *c = state->clients[i];
    if (c != newc && c->type == CLIENT_HUB && c->fd >= 0 && c->fd == peer->fd)
      old = c;
  }
  if (!old) return true;
  bool keep_new = old->inbound || strcmp(peer->uuid, state->hub_uuid) < 0;
  if (keep_new) {
    hub_log_info("[MESH] %s: a second link (old one from %s) — keeping the new one\n",
                 hub_who(state, 'h', peer->uuid), old->ip);
    old->superseded = true;
    shutdown(old->fd, SHUT_RDWR);
  } else {
    hub_log_info("[MESH] %s dialled while our link to it is up — ours stays (the "
                 "lower uuid's link wins)\n", hub_who(state, 'h', peer->uuid));
  }
  return keep_new;
}

/* L6: one live session per bot.  An older one for the same uuid (a reconnect
 * before its dead socket timed out, or a second process with the same key)
 * is shut down now and reaped by the main loop on its EOF; the bot lookups
 * skip it meanwhile.  Repeats are counted per hour across sessions. */
static void supersede_bot_sessions(hub_state_t *state, hub_client_t *client) {
  time_t now = time(NULL);
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *o = state->clients[i];
    if (o == client || o->type != CLIENT_BOT || !o->authenticated || o->superseded ||
        strcmp(o->id, client->id) != 0)
      continue;
    o->superseded = true;
    if (o->fd >= 0) shutdown(o->fd, SHUT_RDWR);
    bool same_hour = now - o->replace_window < 3600;
    client->replace_window = same_hour ? o->replace_window : now;
    client->replace_count = (same_hour ? o->replace_count : 0) + 1;
    if (client->replace_count > BOT_REPLACE_WARN_PER_HOUR)
      hub_log_warning("[HUB] %s replaced its own live session again (%d times in the "
                      "last hour): two processes with one key, or a stolen key\n",
                      hub_who_client(state, client), client->replace_count);
    else
      hub_log_info("[HUB] %s logged in while its old session (%s) was live: the old one "
                   "is closed\n", hub_who_client(state, client), o->ip);
  }
}

bool handle_bot_authentication(hub_state_t *state, hub_client_t *client,
                               unsigned char *data, int packet_len) {

  /* QUARANTINE: a revoked bot was sent CMD_BOT_RETIRE as its ACK; the only
   * frame it may send is CMD_BOT_RETIRE_ACK.  Either way it is closed (false)
   * — never as a failed login. */
  if (client->bot_auth_state == BOT_AUTH_QUARANTINE) {
    unsigned char plain[64], tag[GCM_TAG_LEN];
    int pl = -1;
    if (packet_len > GCM_IV_LEN + GCM_TAG_LEN && packet_len <= (int)sizeof(plain)) {
      memcpy(tag, data + packet_len - GCM_TAG_LEN, GCM_TAG_LEN);
      pl = aes_gcm_decrypt(data, packet_len - GCM_TAG_LEN, client->session_key, plain, tag);
    }
    if (pl >= 5 && plain[0] == CMD_BOT_RETIRE_ACK) {
      char st[2] = {pl > 5 ? (char)plain[5] : '0', '\0'};
      retire_ack_apply(state, client, st);
    } else {
      hub_log_info("[REVOKE] Revoked %s did not answer the wipe (an older build?); "
                   "closed\n", hub_who_client(state, client));
    }
    secure_wipe(plain, sizeof(plain));
    secure_wipe(client->session_key, sizeof(client->session_key));
    return false;
  }

  // PHASE 1: Receive UUID (plaintext)
  if (!client->authenticated && client->bot_auth_state == BOT_AUTH_IDLE) {
    if (packet_len < 1 || packet_len > 63) return false;
    char uuid[64];
    memcpy(uuid, data, (size_t)packet_len);
    uuid[packet_len] = '\0';

    /* The claimed UUID is raw pre-authentication input: logged as the bytes
     * that arrived (the log sanitizer escapes them), never through hub_who,
     * which would flatten control bytes the sanitizer exists to show. */
    hub_log_debug("[HUB] Bot auth attempt from %s with UUID: %s\n", client->ip, uuid);

    /* A revoked bot goes through the whole handshake (it must prove its
     * key) and is then told to wipe itself: never a failed login, so a host
     * that brings an old bot back is not blocked for its other bots. */
    client->quarantine = hub_revoke_find(state, uuid) != NULL;
    bool authorized = client->quarantine;
    for (int i = 0; i < state->bot_count && !authorized; i++) {
      if (strcmp(state->bots[i].uuid, uuid) == 0 &&
          state->bots[i].is_active) { authorized = true; break; }
    }

    if (!authorized) {
      hub_log_warning("[HUB] Unauthorized bot UUID: %s from %s\n", uuid, client->ip);
      record_failed_auth(state, client->ip);
      return false;
    }
    if (client->quarantine)
      hub_log_info("[REVOKE] Revoked %s connecting from %s: checking its key\n",
                   hub_who(state, 'b', uuid), client->ip);

    // Generate challenge + ephemeral X25519 keypair
    if (RAND_bytes(client->challenge, 32) != 1) {
      hub_log_error("[HUB] Failed to generate challenge\n");
      return false;
    }

    unsigned char eph_pub[32];
    EVP_PKEY_CTX *ctx = EVP_PKEY_CTX_new_id(EVP_PKEY_X25519, NULL);
    EVP_PKEY *pk = NULL;
    size_t len = 32;
    bool ok = ctx && EVP_PKEY_keygen_init(ctx) > 0
                  && EVP_PKEY_keygen(ctx, &pk) > 0
                  && EVP_PKEY_get_raw_private_key(pk, client->bot_eph_x25519_priv, &len) > 0
                  && len == 32
                  && EVP_PKEY_get_raw_public_key(pk, eph_pub, &len) > 0
                  && len == 32;
    if (pk)  EVP_PKEY_free(pk);
    if (ctx) EVP_PKEY_CTX_free(ctx);
    if (!ok) { secure_wipe(client->bot_eph_x25519_priv, 32);
               hub_log_error("[HUB] Ephemeral X25519 keygen failed\n"); return false; }
    client->bot_eph_priv_set = true;
    memcpy(client->bot_eph_x25519_pub, eph_pub, 32);

    /* v2 challenge: challenge(32) || eph_pub(32) || hub_sig(64)
     *
     * Signature commits to the bot UUID, challenge, and ephemeral pubkey so
     * a MITM cannot substitute its own eph_pub (the bot would derive a
     * usable session key against the MITM, but the signature wouldn't
     * verify under the legitimate hub's pubkey). */
    size_t uuid_len = strlen(uuid);
    size_t tlen = strlen("irchub-hub-auth-v2|") + uuid_len + 1 + 32 + 32;
    unsigned char *transcript = malloc(tlen);
    if (!transcript) {
      hub_log_error("[HUB] transcript alloc failed\n");
      return false;
    }
    size_t off = 0;
    memcpy(transcript + off, "irchub-hub-auth-v2|", 19); off += 19;
    memcpy(transcript + off, uuid, uuid_len);            off += uuid_len;
    transcript[off++] = '|';
    memcpy(transcript + off, client->challenge, 32);     off += 32;
    memcpy(transcript + off, eph_pub, 32);               off += 32;

    unsigned char hub_sig[ED25519_SIG_LEN];
    if (!hub_crypto_ed25519_sign(state->hub_ed25519_priv,
                                 transcript, off, hub_sig)) {
      hub_log_error("[HUB] Hub Ed25519 sign failed\n");
      secure_wipe(transcript, off);
      free(transcript);
      return false;
    }
    secure_wipe(transcript, off);
    free(transcript);

    /* length prefix and body in one write: two small writes stall ~40 ms on
     * Nagle + the bot's delayed ACK */
    unsigned char out_buf[4 + 128];
    uint32_t nl = htonl(128);
    memcpy(out_buf,       &nl,               4);
    memcpy(out_buf + 4,   client->challenge, 32);
    memcpy(out_buf + 36,  eph_pub,           32);
    memcpy(out_buf + 68,  hub_sig,           64);

    if (write(client->fd, out_buf, sizeof(out_buf)) != (ssize_t)sizeof(out_buf)) {
      hub_log_warning("[HUB] Failed to send v2 challenge to %s\n", hub_who(state, 'b', uuid));
      return false;
    }

    snprintf(client->id, sizeof(client->id), "%s", uuid);
    client->bot_auth_state = BOT_AUTH_CHALLENGE_SENT;
    client->last_seen = time(NULL);

    hub_log_debug("[HUB] Sent v2 signed Curve25519 challenge to %s\n", hub_who(state, 'b', uuid));
    return true;
  }

  // PHASE 2: Receive 64-byte Ed25519 signature
  if (!client->authenticated &&
      client->bot_auth_state == BOT_AUTH_CHALLENGE_SENT) {
    hub_log_debug("[HUB] Received signature from %s (%d bytes)\n", hub_who_client(state, client),
                  packet_len);

    if (packet_len != 64 || !client->bot_eph_priv_set) {
      hub_log_warning("[HUB] Bad signature size or state from %s\n", hub_who_client(state, client));
      return false;
    }

    unsigned char bot_combined[64], bot_ed_pub[32], bot_x_pub[32];
    if (client->quarantine ? !load_revoked_pub(state, client->id, bot_combined)
                           : !load_bot_combined_pub(state, client->id, bot_combined)) {
      hub_log_warning("[HUB] No public key for %s\n", hub_who_client(state, client));
      return false;
    }
    hub_crypto_split_combined(bot_combined, bot_ed_pub, bot_x_pub);

    /* Domain-separated transcript: "irchub-bot-challenge-v1|UUID|" + eph_pub(32)
     * + challenge(32).  Mirrors ed25519_sign_challenge() in hub_client.c. */
    {
      size_t uuid_len = strlen(client->id);
      /* prefix = "irchub-bot-challenge-v1|" + uuid + "|" */
      size_t prefix_len = 24 + uuid_len + 1;
      size_t msg_len = prefix_len + 32 + 32;
      unsigned char *msg = malloc(msg_len);
      if (!msg) {
        hub_log_error("[HUB] OOM building challenge transcript for %s\n",
                hub_who_client(state, client));
        secure_wipe(bot_combined, 64);
        return false;
      }
      size_t off = 0;
      memcpy(msg + off, "irchub-bot-challenge-v1|", 24); off += 24;
      memcpy(msg + off, client->id, uuid_len);           off += uuid_len;
      msg[off++] = '|';
      memcpy(msg + off, client->bot_eph_x25519_pub, 32); off += 32;
      memcpy(msg + off, client->challenge, 32);          off += 32;

      bool sig_ok = hub_crypto_ed25519_verify(bot_ed_pub, msg, msg_len, data);
      secure_wipe(msg, msg_len);
      free(msg);

      if (!sig_ok) {
        hub_log_warning("[HUB] Invalid signature from %s\n", hub_who_client(state, client));
        record_failed_auth(state, client->ip);
        secure_wipe(bot_combined, 64);
        return false;
      }
    }

    unsigned char shared[32];
    if (!hub_crypto_x25519_derive(client->bot_eph_x25519_priv, bot_x_pub, shared)) {
      hub_log_error("[HUB] X25519 derive failed for %s\n", hub_who_client(state, client));
      secure_wipe(bot_combined, 64);
      return false;
    }

    unsigned char info[96];
    int info_len = snprintf((char *)info, sizeof(info),
                            "irchub-bot-session-v1|%s", client->id);
    bool ok = hub_crypto_hkdf_sha256(shared, 32,
                                     client->challenge, 32,
                                     info, (size_t)info_len,
                                     client->session_key, 32);
    secure_wipe(shared, 32);
    secure_wipe(client->bot_eph_x25519_priv, 32);
    client->bot_eph_priv_set = false;
    secure_wipe(bot_combined, 64);
    if (!ok) {
      hub_log_error("[HUB] HKDF failed for %s\n", hub_who_client(state, client));
      return false;
    }

    /* Send GCM-encrypted 1-byte ACK so the bot can confirm the hub knows the
     * session key — without this, a MITM that proxied the v2 challenge could
     * still flip the bot into "authenticated" via a plaintext 0x01.
     *
     * aes_gcm_encrypt writes (iv || ciphertext) into the output buffer and
     * the tag into the separate `tag` argument. Wire format we send is:
     *   iv(GCM_IV_LEN=12) || ciphertext(1) || tag(GCM_TAG_LEN=16) = 29 bytes
     */
    /* A revoked bot gets CMD_BOT_RETIRE in the ACK's place: it wipes its
     * config, answers CMD_BOT_RETIRE_ACK, and is never a CLIENT_BOT here. */
    unsigned char ack_plain = client->quarantine ? CMD_BOT_RETIRE : 0x01;
    /* framed in one buffer, one write (see the challenge above) */
    unsigned char ack_wire[4 + GCM_IV_LEN + 1 + GCM_TAG_LEN];
    unsigned char ack_tag[GCM_TAG_LEN];
    int enc_len = aes_gcm_encrypt(&ack_plain, 1,
                                  client->session_key, ack_wire + 4, ack_tag);
    if (enc_len <= 0) {
      hub_log_error("[HUB] ACK encrypt failed for %s\n", hub_who_client(state, client));
      return false;
    }
    memcpy(ack_wire + 4 + enc_len, ack_tag, GCM_TAG_LEN);
    int ack_total = enc_len + GCM_TAG_LEN;

    uint32_t nl = htonl((uint32_t)ack_total);
    memcpy(ack_wire, &nl, 4);
    if (write(client->fd, ack_wire, (size_t)(4 + ack_total)) != 4 + ack_total) {
      hub_log_warning("[HUB] Failed to send v2 ACK to %s\n", hub_who_client(state, client));
      return false;
    }

    if (client->quarantine) {
      client->bot_auth_state = BOT_AUTH_QUARANTINE;
      hub_log_info("[REVOKE] Revoked %s proved its key: told to wipe its config\n",
                   hub_who_client(state, client));
      return true;
    }

    client->type = CLIENT_BOT;
    client->authenticated = true;
    client->bot_auth_state = BOT_AUTH_COMPLETE;
    client->last_seen = time(NULL);
    supersede_bot_sessions(state, client);
    hub_known_ip_note(state, client->ip);
    hub_link_offer(state, client, NULL);

    /* D2: grow buffers to full size now that the bot is authenticated. */
    if (!hub_client_promote_buffers(client)) {
      hub_log_error("[HUB] Buffer promotion OOM for %s — disconnecting\n",
              hub_who_client(state, client));
      return false;
    }

    hub_storage_update_entry(state, client->id, "seen", "", "", "", client->last_seen);

    /* A new bot joins the tree: gossip and push on the next tick instead of
     * leaving it invisible to the mesh until the periodic refresh. */
    hub_roster_mark_dirty(state, true);
    roster_evict_moved(state, client->id, state->hub_uuid, 0, 0);
    hub_presence_event(state);

    hub_log_info("[HUB] %s authenticated (Curve25519)\n", hub_who_client(state, client));
    return true;
  }

  return false;
}

// Sealed-box open: eph_pub(32) || IV(GCM_IV_LEN) || ct(N) || tag(GCM_TAG_LEN)
static int hub_seal_open(hub_state_t *state,
                         const unsigned char *in, int in_len,
                         const unsigned char *info, size_t info_len,
                         unsigned char *plain_out, int plain_max,
                         unsigned char session_key_out[32]) {
    if (in_len < 32 + GCM_IV_LEN + GCM_TAG_LEN) return -1;
    const unsigned char *eph_pub = in;
    const unsigned char *iv      = in + 32;
    const unsigned char *ct      = in + 32 + GCM_IV_LEN;
    int ct_len                   = in_len - 32 - GCM_IV_LEN - GCM_TAG_LEN;
    const unsigned char *tag_ptr = in + in_len - GCM_TAG_LEN;
    if (ct_len < 0 || ct_len > plain_max) return -1;

    unsigned char shared[32], session_key[32];
    if (!hub_crypto_x25519_derive(state->hub_x25519_priv, eph_pub, shared)) return -1;
    bool ok = hub_crypto_hkdf_sha256(shared, 32, eph_pub, 32,
                                     info, info_len, session_key, 32);
    secure_wipe(shared, 32);
    if (!ok) return -1;

    unsigned char tmp[MAX_BUFFER];
    if (GCM_IV_LEN + ct_len > (int)sizeof(tmp)) { secure_wipe(session_key, 32); return -1; }
    memcpy(tmp,              iv, GCM_IV_LEN);
    memcpy(tmp + GCM_IV_LEN, ct, (size_t)ct_len);

    unsigned char tag_buf[GCM_TAG_LEN];
    memcpy(tag_buf, tag_ptr, GCM_TAG_LEN);
    int pl = aes_gcm_decrypt(tmp, GCM_IV_LEN + ct_len,
                             session_key, plain_out, tag_buf);
    secure_wipe(tmp, (size_t)(GCM_IV_LEN + ct_len));
    if (pl <= 0) { secure_wipe(session_key, 32); return -1; }

    memcpy(session_key_out, session_key, 32);
    secure_wipe(session_key, 32);
    return pl;
}

/* broadcast_new_key removed: independent per-hub keypairs mean private keys
 * must never travel between hubs.  Rekey is local-only — each hub regenerates
 * its own keypair and exports the new pubkey for peers to re-register. */

static void hub_state_add_bot_memory(hub_state_t *state, const char *uuid,
                                     const char *nick, const char *pub_key) {
  for (int i = 0; i < state->bot_count; i++) {
    if (strcmp(state->bots[i].uuid, uuid) == 0)
      return;
  }

  if (state->bot_count < MAX_BOTS) {
    int idx = state->bot_count++;
    bot_config_t *b = &state->bots[idx];
    memset(b, 0, sizeof(bot_config_t));
    snprintf(b->uuid, sizeof(b->uuid), "%s", uuid);
    /* A new registration is live.  is_active follows the 'd' entry alone,
     * so it must be set here (the memset leaves it false). */
    b->is_active = true;
    b->last_sync_time = 0;

    time_t now = time(NULL);
    hub_storage_update_entry(state, uuid, "n", nick, "", "", now);
    hub_storage_update_entry(state, uuid, "pub", pub_key, "", "", now);
    hub_storage_update_entry(state, uuid, "seen", "", "", "", now);
  }
}

// FIXED: Added comprehensive bounds checking for CMD_ADMIN_LIST_PEERS
void hub_broadcast_mesh_state(hub_state_t *state) {
  char *payload = malloc(MAX_BUFFER);
  char *work_buf = malloc(MAX_BUFFER);

  if (!payload || !work_buf) {
      free(payload);
      free(work_buf);
      return;
  }
  
  memset(payload, 0, MAX_BUFFER);
  int offset = 0;
  int written;

  // Format: bind_ip:port:uuid:friendly_name|
  written = snprintf(payload + offset, (size_t)(MAX_BUFFER - offset), "%s:%d:%s:%s|",
                     state->bind_ip, state->port,
                     state->hub_uuid[0] ? state->hub_uuid : "-",
                     state->hub_friendly_name[0] ? state->hub_friendly_name : "-");
  if (written < 0 || written >= MAX_BUFFER - offset) {
    free(payload); free(work_buf);
    return;
  }
  offset += written;

  for (int i = 0; i < state->peer_count; i++) {
    int is_up = 0;
    for (int c = 0; c < state->client_count; c++) {
      if (state->clients[c]->type == CLIENT_HUB &&
          state->clients[c]->authenticated) {
        if (state->peers[i].fd == state->clients[c]->fd &&
            state->peers[i].fd > 0) {
          is_up = 1;
          break;
        }
      }
    }

    // Format: ip:port:is_up:uuid:friendly_name,
    written = snprintf(payload + offset, (size_t)(MAX_BUFFER - offset), "%s:%d:%d:%s:%s,",
                       state->peers[i].ip, state->peers[i].port, is_up,
                       state->peers[i].uuid[0] ? state->peers[i].uuid : "-",
                       state->peers[i].friendly_name[0] ? state->peers[i].friendly_name : "-");
    if (written < 0 || written >= MAX_BUFFER - offset)
      break;
    offset += written;
  }

  if (offset < MAX_BUFFER - 1) {
    payload[offset++] = ';';
    payload[offset] = 0;
  }

  // Aggregate gossip from peers
  for (int i = 0; i < state->peer_count; i++) {
    if (state->peers[i].connected && strlen(state->peers[i].last_gossip) > 0) {
      char *body = strchr(state->peers[i].last_gossip, '|');
      if (!body)
        continue;

      memset(work_buf, 0, MAX_BUFFER);
      snprintf(work_buf, MAX_BUFFER, "%.*s", MAX_BUFFER - 1, body + 1);

      char *saveptr;
      char *block = strtok_r(work_buf, ";", &saveptr);

      while (block) {
        char owner_chk[256];
        if (sscanf(block, "%255[^|]", owner_chk) == 1) {
          char my_sig[128];
          snprintf(my_sig, sizeof(my_sig), "%s:%d", state->bind_ip, state->port);

          if (strcmp(owner_chk, my_sig) != 0) {
            char search_sig[260];
            snprintf(search_sig, sizeof(search_sig), "%s|", owner_chk);

            if (strstr(payload, search_sig) == NULL) {
              int blk_len = (int)strlen(block);
              if (offset + blk_len + 2 < MAX_BUFFER) {
                // SECURITY FIX: Use memcpy instead of strcpy for bounded copy
                memcpy(payload + offset, block, (size_t)blk_len);
                payload[offset + blk_len] = '\0';
                offset += blk_len;
                payload[offset++] = ';';
                payload[offset] = 0;
              }
            }
          }
        }
        block = strtok_r(NULL, ";", &saveptr);
      }
    }
  }

  int connected_peers = 0;
  for (int i = 0; i < state->peer_count; i++) {
    if (state->peers[i].connected)
      connected_peers++;
  }

  int active_bots = 0;
  char bot_uuid_list[MAX_BUFFER];
  int uuid_offset = 0;
  bot_uuid_list[0] = '\0';

  for (int i = 0; i < state->client_count; i++) {
    if (state->clients[i]->type == CLIENT_BOT &&
        state->clients[i]->authenticated) {
      active_bots++;
      // Add bot UUID to list
      if (uuid_offset > 0 && uuid_offset < MAX_BUFFER - 2) {
        bot_uuid_list[uuid_offset++] = ',';
      }
      int uuid_len = (int)strlen(state->clients[i]->id);
      if (uuid_offset + uuid_len < MAX_BUFFER - 1) {
        memcpy(bot_uuid_list + uuid_offset, state->clients[i]->id, (size_t)uuid_len);
        uuid_offset += uuid_len;
        bot_uuid_list[uuid_offset] = '\0';
      }
    }
  }

  char final_packet[MAX_BUFFER];

  written = snprintf(final_packet, sizeof(final_packet), "%d:%d:%d:%s|%s",
                     connected_peers, state->peer_count, active_bots,
                     bot_uuid_list[0] ? bot_uuid_list : "-", payload);
  if (written < 0 || written >= (int)sizeof(final_packet)) {
    free(payload); free(work_buf);
    return;
  }

  int payload_len = (int)strlen(final_packet);
  if (payload_len > MAX_BUFFER - 100) {
    payload_len = MAX_BUFFER - 100;
  }

  /* Mesh-state gossip is best-effort and goes through the BULK lane.  A
   * single coalesce key per (origin_hub_uuid, "mesh") collapses repeated
   * 5-second gossip into the most recent payload if a peer is briefly
   * backed up, so we never queue stale snapshots ahead of fresh ones. */
  char coalesce[80];
  snprintf(coalesce, sizeof(coalesce), "%s|mesh_state", state->hub_uuid);

  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type == CLIENT_HUB && c->authenticated) {
      queued_msg_t *m = queued_msg_new(CMD_MESH_STATE, LANE_BULK,
                                       (const unsigned char *)final_packet,
                                       payload_len);
      if (!m) continue;
      queued_msg_set_coalesce(m, state->hub_uuid,
                              hub_next_lamport_seq(state), coalesce);
      peer_enqueue(c, m);
    }
  }
  free(payload);
  free(work_buf);
}

static void process_mesh_state(hub_state_t *state, hub_client_t *c,
                               char *payload) {
  int remote_conn = 0, remote_total = 0, remote_bots = 0;

  if (sscanf(payload, "%d:%d:%d", &remote_conn, &remote_total, &remote_bots) >=
      2) {
    for (int i = 0; i < state->peer_count; i++) {
      if (state->peers[i].connected && state->peers[i].fd == c->fd) {
        state->peers[i].last_mesh_report = time(NULL);

        // Safe truncating copy with explicit length calculation
        size_t payload_len = strlen(payload);
        size_t max_len = sizeof(state->peers[i].last_gossip) - 1;
        size_t copy_len = (payload_len < max_len) ? payload_len : max_len;

        memcpy(state->peers[i].last_gossip, payload, copy_len);
        state->peers[i].last_gossip[copy_len] = '\0';

        // Extract remote hub's friendly_name and UUID from gossip and update peer record
        // Gossip format: connected:total:bots:bot_list|ip:port:uuid:friendly_name|...
        char *mesh_start = strchr(payload, '|');
        if (mesh_start) {
          mesh_start++; // Skip the first |
          char remote_ip[256], remote_uuid[64], remote_name[64];
          int remote_port;
          memset(remote_uuid, 0, sizeof(remote_uuid));
          memset(remote_name, 0, sizeof(remote_name));

          // Parse: ip:port:uuid:friendly_name|
          int fields = sscanf(mesh_start, "%255[^:]:%d:%63[^:]:%63[^|]",
                             remote_ip, &remote_port, remote_uuid, remote_name);

          bool config_updated = false;

          // Update friendly_name if it changed (and is a well-formed name:
          // it is written to our config and shown to operators)
          if (fields >= 4 && remote_name[0] && strcmp(remote_name, "-") != 0 &&
              hub_name_valid(remote_name)) {
            if (strcmp(state->peers[i].friendly_name, remote_name) != 0) {
              snprintf(state->peers[i].friendly_name,
                      sizeof(state->peers[i].friendly_name), "%s", remote_name);
              hub_log_debug("[MESH] Updated peer friendly_name to: %s\n", remote_name);
              config_updated = true;
            }
          }

          /* Fill in the uuid only for a peer we hold none for.  A linked
           * peer proved the uuid we hold in its handshake; gossip proves
           * nothing.  Rewriting it let a peer take another hub's identity
           * (that hub's own handshake then checked the wrong key) and wrote
           * the unchecked text into the config's peer| line. */
          if (fields >= 3 && !state->peers[i].uuid[0] && hub_uuid_shape(remote_uuid)) {
            snprintf(state->peers[i].uuid, sizeof(state->peers[i].uuid), "%s", remote_uuid);
            hub_log_debug("[MESH] Updated peer UUID to: %s\n", hub_who(state, 'h', remote_uuid));
            config_updated = true;
          }

          // Write config once if anything changed
          if (config_updated) {
            state->config_dirty = true;
          }
        }
        return;
      }
    }
  }
}

/* ==========================================================================
 * Bot presence — the data behind the bot's 'bots' tree.
 *
 * Three hops, none of which touch the config store:
 *   1. bot  -> hub   CMD_BOT_PRESENCE  its version, IRC server, start time
 *   2. hub <-> hub   CMD_BOT_ROSTER    the bots connected to THIS hub
 *   3. hub  -> bot   CMD_BOT_TREE      the assembled tree, DFS pre-order
 *
 * Everything here is volatile and TTL'd.  A bot that disconnects stops being
 * reported and ages out; a hub that dies takes its whole branch with it.  The
 * only persisted data read is identity (nick) and 'seen', both already in the
 * config, used to list bots that are known but currently offline.
 * ========================================================================== */

/* Sanitize one field arriving from a bot or a peer before it is stored or
 * echoed into a tree row.  Presence text is attacker-controlled: it reaches
 * other operators' IRC clients, so '|' (our field separator), CR/LF and any
 * other control byte are dropped outright rather than escaped. */
static void roster_clean(char *dst, size_t cap, const char *src) {
  size_t o = 0;
  if (cap == 0) return;
  for (size_t i = 0; src && src[i] && o + 1 < cap; i++) {
    unsigned char ch = (unsigned char)src[i];
    if (ch < 0x20 || ch == 0x7f || ch == '|') continue;
    dst[o++] = (char)ch;
  }
  dst[o] = '\0';
}

void hub_roster_mark_dirty(hub_state_t *state, bool local) {
  state->tree_dirty = true;
  if (local) state->tree_dirty_local = true;
}

void hub_roster_expire(hub_state_t *state, time_t now) {
  for (int i = 0; i < state->roster_count;) {
    if (now - state->roster[i].reported_at > BOT_ROSTER_TTL) {
      hub_log_info("[PRESENCE] %s on %s aged out of the roster\n",
              hub_who(state, 'b', state->roster[i].bot_uuid),
              hub_who(state, 'h', state->roster[i].hub_uuid));
      state->roster[i] = state->roster[--state->roster_count];
      state->tree_dirty = true;
      continue; /* the swapped-in entry still needs checking */
    }
    i++;
  }
  for (int i = 0; i < state->mesh_hub_count;) {
    if (now - state->mesh_hubs[i].reported_at > BOT_ROSTER_TTL) {
      hub_log_info("[PRESENCE] %s aged out of the mesh map\n",
              hub_who(state, 'h', state->mesh_hubs[i].uuid));
      state->mesh_hubs[i] = state->mesh_hubs[--state->mesh_hub_count];
      state->tree_dirty = true;
      continue;
    }
    i++;
  }
}

/* The mesh-map record for hub `uuid`, or NULL. */
static mesh_hub_t *mesh_hub_find(hub_state_t *state, const char *uuid) {
  for (int i = 0; i < state->mesh_hub_count; i++)
    if (strcmp(state->mesh_hubs[i].uuid, uuid) == 0) return &state->mesh_hubs[i];
  return NULL;
}

/* ...created on first sight.  NULL when the map is full: that hub's frames
 * are then applied as before but not relayed, so a map overflow degrades to
 * the one-hop tree instead of a relay loop. */
static mesh_hub_t *mesh_hub_get(hub_state_t *state, const char *uuid) {
  mesh_hub_t *h = mesh_hub_find(state, uuid);
  if (h) return h;
  if (state->mesh_hub_count >= MAX_MESH_HUBS) {
    hub_log_warning("[PRESENCE] Mesh map full (%d) — %s is not relayed\n",
            MAX_MESH_HUBS, hub_who(state, 'h', uuid));
    return NULL;
  }
  h = &state->mesh_hubs[state->mesh_hub_count++];
  memset(h, 0, sizeof(*h));
  snprintf(h->uuid, sizeof(h->uuid), "%s", uuid);
  h->gen = -1;
  return h;
}

/* Same links, same order: what a hub's l| lines render in the tree.
 * old_n < 0 is "no list before", which is always a change. */
static bool mesh_links_equal(const mesh_link_t *a, int old_n,
                             const mesh_link_t *b, int new_n) {
  if (old_n != new_n) return false;
  for (int i = 0; i < new_n; i++)
    if (a[i].online != b[i].online || strcmp(a[i].uuid, b[i].uuid) != 0 ||
        strcmp(a[i].name, b[i].name) != 0)
      return false;
  return true;
}

/* True when our link to configured peer `p` is up right now. */
static bool peer_is_linked(const hub_state_t *state, const hub_peer_config_t *p) {
  if (p->fd <= 0) return false;
  for (int c = 0; c < state->client_count; c++)
    if (state->clients[c]->type == CLIENT_HUB &&
        state->clients[c]->authenticated && state->clients[c]->fd == p->fd)
      return true;
  return false;
}

/* Upsert one reported bot.  Keyed on (reporting hub, bot) so the same bot
 * briefly reported by two hubs mid-migration shows up once per hub rather
 * than flapping — the stale one expires on its own. */
/* The live link of bot `uuid` on this hub, or NULL. */
static const hub_client_t *roster_local_bot(const hub_state_t *state, const char *uuid) {
  for (int i = 0; i < state->client_count; i++) {
    const hub_client_t *c = state->clients[i];
    if (c->type == CLIENT_BOT && c->authenticated && strcmp(c->id, uuid) == 0) return c;
  }
  return NULL;
}

/* A bot has one hub link at a time: entries for it under any other hub than
 * `keep_hub` that are older than this sighting describe where it was.  `since`
 * 0 (with link_ord 0) drops them all — an authoritative local link.  Phase 4:
 * when both this sighting and the old entry carry a link-order counter the
 * counter decides (a strictly larger one is newer); otherwise it falls back to
 * the hubs' `link_since` clocks, as before. */
static void roster_evict_moved(hub_state_t *state, const char *bot_uuid,
                               const char *keep_hub, time_t since, uint64_t link_ord) {
  for (int i = 0; i < state->roster_count;) {
    bot_roster_t *e = &state->roster[i];
    if (strcmp(e->bot_uuid, bot_uuid) != 0 || strcmp(e->hub_uuid, keep_hub) == 0) {
      i++;
      continue;
    }
    bool older;
    if (since == 0 && link_ord == 0)
      older = true;
    else if (link_ord > 0 && e->link_ord > 0)
      older = e->link_ord < link_ord;
    else
      older = e->link_since > 0 && since > 0 && e->link_since < since;
    if (!older) {
      i++;
      continue;
    }
    hub_log_debug("[PRESENCE] %s moved off %s\n", hub_who(state, 'b', e->bot_uuid),
                  hub_who(state, 'h', e->hub_uuid));
    state->roster[i] = state->roster[--state->roster_count];
    state->tree_dirty = true;
  }
}

/* Every chunk 0..`last_chunk` of hub `mh`'s round has been applied: its bots the
 * round did not list have left it. */
static void roster_round_done(hub_state_t *state, const mesh_hub_t *mh, int last_chunk) {
  if (last_chunk < 0 || last_chunk >= 64) return;
  uint64_t all = last_chunk == 63 ? ~0ULL : (1ULL << (last_chunk + 1)) - 1;
  if ((mh->chunks_seen & all) != all) return;
  for (int i = 0; i < state->roster_count;) {
    bot_roster_t *e = &state->roster[i];
    if (strcmp(e->hub_uuid, mh->uuid) == 0 && e->gen != mh->gen) {
      hub_log_debug("[PRESENCE] %s left %s\n", hub_who(state, 'b', e->bot_uuid),
                    hub_who(state, 'h', e->hub_uuid));
      state->roster[i] = state->roster[--state->roster_count];
      state->tree_dirty = true;
      continue;
    }
    i++;
  }
}

static void roster_upsert(hub_state_t *state, const bot_roster_t *in) {
  /* A deleted bot, reported by a hub that has not heard yet. */
  if (hub_revoke_find(state, in->bot_uuid)) return;
  /* The bot is linked here now and this report is older: it is where it was.
   * Phase 4: the bot's link-order counter decides when both sightings carry it,
   * else the hub clocks (its link time vs our local connect time). */
  const hub_client_t *here = roster_local_bot(state, in->bot_uuid);
  if (here) {
    bool incoming_older = (in->link_ord > 0 && here->bot_link_ord > 0)
                              ? in->link_ord <= here->bot_link_ord
                              : (in->link_since > 0 && in->link_since <= here->connected_at);
    if (incoming_older) return;
  }
  if (in->link_since > 0 || in->link_ord > 0)
    roster_evict_moved(state, in->bot_uuid, in->hub_uuid, in->link_since, in->link_ord);
  for (int i = 0; i < state->roster_count; i++) {
    bot_roster_t *e = &state->roster[i];
    if (strcmp(e->hub_uuid, in->hub_uuid) != 0 ||
        strcmp(e->bot_uuid, in->bot_uuid) != 0)
      continue;
    /* An unchanged report just refreshes the TTL; only a real change is worth
     * re-rendering every bot's tree for. */
    bool changed = strcmp(e->nick, in->nick) != 0 ||
                   strcmp(e->version, in->version) != 0 ||
                   strcmp(e->variant, in->variant) != 0 ||
                   strcmp(e->server, in->server) != 0 ||
                   e->connected_at != in->connected_at;
    /* Phase 4: a report with no counter (a p2 reconcile, which does not carry
     * it this release) must not wipe one the legacy gossip already learned. */
    uint64_t keep_ord = e->link_ord;
    *e = *in;
    if (in->link_ord == 0 && keep_ord > 0) e->link_ord = keep_ord;
    e->p2_stamp = state->p2 ? ++state->p2->stamp_ctr : 0;
    hub_p2_roster_touched(state, in->hub_uuid);
    if (changed) state->tree_dirty = true;
    return;
  }
  if (state->roster_count >= MAX_BOT_ROSTER) {
    hub_log_warning("[PRESENCE] Roster full (%d) — dropping report for %s\n",
            MAX_BOT_ROSTER, hub_who(state, 'b', in->bot_uuid));
    return;
  }
  state->roster[state->roster_count] = *in;
  state->roster[state->roster_count++].p2_stamp = state->p2 ? ++state->p2->stamp_ctr : 0;
  hub_p2_roster_touched(state, in->hub_uuid);
  state->tree_dirty = true;
}

static void bot_nick_from_config(hub_state_t *state, const char *uuid, char *out, size_t cap);

/* Presence v2: hub `hub_uuid` has been unreachable past the grace.  Its bots
 * and its mesh-map entry go now instead of on the BOT_ROSTER_TTL.  Called
 * once per outage, and again if a late relayed round brings entries of it
 * back. */
int hub_roster_p2_drop_hub(hub_state_t *state, const char *hub_uuid) {
  int n = 0;
  for (int i = 0; i < state->roster_count;) {
    if (strcmp(state->roster[i].hub_uuid, hub_uuid) == 0) {
      state->roster[i] = state->roster[--state->roster_count];
      n++;
      continue;
    }
    i++;
  }
  for (int i = 0; i < state->mesh_hub_count; i++) {
    if (strcmp(state->mesh_hubs[i].uuid, hub_uuid) != 0) continue;
    state->mesh_hubs[i] = state->mesh_hubs[--state->mesh_hub_count];
    n++;
    break;
  }
  if (n) state->tree_dirty = true;
  return n;
}

/* Presence v2: a reachable hub's record says which bots it has.  An entry of
 * that hub for a bot it no longer lists goes, unless it arrived after the
 * record (p2_stamp); a listed bot nobody reported yet gets a bare entry (nick
 * from the config, details "-") until the hub's own round fills it in. */
int hub_roster_p2_reconcile(hub_state_t *state, const p2_rec_t *rec) {
  int n = 0;
  for (int i = 0; i < state->roster_count;) {
    bot_roster_t *e = &state->roster[i];
    if (strcmp(e->hub_uuid, rec->origin) == 0 && e->p2_stamp < rec->stamp) {
      bool listed = false;
      for (int b = 0; b < rec->nbots && !listed; b++)
        listed = strcmp(rec->bots[b].id, e->bot_uuid) == 0;
      if (!listed) {
        hub_log_debug("[PRESENCE] %s left %s (record)\n", hub_who(state, 'b', e->bot_uuid),
                      hub_who(state, 'h', e->hub_uuid));
        state->roster[i] = state->roster[--state->roster_count];
        state->tree_dirty = true;
        n++;
        continue;
      }
    }
    i++;
  }
  const mesh_hub_t *mh = mesh_hub_find(state, rec->origin);
  for (int b = 0; b < rec->nbots; b++) {
    /* Skip it when it is there already, or linked to another hub more
     * recently (it moved and this hub has not noticed yet). */
    bool have = false;
    for (int i = 0; i < state->roster_count && !have; i++) {
      const bot_roster_t *x = &state->roster[i];
      if (strcmp(x->bot_uuid, rec->bots[b].id) != 0) continue;
      have = strcmp(x->hub_uuid, rec->origin) == 0 || x->link_since >= rec->bots[b].since;
    }
    if (have) continue;
    bot_roster_t e;
    memset(&e, 0, sizeof(e));
    snprintf(e.hub_uuid, sizeof(e.hub_uuid), "%s", rec->origin);
    snprintf(e.hub_name, sizeof(e.hub_name), "%s", mh && mh->name[0] ? mh->name : rec->origin);
    snprintf(e.bot_uuid, sizeof(e.bot_uuid), "%s", rec->bots[b].id);
    bot_nick_from_config(state, e.bot_uuid, e.nick, sizeof(e.nick));
    time_t now = time(NULL);
    e.link_since = rec->bots[b].since > 0 && rec->bots[b].since <= now
                       ? (time_t)rec->bots[b].since : 0;
    e.reported_at = now;
    e.gen = mh ? mh->gen : 0;
    roster_upsert(state, &e);
    /* Added (it was absent): still "older" than any round. */
    for (int i = 0; i < state->roster_count; i++) {
      if (strcmp(state->roster[i].hub_uuid, rec->origin) != 0 ||
          strcmp(state->roster[i].bot_uuid, rec->bots[b].id) != 0)
        continue;
      state->roster[i].p2_stamp = rec->stamp;
      n++;
      break;
    }
  }
  return n;
}

/* This bot just told us what it is running.  Per connection and volatile. */
static void process_bot_presence(hub_state_t *state, hub_client_t *client,
                                 const char *payload) {
  char version[ROSTER_VERSION_MAX + 1] = "";
  char server[ROSTER_SERVER_MAX + 1] = "";
  char variant[ROSTER_VARIANT_MAX + 1] = "";
  char cron[CRON_STATUS_MAX + 1] = "";
  long long started = 0;
  unsigned long long link_ord = 0; /* phase 4: the bot's link-order counter */

  /* "<version>|<server>|<started>|<variant>[|<cron>[|<linkord>]]" (BOT_PRESENCE_MAX) — a short, fixed shape.  The
   * variant (code base, c / rs) is the newest field; a bot that predates it
   * sends three and simply shows no code base.  Anything longer than the
   * field caps is truncated by roster_clean, never rejected, so a newer bot
   * advertising more never drops off the tree entirely. */
  char work[BOT_PRESENCE_MAX + 1];
  int plen = snprintf(work, sizeof(work), "%s", payload ? payload : "");
  bool cut = plen < 0 || plen >= (int)sizeof(work); /* the counter rode past the cut */
  char *p1 = strchr(work, '|');
  if (p1) {
    *p1 = '\0';
    char *p2 = strchr(p1 + 1, '|');
    if (p2) {
      *p2 = '\0';
      char *p3 = strchr(p2 + 1, '|');
      if (p3) {
        *p3 = '\0';
        char *p4 = strchr(p3 + 1, '|'); /* room for fields after it */
        if (p4) {
          *p4 = '\0';
          char *p5 = strchr(p4 + 1, '|');
          if (p5) {
            *p5 = '\0';
            /* Phase 4: the link-order counter rides last.  A bad or missing
             * value reads 0, which the move decision treats as "no counter"
             * and falls back to the hubs' clocks. */
            char *p6 = strchr(p5 + 1, '|');
            if (p6) *p6 = '\0';
            char *end = NULL;
            errno = 0;
            unsigned long long v = strtoull(p5 + 1, &end, 10);
            if (!cut && !errno && end && !*end && end != p5 + 1) link_ord = v;
          }
          roster_clean(cron, sizeof(cron), p4 + 1);
        }
        roster_clean(variant, sizeof(variant), p3 + 1);
      }
      started = atoll(p2 + 1);
    }
    roster_clean(server, sizeof(server), p1 + 1);
  }
  roster_clean(version, sizeof(version), work);

  /* A bot cannot claim to have started in the future, nor before the epoch of
   * this mesh; an out-of-range value just means "unknown uptime". */
  time_t now = time(NULL);
  if (started <= 0 || (time_t)started > now) started = 0;

  /* D1 of the 2.5.1 plan: a bot below MESH_MIN_VERSION is not served (it
   * still reads 100k files and old record shapes).  The hub cannot roll it
   * up either, so it says what to do and drops the link. */
  if (version[0] && hub_update_version_cmp(version, MESH_MIN_VERSION) < 0) {
    hub_log_warning("[HUB] %s runs %s: refused; upgrade it by hand to %s\n",
                    hub_who_client(state, client), version, MESH_MIN_VERSION);
    client->refused = true;
    return;
  }
  /* Review 6: every bot sends CMD_LINK_SEQ "offer" as its first frame,
   * before any presence; none means it was stripped on the way. */
  if (version[0] && !client->link_offered) {
    hub_log_warning("[HUB] %s runs %s but never offered the sequenced link framing "
                    "(a frame stripped on the way?): dropped\n",
                    hub_who_client(state, client), version);
    client->refused = true;
    return;
  }

  /* The bot's first config may have gone out before its version was known:
   * once it shows it takes the pool (or stops), it is owed one with (without)
   * the N|/S| lines — a delta, since it already holds a base.  A held first
   * config (CFG_FIRST_HOLD) has not gone out: it is sent below instead. */
  bool held = client->cfg_hold_at && !client->cfg_hold_done;
  if (!held && hub_bot_version_takes_pool(client->bot_version) !=
      hub_bot_version_takes_pool(version)) {
    client->cfg_owed = true;
    g_cfg_owed = true;
  }

  bool changed = strcmp(client->bot_version, version) != 0 ||
                 strcmp(client->bot_server, server) != 0 ||
                 strcmp(client->bot_variant, variant) != 0 ||
                 client->bot_started != (time_t)started ||
                 client->bot_link_ord != (uint64_t)link_ord;
  client->bot_link_ord = (uint64_t)link_ord;
  snprintf(client->bot_version, sizeof(client->bot_version), "%s", version);
  if (held) cfg_hold_release(state, client);
  snprintf(client->bot_server, sizeof(client->bot_server), "%s", server);
  snprintf(client->bot_variant, sizeof(client->bot_variant), "%s", variant);
  if (strcmp(client->bot_cron, cron) != 0) {
    snprintf(client->bot_cron, sizeof(client->bot_cron), "%s", cron);
    state->tree_dirty = true;
  }
  client->bot_started = (time_t)started;

  if (changed) {
    hub_log_info("[PRESENCE] %s: version %s (%s) on %s\n", hub_who_client(state, client),
            version[0] ? version : "?", variant[0] ? variant : "?",
            server[0] ? server : "(no server)");
    hub_roster_mark_dirty(state, true);
    hub_presence_event(state); /* gossip the change now, damped */
  }

  /* A committed node coming back on the target version is the authoritative
   * success signal for a rolling upgrade — CMD_UPGRADE_RESULT can be lost,
   * but without this frame the bot is not on the mesh at all. */
  hub_upgrade_note_presence(state, client->id, version, variant);
  hub_rollup_note_presence(state, client->id, 'b', version);
  hub_upgrade_prepare_late(state, client, version);

  /* If this hub is following a run another hub drives, a local bot reappearing
   * on the followed target is that bot's authoritative success: synthesize a
   * RESULT up to the driver so a lost bot RESULT does not stall the run. */
  char want[8] = "";
  if (state->follow_id[0] &&
      !upgrade_sel_lookup(state->follow_sel, client->id, want, sizeof(want)))
    snprintf(want, sizeof(want), "%s", state->follow_bot_variant);
  if (state->follow_id[0] && version[0] &&
      hub_update_version_cmp(version, state->follow_target) == 0 &&
      (!want[0] || strcmp(variant, want) == 0)) {
    hub_client_t *origin = upgrade_find_peer(state, state->follow_origin);
    if (origin) {
      /* A bot that reports ready itself is only "back". */
      char p[192];
      snprintf(p, sizeof(p), "%s|%s|back|%s|", state->follow_id, client->id,
               version);
      peer_send_urgent(state, origin, CMD_UPGRADE_RESULT, p);
    }
  }
}

/* The nick the config knows this bot by (persisted 'n' key); empty if none. */
static void bot_nick_from_config(hub_state_t *state, const char *uuid,
                                 char *out, size_t cap) {
  if (cap) out[0] = '\0';
  for (int i = 0; i < state->bot_count; i++) {
    if (strcmp(state->bots[i].uuid, uuid) != 0) continue;
    for (int k = 0; k < state->bots[i].entry_count; k++) {
      if (strcmp(state->bots[i].entries[k].key, "n") == 0) {
        roster_clean(out, cap, state->bots[i].entries[k].value);
        return;
      }
    }
    return;
  }
}

/* One roster frame to every authenticated peer except `skip` (NULL: all).
 * Deliberately NOT coalesced: a large roster is chunked into several frames
 * and coalescing on one key would collapse them into whichever arrived last.
 * Best-effort on the BULK lane — a dropped frame just means those bots
 * refresh on the next tick. */
static void roster_send_to_peers(hub_state_t *state, const char *frame,
                                 int len, const hub_client_t *skip,
                                 const mesh_hub_t *origin, const hub_client_t *only) {
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type != CLIENT_HUB || !c->authenticated || c == skip) continue;
    if (only && c != only) continue;
    /* Split horizon for a relayed frame: a peer that IS the origin, or that
     * the origin says it is linked to right now, already has it first hand.
     * On a full mesh this leaves nothing to relay at all. */
    if (origin) {
      const char *cu = upgrade_peer_uuid(state, c);
      bool direct = cu[0] && strcmp(cu, origin->uuid) == 0;
      for (int l = 0; l < origin->link_count && !direct; l++)
        direct = origin->links[l].online && cu[0] &&
                 strcmp(origin->links[l].uuid, cu) == 0;
      if (direct) continue;
    }
    /* Ahead of bulk syncs: after a heal the link list must not wait behind one. */
    queued_msg_t *m = queued_msg_new(CMD_BOT_ROSTER, LANE_DELTA,
                                     (const unsigned char *)frame, len);
    if (!m) continue;
    if (!peer_enqueue(c, m))
      hub_log_warning("[PRESENCE] roster enqueue failed for peer %s\n", c->ip);
  }
}

/* Start one gossip frame: the header lines every frame repeats, the relay
 * line, and — on the first chunk only — this hub's peer links.  Returns the
 * offset rows start at, or -1 if it cannot fit. */
static int roster_frame_begin(hub_state_t *state, char *frame, int cap,
                              long long gen, int chunk, bool last) {
  int off = snprintf(frame, (size_t)cap, "h|%s|%s|%lld|%s\nv|%s\ng|%lld|%d|%d|%d\n",
                     state->hub_uuid[0] ? state->hub_uuid : "-",
                     state->hub_friendly_name[0] ? state->hub_friendly_name
                                                 : "-",
                     (long long)state->hub_started, HUB_VERSION,
                     HUB_UPDATE_VARIANT, gen, chunk, ROSTER_RELAY_HOPS, last ? 1 : 0);
  if (off <= 0 || off >= cap) return -1;
  /* A line of its own, like v|: older hubs skip a line they do not know. */
  if (hub_update_cron_status()[0]) {
    int cw = snprintf(frame + off, (size_t)(cap - off), "c|%s\n", hub_update_cron_status());
    if (cw <= 0 || cw >= cap - off) return -1;
    off += cw;
  }
  /* This hub answers CMD_HUB_ROLLCALL.  Every hub the mesh admits does
   * (MESH_MIN_VERSION 2.5.3); a 2.5.3 hub still asks only hubs that say so. */
  {
    int kw = snprintf(frame + off, (size_t)(cap - off), "k|rollcall\n");
    if (kw <= 0 || kw >= cap - off) return -1;
    off += kw;
  }
  if (chunk != 0) return off;
  for (int p = 0; p < state->peer_count; p++) {
    const hub_peer_config_t *peer = &state->peers[p];
    if (!peer->uuid[0]) continue;
    char pname[64];
    roster_clean(pname, sizeof(pname),
                 peer->friendly_name[0] ? peer->friendly_name : peer->ip);
    int w = snprintf(frame + off, (size_t)(cap - off), "l|%s|%s|%d\n", peer->uuid,
                     pname[0] ? pname : "-",
                     peer_is_linked(state, peer) ? 1 : 0);
    if (w <= 0 || w >= cap - off) return -1;
    off += w;
  }
  return off;
}

/* Gossip the bots connected to THIS hub out to the peers.  Chunked to a byte
 * budget: each frame repeats the h| header and carries whole rows only, so a
 * receiver can apply any frame on its own without waiting for the rest.
 *
 * Frame shape:
 *   h|<hub_uuid>|<name>|<started>|<hub_version>
 *   v|<hub_variant>                          (this hub's code base: c / rs)
 *   g|<gen>|<chunk>|<ttl>|<last>             (relay control, see below; last=1 on
 *                                            the round's final chunk)
 *   l|<peer_uuid>|<peer_name>|<online>       (first chunk only, per peer)
 *   b|<bot_uuid>|<nick>|<version>|<server>|<started>|<variant>
 * The hub's variant is a line of its own, not a sixth h| field: a hub that
 * predates it reads everything after the version's '|' into the version
 * (roster_clean drops the '|'), which would read as "2.4.0c" and stall any
 * upgrade run waiting on "2.4.0".  Older hubs skip an unknown line, which is
 * also why g| and l| are lines of their own.  The b| variant can ride last
 * because older hubs split five fields and atoll() the start time, which
 * stops at the '|'.
 *
 * g| makes the gossip multi-hop: a hub that receives a frame it has not seen
 * (origin, gen, chunk) passes it on with ttl-1, so every hub hears every
 * other hub however the peers are wired.  l| is what lets a receiver draw
 * the mesh deeper than its own peers. */
/* One gossip round, chunked.  `total` < 0 only counts the frames it would send;
 * otherwise it sends them, the frame numbered total-1 marked last.  Returns the
 * frames (to be) sent, or -1. */
static int roster_round(hub_state_t *state, long long gen, int total,
                        const hub_client_t *only) {
  char frame[ROSTER_FRAME_BUDGET];
  bool send = total >= 0;
  int chunk = 0;
  int offset = roster_frame_begin(state, frame, sizeof(frame), gen, chunk, total == 1);
  if (offset < 0) return -1;
  int rows = 0, frames = 0;

  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type != CLIENT_BOT || !c->authenticated || c->retiring) continue;

    char nick[MAX_NICK];
    bot_nick_from_config(state, c->id, nick, sizeof(nick));
    /* + the i| and j| riders */
    char row[TREE_ROW_MAX + CRON_STATUS_MAX + 48 + 128 + POOL_NET_NAME_MAX + CHAN_STATE_MAX + 48];
    /* 7th field: when the bot linked to this hub; 8th: the bot's address as
     * this hub sees it; 9th: its crontab status; 10th (phase 4): the bot's
     * link-order counter (a hub that predates any of them stops reading before
     * it). */
    int rl = snprintf(row, sizeof(row), "b|%s|%s|%s|%s|%lld|%s|%lld|%s|%s|%llu\n", c->id,
                      nick[0] ? nick : "-",
                      c->bot_version[0] ? c->bot_version : "-",
                      c->bot_server[0] ? c->bot_server : "-",
                      (long long)c->bot_started,
                      c->bot_variant[0] ? c->bot_variant : "-",
                      (long long)c->connected_at, c->ip[0] ? c->ip : "-",
                      c->bot_cron[0] ? c->bot_cron : "-",
                      (unsigned long long)c->bot_link_ord);
    if (rl <= 0 || rl >= (int)sizeof(row)) continue; /* unrepresentable row */
    /* Server pool: the IRC link's entry and state, on the row's heels so a
     * chunk never splits the two (an older hub skips the i| tag). */
    if (c->bot_irc_link[0]) {
      int il = snprintf(row + rl, sizeof(row) - (size_t)rl, "i|%s|%s|%s|%s|%s|\n", c->id,
                        POOL_DEFAULT_NET, c->bot_irc_entry[0] ? c->bot_irc_entry : "-",
                        c->bot_irc_link, c->bot_irc_network[0] ? c->bot_irc_network : "-");
      if (il > 0 && il < (int)sizeof(row) - rl) rl += il;
      else row[rl] = '\0';
    }
    /* bot show's channels line (an older hub skips the j| tag) */
    if (c->bot_chan_state[0]) {
      int jl = snprintf(row + rl, sizeof(row) - (size_t)rl, "j|%s|%s|\n", c->id, c->bot_chan_state);
      if (jl > 0 && jl < (int)sizeof(row) - rl) rl += jl;
      else row[rl] = '\0';
    }

    if (offset + rl >= (int)sizeof(frame) && rows > 0) { /* full: flush */
      if (send) roster_send_to_peers(state, frame, offset, NULL, NULL, only);
      frames++;
      chunk++;
      offset = roster_frame_begin(state, frame, sizeof(frame), gen, chunk, chunk == total - 1);
      if (offset < 0) return -1;
      rows = 0;
    }
    if (offset + rl >= (int)sizeof(frame)) continue; /* still won't fit */
    memcpy(frame + offset, row, (size_t)rl);
    offset += rl;
    rows++;
  }

  /* Always send a final frame, even carrying no bots: the header doubles as
   * this hub's liveness and uptime beacon, which is what lets a peer show an
   * empty hub in the tree with a real uptime instead of a blank. */
  if (rows > 0 || frames == 0) {
    if (send) roster_send_to_peers(state, frame, offset, NULL, NULL, only);
    frames++;
  }
  return frames;
}

/* Gossip the bots connected to THIS hub out to the peers, as one round: the
 * receivers drop this hub's bots the round no longer lists (see roster_round_done). */
static void hub_gossip_bot_roster(hub_state_t *state) {
  if (state->peer_count == 0) return;
  time_t now = time(NULL);
  /* Generations only ever grow, across restarts too (wall-clock based), so a
   * receiver can tell a new round from a late copy of an old one. */
  long long gen = (long long)now * 1000;
  if (gen <= state->roster_gen) gen = state->roster_gen + 1;
  state->roster_gen = gen;
  int total = roster_round(state, gen, -1, NULL);
  if (total > 0) roster_round(state, gen, total, NULL);
  state->last_presence_gossip = now;
  state->presence_event_due = false;
}

/* A peer link just authenticated: one round of our own, to it alone and past
 * the damping.  A hub that restarted knows nothing of us until our gossip
 * reaches it — not our bots, and not that we answer a roll call (k|), so its
 * upgrade gates would fall back to the gossip check for up to a full
 * BOT_PRESENCE_INTERVAL.  A fresh generation, so it relays and replaces like
 * any round; the other peers' damping clock is left alone. */
void hub_roster_send_to_peer(hub_state_t *state, const hub_client_t *peer) {
  if (!peer || peer->type != CLIENT_HUB || !peer->authenticated) return;
  long long gen = (long long)time(NULL) * 1000;
  if (gen <= state->roster_gen) gen = state->roster_gen + 1;
  state->roster_gen = gen;
  int total = roster_round(state, gen, -1, peer);
  if (total > 0) roster_round(state, gen, total, peer);
}

/* Read the h| and g| lines of a roster frame without touching it.  Returns
 * true when the frame carries a g| relay line. */
static bool roster_frame_peek(const char *payload, char *origin, size_t ocap,
                              long long *started, long long *gen, int *chunk,
                              int *ttl, bool *last) {
  bool have_g = false;
  origin[0] = '\0';
  *started = 0;
  *last = false;
  for (const char *line = payload; line && *line;) {
    const char *nl = strchr(line, '\n');
    size_t len = nl ? (size_t)(nl - line) : strlen(line);
    char buf[256];
    if (len < sizeof(buf)) {
      memcpy(buf, line, len);
      buf[len] = '\0';
      if (strncmp(buf, "h|", 2) == 0 && !origin[0]) {
        char tmp[64] = "", st[24] = "";
        if (wire_field(buf + 2, 0, tmp, sizeof(tmp)))
          roster_clean(origin, ocap, tmp);
        if (wire_field(buf + 2, 2, st, sizeof(st))) *started = atoll(st);
      } else if (strncmp(buf, "g|", 2) == 0 && !have_g) {
        char g[24] = "", c[12] = "", t[12] = "";
        if (wire_field(buf + 2, 0, g, sizeof(g)) &&
            wire_field(buf + 2, 1, c, sizeof(c)) &&
            wire_field(buf + 2, 2, t, sizeof(t)) && g[0]) {
          *gen = atoll(g);
          *chunk = atoi(c);
          *ttl = atoi(t);
          char l[4] = "";
          *last = wire_field(buf + 2, 3, l, sizeof(l)) && l[0] == '1';
          have_g = true;
        }
      }
    }
    line = nl ? nl + 1 : NULL;
  }
  return have_g;
}

/* The same frame with its g| ttl replaced, for the next hop.  Returns the new
 * length, or -1. */
static int roster_frame_rettl(const char *payload, char *out, int cap,
                              long long gen, int chunk, int ttl, bool last) {
  int off = 0;
  for (const char *line = payload; line && *line;) {
    const char *nl = strchr(line, '\n');
    size_t len = nl ? (size_t)(nl - line) : strlen(line);
    int w;
    if (strncmp(line, "g|", 2) == 0)
      w = snprintf(out + off, (size_t)(cap - off), "g|%lld|%d|%d|%d\n", gen, chunk, ttl,
                   last ? 1 : 0);
    else
      w = snprintf(out + off, (size_t)(cap - off), "%.*s\n", (int)len, line);
    if (w <= 0 || w >= cap - off) return -1;
    off += w;
    line = nl ? nl + 1 : NULL;
  }
  return off;
}

/* A hub told us which bots are on it — a peer about itself, or any hub
 * further out, relayed.  `from` is the peer link it arrived on. */
static void process_bot_roster(hub_state_t *state, hub_client_t *from,
                               char *payload) {
  char hub_uuid[64] = "", hub_name[64] = "";
  time_t now = time(NULL);
  char *saveptr = NULL;

  /* Relay bookkeeping first, on the untouched frame. */
  char origin[64];
  long long o_started = 0, gen = 0;
  int chunk = 0, ttl = 0;
  bool last = false;
  bool relayable = roster_frame_peek(payload, origin, sizeof(origin),
                                     &o_started, &gen, &chunk, &ttl, &last);
  if (!origin[0] || strcmp(origin, "-") == 0) return;
  if (state->hub_uuid[0] && strcmp(origin, state->hub_uuid) == 0)
    return; /* our own gossip, back around a cycle */
  mesh_hub_t *mh = mesh_hub_get(state, origin);
  if (relayable && mh) {
    /* A restarted origin starts its generations over from its clock, so a
     * new start time resets the window rather than reading as stale. */
    if (o_started > 0 && mh->started > 0 && (time_t)o_started != mh->started) {
      mh->gen = -1;
      mh->chunks_seen = 0;
    }
    if (gen < mh->gen) return; /* a late copy of an older round */
    uint64_t bit = (chunk >= 0 && chunk < 64) ? (1ULL << chunk) : 0;
    if (gen == mh->gen && (!bit || (mh->chunks_seen & bit))) return;
    if (gen > mh->gen) {
      mh->gen = gen;
      mh->chunks_seen = 0;
    }
    mh->chunks_seen |= bit;
  }
  char *relay = NULL;
  int relay_len = -1;
  if (relayable && mh && ttl > 1 && ttl <= ROSTER_RELAY_HOPS) {
    relay = malloc(ROSTER_FRAME_BUDGET + 64);
    if (relay)
      relay_len = roster_frame_rettl(payload, relay, ROSTER_FRAME_BUDGET + 64,
                                     gen, chunk, ttl - 1, last);
  }
  bool links_reset = false;
  /* The link list this frame replaces: re-rendering every bot's tree is only
   * worth it when the list really changed, not on every gossip round. */
  mesh_link_t old_links[MAX_PEERS];
  int old_link_count = -1;

  for (char *line = strtok_r(payload, "\n", &saveptr); line;
       line = strtok_r(NULL, "\n", &saveptr)) {
    if (strncmp(line, "h|", 2) == 0) {
      char *f1 = strchr(line + 2, '|');
      if (!f1) continue;
      *f1 = '\0';
      char *f2 = strchr(f1 + 1, '|');
      long long started = 0;
      char hub_ver[ROSTER_VERSION_MAX + 1] = "";
      if (f2) {
        *f2 = '\0';
        char *f3 = strchr(f2 + 1, '|');
        if (f3) { *f3 = '\0'; roster_clean(hub_ver, sizeof(hub_ver), f3 + 1); }
        started = atoll(f2 + 1);
      }
      roster_clean(hub_uuid, sizeof(hub_uuid), line + 2);
      roster_clean(hub_name, sizeof(hub_name), f1 + 1);
      if (!hub_uuid[0]) continue;
      bool sane_start = started > 0 && (time_t)started <= now;
      /* The header doubles as the remote hub's uptime and version beacon.
       * Clamp rather than trust: a peer's clock skew would render as a
       * negative uptime. */
      if (mh && strcmp(mh->uuid, hub_uuid) == 0) {
        if (strcmp(mh->name, hub_name) != 0 ||
            strcmp(mh->version, hub_ver) != 0 ||
            (sane_start && mh->started != (time_t)started))
          state->tree_dirty = true;
        snprintf(mh->name, sizeof(mh->name), "%s", hub_name);
        snprintf(mh->version, sizeof(mh->version), "%s", hub_ver);
        if (sane_start) mh->started = (time_t)started;
        mh->reported_at = now;
      }
      for (int p = 0; p < state->peer_count; p++) {
        if (!state->peers[p].uuid[0] ||
            strcmp(state->peers[p].uuid, hub_uuid) != 0)
          continue;
        if (sane_start && state->peers[p].remote_started != (time_t)started) {
          state->peers[p].remote_started = (time_t)started;
          state->tree_dirty = true;
        }
        if (strcmp(state->peers[p].remote_version, hub_ver) != 0) {
          snprintf(state->peers[p].remote_version,
                   sizeof(state->peers[p].remote_version), "%s", hub_ver);
          state->tree_dirty = true;
        }
        break;
      }
      /* D4 of the 2.5.1 plan: a direct peer below MESH_MIN_VERSION loses
       * its link once its own roster header names its version (relayed
       * headers of hubs further away are only shown). */
      if (hub_ver[0] && hub_update_version_cmp(hub_ver, MESH_MIN_VERSION) < 0 &&
          strcmp(hub_uuid, upgrade_peer_uuid(state, from)) == 0) {
        hub_log_warning("[MESH] Peer %s (%s) runs %s: link refused; upgrade it by "
                        "hand to %s\n", hub_name, from->ip, hub_ver, MESH_MIN_VERSION);
        from->refused = true;
        free(relay);
        return;
      }
      /* Review 6: every direct peer offers CMD_LINK_SEQ on connect. */
      if (hub_ver[0] && !from->link_offered &&
          strcmp(hub_uuid, upgrade_peer_uuid(state, from)) == 0) {
        hub_log_warning("[MESH] Peer %s (%s) runs %s but never offered the sequenced link "
                        "framing (a frame stripped on the way?): link dropped\n",
                        hub_name, from->ip, hub_ver);
        from->refused = true;
        free(relay);
        return;
      }
      /* Same authoritative signal the bots give through their presence: a
       * hub node of a run we drive is done when it reappears in the gossip on
       * the target version.  Its CMD_UPGRADE_RESULT can be lost — several
       * hops more of it, now that a run reaches the whole mesh — but this
       * gossip cannot, or the hub is not on the mesh at all.  Relayed gossip
       * counts too: that is how a hub several hops out reports in.
       * No roll-up here: a peer hub is never rolled up by a PREPARE from its
       * neighbour.  A peer cannot tell a single-node roll-up PREPARE from a
       * run's, so it would fan the frame out to the whole mesh — and every
       * hub holding the plan would do the same to every other, which is the
       * storm a hub-and-bot net produced. */
      /* No variant here: it follows on the v| line, so a hub asked to switch
       * build at the same version is proven by its RESULT alone. */
      hub_upgrade_note_presence(state, hub_uuid, hub_ver, "");
      continue;
    }
    if (strncmp(line, "v|", 2) == 0) {
      /* The code base of the hub whose h| header this frame opened with. */
      if (!hub_uuid[0] || strcmp(hub_uuid, "-") == 0) continue;
      char hv[ROSTER_VARIANT_MAX + 1];
      roster_clean(hv, sizeof(hv), line + 2);
      if (mh && strcmp(mh->uuid, hub_uuid) == 0 && strcmp(mh->variant, hv) != 0) {
        snprintf(mh->variant, sizeof(mh->variant), "%s", hv);
        state->tree_dirty = true;
      }
      for (int p = 0; p < state->peer_count; p++) {
        if (!state->peers[p].uuid[0] ||
            strcmp(state->peers[p].uuid, hub_uuid) != 0)
          continue;
        if (strcmp(state->peers[p].remote_variant, hv) != 0) {
          snprintf(state->peers[p].remote_variant,
                   sizeof(state->peers[p].remote_variant), "%s", hv);
          state->tree_dirty = true;
        }
        break;
      }
      continue;
    }
    if (strncmp(line, "c|", 2) == 0) {
      /* The production crontab line of the hub whose h| header opened it. */
      if (!mh || strcmp(mh->uuid, hub_uuid) != 0) continue;
      char hc[CRON_STATUS_MAX + 1];
      roster_clean(hc, sizeof(hc), line + 2);
      if (strcmp(mh->cron, hc) != 0) {
        snprintf(mh->cron, sizeof(mh->cron), "%s", hc);
        state->tree_dirty = true;
      }
      continue;
    }
    if (strncmp(line, "k|", 2) == 0) continue; /* capabilities: every hub answers a roll call */
    if (strncmp(line, "i|", 2) == 0) {
      /* Server pool: a bot's IRC link, right after its b| row (upserted above). */
      if (!hub_uuid[0] || strcmp(hub_uuid, "-") == 0) continue;
      char bu[64] = "", ent[POOL_UUID_LEN + 2] = "", lk[POOL_LINK_WORD_MAX + 1] = "";
      if (!wire_field(line + 2, 0, bu, sizeof(bu)) || !wire_field(line + 2, 2, ent, sizeof(ent)) ||
          !wire_field(line + 2, 3, lk, sizeof(lk)))
        continue;
      if (!hub_pool_link_word_ok(lk) || (strcmp(ent, "-") != 0 && strlen(ent) != POOL_UUID_LEN))
        continue;
      for (int r = 0; r < state->roster_count; r++) {
        bot_roster_t *e = &state->roster[r];
        if (strcmp(e->bot_uuid, bu) != 0 || strcmp(e->hub_uuid, hub_uuid) != 0) continue;
        roster_clean(e->irc_entry, sizeof(e->irc_entry), strcmp(ent, "-") ? ent : "");
        snprintf(e->irc_link, sizeof(e->irc_link), "%s", lk);
        /* field 4 (2.5.4): NETWORK=; absent or bad reads as unknown */
        char nw[POOL_NET_NAME_MAX + 1] = ""; /* wire_field refuses a longer field */
        bool has_nw = wire_field(line + 2, 4, nw, sizeof(nw)) && strcmp(nw, "-") != 0 &&
                      pool_net_name_ok(nw);
        snprintf(e->irc_network, sizeof(e->irc_network), "%s", has_nw ? nw : "");
        break;
      }
      continue;
    }
    if (strncmp(line, "j|", 2) == 0) {
      /* bot show's channels line, right after its b| row */
      if (!hub_uuid[0] || strcmp(hub_uuid, "-") == 0) continue;
      char bu[64] = "";
      char *list = malloc(CHAN_STATE_MAX + 2);
      if (!list) continue;
      if (wire_field(line + 2, 0, bu, sizeof(bu)) &&
          wire_field(line + 2, 1, list, CHAN_STATE_MAX + 2) && hub_chan_state_ok(list)) {
        for (int r = 0; r < state->roster_count; r++) {
          bot_roster_t *e = &state->roster[r];
          if (strcmp(e->bot_uuid, bu) != 0 || strcmp(e->hub_uuid, hub_uuid) != 0) continue;
          snprintf(e->chan_state, sizeof(e->chan_state), "%s", list);
          break;
        }
      }
      free(list);
      continue;
    }
    if (strncmp(line, "l|", 2) == 0) {
      /* The origin's peer links, first chunk of a round only: the list
       * replaces what we had, so a link it dropped disappears. */
      if (!relayable || chunk != 0 || !mh || strcmp(mh->uuid, hub_uuid) != 0)
        continue;
      if (!links_reset) {
        old_link_count = mh->have_links ? mh->link_count : -1;
        if (old_link_count > 0)
          memcpy(old_links, mh->links, sizeof(mesh_link_t) * (size_t)old_link_count);
        mh->link_count = 0;
        mh->have_links = true;
        mh->links_at = now;
        links_reset = true;
      }
      char lu[64] = "", ln[64] = "", lo[4] = "";
      if (!wire_field(line + 2, 0, lu, sizeof(lu)) ||
          !wire_field(line + 2, 1, ln, sizeof(ln)) ||
          !wire_field(line + 2, 2, lo, sizeof(lo)))
        continue;
      if (mh->link_count >= MAX_PEERS) continue;
      mesh_link_t *L = &mh->links[mh->link_count];
      roster_clean(L->uuid, sizeof(L->uuid), lu);
      if (!L->uuid[0]) continue;
      roster_clean(L->name, sizeof(L->name), ln);
      L->online = lo[0] == '1';
      mh->link_count++;
      continue;
    }
    if (strncmp(line, "b|", 2) != 0) continue;
    /* A row before its header has no hub to hang off — ignore it rather than
     * guess, so a malformed frame cannot graft bots onto the wrong branch. */
    if (!hub_uuid[0] || strcmp(hub_uuid, "-") == 0) continue;
    /* Never let a peer report bots as belonging to US: our own branch is
     * built from our live client list and nothing else. */
    if (state->hub_uuid[0] && strcmp(hub_uuid, state->hub_uuid) == 0) continue;

    /* Five fields from any hub; a sixth (the bot's code base), a seventh
     * (when it linked to that hub) and an eighth (its address) from one that
     * knows them. */
    char *fields[10] = {NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL};
    char *cur = line + 2;
    int n = 0;
    while (n < 10) {
      fields[n++] = cur;
      char *sep = strchr(cur, '|');
      if (!sep) break;
      *sep = '\0';
      cur = sep + 1;
    }
    if (n < 5 || !fields[0] || !fields[0][0]) continue;

    bot_roster_t e;
    memset(&e, 0, sizeof(e));
    snprintf(e.hub_uuid, sizeof(e.hub_uuid), "%s", hub_uuid);
    snprintf(e.hub_name, sizeof(e.hub_name), "%s",
             hub_name[0] ? hub_name : hub_uuid);
    roster_clean(e.bot_uuid, sizeof(e.bot_uuid), fields[0]);
    if (!e.bot_uuid[0]) continue;
    if (strcmp(fields[1], "-") != 0) roster_clean(e.nick, sizeof(e.nick), fields[1]);
    if (strcmp(fields[2], "-") != 0) roster_clean(e.version, sizeof(e.version), fields[2]);
    if (strcmp(fields[3], "-") != 0) roster_clean(e.server, sizeof(e.server), fields[3]);
    if (n >= 6 && strcmp(fields[5], "-") != 0)
      roster_clean(e.variant, sizeof(e.variant), fields[5]);
    if (n >= 9 && strcmp(fields[8], "-") != 0)
      roster_clean(e.cron, sizeof(e.cron), fields[8]);
    long long started = atoll(fields[4]);
    /* Clamp a peer's clock skew rather than trusting it: a future start time
     * would render as a negative uptime. */
    e.connected_at = (started > 0 && (time_t)started <= now) ? (time_t)started : 0;
    if (n >= 7) {
      long long since = atoll(fields[6]);
      e.link_since = (since > 0 && (time_t)since <= now) ? (time_t)since : 0;
    }
    if (n >= 10 && fields[9][0]) {
      char *end = NULL;
      errno = 0;
      unsigned long long v = strtoull(fields[9], &end, 10);
      if (!errno && end && !*end && end != fields[9]) e.link_ord = (uint64_t)v;
    }
    /* Display only, but still a peer's word: an IPv4/IPv6 literal or nothing. */
    if (n >= 8 && fields[7][0] && strcmp(fields[7], "-") != 0 &&
        strlen(fields[7]) <= ROSTER_IP_MAX &&
        strspn(fields[7], "0123456789abcdefABCDEF:.") == strlen(fields[7]))
      snprintf(e.ip, sizeof(e.ip), "%s", fields[7]);
    e.reported_at = now;
    e.gen = relayable && mh && strcmp(hub_uuid, origin) == 0 ? gen : 0;
    roster_upsert(state, &e);
  }
  if (relayable && mh && last) roster_round_done(state, mh, chunk);

  if (links_reset && !mesh_links_equal(old_links, old_link_count, mh->links,
                                        mh->link_count))
    state->tree_dirty = true;

  /* Pass it on after applying it, so the split horizon uses the links this
   * very frame just reported. */
  if (relay && relay_len > 0)
    roster_send_to_peers(state, relay, relay_len, from, mh, NULL);
  free(relay);
}

/* One hub node of the tree while it is being laid out. */
enum { TREE_HUBS = MAX_MESH_HUBS + MAX_PEERS + 1 };
typedef struct {
  char uuid[64];
  char name[64];
  bool online;
  int depth, parent; /* parent: index into the same array, -1 = the root */
} tree_hub_t;

/* Is `uuid` this hub, or already placed in the tree? */
static bool tree_hub_placed(const hub_state_t *state, const tree_hub_t *th,
                            int nth, const char *uuid) {
  if (strcmp(uuid, state->hub_uuid) == 0) return true;
  for (int k = 0; k < nth; k++)
    if (strcmp(th[k].uuid, uuid) == 0) return true;
  return false;
}

/* Build the tree for the bots on THIS hub, in DFS pre-order.  Row shapes:
 *   H|<depth>|<name>|<uuid>|<online>|<uptime>|<version>|<variant>
 *   B|<depth>|<nick>|<uuid>|<version>|<server>|<uptime>|<variant>
 *   D|<nick>|<uuid>|<last_seen>            (offline; always the tail)
 * Depth plus pre-order is all a renderer needs to draw the connectors: a node
 * is the last child at its level when no later row shares its depth before a
 * shallower one appears.  The bot does the drawing (commands.c) so the glyphs
 * can change without a hub deploy.
 *
 * Rooted at this hub because that is the vantage point the asking bot has:
 * its own hub first, its peer hubs beneath it, and every hub further out
 * beneath the hub that links to it (from the relayed gossip).  The same
 * network legitimately renders differently depending on which bot you ask. */
/* A set of row keys (uuids), open-addressed over TREE_USET_SLOTS pointers.
 * The strings are the caller's and must outlive the set; `len` < 0 means
 * NUL-terminated.  tree_uset_add: true when `u` was not in the set yet. */
typedef struct {
  const char *k[TREE_USET_SLOTS];
  int         l[TREE_USET_SLOTS];
} tree_uset_t;

static bool tree_uset_add(tree_uset_t *set, const char *u, int len) {
  if (len < 0) len = (int)strlen(u);
  uint64_t h = 0xcbf29ce484222325ULL;
  for (int i = 0; i < len; i++) {
    h ^= (unsigned char)u[i];
    h *= 1099511628211ULL;
  }
  for (size_t i = (size_t)h & (TREE_USET_SLOTS - 1);; i = (i + 1) & (TREE_USET_SLOTS - 1)) {
    if (!set->k[i]) {
      set->k[i] = u;
      set->l[i] = len;
      return true;
    }
    if (set->l[i] == len && memcmp(set->k[i], u, (size_t)len) == 0) return false;
  }
}

static bool tree_uset_has(const tree_uset_t *set, const char *u, int len) {
  uint64_t h = 0xcbf29ce484222325ULL;
  for (int i = 0; i < len; i++) {
    h ^= (unsigned char)u[i];
    h *= 1099511628211ULL;
  }
  for (size_t i = (size_t)h & (TREE_USET_SLOTS - 1); set->k[i];
       i = (i + 1) & (TREE_USET_SLOTS - 1))
    if (set->l[i] == len && memcmp(set->k[i], u, (size_t)len) == 0) return true;
  return false;
}

static int hub_build_tree(hub_state_t *state, char *buf, int max_len) {
  int offset = 0, written;
  buf[0] = '\0';
  /* the bots listed so far: each once (see below) */
  tree_uset_t *listed = calloc(1, sizeof(*listed));
  if (!listed) return 0;

  /* <variant> is the code base (c / rs); after it comes <started>, the
   * node's absolute start time (0 = unknown), from which the bot works out
   * the uptime itself.  A bot that predates a field splits a fixed field
   * count and never looks past it.  The old uptime field is always 0: a tree
   * that says the same thing is then the same bytes, and an unchanged tree is
   * not pushed again (hub_push_tree_to_bots). */
  written = snprintf(buf, (size_t)max_len, "H|0|%s|%s|1|0|%s|%s|%lld|%s\n",
                     state->hub_friendly_name[0] ? state->hub_friendly_name
                                                 : "hub",
                     state->hub_uuid[0] ? state->hub_uuid : "-",
                     HUB_VERSION, HUB_UPDATE_VARIANT,
                     (long long)state->hub_started,
                     hub_update_cron_status()[0] ? hub_update_cron_status() : "-");
  if (written < 0 || written >= max_len) {
    free(listed);
    return 0;
  }
  offset += written;

  /* Our own bots, from the live client list — never from a peer's report.
   * Each bot once (uuid-keyed row deltas need unique rows): a superseded
   * session still open during a reconnect, or a moved bot a peer's roster
   * still reports, would list it twice.  Our own live session comes first. */
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type != CLIENT_BOT || !c->authenticated || c->superseded) continue;
    if (max_len - offset <= TREE_ROW_MAX) break;
    if (!tree_uset_add(listed, c->id, -1)) continue;
    char nick[MAX_NICK];
    bot_nick_from_config(state, c->id, nick, sizeof(nick));
    written = snprintf(buf + offset, (size_t)(max_len - offset),
                       "B|1|%s|%s|%s|%s|0|%s|%lld|%s\n",
                       nick[0] ? nick : "-", c->id,
                       c->bot_version[0] ? c->bot_version : "-",
                       c->bot_server[0] ? c->bot_server : "-",
                       c->bot_variant[0] ? c->bot_variant : "-",
                       (long long)c->bot_started, c->bot_cron[0] ? c->bot_cron : "-");
    if (written < 0 || written >= max_len - offset) break;
    offset += written;
  }

  /* Every other hub, breadth-first from here: our configured peers at depth
   * 1 (linked or not — "configured, down" is worth showing), then whatever
   * each linked hub reports it is linked to, one level further out.  A hub is
   * placed once, at the first (so the shortest) path found; a hub only
   * reported through a DOWN link is hung, unlinked, under the first hub that
   * reports it once the live mesh has been walked.  Emitted depth-first
   * below, since pre-order plus depth is what the renderer reads. */
  tree_hub_t *th = calloc(TREE_HUBS, sizeof(*th));
  if (!th) {
    free(listed);
    return offset;
  }
  int nth = 0;
  for (int p = 0; p < state->peer_count && nth < TREE_HUBS; p++) {
    hub_peer_config_t *peer = &state->peers[p];
    snprintf(th[nth].uuid, sizeof(th[nth].uuid), "%s",
             peer->uuid[0] ? peer->uuid : "-");
    roster_clean(th[nth].name, sizeof(th[nth].name),
                 peer->friendly_name[0] ? peer->friendly_name : peer->ip);
    th[nth].online = peer_is_linked(state, peer);
    th[nth].depth = 1;
    th[nth].parent = -1;
    nth++;
  }
  for (int pass = 0; pass < 2; pass++) {
    /* pass 0 walks live links only; pass 1 hangs what is left, unlinked. */
    for (int i = 0; i < nth && nth < TREE_HUBS; i++) {
      if (!th[i].online || th[i].depth >= MAX_TREE_DEPTH) continue;
      const mesh_hub_t *mh = mesh_hub_find(state, th[i].uuid);
      if (!mh) continue;
      for (int l = 0; l < mh->link_count && nth < TREE_HUBS; l++) {
        const mesh_link_t *L = &mh->links[l];
        if (L->online != (pass == 0) ||
            tree_hub_placed(state, th, nth, L->uuid))
          continue;
        snprintf(th[nth].uuid, sizeof(th[nth].uuid), "%s", L->uuid);
        const mesh_hub_t *lh = mesh_hub_find(state, L->uuid);
        roster_clean(th[nth].name, sizeof(th[nth].name),
                     lh && lh->name[0] ? lh->name : L->name);
        th[nth].online = L->online;
        th[nth].depth = th[i].depth + 1;
        th[nth].parent = i;
        nth++;
      }
    }
  }

  /* Depth-first emission: a hub, its bots, then its child hubs. */
  int stack[TREE_HUBS], sp = 0;
  for (int i = nth - 1; i >= 0; i--)
    if (th[i].parent < 0) stack[sp++] = i;
  while (sp > 0) {
    int i = stack[--sp];
    if (max_len - offset <= TREE_ROW_MAX) break;
    const char *puuid = strcmp(th[i].uuid, "-") != 0 ? th[i].uuid : "";
    /* Uptime / version / code base: from our own peer record for a direct
     * peer, else from the hub's own (relayed) gossip. */
    time_t started = 0;
    const char *ver = "", *var = "";
    for (int p = 0; p < state->peer_count && puuid[0]; p++) {
      if (strcmp(state->peers[p].uuid, puuid) != 0) continue;
      started = state->peers[p].remote_started;
      ver = state->peers[p].remote_version;
      var = state->peers[p].remote_variant;
      break;
    }
    const mesh_hub_t *mh = puuid[0] ? mesh_hub_find(state, puuid) : NULL;
    if (mh) {
      if (!started) started = mh->started;
      if (!ver[0]) ver = mh->version;
      if (!var[0]) var = mh->variant;
    }
    written = snprintf(buf + offset, (size_t)(max_len - offset),
                       "H|%d|%s|%s|%d|0|%s|%s|%lld|%s\n", th[i].depth,
                       th[i].name[0] ? th[i].name : "peer",
                       puuid[0] ? puuid : "-", th[i].online ? 1 : 0,
                       ver[0] ? ver : "-", var[0] ? var : "-",
                       (long long)started, mh && mh->cron[0] ? mh->cron : "-");
    if (written < 0 || written >= max_len - offset) break;
    offset += written;

    if (puuid[0]) {
      for (int r = 0; r < state->roster_count; r++) {
        bot_roster_t *e = &state->roster[r];
        if (strcmp(e->hub_uuid, puuid) != 0) continue;
        if (hub_p2_hub_gone(state, puuid)) break; /* unreachable now: hide at once */
        if (max_len - offset <= TREE_ROW_MAX) break;
        if (!tree_uset_add(listed, e->bot_uuid, -1)) continue;
        written = snprintf(buf + offset, (size_t)(max_len - offset),
                           "B|%d|%s|%s|%s|%s|0|%s|%lld|%s\n", th[i].depth + 1,
                           e->nick[0] ? e->nick : "-", e->bot_uuid,
                           e->version[0] ? e->version : "-",
                           e->server[0] ? e->server : "-",
                           e->variant[0] ? e->variant : "-",
                           (long long)e->connected_at, e->cron[0] ? e->cron : "-");
        if (written < 0 || written >= max_len - offset) break;
        offset += written;
      }
    }
    for (int k = nth - 1; k > i; k--)
      if (th[k].parent == i && sp < TREE_HUBS) stack[sp++] = k;
  }
  free(th);
  free(listed);

  /* Bots the config knows but nobody currently reports.  'seen' is already
   * persisted and replicated, so this needs no new storage — it is the one
   * place the tree reads the config store, and it reads it read-only. */
  for (int i = 0; i < state->bot_count; i++) {
    bot_config_t *b = &state->bots[i];
    if (!b->is_active) continue;
    if (max_len - offset <= TREE_ROW_MAX) break;

    bool live = false;
    for (int c = 0; c < state->client_count && !live; c++)
      if (state->clients[c]->type == CLIENT_BOT &&
          state->clients[c]->authenticated &&
          strcmp(state->clients[c]->id, b->uuid) == 0)
        live = true;
    for (int r = 0; r < state->roster_count && !live; r++)
      if (strcmp(state->roster[r].bot_uuid, b->uuid) == 0) live = true;
    if (live) continue;

    time_t last_seen = b->last_sync_time;
    char nick[MAX_NICK] = "";
    for (int k = 0; k < b->entry_count; k++) {
      if (strcmp(b->entries[k].key, "seen") == 0) {
        if (b->entries[k].timestamp > last_seen) last_seen = b->entries[k].timestamp;
      } else if (strcmp(b->entries[k].key, "n") == 0) {
        roster_clean(nick, sizeof(nick), b->entries[k].value);
      }
    }
    written = snprintf(buf + offset, (size_t)(max_len - offset), "D|%s|%s|%lld\n",
                       nick[0] ? nick : "-", b->uuid, (long long)last_seen);
    if (written < 0 || written >= max_len - offset) break;
    offset += written;
  }
  return offset;
}

/* Push the assembled tree to every connected bot.  Coalesced per bot so a
 * burst of roster changes collapses to one send per drain cycle; a bot that
 * already holds this exact tree is skipped.  On a quiet mesh the keepalive
 * tree hash (hub_bot_ping_payload) is what keeps a bot's tree from looking
 * stale (BOT_TREE_STALE_AFTER). */
/* Phase 5: FNV-1a 64 over the whole tree text — the hash carried in each row
 * delta so a bot that applied one can tell its tree matches ours, and pull the
 * whole tree when it does not. */
static uint64_t tree_fnv64(const char *s, int n) {
  uint64_t h = 0xcbf29ce484222325ULL; /* FNV-1a 64 offset basis: irchub.rs and both bots must match */
  for (int i = 0; i < n; i++) {
    h ^= (unsigned char)s[i];
    h *= 1099511628211ULL;
  }
  return h;
}

/* The uuid of a tree row, "" if malformed: field 3 of KIND|depth|name|uuid|...,
 * but field 2 of an offline row D|nick|uuid|last_seen (its field 3 is a time
 * that offline bots share, which made deltas hit the wrong row).  The bots'
 * row key (ircbot bot_row_uuid, ircbot.rs tree_row_uuid) must match. */
static void tree_row_uuid(const char *line, int linelen, char *out, size_t cap) {
  out[0] = '\0';
  int bars = 0;
  int want = (linelen > 0 && line[0] == 'D') ? 2 : 3;
  for (int i = 0; i < linelen; i++) {
    if (line[i] == '|' && ++bars == want) {
      size_t o = 0;
      for (int j = i + 1; j < linelen && line[j] != '|' && o + 1 < cap; j++) out[o++] = line[j];
      out[o] = '\0';
      return;
    }
  }
}

typedef struct {
  char uuid[64];
  const char *line;
  int len;
} trow_t;

static int tree_parse_rows(const char *text, int textlen, trow_t *rows, int max) {
  int n = 0, i = 0;
  while (i < textlen && n < max) {
    int start = i;
    while (i < textlen && text[i] != '\n') i++;
    int len = i - start;
    if (len > 0) {
      rows[n].line = text + start;
      rows[n].len = len;
      tree_row_uuid(text + start, len, rows[n].uuid, sizeof(rows[n].uuid));
      n++;
    }
    if (i < textlen) i++; /* skip '\n' */
  }
  return n;
}

/* Every row has a key and no key repeats: the rows a delta addresses by uuid
 * are then exactly one each.  `set` gets the keys. */
static bool tree_rows_keyed(const trow_t *rows, int n, tree_uset_t *set) {
  for (int i = 0; i < n; i++)
    if (!rows[i].uuid[0] || !tree_uset_add(set, rows[i].uuid, -1)) return false;
  return true;
}

/* Build the row-delta from `oldt` to `newt` into `out`: `<fnvhex>\n`, then a
 * `-|uuid` for each row that went and a `+|anchor|row` for each row added,
 * moved or changed (anchor = the uuid of the row it now follows, `^` at head:
 * no uuid is `^`, while `-` is the key of a hub whose uuid is not known yet).
 * Returns the length, or -1 if it does not fit, is not smaller than the whole
 * tree, or either tree has a row without a key or two rows with one key (then
 * the caller sends the whole tree instead). */
static int hub_build_tree_delta(const char *oldt, int oldlen, const char *newt, int newlen,
                                uint64_t fnv, char *out, int outcap) {
  trow_t *oldr = calloc(MAX_TREE_ROWS, sizeof(*oldr));
  trow_t *newr = calloc(MAX_TREE_ROWS, sizeof(*newr));
  trow_t *w = calloc(MAX_TREE_ROWS, sizeof(*w));
  tree_uset_t *oldk = calloc(1, sizeof(*oldk));
  tree_uset_t *newk = calloc(1, sizeof(*newk));
  int o = -1;
  if (!oldr || !newr || !w || !oldk || !newk) goto done;
  int no = tree_parse_rows(oldt, oldlen, oldr, MAX_TREE_ROWS);
  int nn = tree_parse_rows(newt, newlen, newr, MAX_TREE_ROWS);
  if (!tree_rows_keyed(oldr, no, oldk) || !tree_rows_keyed(newr, nn, newk)) goto done;
  o = snprintf(out, (size_t)outcap, "%016llx\n", (unsigned long long)fnv);
  bool ok = o > 0 && o < outcap;
  /* The deletions, and `w` = the old rows that stay (in order). */
  int nw = 0;
  for (int i = 0; ok && i < no; i++) {
    if (tree_uset_has(newk, oldr[i].uuid, (int)strlen(oldr[i].uuid))) {
      w[nw++] = oldr[i];
      continue;
    }
    int wr = snprintf(out + o, (size_t)(outcap - o), "-|%s\n", oldr[i].uuid);
    if (wr < 0 || wr >= outcap - o) ok = false;
    else o += wr;
  }
  /* Replay the bot's apply on `w`: after step j, w[0..j] == new[0..j].  A row
   * is skipped only when it already sits at position j, so a row left behind
   * by a moved neighbour is re-sent. */
  for (int j = 0; ok && j < nn; j++) {
    if (j < nw && w[j].len == newr[j].len &&
        memcmp(w[j].line, newr[j].line, (size_t)newr[j].len) == 0)
      continue;
    const char *anchor = j == 0 ? "^" : newr[j - 1].uuid;
    int wr = snprintf(out + o, (size_t)(outcap - o), "+|%s|%.*s\n", anchor, newr[j].len,
                      newr[j].line);
    if (wr < 0 || wr >= outcap - o) {
      ok = false;
      break;
    }
    o += wr;
    /* rows before j are final, so the old copy of this row sits at j or later */
    for (int i = j; i < nw; i++)
      if (strcmp(w[i].uuid, newr[j].uuid) == 0) {
        memmove(&w[i], &w[i + 1], (size_t)(nw - i - 1) * sizeof(*w));
        nw--;
        break;
      }
    int pos = j < nw ? j : nw;
    memmove(&w[pos + 1], &w[pos], (size_t)(nw - pos) * sizeof(*w));
    w[pos] = newr[j];
    nw++;
  }
  if (!ok || o >= newlen) o = -1;
done:
  free(newk);
  free(oldk);
  free(w);
  free(oldr);
  free(newr);
  return o;
}

/* A tree or row delta still queued to `c` (not yet on the wire). */
static bool tree_frame_queued(const hub_client_t *c) {
  for (int l = 0; l < LANE_COUNT; l++)
    for (const queued_msg_t *m = c->out_lanes[l].head; m; m = m->next)
      if (m->cmd == CMD_BOT_TREE || m->cmd == CMD_BOT_TREE_DELTA) return true;
  return false;
}

/* The payload of a keepalive PING to `c`: "t|<fnv64hex>", the hash of the tree
 * the bot holds once everything we sent it has landed, so a bot whose tree
 * diverged pulls the whole one (the hash check that replaced the periodic
 * whole-tree push); and, to a 2.5.4+ bot, a second line "c|<sha256hex>", the
 * hash of S, the config text it holds once every config frame already written
 * has applied (plan §4.3a I5): a bot holding anything else pulls a full
 * config.  Each part is left out when there is nothing to vouch for: not a
 * bot, a frame of that kind still queued (pings jump the queue), or the bot
 * not current.  "" when both are out.  2.5.3 bots read t| alone and ignore a
 * payload that is anything more, so they never get c|. */
void hub_bot_ping_payload(const hub_state_t *state, const hub_client_t *c, char *out,
                          size_t cap) {
  if (cap) out[0] = '\0';
  if (!c || c->type != CLIENT_BOT || !c->authenticated || c->superseded) return;
  size_t at = 0;
  if (state->tree_last && state->tree_last_len > 0 &&
      c->tree_sent_valid && c->tree_sent_seq == state->tree_seq && !tree_frame_queued(c)) {
    int n = snprintf(out, cap, "t|%016llx", (unsigned long long)state->tree_last_fnv);
    if (n < 0 || (size_t)n >= cap) {
      out[0] = '\0';
      return;
    }
    at = (size_t)n;
  }
  if (bot_takes_cfg_deltas(c) && c->cfg_base && !c->cfg_queued && !c->cfg_owed) {
    char hex[CFGD_HASH_HEX + 1];
    cfg_hex(c->cfg_base_hash, hex);
    int n = snprintf(out + at, cap - at, "%sc|%s", at ? "\n" : "", hex);
    if (n < 0 || (size_t)n >= cap - at) out[at] = '\0';
  }
}

/* A bot that is owed a whole tree (a queued tree or delta was dropped, or it
 * just connected): pushed on the next tick, not left for the next change. */
static bool tree_owed(const hub_state_t *state) {
  for (int i = 0; i < state->client_count; i++) {
    const hub_client_t *c = state->clients[i];
    if (c->type == CLIENT_BOT && c->authenticated && !c->superseded && !c->tree_sent_valid)
      return true;
  }
  return false;
}

/* Send bot `c` the whole current tree (its own frame, coalesced). */
static void hub_send_whole_tree(hub_state_t *state, hub_client_t *c, const char *payload,
                                int len, uint64_t seq) {
  queued_msg_t *m =
      queued_msg_new(CMD_BOT_TREE, LANE_BULK, (const unsigned char *)payload, len);
  if (!m) return;
  c->tree_sent_valid = true;
  c->tree_sent_seq = seq;
  char coalesce[160];
  snprintf(coalesce, sizeof(coalesce), "%s|bot_tree|%s", state->hub_uuid, c->id);
  queued_msg_set_coalesce(m, state->hub_uuid, hub_next_lamport_seq(state), coalesce);
  if (!peer_enqueue(c, m)) {
    c->tree_sent_valid = false;
    return;
  }
  g_hub_stats.tree_full++;
  g_hub_stats.tree_full_bytes += (uint64_t)len;
}

static void hub_push_tree_to_bots(hub_state_t *state) {
  int bots = 0;
  for (int i = 0; i < state->client_count; i++)
    if (state->clients[i]->type == CLIENT_BOT && state->clients[i]->authenticated &&
        !state->clients[i]->superseded)
      bots++;
  if (bots == 0) return;

  char *payload = malloc(MAX_TREE_PAYLOAD);
  if (!payload) {
    hub_log_error("[PRESENCE] OOM building bot tree\n");
    return;
  }
  int len = hub_build_tree(state, payload, MAX_TREE_PAYLOAD);
  if (len <= 0) {
    free(payload);
    return;
  }
  if (!state->tree_last) state->tree_last = malloc(MAX_TREE_PAYLOAD);
  uint64_t fnv = tree_fnv64(payload, len);
  bool changed = state->tree_last_len != len || fnv != state->tree_last_fnv ||
                 !state->tree_last || memcmp(payload, state->tree_last, (size_t)len) != 0;
  uint64_t old_seq = state->tree_seq;
  uint64_t new_seq = changed ? old_seq + 1 : old_seq;

  /* One delta, shared by every bot holding the previous tree; the keepalive
   * hash checks that it landed. */
  char *delta = NULL;
  int dlen = -1;
  if (changed && state->tree_last && state->tree_last_len > 0) {
    delta = malloc((size_t)MAX_TREE_PAYLOAD * 2);
    if (delta)
      dlen = hub_build_tree_delta(state->tree_last, state->tree_last_len, payload, len, fnv,
                                  delta, MAX_TREE_PAYLOAD * 2);
  }

  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    /* A superseded session is closing: no tree frames to it. */
    if (c->type != CLIENT_BOT || !c->authenticated || c->superseded) continue;
    bool current = c->tree_sent_valid && c->tree_sent_seq == old_seq;
    if (!changed && current) continue; /* already up to date */
    if (changed && current && delta && dlen > 0) {
      queued_msg_t *m =
          queued_msg_new(CMD_BOT_TREE_DELTA, LANE_BULK, (const unsigned char *)delta, dlen);
      if (!m) continue;
      c->tree_sent_valid = true;
      c->tree_sent_seq = new_seq;
      if (!peer_enqueue(c, m)) {
        c->tree_sent_valid = false;
      } else {
        g_hub_stats.tree_delta++;
        g_hub_stats.tree_delta_bytes += (uint64_t)dlen;
        g_hub_stats.tree_delta_of += (uint64_t)len;
      }
    } else {
      hub_send_whole_tree(state, c, payload, len, new_seq);
    }
  }

  if (changed && state->tree_last) {
    memcpy(state->tree_last, payload, (size_t)len);
    state->tree_last_len = len;
    state->tree_last_fnv = fnv;
    state->tree_seq = new_seq;
  }
  free(delta);
  free(payload);
}

/* A bot applied a delta whose hash did not match its tree: send it the whole
 * current tree (CMD_BOT_TREE_PULL), at most once per TREE_PULL_MIN_GAP; one
 * inside the gap is held and served by hub_presence_tick when the gap ends. */
static void hub_tree_pull(hub_state_t *state, hub_client_t *c) {
  if (!c || c->type != CLIENT_BOT || !c->authenticated) return;
  time_t now = time(NULL);
  if (c->tree_pull_at && now - c->tree_pull_at < TREE_PULL_MIN_GAP) {
    c->tree_pull_due = true;
    return;
  }
  c->tree_pull_due = false;
  c->tree_pull_at = now;
  g_hub_stats.tree_pull++;
  if (state->tree_last && state->tree_last_len > 0) {
    hub_send_whole_tree(state, c, state->tree_last, state->tree_last_len, state->tree_seq);
    return;
  }
  /* No tree built yet: let the next tick push build and send one. */
  c->tree_sent_valid = false;
  state->tree_dirty = true;
}

/* How long event gossip holds after `burst` event gossips in a row: 1, 2, 4, 8, 16,
 * then PRESENCE_HOLD_MAX seconds. */
int hub_presence_hold(int burst) {
  if (burst < 0) burst = 0;
  if (burst >= 5) return PRESENCE_HOLD_MAX;
  int hold = 1 << burst;
  return hold > PRESENCE_HOLD_MAX ? PRESENCE_HOLD_MAX : hold;
}

/* A bot linked or left, or a peer link changed: gossip it as soon as the damping
 * allows (hub_presence_tick). */
void hub_presence_event(hub_state_t *state) { state->presence_event_due = true; }

void hub_presence_tick(hub_state_t *state, time_t now) {
  if (state->hub_started == 0) state->hub_started = now;

  hub_roster_expire(state, now);
  hub_p2_tick(state); /* presence v2 records, reachability (phase 1) */

  /* A peer link that came up or went down is news for everyone's tree and for
   * every forwarder's split horizon (hub_broadcast_sync_to_peers): gossip it
   * now rather than on the next interval. */
  uint32_t mask = 0;
  for (int p = 0; p < state->peer_count && p < 32; p++)
    if (peer_is_linked(state, &state->peers[p])) mask |= 1u << p;
  if (mask != state->gossip_link_mask) {
    /* A link went down: see SYNC_RESYNC_AFTER_LINK_LOSS. */
    if (state->gossip_link_mask & ~mask)
      state->resync_due_at = now + SYNC_RESYNC_AFTER_LINK_LOSS;
    state->gossip_link_mask = mask;
    hub_presence_event(state);
    /* Once more shortly: the first round can go out on a duplicate link the far
     * end then closes (both ends dialled). */
    state->gossip_again_at = now + PRESENCE_LINK_REGOSSIP;
    state->tree_dirty = true;
  }
  if (state->gossip_again_at && now >= state->gossip_again_at) {
    state->gossip_again_at = 0;
    hub_presence_event(state);
  }
  if (state->resync_due_at && now >= state->resync_due_at) {
    state->resync_due_at = 0;
    hub_request_sync_from_peers(state);
  }

  /* Presence v2 runs alongside today's rounds for one release (plan §8.4):
   * v2 gossips who is where, these rounds keep carrying it too and the roster
   * details (nick, version, capabilities) on their own cadence. */
  int round = BOT_PRESENCE_INTERVAL;
  if (now - state->last_presence_gossip >= round) {
    hub_gossip_bot_roster(state);
  } else if (state->presence_event_due && now >= state->presence_hold_until) {
    hub_gossip_bot_roster(state);
    /* Damping: an event gossip close on the last one doubles the next hold. */
    state->presence_burst = state->presence_last_event &&
                                    now - state->presence_last_event < PRESENCE_FLAP_WINDOW
                                ? state->presence_burst + 1
                                : 0;
    state->presence_last_event = now;
    state->presence_hold_until = now + hub_presence_hold(state->presence_burst);
  }

  /* Pulls held by the TREE_PULL_MIN_GAP throttle, once the gap is over. */
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->tree_pull_due && now - c->tree_pull_at >= TREE_PULL_MIN_GAP) hub_tree_pull(state, c);
  }

  /* Push on change (only to bots whose tree it changes).  A bot that missed
   * a frame converges through the keepalive tree hash (it pulls), one that
   * connected between changes through tree_owed.  Changes are coalesced (see
   * BOT_TREE_COALESCE): under churn every peer's gossip round re-rendered the
   * tree for every bot, O(hubs x bots) 10 KB frames a minute. */
  int gap = state->tree_dirty_local ? BOT_TREE_COALESCE_LOCAL : BOT_TREE_COALESCE;
  bool due = state->tree_dirty && now - state->last_tree_change_push >= gap;
  /* A bot owed a whole tree gets it now (a dropped frame used to wait for
   * the next change). */
  if (!due && tree_owed(state)) {
    hub_push_tree_to_bots(state);
    return;
  }
  if (due) {
    state->tree_dirty = false;
    state->tree_dirty_local = false;
    state->last_tree_change_push = now;
    hub_push_tree_to_bots(state);
  }
}

/* The opcode a config broadcast goes to peer `c` under: CMD_PEER_BCAST when
 * its gossip shows it knows the opcode (it sends l| lines), else the
 * CMD_PEER_SYNC every hub understands. */
static uint8_t sync_bcast_opcode(hub_state_t *state, const hub_client_t *c) {
  const char *cu = upgrade_peer_uuid(state, c);
  const mesh_hub_t *mh = cu[0] ? mesh_hub_find(state, cu) : NULL;
  return (mh && mh->have_links) ? CMD_PEER_BCAST : CMD_PEER_SYNC;
}

/* The mesh-map record of the peer on `from_fd`, if its link report is fresh
 * enough to trust for a split horizon (sent the moment a link changes,
 * refreshed every BOT_PRESENCE_INTERVAL), else NULL. */
static const mesh_hub_t *split_horizon_sender(hub_state_t *state, int from_fd) {
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type != CLIENT_HUB || !c->authenticated || c->fd != from_fd)
      continue;
    const char *su = upgrade_peer_uuid(state, c);
    const mesh_hub_t *mh = su[0] ? mesh_hub_find(state, su) : NULL;
    /* The list must be fresh and have come over this link: one from before it came
     * up describes the mesh before a cut. */
    if (mh && mh->have_links && time(NULL) - mh->links_at <= SYNC_SPLIT_HORIZON_FRESH &&
        mh->links_at >= c->connected_at)
      return mh;
    return NULL;
  }
  return NULL;
}

/* True when `sender` is linked to peer `c` right now: it sent `c` its flood
 * directly, so we need not. */
static bool split_horizon_has(hub_state_t *state, const mesh_hub_t *sender,
                              const hub_client_t *c) {
  const char *cu = upgrade_peer_uuid(state, c);
  bool listed = false;
  for (int l = 0; l < sender->link_count && cu[0] && !listed; l++)
    listed = sender->links[l].online && strcmp(sender->links[l].uuid, cu) == 0;
  if (!listed) return false;
  /* Both ends must agree when the peer's own list is fresh: a link one side
   * still lists may already be down. */
  const mesh_hub_t *peer = mesh_hub_find(state, cu);
  if (!peer || !peer->have_links || time(NULL) - peer->links_at > SYNC_SPLIT_HORIZON_FRESH)
    return true;
  for (int l = 0; l < peer->link_count; l++)
    if (strcmp(peer->links[l].uuid, sender->uuid) == 0) return peer->links[l].online;
  return false;
}

/* Whether peer `c` is known current: 2 = MESH_MIN_VERSION or newer, 1 =
 * known older (its link is being refused), 0 = not known yet (its version
 * arrives with its first roster).  Config sync flows only at 2: an older hub
 * does not know uf| / uc| and would over-trust every restricted user. */
static int peer_version_level(hub_state_t *state, const hub_client_t *c) {
  const char *cu = upgrade_peer_uuid(state, c);
  const char *ver = "";
  for (int i = 0; cu[0] && i < state->peer_count && !ver[0]; i++)
    if (strcmp(state->peers[i].uuid, cu) == 0) ver = state->peers[i].remote_version;
  if (!ver[0] && cu[0]) {
    const mesh_hub_t *mh = mesh_hub_find(state, cu);
    if (mh) ver = mh->version;
  }
  if (!ver[0]) return 0;
  return hub_update_version_cmp(ver, MESH_MIN_VERSION) >= 0 ? 2 : 1;
}

static const char *peer_version_str(hub_state_t *state, const hub_client_t *c);

bool hub_bot_version_takes_pool(const char *version) {
  return version && version[0] && hub_update_version_cmp(version, POOL_MIN_BOT) >= 0;
}

/* Whether peer c takes server pool N|/S| sync lines (POOL_MIN_HUB).  An older
 * hub reads an unknown sync key as "uuid|key|..." and stores a phantom bot
 * named "N" or "S", so those lines never reach it. */
static bool peer_takes_pool(hub_state_t *state, const hub_client_t *c) {
  const char *v = peer_version_str(state, c);
  return v[0] && hub_update_version_cmp(v, POOL_MIN_HUB) >= 0;
}

bool hub_peer_takes_pool(hub_state_t *state, const hub_client_t *c) {
  return peer_takes_pool(state, c);
}

/* N|, S|, the hs|sgrant marker and a bot's pm| (b|<uuid>|pm|...): new in
 * POOL_MIN_HUB. */
static bool line_is_pool(const char *l) {
  return ((l[0] == 'N' || l[0] == 'S') && l[1] == '|') || strncmp(l, "hs|sgrant|", 10) == 0 ||
         (l[0] == 'b' && l[1] == '|' && strlen(l) > 2 + 36 + 4 &&
          strncmp(l + 2 + 36, "|pm|", 4) == 0);
}

/* `payload` without its N|/S| lines, malloc'd; NULL when it has none (send
 * it as it is) or on OOM (*oom set). */
static char *strip_pool_lines(const char *payload, bool *oom) {
  *oom = false;
  bool any = line_is_pool(payload);
  for (const char *p = strchr(payload, '\n'); p && !any; p = strchr(p + 1, '\n'))
    any = line_is_pool(p + 1);
  if (!any) return NULL;
  size_t n = strlen(payload);
  char *out = malloc(n + 1);
  if (!out) { *oom = true; return NULL; }
  size_t o = 0;
  for (const char *l = payload; *l;) {
    const char *e = strchr(l, '\n');
    size_t len = e ? (size_t)(e - l) + 1 : strlen(l);
    if (!line_is_pool(l)) { memcpy(out + o, l, len); o += len; }
    l += len;
  }
  out[o] = '\0';
  return out;
}

/* One sync payload onto peer c's queue.  Held, not sent, while c's version
 * is not known: hub_peer_sync_release sends the full state once it is. */
void hub_peer_enqueue_sync(hub_state_t *state, hub_client_t *c, uint8_t op, lane_t lane,
                              const char *payload, const char *coalesce, uint64_t seq) {
  int level = peer_version_level(state, c);
  if (level < 2) {
    if (level == 0) c->sync_held = true;
    return;
  }
  char *stripped = NULL;
  if (!peer_takes_pool(state, c)) {
    bool oom;
    stripped = strip_pool_lines(payload, &oom);
    if (oom) {
      hub_log_error("[MESH] OOM filtering a sync for %s; not sent\n", c->ip);
      return;
    }
    if (stripped) payload = stripped;
  }
  int len = (int)strlen(payload);
  if (len > 0) {
    queued_msg_t *m = queued_msg_new(op, lane, (const unsigned char *)payload, len);
    if (m) {
      if (coalesce) queued_msg_set_coalesce(m, state->hub_uuid, seq, coalesce);
      if (!peer_enqueue(c, m)) {
        /* Only URGENT can fail here; PEER_SYNC is DELTA/BULK so this is
         * effectively unreachable, but be safe. */
        hub_log_warning("[MESH] enqueue failed for peer %s\n", c->ip);
      }
    }
  }
  free(stripped);
}

/* Peer c's roster just named a current version: everything held while it
 * was unknown goes now, as one full sync, and a CMD_SYNC_REQUEST fetches
 * the state it sent meanwhile (dropped unread, see the dispatch). */
static void hub_peer_sync_release(hub_state_t *state, hub_client_t *c) {
  if (!c->sync_held || peer_version_level(state, c) != 2) return;
  c->sync_held = false;
  char *full = malloc(MAX_SYNC_PAYLOAD);
  if (!full) {
    hub_log_error("[PEER] OOM building the held sync for %s\n", c->ip);
    c->sync_held = true; /* the next roster tries again */
    return;
  }
  hub_generate_sync_packet(state, full, MAX_SYNC_PAYLOAD);
  hub_peer_enqueue_sync(state, c, CMD_PEER_SYNC, LANE_BULK, full, "handshake_sync",
                        hub_next_lamport_seq(state));
  free(full);
  peer_send_urgent(state, c, CMD_SYNC_REQUEST, "");
  hub_uhist_send_digest(state, c);
  hub_plan_send_digest(state, c);
  hub_log_debug("[MESH] Peer %s is current: held sync sent, its own requested\n", c->ip);
}

/* Sync tracing (debug): a delta's path through the mesh, record by record,
 * so a lost or leaked record can be followed hub to hub.  Frames longer than
 * SYNC_TRACE_MAX_LINES are full-state syncs and are not traced. */
#define SYNC_TRACE_MAX_LINES 16
#define SYNC_TRACE_LINE 120

static int sync_trace_lines(const char *payload) {
  int n = 0;
  for (const char *p = payload; *p; p++)
    if (*p == '\n') n++;
  return n + (payload[0] && payload[strlen(payload) - 1] != '\n');
}

/* The payload's first line, cut at SYNC_TRACE_LINE - 1 bytes. */
static void sync_trace_first(char *out, size_t size, const char *payload) {
  size_t n = strcspn(payload, "\n");
  if (n >= size) n = size - 1;
  memcpy(out, payload, n);
  out[n] = '\0';
}

/* Append peer c's name to a ", "-separated list. */
static void sync_trace_name(char *list, size_t size, const hub_client_t *c) {
  size_t o = strlen(list);
  if (o < size)
    snprintf(list + o, size - o, "%s%s", o ? ", " : "", c->id[0] ? c->id : c->ip);
}

/* One config payload to every authenticated peer except `exclude_fd`.
 * `split`: the payload is a forward of a CMD_PEER_BCAST the peer on
 * `exclude_fd` sent us, so the split horizon may apply (see CMD_PEER_BCAST).
 * `coalesce`/`seq`: queue coalescing for a single-key delta, or NULL. */
static void sync_send_to_peers(hub_state_t *state, const char *payload,
                               int exclude_fd, bool split, lane_t lane,
                               const char *coalesce, uint64_t seq) {
  int payload_len = (int)strlen(payload);
  /* Change 5: a full-state anti-entropy sync can exceed MAX_BUFFER; bound by
   * the sync-payload ceiling so it is never silently dropped here. */
  if (payload_len > (MAX_SYNC_PAYLOAD - 10))
    return;

  /* The sender's links, if we may trust them: its report is fresh (sent the
   * moment a link changes, refreshed every BOT_PRESENCE_INTERVAL).  A peer it
   * is linked to right now got this frame from it directly.  A copy lost to a
   * link that dropped in the moment before its gossip said so is what the
   * resync after a link loss (SYNC_RESYNC_AFTER_LINK_LOSS) and the periodic
   * anti-entropy exist to repair. */
  const mesh_hub_t *sender = split ? split_horizon_sender(state, exclude_fd)
                                   : NULL;

  int skipped = 0;
  char to[256] = "", skip[256] = "", held[256] = "";
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type != CLIENT_HUB || !c->authenticated || c->fd == exclude_fd)
      continue;
    if (sender && split_horizon_has(state, sender, c)) {
      skipped++;
      sync_trace_name(skip, sizeof(skip), c);
      continue;
    }
    if (peer_version_level(state, c) == 2)
      sync_trace_name(to, sizeof(to), c);
    else
      sync_trace_name(held, sizeof(held), c);
    hub_peer_enqueue_sync(state, c, sync_bcast_opcode(state, c), lane, payload, coalesce, seq);
  }
  if (skipped)
    hub_log_debug("[MESH] Forward skipped %d peer(s) the sender reaches itself\n",
            skipped);
  /* Where a delta went (a full-state sync is too big and too routine). */
  int lines = sync_trace_lines(payload);
  if (lines <= SYNC_TRACE_MAX_LINES) {
    char first[SYNC_TRACE_LINE];
    sync_trace_first(first, sizeof(first), payload);
    hub_log_debug("[MESH] Sync %s, %d line(s) [%s]: to %s; skipped %s; held %s\n",
                  split ? "bcast forward" : exclude_fd != -1 ? "forward" : "own change",
                  lines, first, to[0] ? to : "-", skip[0] ? skip : "-", held[0] ? held : "-");
  }
}

void hub_broadcast_sync_to_peers(hub_state_t *state, const char *payload,
                                 int exclude_fd) {
  /* Lane heuristic:
   *  - Single-line CMD_PEER_SYNC payloads originating from a delta forward
   *    (typical: one trailing newline) are short — < 1 KB — and time-
   *    sensitive; treat as DELTA so they're not throttled by the BULK budget.
   *  - Larger payloads (multi-line, e.g. anti-entropy full sync) ride BULK. */
  lane_t lane = (strlen(payload) > 1024) ? LANE_BULK : LANE_DELTA;
  sync_send_to_peers(state, payload, exclude_fd, false, lane, NULL, 0);
}

/* ---- Hash-first anti-entropy (CMD_SYNC_DIGEST, 2.5.4) ----------------------
 * docs/plans/2026-11-20_sync_digest_plan.md; spec proto/syncdigest/model.py.
 * G1: a digest applies nothing — only the ordinary CMD_PEER_SYNC records it
 * makes us send do, through process_peer_sync.  G2: anything malformed sends
 * more, never less. */

/* The peer's version, as peer_version_level reads it ("" unknown). */
static const char *peer_version_str(hub_state_t *state, const hub_client_t *c) {
  const char *cu = upgrade_peer_uuid(state, c);
  for (int i = 0; cu[0] && i < state->peer_count; i++)
    if (strcmp(state->peers[i].uuid, cu) == 0 && state->peers[i].remote_version[0])
      return state->peers[i].remote_version;
  const mesh_hub_t *mh = cu[0] ? mesh_hub_find(state, cu) : NULL;
  return mh ? mh->version : "";
}

static bool peer_takes_sync_digest(hub_state_t *state, const hub_client_t *c) {
  const char *v = peer_version_str(state, c);
  return v[0] && hub_update_version_cmp(v, SYNC_DIGEST_MIN_HUB) >= 0;
}

static void sd_send(hub_client_t *c, const char *text) {
  queued_msg_t *m =
      queued_msg_new(CMD_SYNC_DIGEST, LANE_BULK, (const unsigned char *)text, (int)strlen(text));
  if (m && peer_enqueue(c, m)) return;
  hub_log_warning("[MESH] Could not queue a sync digest to %s\n", c->ip);
}

/* Our records of `kinds` (all for `all`) to peer c as one CMD_PEER_SYNC.
 * `packet` is our current hub_generate_sync_packet text. */
static void sd_push(hub_state_t *state, hub_client_t *c, const char *packet,
                    char kinds[][SDG_KIND_MAX + 1], int nk, bool all) {
  char *sel = malloc(MAX_SYNC_PAYLOAD);
  if (!sel) return;
  long n = sdg_select(packet, strlen(packet), kinds, nk, all, sel, MAX_SYNC_PAYLOAD);
  if (n > 0)
    hub_peer_enqueue_sync(state, c, CMD_PEER_SYNC, n > 1024 ? LANE_BULK : LANE_DELTA, sel, NULL, 0);
  free(sel);
}

/* One periodic anti-entropy round: to each peer the digest of `full` (our
 * hub_generate_sync_packet text), or the full state to a peer older than
 * SYNC_DIGEST_MIN_HUB and on every SYNC_DIGEST_FULL_EVERY-th round (S2). */
void hub_anti_entropy_round(hub_state_t *state, const char *full) {
  char *dg = malloc(SYNC_DIGEST_MAX);
  long dl = dg ? sdg_digest(full, strlen(full), dg, SYNC_DIGEST_MAX) : -1;
  lane_t lane = strlen(full) > 1024 ? LANE_BULK : LANE_DELTA;
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type != CLIENT_HUB || !c->authenticated) continue;
    bool digest = dl > 0 && peer_takes_sync_digest(state, c) &&
                  ++c->sd_rounds % SYNC_DIGEST_FULL_EVERY != 0;
    if (digest) {
      sd_send(c, dg);
      g_hub_stats.sd_tx++;
    } else {
      hub_peer_enqueue_sync(state, c, sync_bcast_opcode(state, c), lane, full, NULL, 0);
    }
  }
  free(dg);
}

/* G3: the kinds that differed this round on peer c's link, counted across
 * consecutive rounds (a kind that matched drops out).  True when one has
 * differed SYNC_DIGEST_STUCK times running: send the whole state. */
static bool sd_note_stuck(hub_state_t *state, hub_client_t *c, char bad[][SDG_KIND_MAX + 1],
                          int nb) {
  int keep = 0;
  bool stuck = false;
  const char *which = NULL;
  for (int b = 0; b < nb; b++) {
    int n = 1;
    for (int i = 0; i < c->sd_stuck_n; i++)
      if (strcmp(c->sd_stuck[i].kind, bad[b]) == 0) n = c->sd_stuck[i].n + 1;
    if (keep >= SYNC_DIGEST_KINDS_MAX) break;
    snprintf(c->sd_stuck[keep].kind, sizeof(c->sd_stuck[keep].kind), "%s", bad[b]);
    c->sd_stuck[keep].n = n;
    keep++;
    if (n >= SYNC_DIGEST_STUCK && !stuck) {
      stuck = true;
      which = bad[b];
    }
  }
  /* bad[] is ascending and so is what we keep: the next round compares. */
  c->sd_stuck_n = keep;
  if (stuck) {
    time_t now = time(NULL);
    if (now - c->sd_warned >= SYNC_DIGEST_WARN_EVERY) {
      c->sd_warned = now;
      hub_log_warning("[MESH] Sync with %s: records of kind %s still differ after %d repaired "
                      "rounds; sending the whole state both ways\n",
                      hub_who_client(state, c), which, SYNC_DIGEST_STUCK);
    }
    c->sd_stuck_n = 0;
  }
  return stuck;
}

/* CMD_SYNC_DIGEST from a peer: a digest to compare, or a pull to answer. */
static void process_sync_digest(hub_state_t *state, hub_client_t *peer, const char *payload) {
  size_t len = strlen(payload);
  char *full = malloc(MAX_SYNC_PAYLOAD);
  if (!full) return;
  hub_generate_sync_packet(state, full, MAX_SYNC_PAYLOAD);
  char (*kinds)[SDG_KIND_MAX + 1] = calloc(SDG_KINDS_MAX, sizeof(*kinds));
  if (!kinds) {
    free(full);
    return;
  }
  if (len >= 2 && payload[0] == 'r' && payload[1] == '|') {
    bool all = false;
    int nk = sdg_parse_pull(payload, len, kinds, SDG_KINDS_MAX, &all);
    if (nk < 0)
      hub_log_warning("[MESH] Malformed sync pull from %s\n", hub_who_client(state, peer));
    else
      sd_push(state, peer, full, kinds, nk, all);
    goto out;
  }
  g_hub_stats.sd_rx++;
  sdg_entry_t *theirs = calloc(SDG_KINDS_MAX, sizeof(*theirs));
  sdg_entry_t *mine = calloc(SDG_KINDS_MAX, sizeof(*mine));
  char *dg = malloc(SYNC_DIGEST_MAX);
  int nt = -1, nm = -1, nb = -1;
  if (theirs && mine && dg) {
    nt = sdg_parse(payload, len, theirs, SDG_KINDS_MAX);
    long dl = sdg_digest(full, strlen(full), dg, SYNC_DIGEST_MAX);
    if (dl > 0) nm = sdg_parse(dg, (size_t)dl, mine, SDG_KINDS_MAX);
    if (nt >= 0 && nm >= 0) nb = sdg_mismatch(mine, nm, theirs, nt, kinds, SDG_KINDS_MAX);
  }
  if (nb == 0) {
    g_hub_stats.sd_match++;
    peer->sd_stuck_n = 0;
  } else if (nb > 0 && !sd_note_stuck(state, peer, kinds, nb)) {
    /* Push ours of every kind that differs, pull theirs: either may be behind. */
    g_hub_stats.sd_kinds += (uint64_t)nb;
    sd_push(state, peer, full, kinds, nb, false);
    char *pull = malloc(SYNC_DIGEST_MAX);
    if (pull) {
      size_t at = (size_t)snprintf(pull, SYNC_DIGEST_MAX, "r|");
      for (int i = 0; i < nb; i++)
        at += (size_t)snprintf(pull + at, SYNC_DIGEST_MAX - at, "%s%s", i ? "," : "", kinds[i]);
      snprintf(pull + at, SYNC_DIGEST_MAX - at, "\n");
      sd_send(peer, pull);
      free(pull);
    }
  } else {
    /* Malformed, unreadable, or stuck: the whole state both ways (G2/G3). */
    if (nb < 0)
      hub_log_warning("[MESH] Unreadable sync digest from %s; sending the whole state\n",
                      hub_who_client(state, peer));
    g_hub_stats.sd_full++;
    sd_push(state, peer, full, kinds, 0, true);
    sd_send(peer, "r|*\n");
  }
  free(theirs);
  free(mine);
  free(dg);
out:
  free(kinds);
  secure_wipe(full, strlen(full));
  free(full);
}

/* A forward of what we accepted from a peer's frame.  `bcast`: that frame
 * was a CMD_PEER_BCAST, so the split horizon applies. */
static void sync_forward_to_peers(hub_state_t *state, const char *payload,
                                  int origin_fd, bool bcast) {
  lane_t lane = (strlen(payload) > 1024) ? LANE_BULK : LANE_DELTA;
  sync_send_to_peers(state, payload, origin_fd, bcast, lane, NULL, 0);
}

// NEW FUNCTION: Broadcast full config to all connected bots to ensure
// consistency
static void hub_request_sync_from_peers(hub_state_t *state) {
  int sent = 0;
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type == CLIENT_HUB && c->authenticated) {
      if (peer_send_urgent(state, c, CMD_SYNC_REQUEST, ""))
        sent++;
    }
  }
  if (sent > 0)
    hub_log_debug("[MESH] Sent sync request to %d peer(s)\n", sent);
}

/* Owe every local bot a full config push.  It used to be sent right here, once
 * per accepted update: a burst of N updates (fifty bots reconnecting send two
 * each, and each one reaches every hub) became N full pushes to every bot,
 * O(updates x bots) of 8 KB frames, while each push only ever carries the
 * current state anyway.  hub_flush_bot_config sends one, at most once per
 * BOT_CONFIG_PUSH_COALESCE, with whatever the state is by then. */
static void broadcast_full_config_to_all_bots(hub_state_t *state) {
  state->bot_config_pending = true;
}

static void send_owed_bot_config(hub_state_t *state, time_t now);

/* End a bot's first-config hold: the config goes out now (full). */
static void cfg_hold_release(hub_state_t *state, hub_client_t *client) {
  if (client->cfg_hold_done) return;
  client->cfg_hold_done = true;
  client->cfg_hold_at = 0;
  send_config_to_bot(state, client, true);
}

void hub_flush_bot_config(hub_state_t *state, time_t now) {
  if (g_cfg_holds > 0) {
    /* recounted here: a held bot that dropped its link leaves no count */
    int held = 0;
    for (int i = 0; i < state->client_count; i++) {
      hub_client_t *c = state->clients[i];
      if (c->type != CLIENT_BOT || !c->cfg_hold_at || c->cfg_hold_done) continue;
      if (now - c->cfg_hold_at < CFG_FIRST_HOLD) {
        held++;
        continue;
      }
      hub_log_debug("[HUB] %s sent no presence within %d s: config sent without it\n",
                    hub_who_client(state, c), CFG_FIRST_HOLD);
      cfg_hold_release(state, c);
    }
    g_cfg_holds = held;
  }
  if (now - state->last_bot_config_push < BOT_CONFIG_PUSH_COALESCE) return;
  if (state->bot_config_pending) {
    send_owed_bot_config(state, now); /* every bot, owed ones included */
    return;
  }
  if (!g_cfg_owed) return;
  /* Only bots whose last config frame was lost (cfg_push_lost). */
  g_cfg_owed = false;
  state->last_bot_config_push = now;
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type == CLIENT_BOT && c->authenticated && c->cfg_owed) send_config_to_bot(state, c, false);
  }
}


static void send_owed_bot_config(hub_state_t *state, time_t now) {
  state->bot_config_pending = false;
  g_cfg_owed = false;
  state->last_bot_config_push = now;
  int sent_count = 0;
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type == CLIENT_BOT && c->authenticated) {
      send_config_to_bot(state, c, false);
      sent_count++;
    }
  }
  hub_log_debug("[HUB] Broadcasted FULL config to %d bots\n", sent_count);
}

/* One accepted record of a bot's config push, onto the batch forwarded to
 * peer hubs (buf is MAX_BUFFER bytes).  A line that would not fit sends the
 * batch first, so nothing accepted is dropped and *off never passes the end
 * of buf.  snprintf's return is the untruncated length: adding it unchecked
 * once ran *off past a stack buffer on a large push. */
static void config_push_sync(hub_state_t *state, char *buf, int *off,
                             int exclude_fd, const char *fmt, ...)
    __attribute__((format(printf, 5, 6)));
static void config_push_sync(hub_state_t *state, char *buf, int *off,
                             int exclude_fd, const char *fmt, ...) {
  char line[MAX_BUFFER / 8];  /* longest record line (B|) is < 1.1 KB */
  va_list ap;
  va_start(ap, fmt);
  int w = vsnprintf(line, sizeof(line), fmt, ap);
  va_end(ap);
  if (w <= 0 || w >= (int)sizeof(line)) return;  /* bounded fields: never */
  if (*off + w >= MAX_BUFFER) {
    hub_broadcast_sync_to_peers(state, buf, exclude_fd);
    *off = 0;
  }
  memcpy(buf + *off, line, (size_t)w);
  *off += w;
  buf[*off] = '\0';
}

/* A bot's migration of its 2.5.3 s| list (stamp-0 S| lines, sent once on its
 * first pool-aware link): the first such line stamps pm|<now> on the bot,
 * mesh-wide; under opt 'h' its lines are taken for POOL_MIGRATE_WINDOW after
 * that, never later (2.5.5 ends this opt 'h' exception).  False also for a
 * bot with no record. */
static bool pool_migrate_gate(hub_state_t *state, const hub_client_t *client, char *buf,
                              int *off, int *updates) {
  bot_config_t *b = bot_by_uuid(state, client->id);
  if (!b) return false;
  const config_entry_t *pm = bot_entry_rec(b, "pm");
  time_t now = time(NULL);
  if (!pm) {
    char v[24];
    snprintf(v, sizeof(v), "%lld", (long long)now);
    long long ts = (long long)hub_lww_next_ts(0);
    if (!hub_storage_update_entry(state, client->id, "pm", v, "", "", (time_t)ts)) return false;
    (*updates)++;
    config_push_sync(state, buf, off, client->fd, "b|%s|pm|%s|%lld\n", client->id, v, ts);
    hub_log_info("[POOL] %s is migrating its s| list to the pool\n",
                 hub_who_client(state, client));
    return true;
  }
  long long window = POOL_MIGRATE_WINDOW;
#ifdef IRC_TEST_HOOKS
  /* A sandbox cannot wait 5 minutes to see a second offer refused. */
  const char *hook = getenv("IRCHUB_TEST_POOL_MIGRATE_WINDOW");
  if (hook && atoi(hook) > 0) window = atoi(hook);
#endif
  char *end = NULL;
  long long first = strtoll(pm->value, &end, 10);
  return end && !*end && first <= (long long)now && (long long)now - first <= window;
}

/* The v| protocol a config push carries (0 when unreadable), -1 when it has
 * no v| line. */
static long push_proto(const char *payload) {
  for (const char *p = payload; p && *p; p = strchr(p, '\n'), p = p ? p + 1 : NULL) {
    if (p[0] == 'v' && p[1] == '|') {
      long v = strtol(p + 2, NULL, 10);
      return v > 0 && v < 1000 ? v : 0;
    }
  }
  return -1;
}

static void process_bot_config_push(hub_state_t *state, hub_client_t *client,
                                    char *payload) {
  if (client->type != CLIENT_BOT || !client->authenticated) {
    hub_log_warning("[HUB] Rejected config push from non-bot client\n");
    return;
  }

  hub_log_debug("[HUB] Processing config push from %s\n", hub_who_client(state, client));
  /* The bot's tables may now differ from what it was last sent (a push the
   * hub does not accept stays in them), so its next broadcast goes out. */
  client->cfg_sent_valid = false;

  /* opt 'h' (OPT_HUB_ONLY_MUTATIONS) enforcement point.  When the network is in
   * hub-only-mutation mode the hub is the SOLE authority for privileged record
   * types, and this is what makes the flag *binding* against a rogue or
   * malicious bot.  The matching bot-side guard (ircbot/commands.c:516) only
   * stops a well-behaved bot from issuing the command locally; a modified or
   * compromised bot can ignore it and push the record straight up this path.
   * Rejecting those pushes here ensures a bot cannot mutate admin/oper/usermask/
   * channel/password state under opt 'h'.  These map 1:1 to the bot-side
   * HUB_ONLY_CMDS list: a=+/-admin/chkey, o=+/-oper/chkey, m=+/-usermask,
   * c=join/part.
   * The bot's own runtime identity (nick 'n', hostmask 'h') and its protocol
   * version 'v' are intrinsic state only the bot can report, so they stay
   * accepted.
   * Note: bots cannot clear this flag — 'opt|' updates arrive only via
   * CMD_PEER_SYNC (CLIENT_HUB) or CMD_ADMIN_SET_OPT_FLAGS (CLIENT_ADMIN);
   * the CLIENT_BOT dispatch never reaches process_peer_sync.  Combined with the
   * rejection below, once opt 'h' is set a bot can neither mutate privileged
   * records nor escalate to an admin record that would let it clear the flag. */
  const bool hub_only_mutations =
      (strchr(state->opt_flags, OPT_HUB_ONLY_MUTATIONS) != NULL);

  /* Task 6 — opt 'F' (OPT_CONFIG_FROZEN): an upgrade run is open, so the
   * store holds still: a bot that restarts mid-roll re-pushes its config on
   * reconnect, and nothing is lost that it will not offer again once the
   * freeze lifts.  Its own nick (n|) and hostmask (h|) are the exception —
   * runtime identity, not config.  A bot that comes back from its upgrade
   * under another nick is opped by its peers only once they learn the new
   * mask, and the run waits for exactly that op (UPGRADE_OPS_WAIT). */
  const bool frozen = hub_config_frozen(state);
  if (frozen)
    hub_log_warning("[UPGRADE] config frozen: only nick/hostmask taken from "
                    "config push from %s\n", hub_who_client(state, client));

  /* v|<proto>|<unused> (docs/passwordless.md §3.4) heads a bot's full
   * push; record-only pushes (user/mask/ban deltas, split frames) carry
   * none.  A bot below BOT_PROTO_USER_FLAGS is refused before a line of it
   * is taken in: it would over-trust restricted users (MESH_MIN_VERSION). */
  long proto = push_proto(payload);
  if (proto >= 0 && proto < BOT_PROTO_USER_FLAGS) {
    hub_log_warning("[HUB] %s pushes protocol v%ld (below v%d): refused; "
                    "upgrade it by hand to %s\n", hub_who_client(state, client), proto,
                    BOT_PROTO_USER_FLAGS, MESH_MIN_VERSION);
    client->refused = true;
    return;
  }

  char work_buf[MAX_BUFFER];
  snprintf(work_buf, sizeof(work_buf), "%s", payload);

  char *saveptr;
  char *line = strtok_r(work_buf, "\n", &saveptr);
  int updates = 0;
  char sync_buffer[MAX_BUFFER];
  int sync_offset = 0;

  while (line) {
    if (strlen(line) < 2 || line[0] == '#' ||
        (frozen && !((line[0] == 'n' || line[0] == 'h') && line[1] == '|'))) {
      line = strtok_r(NULL, "\n", &saveptr);
      continue;
    }

    /* uf| / uc|: admin flags and oper channel bindings (hub_access.c).  A
     * bot pushes them for its own chattr / chanoper / +admin / +oper; they
     * are hub-authoritative records exactly like a| / o| / m|. */
    if ((line[0] == 'u') && (line[1] == 'f' || line[1] == 'c') && line[2] == '|') {
      bool changed = false;
      if (hub_only_mutations) {
        hub_log_warning("[HUB] opt 'h' active: REJECTED bot-pushed '%.2s' record from %s "
                        "(hub-authoritative)\n", line, hub_who_client(state, client));
      } else if (!hub_access_ingest(state, line[1], line + 3, true, &changed)) {
        hub_log_warning("[HUB] Ignored invalid '%.2s' record from %s\n", line,
                        hub_who_client(state, client));
      } else if (changed) {
        updates++;
        config_push_sync(state, sync_buffer, &sync_offset, client->fd, "%s\n", line);
      }
      line = strtok_r(NULL, "\n", &saveptr);
      continue;
    }

    /* hl|<addr>/<fp>,...: the hubs this bot dials (the console's hub del
     * preview).  Only the bot knows it, so it is taken under every opt and
     * stamped here when it changed. */
    if (line[0] == 'h' && line[1] == 'l' && line[2] == '|') {
      const char *v = line + 3;
      bot_config_t *b = bot_by_uuid(state, client->id);
      const config_entry_t *cur = b ? bot_entry_rec(b, "hl") : NULL;
      if (!hub_hublist_valid(v)) {
        hub_log_warning("[HUB] Ignored invalid hub list from %s\n", hub_who_client(state, client));
      } else if (b && (!cur || strcmp(cur->value, v) != 0)) {
        long long ts = (long long)hub_lww_next_ts(cur ? cur->timestamp : 0);
        if (hub_storage_update_entry(state, client->id, "hl", v, "", "", (time_t)ts)) {
          updates++;
          config_push_sync(state, sync_buffer, &sync_offset, client->fd,
                           "b|%s|hl|%s|%lld\n", client->id, v, ts);
        }
      }
      line = strtok_r(NULL, "\n", &saveptr);
      continue;
    }

    // Parse line: type|data
    char type = line[0];
    if (line[1] != '|') {
      line = strtok_r(NULL, "\n", &saveptr);
      continue;
    }

    char *data = line + 2;

    if (type == 'v') { /* read up front (push_proto) */
      line = strtok_r(NULL, "\n", &saveptr);
      continue;
    }

    /* Reject hub-authoritative record types from bots while opt 'h' is active.
     * 'c' is the exception for what a bot learns (key / modes of a channel
     * that is already managed): that is enforcement, not an admin change, and
     * stays accepted (D43) -- see the 'c' branch below. */
    if (hub_only_mutations &&
        (type == 'a' || type == 'o' || type == 'm')) {
      hub_log_warning("[HUB] opt 'h' active: REJECTED bot-pushed '%c' record from %s "
              "(hub-authoritative — mutation must originate from the admin console)\n",
              type, hub_who_client(state, client));
      line = strtok_r(NULL, "\n", &saveptr);
      continue;
    }

    // Special handling for different types
    if (type == 'c') {
      // Channel: c|#chan|key|modes|add|timestamp (new) or c|#chan|key|add|timestamp (old)
      char chan[MAX_CHAN], key[MAX_KEY], op[8];
      long long ts = 0;  /* the 4-field fallback can match 3 fields, no ts */
      int modes_val = 0;
      int parsed;

      /* Try new 5-field: chan|key|modes|op|ts */
      parsed = sscanf(data, "%64[^|]|%30[^|]|%d|%7[^|]|%lld",
                      chan, key, &modes_val, op, &ts);
      if (parsed < 5) {
        /* Try new 5-field without key: chan||modes|op|ts */
        modes_val = 0;
        parsed = sscanf(data, "%64[^|]||%d|%7[^|]|%lld",
                        chan, &modes_val, op, &ts);
        if (parsed >= 4) {
          key[0] = '\0';
        } else {
          /* Old 4-field: chan|key|op|ts */
          modes_val = 0;
          parsed = sscanf(data, "%64[^|]|%30[^|]|%7[^|]|%lld",
                          chan, key, op, &ts);
          if (parsed < 3) {
            parsed = sscanf(data, "%64[^|]||%7[^|]|%lld", chan, op, &ts);
            key[0] = '\0';
          }
        }
      }

      /* Opt 'h': a bot may only report the key / modes of a channel the
       * admins already manage; it may not add or remove one (D43). */
      if (parsed >= 3 && hub_only_mutations &&
          (strcmp(op, "add") != 0 || !hub_chan_live(state, chan, NULL, 0))) {
        hub_log_warning("[HUB] opt 'h' active: REJECTED bot-pushed 'c' %s for %s "
                "from %s (hub-authoritative)\n", op, chan, hub_who_client(state, client));
        parsed = 0;
      }

      if (parsed >= 3) {
        /* Build extra as "key|modes" so storage value = "chan|key|modes|op" */
        char extra[80];
        if (key[0])
          snprintf(extra, sizeof(extra), "%s|%d", key, modes_val);
        else
          snprintf(extra, sizeof(extra), "|%d", modes_val);

        bool accepted = hub_storage_update_global_entry(state, "c", chan, extra, op, ts);
        hub_log_debug("[HUB] Channel %s: ts=%lld op=%s modes=%d -> %s\n",
                chan, ts, op, modes_val, accepted ? "ACCEPTED" : "REJECTED");
        if (accepted) {
          updates++;
          /* Sync buffer: include modes for peer hubs */
          config_push_sync(state, sync_buffer, &sync_offset, client->fd,
                           "b|%s|c|%s|%s|%d|%s|%lld\n",
                           client->id, chan, key, modes_val, op, ts);
        }
      }
    } else if (type == 'K') {
      /* K|chan|key|modes|ts: what this bot saw on IRC (learned key, +k/+i).
       * Never existence: taken only while the channel is managed, under every
       * opt (enforcement, D43). */
      if (hub_learned_ingest(state, data)) {
        updates++;
        config_push_sync(state, sync_buffer, &sync_offset, client->fd, "K|%s\n", data);
      } else {
        hub_log_debug("[HUB] K| from %s not taken (channel not managed or not newer)\n",
                      hub_who_client(state, client));
      }
    } else if (type == 'B') {
      /* Enforcement ban: B|chan|mask|expires|flags|setter|reason|op|ts.  A bot
       * writes only its own timed bans (hub_ban_bot_write holds the rules);
       * opt 'h' does not gate it (D43). */
      char *tsp = strrchr(data, '|');
      char bval[1024];
      if (tsp && tsp > data && (size_t)(tsp - data) < sizeof(bval)) {
        memcpy(bval, data, (size_t)(tsp - data));
        bval[tsp - data] = '\0';
        long long bts = atoll(tsp + 1);
        if (hub_ban_bot_write(state, client->id, bval, (time_t)bts)) {
          updates++;
          config_push_sync(state, sync_buffer, &sync_offset, client->fd,
                           "B|%s|%lld\n", bval, bts);
        }
      }
    } else if (type == 'S') {
      /* Server pool entry (plan §4): hub_pool_bot_write holds the rules.  A
       * stamp-0 line is the bot's migration of its s| list: pool_migrate_gate
       * marks the first one (pm|) and says whether opt 'h' still takes it. */
      char sval[POOL_S_LINE_MAX];
      time_t sts = 0;
      const char *sbar = strrchr(data, '|');
      bool migrate_ok = sbar && strcmp(sbar + 1, "0") == 0 &&
                        pool_migrate_gate(state, client, sync_buffer, &sync_offset, &updates);
      if (hub_pool_bot_write(state, hub_who_client(state, client), data, hub_only_mutations,
                             migrate_ok, sval, sizeof(sval), &sts)) {
        updates++;
        config_push_sync(state, sync_buffer, &sync_offset, client->fd, "S|%s|%lld\n", sval,
                         (long long)sts);
      }
    } else if (type == 'N') {
      hub_log_warning("[HUB] Ignored bot-pushed 'N' record from %s (console only)\n",
                      hub_who_client(state, client));
    } else if (type == 'C' || type == 'D') {
      /* Channel settings and network defaults are written by the console only. */
      hub_log_warning("[HUB] Ignored bot-pushed '%c' record from %s (console only)\n",
              type, hub_who_client(state, client));
    } else if (type == 'm') {
      /* uuid|mask|add/del|last_used|timestamp; anything else is ignored */
      char first[40] = {0};
      char *pf = strchr(data, '|');
      if (pf) { size_t fl = (size_t)(pf-data); if (fl<sizeof(first)){memcpy(first,data,fl);first[fl]=0;} }
      bool is_new_m = (strlen(first)==36 && first[8]=='-' && first[13]=='-' && first[18]=='-' && first[23]=='-');
      if (is_new_m) {
        char *p1=strchr(data,'|'), *p2=p1?strchr(p1+1,'|'):NULL;
        char *p3=p2?strchr(p2+1,'|'):NULL, *p4=p3?strchr(p3+1,'|'):NULL;
        if (p1&&p2&&p3&&p4) {
          char uuid[37], mask_s[MAX_MASK_LEN], act[8];
          long long last_used, ts;
          snprintf(uuid,   sizeof(uuid),   "%.*s",(int)(p1-data),data);
          snprintf(mask_s, sizeof(mask_s), "%.*s",(int)(p2-p1-1),p1+1);
          snprintf(act,    sizeof(act),    "%.*s",(int)(p3-p2-1),p2+1);
          last_used = atoll(p3+1);
          ts        = atoll(p4+1);
          bool is_active = (strncmp(act,"add",3)==0);
          /* Find or create mask record */
          hub_mask_record_t *found_m = NULL;
          for (int mi=0; mi<state->mask_record_count; mi++) {
            if (strcmp(state->mask_records[mi].uuid,uuid)==0 &&
                strcasecmp(state->mask_records[mi].mask,mask_s)==0) {
              found_m = &state->mask_records[mi]; break;
            }
          }
          if (!found_m && state->mask_record_count < MAX_HUB_USER_MASKS &&
              !hub_ts_ahead((time_t)ts) &&
              (is_active || !hub_purge_floor_blocks(state, (time_t)ts))) {
            found_m = &state->mask_records[state->mask_record_count++];
            memset(found_m,0,sizeof(*found_m));
            snprintf(found_m->uuid,sizeof(found_m->uuid),"%s",uuid);
            snprintf(found_m->mask,sizeof(found_m->mask),"%s",mask_s);
          }
          if (found_m && hub_lww_accepts(ts, is_active, found_m->timestamp,
                                         found_m->is_active)) {
            found_m->is_active = is_active;
            if (last_used > found_m->last_used) found_m->last_used = last_used;
            found_m->timestamp = ts;
            state->config_dirty = true;
            updates++;
            config_push_sync(state, sync_buffer, &sync_offset, client->fd,
                             "m|%s|%s|%s|%lld|%lld\n", uuid, mask_s, act, last_used, ts);
          } else if (found_m) {
            /* Activity repair, outside LWW: not an update. */
            activity_raise(state, &found_m->last_used, (time_t)last_used);
          }
        }
      }
    } else if (type == 'o' || type == 'a') {
      /* hub_parse_user_record: uuid|name|pubkey|act|seen|ts|.  LWW by
       * timestamp.  Outside opt
       * 'h' the network lets bots create/re-key users (+admin/+oper/chkey);
       * a keyless push never erases a key the hub already holds. */
      hub_user_record_t in;
      if (hub_parse_user_record(data, type, &in)) {
        hub_user_record_t *found_u = NULL;
        for (int ui = 0; ui < state->user_record_count; ui++) {
          if (strcmp(state->user_records[ui].uuid, in.uuid) == 0) {
            found_u = &state->user_records[ui]; break;
          }
        }
        if (!found_u && state->user_record_count < MAX_HUB_USER_RECORDS &&
            !hub_ts_ahead(in.timestamp) &&
            (in.is_active || !hub_purge_floor_blocks(state, in.timestamp))) {
          found_u = &state->user_records[state->user_record_count++];
          memset(found_u, 0, sizeof(*found_u));
          snprintf(found_u->uuid, sizeof(found_u->uuid), "%s", in.uuid);
        }
        if (found_u && hub_lww_accepts(in.timestamp, in.is_active,
                                       found_u->timestamp, found_u->is_active)) {
          snprintf(found_u->name, sizeof(found_u->name), "%s", in.name);
          found_u->type      = type;
          found_u->is_active = in.is_active;
          if (in.last_seen > found_u->last_seen) found_u->last_seen = in.last_seen;
          found_u->timestamp = in.timestamp;
          if (in.has_pubkey) {
            snprintf(found_u->pubkey_b64, sizeof(found_u->pubkey_b64), "%s",
                     in.pubkey_b64);
            found_u->has_pubkey = true;
          }
          state->config_dirty = true;
          updates++;
          char uline[USER_LINE_MAX];
          int w = hub_format_user_record(found_u, uline, sizeof(uline));
          if (w > 0 && w < (int)sizeof(uline))
            config_push_sync(state, sync_buffer, &sync_offset, client->fd,
                             "%s", uline);
        } else if (found_u) {
          activity_raise(state, &found_u->last_seen, in.last_seen);
        }
      }
    } else if (type == 'h') {
      // Hostmask: h|nick!user@host|timestamp
      char hostmask[256];
      long long ts;
      if (sscanf(data, "%255[^|]|%lld", hostmask, &ts) == 2) {
        bool accepted = hub_storage_update_entry(state, client->id, "h", hostmask, "", "", ts);
        hub_log_debug("[HUB] Hostmask %s: ts=%lld -> %s\n", hostmask, ts, accepted ? "ACCEPTED" : "REJECTED");
        if (accepted) {
          updates++;
          // Broadcast in bot entry format: b|uuid|h|hostmask|timestamp
          config_push_sync(state, sync_buffer, &sync_offset, client->fd,
                           "b|%s|h|%s|%lld\n", client->id, hostmask, ts);
        }
      }
    } else if (type == 'n') {
      // Nick: n|nickname|timestamp
      char nick[MAX_NICK];
      long long ts;
      /* %31 not %32: a 32-char field + NUL would write 33 bytes into nick[32]
       * (1-byte stack overflow).  Reachable by any authenticated bot via an
       * 'n|' config-push record. */
      if (sscanf(data, "%31[^|]|%lld", nick, &ts) == 2) {
        bool accepted = hub_storage_update_entry(state, client->id, "n", nick, "", "", ts);
        hub_log_debug("[HUB] Nick %s: ts=%lld -> %s\n", nick, ts, accepted ? "ACCEPTED" : "REJECTED");
        if (accepted) {
          updates++;
          // Broadcast in bot entry format: b|uuid|n|nickname|timestamp
          config_push_sync(state, sync_buffer, &sync_offset, client->fd,
                           "b|%s|n|%s|%lld\n", client->id, nick, ts);
        }
      }
    }

    line = strtok_r(NULL, "\n", &saveptr);
  }

  /* A user this push created without uf| / uc| gets what it could do
   * before flags (hub_access_migrate). */
  if (hub_access_migrate(state) > 0) updates++;
  /* A hubless bot's removal may have left no +a admin: undo it everywhere. */
  if (updates > 0) {
    int restored = 0;
    char *floor = hub_admin_floor_restore(state, hub_who_client(state, client), &restored);
    if (floor) {
      if (floor[0]) hub_broadcast_sync_to_peers(state, floor, -1);
      free(floor);
    }
  }

  bool first_push = !client->pushed;
  client->pushed = true;

  if (updates > 0) {
    hub_log_debug("[HUB] Applied %d updates from %s\n", updates, hub_who_client(state, client));

    // Update "seen" timestamp to track last successful sync
    time_t now = time(NULL);
    hub_storage_update_entry(state, client->id, "seen", "", "", "", now);

    state->config_dirty = true;

    // Broadcast to peer hubs
    if (sync_offset > 0) {
      hub_broadcast_sync_to_peers(state, sync_buffer, client->fd);
    }

    // Broadcast to other bots
    // FIXED: Send FULL config to all connected bots to ensure consistency
    // This fixes issues where bots might miss updates if they were temporarily
    // unreachable
    broadcast_full_config_to_all_bots(state);
  } else if (first_push) {
    send_config_to_bot(state, client, true);
  }
}

void hub_generate_sync_packet(hub_state_t *state, char *buffer, int max_len) {
  int offset = 0;
  int written;
  buffer[0] = 0;

  // 1. Include global entries (c, m, o, a, p)
  // Note: h/n/w/x are hub-only local metadata and never belong here
  // - h/n: hub name/bind settings (shouldn't exist in global_entries)
  // - w/x: allowlist/denylist, kept in ip_allow/ip_deny (local-only)
  // Bot-specific h/n (like b|uuid|h|..., b|uuid|n|...) are synced in the bot loop below
  for (int i = 0; i < state->global_entry_count; i++) {
    config_entry_t *e = &state->global_entries[i];
    /* Skip local-only and entries now handled via typed arrays */
    if (strcmp(e->key, "h") == 0 || strcmp(e->key, "n") == 0 ||
        strcmp(e->key, "w") == 0 || strcmp(e->key, "x") == 0 ||
        strcmp(e->key, "a") == 0 || strcmp(e->key, "o") == 0 ||
        strcmp(e->key, "m") == 0 || strcmp(e->key, "p") == 0)
      continue;
    if (max_len - offset <= 1)
      break;

    // Format: key|value|timestamp (same as config file format)
    written = snprintf(buffer + offset, (size_t)(max_len - offset), "%s|%s|%ld\n",
                       e->key, e->value, (long)e->timestamp);
    if (written < 0 || written >= (max_len - offset))
      break;
    offset += written;
  }
  /* K|: what the bots saw on IRC, after the c| lines it hangs off. */
  hub_learned_append(state, buffer, max_len, &offset);

  /* User records so peer hubs share admin/oper records, in the passwordless
   * shape uuid|name|pubkey|act|seen|ts| (peers are HUBv3, so they parse it). */
  for (int i = 0; i < state->user_record_count; i++) {
    hub_user_record_t *u = &state->user_records[i];
    if (max_len - offset <= 1) break;
    written = hub_format_user_record(u, buffer + offset,
                                     (size_t)(max_len - offset));
    if (written < 0 || written >= (max_len - offset)) break;
    offset += written;
  }
  /* Include new-format mask records */
  for (int i = 0; i < state->mask_record_count; i++) {
    hub_mask_record_t *m = &state->mask_records[i];
    if (max_len - offset <= 1) break;
    written = snprintf(buffer + offset, (size_t)(max_len - offset),
                       "m|%s|%s|%s|%ld|%ld\n",
                       m->uuid, m->mask,
                       m->is_active ? "add" : "del",
                       (long)m->last_used, (long)m->timestamp);
    if (written < 0 || written >= (max_len - offset)) break;
    offset += written;
  }

  /* Admin flags and oper channel bindings, after the users they name. */
  hub_access_append(state, buffer, max_len, &offset, NULL, NULL);

  /* Include network opt flag string (peers must converge on this). */
  if (max_len - offset > 1 && state->opt_flags_ts > 0) {
    written = snprintf(buffer + offset, (size_t)(max_len - offset), "opt|%s|%ld\n",
                       state->opt_flags[0] ? state->opt_flags : "",
                       (long)state->opt_flags_ts);
    if (written > 0 && written < (max_len - offset)) offset += written;
  }

  /* Mesh-wide settings and the revoke list. */
  hub_gsetting_append(state, buffer, max_len, &offset);
  hub_revoke_append(state, buffer, max_len, &offset);

  // 2. Include bot entries
  for (int i = 0; i < state->bot_count; i++) {
    bot_config_t *b = &state->bots[i];
    if (max_len - offset <= 1)
      break;

    for (int j = 0; j < b->entry_count; j++) {
      if (max_len - offset <= 1)
        break;

      // Special handling for "seen" and "t" - omit value field
      if (strcmp(b->entries[j].key, "seen") == 0 || strcmp(b->entries[j].key, "t") == 0) {
        written = snprintf(buffer + offset, (size_t)(max_len - offset), "b|%s|%s|%ld\n",
                           b->uuid, b->entries[j].key,
                           (long)b->entries[j].timestamp);
      } else {
        written = snprintf(buffer + offset, (size_t)(max_len - offset), "b|%s|%s|%s|%ld\n",
                           b->uuid, b->entries[j].key, b->entries[j].value,
                           (long)b->entries[j].timestamp);
      }
      if (written < 0 || written >= (max_len - offset))
        break;
      offset += written;
    }
  }
}

// Helper: Check if a key is a global config key
static bool is_global_key(const char *key) {
  return (strcmp(key, "c") == 0 || strcmp(key, "m") == 0 ||
          strcmp(key, "o") == 0 || strcmp(key, "a") == 0 ||
          strcmp(key, "p") == 0 ||
          /* 2.4.5: channel settings, network defaults, bans */
          strcmp(key, "C") == 0 || strcmp(key, "D") == 0 ||
          strcmp(key, "B") == 0 ||
          /* 2.5.4: server pool network / server entry */
          strcmp(key, "N") == 0 || strcmp(key, "S") == 0);
}

// Helper: Store global entry directly without re-formatting (value is already combined)
static bool store_global_entry_raw(hub_state_t *state, const char *key,
                                   const char *value, time_t ts) {
  /* C|, D|, B|, N|, S|: one validator, one LWW, one set of ceilings. */
  if (strcmp(key, "C") == 0 || strcmp(key, "D") == 0 || strcmp(key, "B") == 0 ||
      strcmp(key, "N") == 0 || strcmp(key, "S") == 0)
    return hub_storage_put_record(state, key, value, ts);

  int i = hub_global_find(state, key, value);
  if (i >= 0) {
    config_entry_t *g = &state->global_entries[i];
    /* A channel keeps the spelling of its first writer (D39). */
    char norm[sizeof(g->value)];
    snprintf(norm, sizeof(norm), "%s", value);
    if (strcmp(key, "c") == 0) {
      const char *bar = strchr(value, '|');
      size_t sl = strcspn(g->value, "|");
      if (bar && sl + strlen(bar) < sizeof(norm)) {
        memcpy(norm, g->value, sl);
        strcpy(norm + sl, bar);
      }
    }
    if (hub_lww_accepts(ts, hub_global_value_active(norm), g->timestamp,
                        hub_global_value_active(g->value))) {
      snprintf(g->value, sizeof(g->value), "%s", norm);
      g->timestamp = ts;
      if (strcmp(key, "c") == 0 && !hub_global_value_active(norm)) {
        char chan[MAX_CHAN];
        size_t cl = strcspn(norm, "|");
        if (cl >= sizeof(chan)) cl = sizeof(chan) - 1;
        memcpy(chan, norm, cl);
        chan[cl] = '\0';
        hub_chan_cascade_del(state, chan, ts, false);
      }
      return true;
    }
    return false;
  }

  // Add new entry (a tombstone older than the last purge is not re-created)
  if (hub_ts_ahead(ts)) return false;
  if (!hub_global_value_active(value) && hub_purge_floor_blocks(state, ts))
    return false;
  if (hub_global_room(state, key)) {
    snprintf(state->global_entries[state->global_entry_count].key,
             sizeof(state->global_entries[state->global_entry_count].key), "%s",
             key);
    snprintf(state->global_entries[state->global_entry_count].value,
             sizeof(state->global_entries[state->global_entry_count].value),
             "%s", value);
    state->global_entries[state->global_entry_count].timestamp = ts;
    state->global_entry_count++;
    hub_global_note_new(state, state->global_entry_count - 1);
    return true;
  }
  return false;
}

/* Split a stored global 'c' entry value into its parts.
 *
 * Two shapes exist because two writers produce them:
 *   3-field  chan|key|op        — CMD_ADMIN_ADD/DEL_CHANNEL and legacy records
 *   4-field  chan|key|modes|op  — process_bot_config_push (bots report modes)
 * Both share the same anchors — channel is the first field, op is the last — so
 * split on those instead of counting fields.  Whatever sits between is the key,
 * optionally followed by the modes.  Reading op as the *last* field is what makes
 * the "del" tombstone check reliable across both shapes: a positional parse reads
 * "0|del" as the op on the 4-field form and treats a deleted channel as live.
 *
 * Any out-param may be NULL.  Returns false only when value has no '|' at all. */
static bool parse_global_channel_value(const char *value,
                                       char *chan_out, size_t chan_len,
                                       char *key_out, size_t key_len,
                                       int *modes_out,
                                       char *op_out, size_t op_len) {
  if (chan_out && chan_len) chan_out[0] = '\0';
  if (key_out && key_len)   key_out[0]  = '\0';
  if (op_out && op_len)     op_out[0]   = '\0';
  if (modes_out)            *modes_out  = 0;
  if (!value) return false;

  const char *first = strchr(value, '|');
  const char *last  = strrchr(value, '|');
  if (!first || !last) return false;

  if (chan_out && chan_len) {
    size_t n = (size_t)(first - value);
    if (n >= chan_len) n = chan_len - 1;
    memcpy(chan_out, value, n);
    chan_out[n] = '\0';
  }
  if (op_out && op_len) {
    size_t n = strlen(last + 1);
    if (n >= op_len) n = op_len - 1;
    memcpy(op_out, last + 1, n);
    op_out[n] = '\0';
  }

  /* Middle field(s): "key" (3-field) or "key|modes" (4-field). */
  if (last > first) {
    char middle[128];
    size_t n = (size_t)(last - first - 1);
    if (n >= sizeof(middle)) n = sizeof(middle) - 1;
    memcpy(middle, first + 1, n);
    middle[n] = '\0';

    char *sep = strrchr(middle, '|');
    if (sep) {
      *sep = '\0';
      if (modes_out) *modes_out = atoi(sep + 1);
    }
    if (key_out && key_len) {
      size_t klen = strlen(middle);
      if (klen >= key_len) klen = key_len - 1;
      memcpy(key_out, middle, klen);
      key_out[klen] = '\0';
    }
  }
  return true;
}

/* Modes currently recorded for a channel, or 0 when unknown.  The admin add path
 * has no modes of its own — they only ever arrive from a bot reporting a live
 * MODE change — so a re-add must carry forward what is already stored.  Global
 * entries are overwritten wholesale once the timestamp wins
 * (hub_storage_update_global_entry), so not carrying them forward erases them.
 * Matched ASCII case-insensitively on the channel name (D39), same as the storage layer. */
/* The +k/+i the bots last saw (K|), 0 when no bot has reported the channel. */
static int global_channel_modes(hub_state_t *state, const char *chan) {
  const hub_chan_learned_t *l = hub_learned_find(state, chan);
  return l ? l->modes : 0;
}

static void process_peer_sync(hub_state_t *state, char *payload,
                              int origin_fd, bool bcast) {
  char *saveptr;
  /* Change 5: a full-state peer sync can far exceed MAX_BUFFER (usermasks
   * alone reach tens of KB), so both the tokenizing copy and the re-forward
   * buffer are heap-allocated to the sync ceiling.  A stack MAX_BUFFER here
   * silently truncated the sync, dropping every record past 16 KB. */
  const size_t sync_cap = MAX_SYNC_PAYLOAD;
  /* The tokenizing copy is sized to this frame.  The forward buffer keeps the
   * full ceiling -- forwarded lines can be re-formatted from stored records,
   * longer than they came in -- but is allocated once and reused, not twice
   * MAX_SYNC_PAYLOAD per frame (review 2026-10-25 #25).  One caller, the
   * pump, so it is never in use twice. */
  static char *forward_buf;
  size_t plen = strnlen(payload, sync_cap - 1);
  char *work_buf = malloc(plen + 1);
  if (!forward_buf) forward_buf = malloc(sync_cap);
  if (!work_buf || !forward_buf) {
    free(work_buf);
    return;
  }
  memcpy(work_buf, payload, plen);
  work_buf[plen] = '\0';

  char *line = strtok_r(work_buf, "\n", &saveptr);
  int updates = 0;
  int bot_push_updates = 0; /* only keys bots actually consume; gates full config push */
  int fwd_offset = 0;
  forward_buf[0] = 0;
  g_hub_stats.sync_frames++;

  /* Sync tracing: every record applied is logged, and in a delta (not a
   * full-state sync) every record refused too. */
  const char *frame = bcast ? "PEER_BCAST" : "PEER_SYNC";
  bool trace = sync_trace_lines(payload) <= SYNC_TRACE_MAX_LINES;
  char from[HUB_WHO_MAX] = "?";
  for (int i = 0; i < state->client_count; i++)
    if (state->clients[i]->fd == origin_fd)
      snprintf(from, sizeof(from), "%s", hub_who_client(state, state->clients[i]));

  while (line) {
    g_hub_stats.sync_records++;
    // Check for PURGE command
    if (strncmp(line, "PURGE|", 6) == 0) {
      time_t cutoff;
      char purge_id[PURGE_ID_HEX + 1];
      if (!parse_purge_line(line, &cutoff, purge_id)) {
        hub_log_warning("[MESH] Dropped malformed PURGE line from peer\n");
      } else {
        hub_log_info("[MESH] Received PURGE from peer: cutoff=%ld id=%s\n",
                (long)cutoff, purge_id[0] ? purge_id : "-");

        // DEDUPLICATION: Check if this PURGE was recently seen
        if (is_purge_recent(state, cutoff, purge_id)) {
          hub_log_debug("[MESH] PURGE cutoff=%ld id=%s already processed recently, skipping to prevent loop\n",
                  (long)cutoff, purge_id[0] ? purge_id : "-");
        } else {
          // Record this PURGE and process it
          record_recent_purge(state, cutoff, purge_id);

          int purged = hub_execute_purge(state, cutoff, NULL);
          if (purged > 0) {
            hub_log_info("[MESH] Purged %d entries from peer sync\n", purged);
            updates += purged;
          }

          // Forward to all other peers (exclude sender to prevent immediate
          // echo; combined with deduplication prevents feedback loops).
          if (origin_fd != -1) {
            sync_forward_to_peers(state, line, origin_fd, bcast);
          }
        }
      }
      line = strtok_r(NULL, "\n", &saveptr);
      continue;
    }

    /* uf| / uc|: admin flags and oper channel bindings (hub_access.c), for
     * users this hub holds (their a| / o| lines come first in every sync). */
    if (line[0] == 'u' && (line[1] == 'f' || line[1] == 'c') && line[2] == '|') {
      bool changed = false;
      if (hub_access_ingest(state, line[1], line + 3, true, &changed) && changed) {
        updates++;
        bot_push_updates++;
        if (fwd_offset < (int)sync_cap - UC_LINE_MAX) {
          int wfwd = snprintf(forward_buf + fwd_offset, sync_cap - (size_t)fwd_offset,
                              "%s\n", line);
          if (wfwd > 0) fwd_offset += wfwd;
        }
      }
      line = strtok_r(NULL, "\n", &saveptr);
      continue;
    }

    /* K|chan|key|modes|ts: what the bots saw on IRC.  Taken only while the
     * channel is managed here; its c| line comes first in every sync. */
    if (line[0] == 'K' && line[1] == '|') {
      if (hub_learned_ingest(state, line + 2)) {
        updates++;
        bot_push_updates++;
        state->config_dirty = true;
        if (fwd_offset < (int)sync_cap - K_LINE_MAX) {
          int wfwd = snprintf(forward_buf + fwd_offset, sync_cap - (size_t)fwd_offset,
                              "%s\n", line);
          if (wfwd > 0) fwd_offset += wfwd;
        }
      }
      line = strtok_r(NULL, "\n", &saveptr);
      continue;
    }

    /* Handle 'opt|<letters>|<ts>' from peer hubs (mesh-replicated opt flags),
     * including the 'opt||<ts>' of a clear.  Adopt it if newer than ours. */
    if (strncmp(line, "opt|", 4) == 0) {
      char incoming_flags[MAX_OPT_FLAGS + 1];
      time_t incoming_ts;
      if (hub_parse_opt_value(line + 4, incoming_flags, &incoming_ts)) {
        if (hub_opt_accepts(incoming_ts, incoming_flags, state->opt_flags_ts,
                            state->opt_flags)) {
          memcpy(state->opt_flags, incoming_flags, sizeof(incoming_flags));
          state->opt_flags_ts = incoming_ts;
          state->config_dirty = true;
          updates++;
          bot_push_updates++;
          if (fwd_offset < (int)sync_cap - 64) {
            int wfwd = snprintf(forward_buf + fwd_offset,
                                sync_cap - (size_t)fwd_offset,
                                "%s\n", line);
            if (wfwd > 0) fwd_offset += wfwd;
          }
        }
      }
      line = strtok_r(NULL, "\n", &saveptr);
      continue;
    }

    /* hs|<name>|<value>|<ts>: a mesh-wide hub setting (hub_revoke.c). */
    if (strncmp(line, "hs|", 3) == 0) {
      bool changed = false;
      if (hub_gsetting_ingest(state, line + 3, &changed) && changed) {
        updates++;
        if (fwd_offset < (int)sync_cap - HS_LINE_MAX) {
          int wfwd = snprintf(forward_buf + fwd_offset, sync_cap - (size_t)fwd_offset,
                              "%s\n", line);
          if (wfwd > 0) fwd_offset += wfwd;
        }
      }
      line = strtok_r(NULL, "\n", &saveptr);
      continue;
    }

    /* rv|...: a revoked bot, union-merged (hub_revoke.c). */
    if (strncmp(line, "rv|", 3) == 0) {
      hub_revoked_t rv;
      if (!hub_revoke_parse(line + 3, &rv)) {
        hub_log_warning("[MESH] Dropped malformed rv| line from peer\n");
      } else if (hub_revoke_merge(state, &rv)) {
        updates++;
        if (fwd_offset < (int)sync_cap - RV_LINE_MAX) {
          int wfwd = hub_revoke_format(hub_revoke_find(state, rv.uuid),
                                       forward_buf + fwd_offset,
                                       sync_cap - (size_t)fwd_offset);
          if (wfwd > 0 && wfwd < (int)(sync_cap - (size_t)fwd_offset)) fwd_offset += wfwd;
        }
      }
      line = strtok_r(NULL, "\n", &saveptr);
      continue;
    }

    // Check if this is a global entry (format: key|value|timestamp)
    // Global keys: c, m, o, a, p (NOT starting with b|)
    if (strncmp(line, "b|", 2) != 0) {
      char *p1 = strchr(line, '|');
      if (p1) {
        // Extract key (before first |)
        char key[32];
        size_t key_len = (size_t)(p1 - line);
        if (key_len < sizeof(key)) {
          memcpy(key, line, key_len);
          key[key_len] = 0;

          if (is_global_key(key)) {
            /* Detect new-format user/mask records by UUID in first value field.
             * New: a|uuid|name|pass|add/del|last_seen|ts  (7 pipe-fields)
             *      o|uuid|name|pass|add/del|last_seen|ts
             *      m|uuid|mask|add/del|last_used|ts        (6 pipe-fields)
             * Route these to typed arrays; old-format goes to global_entries. */
            bool is_user_key = (key[0]=='a' || key[0]=='o') && key[1]=='\0';
            bool is_mask_key = key[0]=='m' && key[1]=='\0';

            if (is_user_key || is_mask_key) {
              /* Check if first value field looks like a UUID */
              char *vstart = p1 + 1;
              char *vp1 = strchr(vstart, '|');
              char first_f[40] = {0};
              if (vp1) {
                size_t fl = (size_t)(vp1 - vstart);
                if (fl < sizeof(first_f)) { memcpy(first_f, vstart, fl); first_f[fl]=0; }
              }
              bool is_new_fmt = (strlen(first_f)==36 && first_f[8]=='-' &&
                                 first_f[13]=='-' && first_f[18]=='-' && first_f[23]=='-');

              if (is_new_fmt && is_user_key) {
                /* hub_parse_user_record: uuid|name|pubkey|act|seen|ts| */
                hub_user_record_t in;
                if (hub_parse_user_record(vstart, key[0], &in)) {
                  const char *uuid = in.uuid, *uname = in.name;
                  long long last_seen = (long long)in.last_seen;
                  long long ts = (long long)in.timestamp;
                  hub_user_record_t *found_u = NULL;
                  for (int ui=0; ui<state->user_record_count; ui++)
                    if (strcmp(state->user_records[ui].uuid,uuid)==0)
                      { found_u=&state->user_records[ui]; break; }
                  bool discard_incoming = false;
                  if (!found_u && in.is_active) {
                    /* No UUID match — two LIVE records of one name are the
                     * same user created on two hubs at once: merge them.  A
                     * tombstone is never merged by name: it is a past
                     * incarnation (add, del, add again) and stays its own
                     * uuid, as on the hub that made it — merging it there
                     * left the hubs holding different records. */
                    for (int ni=0; ni<state->user_record_count; ni++) {
                      hub_user_record_t *ex = &state->user_records[ni];
                      if (ex->is_active && ex->type == key[0] &&
                          strcasecmp(ex->name, uname) == 0) {
                        bool incoming_wins = (last_seen > ex->last_seen) ||
                            (last_seen == ex->last_seen && ts > ex->timestamp) ||
                            (last_seen == ex->last_seen && ts == ex->timestamp &&
                             strcmp(uuid, ex->uuid) < 0);
                        if (incoming_wins) {
                          hub_log_info("[MESH] Dedup: '%s' (%c) UUID collision resolved, adopting %s\n",
                                  uname, key[0], hub_who(state, 'u', uuid));
                          /* Remap existing record's masks, flags and channel
                           * bindings to the incoming UUID */
                          hub_access_remap_uuid(state, ex->uuid, uuid);
                          for (int mi=0; mi<state->mask_record_count; mi++)
                            if (strcmp(state->mask_records[mi].uuid, ex->uuid) == 0)
                              snprintf(state->mask_records[mi].uuid, 37, "%s", uuid);
                          /* Update the user record's own UUID so the next sync
                           * finds it by UUID lookup and skips the name collision path */
                          snprintf(ex->uuid, sizeof(ex->uuid), "%s", uuid);
                          state->config_dirty = true;
                          found_u = ex;
                        } else {
                          discard_incoming = true;
                        }
                        break;
                      }
                    }
                  }
                  if (!found_u && !discard_incoming &&
                      state->user_record_count < MAX_HUB_USER_RECORDS &&
                      !hub_ts_ahead(in.timestamp) &&
                      (in.is_active || !hub_purge_floor_blocks(state, in.timestamp))) {
                    found_u=&state->user_records[state->user_record_count++];
                    memset(found_u,0,sizeof(*found_u));
                    snprintf(found_u->uuid,sizeof(found_u->uuid),"%s",uuid);
                  }
                  if (!discard_incoming && found_u &&
                      hub_lww_accepts((time_t)ts, in.is_active,
                                      found_u->timestamp, found_u->is_active)) {
                    snprintf(found_u->name, sizeof(found_u->name), "%s", uname);
                    found_u->type      = key[0];
                    found_u->is_active = in.is_active;
                    if (last_seen > found_u->last_seen) found_u->last_seen = last_seen;
                    found_u->timestamp = ts;
                    if (in.has_pubkey) {
                      snprintf(found_u->pubkey_b64, sizeof(found_u->pubkey_b64),
                               "%s", in.pubkey_b64);
                      found_u->has_pubkey = true;
                    }
                    state->config_dirty = true;
                    updates++;
                    bot_push_updates++; /* admin/oper name change — bots need this */
                    /* Forward our canonical a|/o| line, never the raw one. */
                    char uline[USER_LINE_MAX];
                    int ul = hub_format_user_record(found_u, uline,
                                                    sizeof(uline));
                    if (ul > 0 && ul < (int)sizeof(uline) &&
                        fwd_offset < (int)sync_cap - USER_LINE_MAX) {
                      memcpy(forward_buf + fwd_offset, uline, (size_t)ul);
                      fwd_offset += ul;
                      forward_buf[fwd_offset] = '\0';
                    }
                  } else if (!discard_incoming && found_u) {
                    /* Activity repair, outside LWW: not an update. */
                    activity_raise(state, &found_u->last_seen, (time_t)last_seen);
                  }
                }
                line = strtok_r(NULL, "\n", &saveptr);
                continue;
              }

              if (is_new_fmt && is_mask_key) {
                /* Parse: uuid|mask|add/del|last_used|ts */
                char *pp1=vp1, *pp2=pp1?strchr(pp1+1,'|'):NULL;
                char *pp3=pp2?strchr(pp2+1,'|'):NULL, *pp4=pp3?strchr(pp3+1,'|'):NULL;
                if (pp1&&pp2&&pp3&&pp4) {
                  char uuid[37], mask_s[MAX_MASK_LEN], act[8];
                  long long last_used, ts;
                  snprintf(uuid,   sizeof(uuid),   "%.*s",(int)(pp1-vstart),vstart);
                  snprintf(mask_s, sizeof(mask_s), "%.*s",(int)(pp2-pp1-1),pp1+1);
                  snprintf(act,    sizeof(act),    "%.*s",(int)(pp3-pp2-1),pp2+1);
                  last_used = atoll(pp3+1); ts = atoll(pp4+1);
                  bool is_active = (strncmp(act,"add",3)==0);
                  /* Reject masks for unknown user UUIDs */
                  bool uuid_known = false;
                  for (int ui=0; ui<state->user_record_count; ui++)
                    if (strcmp(state->user_records[ui].uuid,uuid)==0)
                      { uuid_known=true; break; }
                  if (!uuid_known) {
                    line = strtok_r(NULL, "\n", &saveptr);
                    continue;
                  }
                  hub_mask_record_t *found_m = NULL;
                  for (int mi=0; mi<state->mask_record_count; mi++)
                    if (strcmp(state->mask_records[mi].uuid,uuid)==0 &&
                        strcasecmp(state->mask_records[mi].mask,mask_s)==0)
                      { found_m=&state->mask_records[mi]; break; }
                  if (!found_m && state->mask_record_count < MAX_HUB_USER_MASKS &&
                      !hub_ts_ahead((time_t)ts) &&
                      (is_active || !hub_purge_floor_blocks(state, (time_t)ts))) {
                    found_m=&state->mask_records[state->mask_record_count++];
                    memset(found_m,0,sizeof(*found_m));
                    snprintf(found_m->uuid,sizeof(found_m->uuid),"%s",uuid);
                    snprintf(found_m->mask,sizeof(found_m->mask),"%s",mask_s);
                  }
                  if (found_m && hub_lww_accepts(ts, is_active, found_m->timestamp,
                                                 found_m->is_active)) {
                    found_m->is_active = is_active;
                    if (last_used > found_m->last_used) found_m->last_used = last_used;
                    found_m->timestamp = ts;
                    state->config_dirty = true;
                    updates++;
                    bot_push_updates++; /* mask record — bots need this */
                    if (fwd_offset < (int)sync_cap - 200) {
                      int w = snprintf(forward_buf+fwd_offset,
                                       sync_cap-(size_t)fwd_offset,
                                       "%s\n", line);
                      if (w>0) fwd_offset += w;
                    }
                  } else if (found_m) {
                    activity_raise(state, &found_m->last_used, (time_t)last_used);
                  }
                }
                line = strtok_r(NULL, "\n", &saveptr);
                continue;
              }
            }

            /* Retired password-era shapes — the shared bot password p| and
             * the pre-UUID a|<password>|<ts> / o|<mask>|<password>|.. rows —
             * are dropped, never stored or forwarded. */
            if (strcmp(key, "p") == 0 || is_user_key) {
              line = strtok_r(NULL, "\n", &saveptr);
              continue;
            }

            /* Old-format or non-user global key: store in global_entries */
            char *p_last = strrchr(p1 + 1, '|');
            if (p_last && p_last > p1) {
              char val[1024];
              size_t val_len = (size_t)(p_last - (p1 + 1));
              if (val_len < sizeof(val)) {
                memcpy(val, p1 + 1, val_len);
                val[val_len] = 0;
                long long ts = atoll(p_last + 1);

                bool stored = store_global_entry_raw(state, key, val, ts);
                if (stored || trace)
                  hub_log_debug("[MESH] %s from %s: %s|%s|%lld -> %s\n", frame, from, key, val,
                                ts, stored ? "applied" : "refused");
                if (stored) {
                  updates++;
                  bot_push_updates++; /* channel/password/global — bots need this */
                  // Forward to other peers
                  if (sync_cap - (size_t)fwd_offset > 1200) {
                    int w = snprintf(forward_buf + fwd_offset,
                                     sync_cap - (size_t)fwd_offset,
                                     "%s|%s|%lld\n", key, val, ts);
                    if (w > 0 && w < (int)(sync_cap - (size_t)fwd_offset)) {
                      fwd_offset += w;
                    }
                  }
                }
              }
            }
            line = strtok_r(NULL, "\n", &saveptr);
            continue;
          }
        }
      }
    }

    // Handle bot entries (format: b|uuid|key|value|timestamp)
    char *ptr = line;
    if (strncmp(line, "b|", 2) == 0) {
      ptr = line + 2;
    }

    char uuid[64], key[32], val[1024];
    long long ts;

    char *p1 = strchr(ptr, '|');
    if (p1) {
      *p1 = 0;
      char *p2 = strchr(p1 + 1, '|');
      if (p2) {
        *p2 = 0;
        char *p3 = strrchr(p2 + 1, '|');
        /* seen/t entries are 3-field: b|uuid|key|timestamp (no value).
         * When p3 is NULL the timestamp sits at p2+1 and value is empty. */
        if (!p3 && (strcmp(p1 + 1, "seen") == 0 || strcmp(p1 + 1, "t") == 0)) {
          snprintf(uuid, sizeof(uuid), "%s", ptr);
          snprintf(key,  sizeof(key),  "%s", p1 + 1);
          val[0] = '\0';
          ts = atoll(p2 + 1);
          if (hub_storage_update_entry(state, uuid, key, "", "", "", ts)) {
            updates++;
            if (sync_cap - (size_t)fwd_offset > 200) {
              int w = snprintf(forward_buf + fwd_offset,
                               sync_cap - (size_t)fwd_offset,
                               "b|%s|%s|%lld\n", uuid, key, ts);
              if (w > 0 && w < (int)(sync_cap - (size_t)fwd_offset))
                fwd_offset += w;
            }
          }
          line = strtok_r(NULL, "\n", &saveptr);
          continue;
        }
        if (p3) {
          *p3 = 0;
          snprintf(uuid, sizeof(uuid), "%s", ptr);
          snprintf(key, sizeof(key), "%s", p1 + 1);
          snprintf(val, sizeof(val), "%s", p2 + 1);
          ts = atoll(p3 + 1);

          // For c/m/o keys, parse the combined value format.  The split
          // works on a scratch copy: val itself is re-forwarded to the other
          // peers below and must leave exactly as it arrived.  Splitting val
          // in place forwarded "b|uuid|c|#chan|ts" -- no key, modes or op --
          // which the next hub stored as an add, turning deletes into adds
          // one hop out.
          char parsed_val[512] = "", parsed_extra[256] = "", parsed_op[16] = "";
          char split[sizeof(val)];
          memcpy(split, val, strlen(val) + 1);
          if (strcmp(key, "c") == 0 || strcmp(key, "o") == 0) {
            /* Format: chan|key[|modes]|op  (3 or 4 fields)
             * Use first pipe for chan, last pipe for op, middle = extra */
            char *vp1 = strchr(split, '|');
            if (vp1) {
              *vp1 = 0;
              size_t len = strlen(split);
              if (len >= sizeof(parsed_val)) len = sizeof(parsed_val) - 1;
              memcpy(parsed_val, split, len);
              parsed_val[len] = 0;
              /* last pipe gives op (add/del), everything between = extra */
              char *last = strrchr(vp1 + 1, '|');
              if (last) {
                *last = 0;
                len = strlen(last + 1);
                if (len >= sizeof(parsed_op)) len = sizeof(parsed_op) - 1;
                memcpy(parsed_op, last + 1, len);
                parsed_op[len] = 0;
                /* extra = "key" or "key|modes" */
                len = strlen(vp1 + 1);
                if (len >= sizeof(parsed_extra)) len = sizeof(parsed_extra) - 1;
                memcpy(parsed_extra, vp1 + 1, len);
                parsed_extra[len] = 0;
              }
            }
          } else if (strcmp(key, "m") == 0) {
            // Format: value|op
            char *vp1 = strchr(split, '|');
            if (vp1) {
              *vp1 = 0;
              size_t len = strlen(split);
              if (len >= sizeof(parsed_val)) len = sizeof(parsed_val) - 1;
              memcpy(parsed_val, split, len);
              parsed_val[len] = 0;
              len = strlen(vp1 + 1);
              if (len >= sizeof(parsed_op)) len = sizeof(parsed_op) - 1;
              memcpy(parsed_op, vp1 + 1, len);
              parsed_op[len] = 0;
            }
          }
          // For other keys (pub, h, n, etc.): leave parsed_val empty
          // so hub_storage_update_entry will use the original val buffer

          bool stored = hub_storage_update_entry(state, uuid, key,
                                                 parsed_val[0] ? parsed_val : val,
                                                 parsed_extra, parsed_op, ts);
          if (stored || trace)
            hub_log_debug("[MESH] %s from %s: %s %s|%s|%lld -> %s\n", frame, from,
                          hub_who(state, 'b', uuid), key, val, ts,
                          stored ? "applied" : "refused");
          if (stored) {
            updates++;
            /* seen/t are hub-side metadata; bots don't consume them */
            if (strcmp(key, "seen") != 0 && strcmp(key, "t") != 0 &&
                strcmp(key, "pm") != 0)
              bot_push_updates++;

            if (sync_cap - (size_t)fwd_offset > 1200) {
              int w = snprintf(forward_buf + fwd_offset,
                               sync_cap - (size_t)fwd_offset,
                               "b|%s|%s|%s|%lld\n", uuid, key, val, ts);
              if (w > 0 && w < (int)(sync_cap - (size_t)fwd_offset)) {
                fwd_offset += w;
              }
            }
          }
        }
      }
    }
    line = strtok_r(NULL, "\n", &saveptr);
  }

  /* Records left on a merged-away uuid go; a user this sync created without
   * uf| / uc| gets its default (hub_access_migrate). */
  hub_access_prune(state);
  if (hub_access_migrate(state) > 0) {
    updates++;
    bot_push_updates++;
  }
  /* Two hubs that each removed a different +a admin before they synced may
   * have left none: undo the race, on every peer including the sender. */
  if (updates > 0) {
    int restored = 0;
    char *floor = hub_admin_floor_restore(state, "a peer sync", &restored);
    if (floor) {
      if (floor[0]) hub_broadcast_sync_to_peers(state, floor, -1);
      bot_push_updates++;
      free(floor);
    }
  }

  if (updates > 0)
    g_hub_stats.sync_applied += (uint64_t)updates;
  else
    g_hub_stats.sync_noop++;

  if (updates > 0) {
    state->config_dirty = true;
    /* A bot this sync deleted that is connected here is told to wipe. */
    hub_retire_revoked_bots(state);

    if (fwd_offset > 0)
      sync_forward_to_peers(state, forward_buf, origin_fd, bcast);

    if (bot_push_updates > 0)
      broadcast_full_config_to_all_bots(state);
  }

  free(work_buf);
  /* kept for the next frame: wipe what this one put in it */
  secure_wipe(forward_buf, (size_t)fwd_offset + 1);
}

static bool send_response(hub_state_t *state, hub_client_t *client,
                          const char *msg) {
  if (client->internal) {
    /* An SSH console: queued plaintext, never a partial write. */
    if (hub_console_send(client, CONSOLE_REPLY, msg, strlen(msg))) return true;
    hub_log_warning("[CONSOLE] %s's console is not reading — closing it\n",
                    client->console ? client->id : "?");
    hub_disconnect_client(state, client);
    return false;
  }
  /* Admin replies go to SSH consoles only; a bot that sent an admin opcode
   * gets none (a frame sealed here, outside the queue, would also break the
   * link's sequence: review 6). */
  hub_log_debug("[HUB] Admin reply to non-console %s dropped\n", client->ip);
  return true;
}

static bool send_pong(hub_state_t *state, hub_client_t *c) {
  char tp[128];
  hub_bot_ping_payload(state, c, tp, sizeof(tp));
  if (!hub_client_send(state, c, CMD_PING, tp[0] ? tp : NULL)) {
    hub_disconnect_client(state, c);
    return false;
  }
  return true;
}

/* A change the bots must see.  The line is for the log only: what reaches the
 * bots is the full config, owed through broadcast_full_config_to_all_bots and
 * coalesced by hub_flush_bot_config like every other push. */
static void hub_broadcast_config_to_bots(hub_state_t *state,
                                          const char *config_line) {
  hub_log_debug("[HUB] Broadcasting config update to all bots: %s", config_line);
  broadcast_full_config_to_all_bots(state);
}

// Execute tombstone purge locally.
// cutoff == 0: purge all tombstones regardless of age.
// cutoff  > 0: purge tombstones whose timestamp is older than cutoff.
// Peer-hub propagation is the caller's responsibility.
/* One purged tombstone, for the console (tomb|kind|id|name|ts). */
static void purge_note(reply_t *tombs, const char *kind, const char *id,
                       const char *name, time_t ts) {
  if (!tombs) return;
  reply_rec(tombs, "tomb");
  reply_kv(tombs, "kind", kind);
  if (id && id[0]) reply_kv(tombs, "id", id);
  if (name && name[0]) reply_kv(tombs, "name", name);
  if (ts > 0) reply_kvi(tombs, "ts", (long long)ts);
}

static void purge_note_orphan(void *arg, const char *kind, const char *name, time_t ts) {
  purge_note((reply_t *)arg, kind, NULL, name, ts);
}

int hub_execute_purge(hub_state_t *state, time_t cutoff, reply_t *tombs) {
  int purged_count = 0;
  /* For PURGE_FLOOR_HOLD, a sync built before this purge cannot re-create
   * what it removes. */
  hub_purge_floor_set(state, cutoff);

  // --- Purge tombstoned global entries (channels, admin masks, oper masks,
  //     channel settings, bans), compacted in place ---
  int new_count = 0;

  for (int i = 0; i < state->global_entry_count; i++) {
    bool is_tombstone = false;
    const config_entry_t *g = &state->global_entries[i];

    if (strcmp(g->key, "c") == 0 || strcmp(g->key, "m") == 0 ||
        strcmp(g->key, "o") == 0 || strcmp(g->key, "C") == 0 ||
        strcmp(g->key, "B") == 0) {
      const char *last_pipe = strrchr(g->value, '|');
      if (last_pipe && strcmp(last_pipe + 1, "del") == 0) {
        is_tombstone = true;
      }
    }

    if (is_tombstone && (cutoff == 0 || g->timestamp < cutoff)) {
      purged_count++;
      char name[256];
      size_t n = strcspn(g->value, "|");
      snprintf(name, sizeof(name), "%.*s", (int)(n < 255 ? n : 255), g->value);
      purge_note(tombs, g->key[0] == 'c' ? "channel" : g->key[0] == 'm' ? "mask" :
                 g->key[0] == 'C' ? "chanset" : g->key[0] == 'B' ? "ban" : "oper",
                 NULL, name, g->timestamp);
    } else {
      if (new_count != i)
        memmove(&state->global_entries[new_count], g, sizeof(config_entry_t));
      new_count++;
    }
  }

  state->global_entry_count = new_count;
  hub_global_reindex(state);

  // --- Orphans: live C| / B| (not "*") / K| of a channel no one manages,
  //     whatever the cutoff (every hub and bot applies the same rule) ---
  purged_count += hub_purge_chan_orphans(state, purge_note_orphan, tombs);

  // --- Purge tombstoned user_records (admins/opers) ---
  hub_user_record_t new_users[MAX_HUB_USER_RECORDS];
  int new_user_count = 0;
  for (int i = 0; i < state->user_record_count; i++) {
    if (!state->user_records[i].is_active &&
        (cutoff == 0 || state->user_records[i].timestamp < cutoff)) {
      purged_count++;
      purge_note(tombs, "user", NULL, state->user_records[i].name,
                 state->user_records[i].timestamp);
    } else {
      if (new_user_count < MAX_HUB_USER_RECORDS)
        new_users[new_user_count++] = state->user_records[i];
    }
  }
  memcpy(state->user_records, new_users, sizeof(hub_user_record_t) * (size_t)new_user_count);
  state->user_record_count = new_user_count;

  // --- Purge tombstoned mask_records, and masks whose user is gone ---
  /* A mask with no user record left (its user purged above or earlier) can
   * never authenticate anyone and only holds a slot of the shared table.
   * Such orphans were left live on peers and bots by user deletes that did
   * not send the masks' tombstones; every hub applies the same rule on the
   * same PURGE, so they converge away. */
  hub_mask_record_t new_masks[MAX_HUB_USER_MASKS];
  int new_mask_count = 0;
  for (int i = 0; i < state->mask_record_count; i++) {
    bool owned = false;
    for (int u = 0; u < state->user_record_count; u++) {
      if (strcmp(state->user_records[u].uuid, state->mask_records[i].uuid) == 0) {
        owned = true;
        break;
      }
    }
    if (!owned ||
        (!state->mask_records[i].is_active &&
         (cutoff == 0 || state->mask_records[i].timestamp < cutoff))) {
      purged_count++;
      purge_note(tombs, "mask", NULL, state->mask_records[i].mask,
                 state->mask_records[i].timestamp);
    } else {
      if (new_mask_count < MAX_HUB_USER_MASKS)
        new_masks[new_mask_count++] = state->mask_records[i];
    }
  }
  memcpy(state->mask_records, new_masks, sizeof(hub_mask_record_t) * (size_t)new_mask_count);
  state->mask_record_count = new_mask_count;

  // --- Channel-binding tombstones, and flags / bindings whose user is gone
  //     (a live user's "*" del stays: hub_access_purge) ---
  purged_count += hub_access_purge(state, cutoff);

  // --- Purge tombstoned bots (d=1 entry present, regardless of is_active) ---
  // Heap-allocated: bot_config_t[MAX_BOTS] is ~6.8 MB, too large for the stack.
  bot_config_t *new_bots = malloc(sizeof(bot_config_t) * MAX_BOTS);
  if (!new_bots) {
    hub_log_error("[PURGE] malloc failed for new_bots\n");
    goto write_and_notify;
  }
  int new_bot_count = 0;

  for (int i = 0; i < state->bot_count; i++) {
    bot_config_t *b = &state->bots[i];
    bool purge_bot = false;

    time_t del_ts = 0;
    bool found_d1 = false;
    for (int j = 0; j < b->entry_count; j++) {
      if (strcmp(b->entries[j].key, "d") == 0 &&
          strcmp(b->entries[j].value, "1") == 0) {
        found_d1 = true;
        del_ts = b->entries[j].timestamp;
        break;
      }
    }
    if (found_d1 && (cutoff == 0 || (del_ts > 0 && del_ts < cutoff))) {
      purge_bot = true;
    }

    if (purge_bot) {
      purged_count++;
      const config_entry_t *n = bot_entry_rec(b, "n");
      purge_note(tombs, "bot", b->uuid, n ? n->value : NULL, del_ts);
    } else {
      if (new_bot_count < MAX_BOTS) {
        memcpy(&new_bots[new_bot_count++], b, sizeof(bot_config_t));
      }
    }
  }

  memcpy(state->bots, new_bots, sizeof(bot_config_t) * (size_t)new_bot_count);
  state->bot_count = new_bot_count;
  free(new_bots);

write_and_notify:
  state->config_dirty = true;

  /* Local bots: first the purged config, then the PURGE line itself.
   * hub_broadcast_config_to_bots only logs its line and re-sends each bot its
   * full config — that replaces a bot's user/mask tables, but channel
   * tombstones are merged on the bot and only a PURGE| line removes them.
   * The PURGE frame is queued behind the (coalesced) config push on the same
   * lane, so a pre-purge config still queued cannot re-add what it purged. */
  char purge_msg[64];
  int purge_len = snprintf(purge_msg, sizeof(purge_msg), "PURGE|%lld\n",
                           (long long)cutoff);
  hub_broadcast_config_to_bots(state, purge_msg);
  for (int i = 0; purge_len > 0 && i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type != CLIENT_BOT || !c->authenticated) continue;
    queued_msg_t *m = queued_msg_new(CMD_CONFIG_DATA, LANE_BULK,
                                     (const unsigned char *)purge_msg,
                                     purge_len);
    if (!m) {
      hub_log_error("[PURGE] OOM queueing PURGE for %s\n", hub_who_client(state, c));
      continue;
    }
    if (!peer_enqueue(c, m))
      hub_log_warning("[PURGE] could not queue PURGE for %s\n", hub_who_client(state, c));
  }

  return purged_count;
}

/* ==========================================================================
 * Admin commands — the SSH console's requests (docs/console.md §2).  Every
 * reply is a record list (hub_reply.h, docs/console.md §3.1): a result line
 * with a stable code, then data records.  The console lays them out; nothing
 * here formats for a screen.
 * ========================================================================== */

static bool send_reply(hub_state_t *state, hub_client_t *client, reply_t *r) {
  bool ok = send_response(state, client, reply_text(r));
  reply_free(r);
  return ok;
}

static bool admin_err(hub_state_t *state, hub_client_t *client,
                      const char *code, const char *msg, const char *hint) {
  reply_t r;
  reply_init(&r);
  reply_err(&r, code, msg, hint);
  return send_reply(state, client, &r);
}

/* Peer hubs a sync sent now reaches, and bots a config push reaches. */
static int linked_peer_count(const hub_state_t *state) {
  int n = 0;
  for (int i = 0; i < state->client_count; i++)
    if (state->clients[i]->type == CLIENT_HUB && state->clients[i]->authenticated)
      n++;
  return n;
}

static int local_bot_count(const hub_state_t *state) {
  int n = 0;
  for (int i = 0; i < state->client_count; i++)
    if (state->clients[i]->type == CLIENT_BOT && state->clients[i]->authenticated)
      n++;
  return n;
}

static hub_client_t *local_bot_client(hub_state_t *state, const char *uuid) {
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type == CLIENT_BOT && c->authenticated && !c->superseded &&
        strcmp(c->id, uuid) == 0)
      return c;
  }
  return NULL;
}

/* 8-4-4-4-12 hex digits. */
static bool uuid_valid(const char *s) {
  if (!s || strlen(s) != 36) return false;
  for (int i = 0; i < 36; i++) {
    if (i == 8 || i == 13 || i == 18 || i == 23) {
      if (s[i] != '-') return false;
    } else if (!isxdigit((unsigned char)s[i])) {
      return false;
    }
  }
  return true;
}

static const char *hub_display_name(const hub_state_t *state) {
  return state->hub_friendly_name[0] ? state->hub_friendly_name : "hub";
}

/* The freshest roster report of a bot some other hub holds, or NULL. */
static const bot_roster_t *roster_best(const hub_state_t *state, const char *uuid) {
  const bot_roster_t *best = NULL;
  for (int r = 0; r < state->roster_count; r++)
    if (strcmp(state->roster[r].bot_uuid, uuid) == 0 &&
        (!best || state->roster[r].reported_at >= best->reported_at))
      best = &state->roster[r];
  return best;
}

static const config_entry_t *bot_entry_rec(const bot_config_t *b, const char *key) {
  for (int k = 0; k < b->entry_count; k++)
    if (strcmp(b->entries[k].key, key) == 0) return &b->entries[k];
  return NULL;
}

static char *who_slot(void) {
  static _Thread_local char slots[HUB_WHO_SLOTS][HUB_WHO_MAX];
  static _Thread_local int next;
  next = (next + 1) % HUB_WHO_SLOTS;
  return slots[next];
}

/* Names come from the store and from peers: no control byte reaches a log
 * line through one. */
static char *who_clean(char *out) {
  for (char *q = out; *q; q++)
    if ((unsigned char)*q < 0x20 || *q == 0x7f) *q = '_';
  return out;
}

/* The name a uuid goes by, or NULL; *word is what it is ("bot", "hub",
 * "admin", "oper"). */
static const char *who_name(const hub_state_t *state, char kind, const char *uuid,
                            const char **word) {
  if (kind == 0 || kind == 'b') {
    *word = "bot";
    for (int i = 0; i < state->bot_count; i++) {
      if (strcmp(state->bots[i].uuid, uuid) != 0) continue;
      const config_entry_t *n = bot_entry_rec(&state->bots[i], "n");
      if (n && n->value[0]) return n->value;
      break;
    }
    for (int r = 0; r < state->roster_count; r++)
      if (strcmp(state->roster[r].bot_uuid, uuid) == 0 && state->roster[r].nick[0])
        return state->roster[r].nick;
  }
  if (kind == 0 || kind == 'h') {
    *word = "hub";
    if (strcmp(state->hub_uuid, uuid) == 0 && state->hub_friendly_name[0])
      return state->hub_friendly_name;
    for (int i = 0; i < state->peer_count; i++)
      if (strcmp(state->peers[i].uuid, uuid) == 0 && state->peers[i].friendly_name[0])
        return state->peers[i].friendly_name;
    for (int i = 0; i < state->mesh_hub_count; i++)
      if (strcmp(state->mesh_hubs[i].uuid, uuid) == 0 && state->mesh_hubs[i].name[0])
        return state->mesh_hubs[i].name;
    /* A plan's director, by the name it published: known even at boot. */
    if (state->splan.driver_name[0] && strcmp(state->splan.driver, uuid) == 0)
      return state->splan.driver_name;
  }
  if (kind == 0 || kind == 'u') {
    *word = "user";
    for (int i = 0; i < state->user_record_count; i++) {
      const hub_user_record_t *u = &state->user_records[i];
      if (strcmp(u->uuid, uuid) != 0) continue;
      *word = u->type == 'a' ? "admin" : "oper";
      if (u->name[0]) return u->name;
      break;
    }
  }
  if (kind == 0) *word = "?";
  return NULL;
}

const char *hub_who(const hub_state_t *state, char kind, const char *uuid) {
  char *out = who_slot();
  const char *word = kind == 'b' ? "bot" : kind == 'h' ? "hub" : kind == 'u' ? "user" : "?";
  const char *name = state && uuid && uuid[0] ? who_name(state, kind, uuid, &word) : NULL;
  if (kind == 0 && !name) /* nothing knows it, not even what it is */
    snprintf(out, HUB_WHO_MAX, "? (%.63s)", uuid && uuid[0] ? uuid : "?");
  else
    snprintf(out, HUB_WHO_MAX, "%s %.63s (%.63s)", word, name ? name : "?",
             uuid && uuid[0] ? uuid : "?");
  return who_clean(out);
}

const char *hub_who_client(const hub_state_t *state, const hub_client_t *c) {
  if (!c) return "?";
  if (c->type == CLIENT_BOT && c->id[0]) return hub_who(state, 'b', c->id);
  char *out = who_slot();
  if (c->type == CLIENT_HUB) {
    const char *uuid = "";
    for (int i = 0; state && i < state->peer_count; i++)
      if (state->peers[i].connected && state->peers[i].fd == c->fd)
        uuid = state->peers[i].uuid;
    snprintf(out, HUB_WHO_MAX, "hub %.63s (%.63s)", c->id[0] ? c->id : "?",
             uuid[0] ? uuid : "?");
  } else if (c->type == CLIENT_ADMIN && strncmp(c->id, "ADMIN:", 6) == 0) {
    snprintf(out, HUB_WHO_MAX, "admin %s", c->id + 6);
  } else {
    snprintf(out, HUB_WHO_MAX, "%s", c->id[0] ? c->id : c->ip);
  }
  return who_clean(out);
}

static bot_config_t *bot_by_uuid(hub_state_t *state, const char *uuid) {
  for (int i = 0; i < state->bot_count; i++)
    if (strcmp(state->bots[i].uuid, uuid) == 0) return &state->bots[i];
  return NULL;
}

/* Online anywhere on the mesh: connected here, or in a peer's roster. */
static bool bot_online(hub_state_t *state, const char *uuid) {
  return local_bot_client(state, uuid) || roster_best(state, uuid);
}

/* Distinct bots online on the whole network (here + every roster). */
static int network_bots_online(hub_state_t *state) {
  int n = 0;
  for (int i = 0; i < state->bot_count; i++)
    if (state->bots[i].is_active && bot_online(state, state->bots[i].uuid)) n++;
  return n;
}

/* Every hub in the mesh tree (its H rows: this hub, its peers and the hubs
 * beyond them); *up gets the ones online.  -1 when the tree can't be built. */
static int network_hubs(hub_state_t *state, int *up) {
  *up = 0;
  char *tree = malloc(MAX_TREE_PAYLOAD);
  if (!tree) return -1;
  int len = hub_build_tree(state, tree, MAX_TREE_PAYLOAD);
  int total = 0;
  for (int i = 0; len > 0 && i < len; i++) {
    if ((i == 0 || tree[i - 1] == '\n') && i + 2 < len && tree[i] == 'H' && tree[i + 1] == '|') {
      total++;
      /* H|depth|name|uuid|online|... */
      int f = 0, j = i;
      while (j < len && tree[j] != '\n' && f < 4) if (tree[j++] == '|') f++;
      if (f == 4 && j < len && tree[j] == '1') (*up)++;
    }
  }
  free(tree);
  return total;
}

/* bot|uuid|nick|online|ver|base|started|server|hub|hub_uuid|hub_name|ip|
 *     since|fp|seen|auth|auth_ts|mask|network|link|place|of|chans — every
 *     field the hub has for one bot.  started is the bot's own start
 *     (uptime), since its link to its hub; mask the stored h (also offline). */
static void reply_bot(hub_state_t *state, reply_t *r, const bot_config_t *b) {
  const config_entry_t *n = bot_entry_rec(b, "n");
  hub_client_t *c = local_bot_client(state, b->uuid);
  const bot_roster_t *e = c ? NULL : roster_best(state, b->uuid);
  /* "seen" is synced between hubs: the last time it authenticated anywhere */
  time_t seen = b->last_sync_time;
  const config_entry_t *s = bot_entry_rec(b, "seen");
  if (s && s->timestamp > seen) seen = s->timestamp;
  if (c && c->last_seen > seen) seen = c->last_seen;

  reply_rec(r, "bot");
  reply_kv(r, "uuid", b->uuid);
  if (n && n->value[0]) reply_kv(r, "nick", n->value);
  reply_kvb(r, "online", c || e);
  const config_entry_t *h = bot_entry_rec(b, "h");
  if (h && h->value[0]) reply_kv(r, "mask", h->value);
  const char *net = c ? c->bot_irc_network : e ? e->irc_network : "";
  const char *link = c ? c->bot_irc_link : e ? e->irc_link : "";
  const char *ent = c ? c->bot_irc_entry : e ? e->irc_entry : "";
  const char *chans = c ? c->bot_chan_state : e ? e->chan_state : "";
  if (net[0]) reply_kv(r, "network", net);
  if (link[0]) reply_kv(r, "link", link);
  int place = 0, of = 0;
  if (hub_pool_order_place(b->uuid, ent, &place, &of)) {
    reply_kvi(r, "place", place);
    reply_kvi(r, "of", of);
  }
  if (chans[0]) reply_kv(r, "chans", chans);
  if (c) {
    if (c->bot_version[0]) reply_kv(r, "ver", c->bot_version);
    if (c->bot_variant[0]) reply_kv(r, "base", c->bot_variant);
    if (c->bot_cron[0]) reply_kv(r, "cron", c->bot_cron);
    if (c->bot_started > 0) reply_kvi(r, "started", (long long)c->bot_started);
    if (c->bot_server[0]) reply_kv(r, "server", c->bot_server);
    reply_kv(r, "hub", "local");
    if (state->hub_uuid[0]) reply_kv(r, "hub_uuid", state->hub_uuid);
    reply_kv(r, "hub_name", hub_display_name(state));
    reply_kv(r, "ip", c->ip);
    reply_kvi(r, "since", (long long)c->connected_at);
  } else if (e) {
    if (e->version[0]) reply_kv(r, "ver", e->version);
    if (e->variant[0]) reply_kv(r, "base", e->variant);
    if (e->cron[0]) reply_kv(r, "cron", e->cron);
    if (e->connected_at > 0) reply_kvi(r, "started", (long long)e->connected_at);
    if (e->server[0]) reply_kv(r, "server", e->server);
    reply_kv(r, "hub", "peer");
    reply_kv(r, "hub_uuid", e->hub_uuid);
    reply_kv(r, "hub_name", e->hub_name);
    if (e->link_since > 0) reply_kvi(r, "since", (long long)e->link_since);
    if (e->ip[0]) reply_kv(r, "ip", e->ip);
  }
  const config_entry_t *pub = bot_entry_rec(b, "pub");
  if (pub && pub->value[0]) {
    char fp[KEY_FP_LEN + 1];
    hub_crypto_key_fingerprint_b64(pub->value, fp);
    reply_kv(r, "fp", fp);
  }
  reply_kvi(r, "seen", (long long)seen);
  /* An active record is the authorization ("t" only stamps the record's
   * sync time, the newest authorization or sync of it). */
  reply_kvb(r, "auth", b->is_active);
  if (b->last_sync_time > 0) reply_kvi(r, "auth_ts", (long long)b->last_sync_time);
}

/* Index of the configured peer `sel` names: its number in peer list
 * (1..n), its uuid, or its name (any case); -1 when none. */
static int peer_find(const hub_state_t *state, const char *sel) {
  unsigned long v = 0;
  if (sel && hub_parse_uint(sel, MAX_PEERS, &v) && v >= 1 &&
      (int)v <= state->peer_count)
    return (int)v - 1;
  for (int i = 0; sel && i < state->peer_count; i++)
    if (state->peers[i].uuid[0] && strcmp(state->peers[i].uuid, sel) == 0) return i;
  for (int i = 0; sel && i < state->peer_count; i++)
    if (state->peers[i].friendly_name[0] &&
        strcasecmp(state->peers[i].friendly_name, sel) == 0)
      return i;
  return -1;
}

static hub_client_t *peer_client(hub_state_t *state, const hub_peer_config_t *p) {
  if (p->fd <= 0) return NULL;
  for (int c = 0; c < state->client_count; c++)
    if (state->clients[c]->type == CLIENT_HUB && state->clients[c]->authenticated &&
        state->clients[c]->fd == p->fd)
      return state->clients[c];
  return NULL;
}

static void peer_key_fp(const hub_peer_config_t *p, char fp[KEY_FP_LEN + 1]) {
  unsigned char k[COMBINED_KEY_LEN];
  memcpy(k, p->ed_pub, ED25519_KEY_LEN);
  memcpy(k + ED25519_KEY_LEN, p->x25519_pub, X25519_KEY_LEN);
  hub_crypto_key_fingerprint(k, fp);
}

/* peer|n|uuid|name|ip|port|remote_ip|up|since|base|ver|started|bots|fp
 * [|bots_list|gossip]: since = the link's connect time while up, the time
 * it went down while down (absent: never up since this hub started). */
static void reply_peer(hub_state_t *state, reply_t *r, int i, bool detail) {
  hub_peer_config_t *p = &state->peers[i];
  hub_client_t *c = peer_client(state, p);
  const mesh_hub_t *mh = p->uuid[0] ? mesh_hub_find(state, p->uuid) : NULL;
  reply_rec(r, "peer");
  reply_kvi(r, "n", i + 1);
  if (p->uuid[0]) reply_kv(r, "uuid", p->uuid);
  if (p->friendly_name[0]) reply_kv(r, "name", p->friendly_name);
  reply_kv(r, "ip", p->ip);
  reply_kvi(r, "port", p->port);
  if (p->remote_ip[0]) reply_kv(r, "remote_ip", p->remote_ip);
  reply_kvb(r, "up", c != NULL);
  if (c) reply_kvi(r, "since", (long long)c->connected_at);
  else if (p->link_down_at > 0) reply_kvi(r, "since", (long long)p->link_down_at);
  const char *var = p->remote_variant[0] ? p->remote_variant : mh ? mh->variant : "";
  const char *ver = p->remote_version[0] ? p->remote_version : mh ? mh->version : "";
  time_t started = p->remote_started ? p->remote_started : mh ? mh->started : 0;
  if (var[0]) reply_kv(r, "base", var);
  if (ver[0]) reply_kv(r, "ver", ver);
  if (mh && mh->cron[0]) reply_kv(r, "cron", mh->cron);
  if (c && started > 0) reply_kvi(r, "started", (long long)started);
  int bots = 0;
  char list[1024] = "";
  size_t lo = 0;
  for (int k = 0; p->uuid[0] && k < state->roster_count; k++) {
    const bot_roster_t *e = &state->roster[k];
    if (strcmp(e->hub_uuid, p->uuid) != 0) continue;
    bots++;
    if (detail && lo + strlen(e->nick) + 2 < sizeof(list))
      lo += (size_t)snprintf(list + lo, sizeof(list) - lo, "%s%s", lo ? "," : "",
                             e->nick[0] ? e->nick : e->bot_uuid);
  }
  if (c) reply_kvi(r, "bots", bots);
  if (p->has_pubkey) {
    char fp[KEY_FP_LEN + 1];
    peer_key_fp(p, fp);
    reply_kv(r, "fp", fp);
  }
  if (detail) {
    if (list[0]) reply_kv(r, "bots_list", list);
    if (p->last_mesh_report > 0) reply_kvi(r, "gossip", (long long)p->last_mesh_report);
  }
}

static bool configured_peer_uuid(const hub_state_t *state, const char *uuid) {
  for (int i = 0; i < state->peer_count; i++)
    if (state->peers[i].uuid[0] && strcmp(state->peers[i].uuid, uuid) == 0) return true;
  return false;
}

/* a and b are configured with each other, by either one's reported links. */
static bool mesh_pair_linked(hub_state_t *state, const char *a, const char *b) {
  const char *ab[2][2] = {{a, b}, {b, a}};
  for (int k = 0; k < 2; k++) {
    const mesh_hub_t *mh = mesh_hub_find(state, ab[k][0]);
    if (!mh || !mh->have_links) continue;
    for (int l = 0; l < mh->link_count; l++)
      if (strcmp(mh->links[l].uuid, ab[k][1]) == 0) return true;
  }
  return false;
}

/* This hub and its configured peers are a full mesh of 3 or more: only then
 * is a hub one of them links to, but this hub has not configured, a stray
 * (Robert 2026-11-24).  On a ring, chain, star or tree it is the layout. */
static bool configured_full_mesh(hub_state_t *state) {
  if (state->peer_count < 2) return false;
  for (int i = 0; i < state->peer_count; i++) {
    if (!state->peers[i].uuid[0]) return false;
    for (int j = i + 1; j < state->peer_count; j++)
      if (state->peers[j].uuid[0] &&
          !mesh_pair_linked(state, state->peers[i].uuid, state->peers[j].uuid))
        return false;
  }
  return true;
}

/* link|a|b|b_name|state: every link a hub reported (its roster gossip), and
 * this hub's own; a pair nobody reported is "unknown" by its absence. */
static void reply_links_of(hub_state_t *state, reply_t *r, const char *uuid) {
  const mesh_hub_t *mh = mesh_hub_find(state, uuid);
  if (!mh || !mh->have_links) return;
  for (int l = 0; l < mh->link_count; l++) {
    reply_rec(r, "link");
    reply_kv(r, "a", mh->uuid);
    reply_kv(r, "b", mh->links[l].uuid);
    if (mh->links[l].name[0]) reply_kv(r, "b_name", mh->links[l].name);
    reply_kv(r, "state", mh->links[l].online ? "up" : "down");
  }
}

/* A hub's name as the hub del preview shows it: its friendly name, else the
 * first 8 characters of its uuid. */
static void refs_hub_name(const char *name, const char *uuid, char *out, size_t cap) {
  if (name && name[0]) snprintf(out, cap, "%s", name);
  else snprintf(out, cap, "%.8s", uuid ? uuid : "?");
}

/* hub del's preview (CMD_ADMIN_PEER_REFS): who still knows hub `sel` once
 * this hub unlinks it.  ok|peer.refs|hubs|bots, the target's peer record,
 * then hubref|uuid|name|state|self for every hub whose links name it (this
 * hub first), hubunrep|uuid|name for hubs whose links never reached us,
 * botref|uuid|nick|on|on_uuid|on_name|seen|addr|others for every bot whose hl| list
 * holds its key (others: the bot's other hubs, by name, or ?<addr> for one
 * this hub has no key for) and botunrep|uuid|nick for bots that sent no list.
 * Read only. */
/* Does the bot's hl| hub list hold this hub key (addr/fp,addr/fp...)? */
static bool bot_hl_has(const bot_config_t *b, const unsigned char ed_pub[32]) {
  const config_entry_t *hl = bot_entry_rec(b, "hl");
  if (!hl || !hub_hublist_valid(hl->value)) return false;
  char fp[HL_FP_LEN + 1];
  hub_crypto_hl_fp(ed_pub, fp);
  size_t fl = strlen(fp);
  for (const char *p = hl->value; *p;) {
    const char *end = strchr(p, ',');
    if (!end) end = p + strlen(p);
    const char *slash = memchr(p, '/', (size_t)(end - p));
    if (slash && (size_t)(end - slash - 1) == fl && memcmp(slash + 1, fp, fl) == 0) return true;
    p = *end ? end + 1 : end;
  }
  return false;
}

/* bot move <bot> hub <hub> | server <server>: payload bot|kind|target.  Run
 * on the bot's home hub, like bot kick (a console elsewhere is told where it
 * is).  hub: the target must be in the bot's own hl| list (a pinned key) and
 * linked; the bot is sent that hub's Ed25519 key (CMD_BOT_HUB_MOVE) and dials
 * it next, its IRC link kept.  server: a usable pool entry; CMD_BOT_MOVE
 * <bot>|<entry> moves its IRC link there now. */
static bool admin_bot_move(hub_state_t *state, hub_client_t *client, const char *payload) {
  char sel[64] = "", kind[16] = "", to[272] = "", msg[256];
  if (!payload || sscanf(payload, "%63[^|]|%15[^|]|%271[^|]", sel, kind, to) != 3 ||
      (strcmp(kind, "hub") != 0 && strcmp(kind, "server") != 0))
    return admin_err(state, client, "bot.usage", "say which bot, hub or server, and where",
                     "bot move <bot> hub <hub>  |  bot move <bot> server <host[:port]>");
  bot_config_t *b = bot_by_uuid(state, sel);
  if (b && !b->is_active) b = NULL;
  for (int i = 0; !b && i < state->bot_count; i++) {
    const config_entry_t *n = bot_entry_rec(&state->bots[i], "n");
    if (state->bots[i].is_active && n && strcasecmp(n->value, sel) == 0) b = &state->bots[i];
  }
  if (!b) {
    snprintf(msg, sizeof(msg), "no registered bot is called or has the uuid \"%.64s\"", sel);
    return admin_err(state, client, "bot.not_found", msg, "bot list");
  }
  char nick[MAX_NICK] = "";
  bot_nick_from_config(state, b->uuid, nick, sizeof(nick));
  const char *who = nick[0] ? nick : b->uuid;
  hub_client_t *c = local_bot_client(state, b->uuid);
  if (!c) {
    const bot_roster_t *e = roster_best(state, b->uuid);
    snprintf(msg, sizeof(msg), "%.64s is not connected to this hub", who);
    reply_t r;
    reply_init(&r);
    if (e) {
      char hint[160];
      snprintf(hint, sizeof(hint), "it is on %.64s: move it there", e->hub_name);
      reply_err(&r, "bot.not_local", msg, hint);
      reply_kv(&r, "hub_name", e->hub_name);
    } else {
      reply_err(&r, "bot.offline", msg, "bot show");
    }
    return send_reply(state, client, &r);
  }
  reply_t r;
  reply_init(&r);
  if (strcmp(kind, "hub") == 0) {
    int pi = peer_find(state, to);
    bool self = strcasecmp(to, hub_display_name(state)) == 0 || strcmp(to, state->hub_uuid) == 0;
    if (self) {
      snprintf(msg, sizeof(msg), "%.64s is already on this hub", who);
      reply_err(&r, "bot.move_refused", msg, NULL);
      return send_reply(state, client, &r);
    }
    if (pi < 0) {
      snprintf(msg, sizeof(msg), "no hub %.64s: none with that uuid or name", to);
      return admin_err(state, client, "peer.not_found", msg, "hub list");
    }
    hub_peer_config_t *p = &state->peers[pi];
    const char *why = !p->has_pubkey              ? "this hub holds no key for it"
                      : !bot_hl_has(b, p->ed_pub) ? "it is not in the bot's hub list"
                      : !peer_client(state, p)    ? "it is not linked"
                                                  : NULL;
    if (why) {
      snprintf(msg, sizeof(msg), "%.64s cannot move to %.64s: %s", who,
               p->friendly_name[0] ? p->friendly_name : to, why);
      reply_err(&r, "bot.move_refused", msg, "hub list");
      return send_reply(state, client, &r);
    }
    char *k = base64_encode(p->ed_pub, ED25519_KEY_LEN);
    if (!k) return admin_err(state, client, "bot.move_refused", "out of memory", NULL);
    queued_msg_t *m = queued_msg_new(CMD_BOT_HUB_MOVE, LANE_URGENT, (const unsigned char *)k,
                                     (int)strlen(k));
    free(k);
    if (!m || !peer_enqueue(c, m)) {
      if (m) queued_msg_free(m);
      return admin_err(state, client, "bot.move_refused", "the bot's link is full", NULL);
    }
    hub_log_info("[HUB] %s: moving bot %s to hub %s\n", hub_who_client(state, client), who,
                 p->friendly_name[0] ? p->friendly_name : p->uuid);
    reply_ok(&r, "bot.moved");
    reply_kv(&r, "bot", who);
    reply_kv(&r, "kind", "hub");
    reply_kv(&r, "from", hub_display_name(state));
    reply_kv(&r, "to", p->friendly_name[0] ? p->friendly_name : p->uuid);
    return send_reply(state, client, &r);
  }
  pool_srv_t s;
  if (!hub_pool_find(state, to, &s) || s.deleted) {
    snprintf(msg, sizeof(msg), "no server %.64s in the pool", to);
    return admin_err(state, client, "server.not_found", msg, "server list");
  }
  if (s.state != POOL_OK || !hub_bot_version_takes_pool(c->bot_version)) {
    snprintf(msg, sizeof(msg), "%.64s cannot move to %.64s: %s", who, s.host,
             s.state != POOL_OK ? "that server is not usable" : "the bot takes no server pool");
    reply_err(&r, "bot.move_refused", msg, "server list");
    return send_reply(state, client, &r);
  }
  if (strcmp(c->bot_irc_entry, s.uuid) == 0 && strcmp(c->bot_irc_link, "up") == 0) {
    snprintf(msg, sizeof(msg), "%.64s is already on %.64s", who, s.host);
    reply_err(&r, "bot.move_refused", msg, NULL);
    return send_reply(state, client, &r);
  }
  char pl[sizeof(c->id) + POOL_UUID_LEN + 2];
  snprintf(pl, sizeof(pl), "%s|%s", c->id, s.uuid);
  queued_msg_t *m = queued_msg_new(CMD_BOT_MOVE, LANE_URGENT, (const unsigned char *)pl,
                                   (int)strlen(pl));
  if (!m || !peer_enqueue(c, m)) {
    if (m) queued_msg_free(m);
    return admin_err(state, client, "bot.move_refused", "the bot's link is full", NULL);
  }
  hub_log_info("[HUB] %s: moving bot %s to server %s:%d\n", hub_who_client(state, client), who,
               s.host, s.port);
  char where[POOL_HOST_MAX + 16];
  snprintf(where, sizeof(where), "%s:%d", s.host, s.port);
  reply_ok(&r, "bot.moved");
  reply_kv(&r, "bot", who);
  reply_kv(&r, "kind", "server");
  reply_kv(&r, "to", where);
  reply_kv(&r, "note", "moved now; the server order may move it back at a rebalance");
  return send_reply(state, client, &r);
}

static bool admin_peer_refs(hub_state_t *state, hub_client_t *client, const char *sel) {
  int ti = sel && sel[0] ? peer_find(state, sel) : -1;
  if (ti < 0) {
    char m[160];
    snprintf(m, sizeof(m), "no hub %.60s: none with that uuid or name", sel ? sel : "");
    return admin_err(state, client, "peer.not_found", m, "hub list");
  }
  const hub_peer_config_t *t = &state->peers[ti];
  char tfp[HL_FP_LEN + 1] = "";
  if (t->has_pubkey) hub_crypto_hl_fp(t->ed_pub, tfp);

  /* The hubs other than the target this hub knows: itself, its peers, and
   * the ones only gossip names. */
  int hubs = 1;
  for (int i = 0; i < state->peer_count; i++)
    if (i != ti && (!state->peers[i].uuid[0] || strcmp(state->peers[i].uuid, t->uuid) != 0))
      hubs++;
  for (int i = 0; i < state->mesh_hub_count; i++) {
    const mesh_hub_t *m = &state->mesh_hubs[i];
    if (!m->uuid[0] || strcmp(m->uuid, state->hub_uuid) == 0 ||
        (t->uuid[0] && strcmp(m->uuid, t->uuid) == 0) || configured_peer_uuid(state, m->uuid))
      continue;
    hubs++;
  }
  int bots = 0;
  for (int i = 0; i < state->bot_count; i++)
    if (state->bots[i].is_active) bots++;

  reply_t r;
  reply_init(&r);
  reply_ok(&r, "peer.refs");
  reply_kvi(&r, "hubs", hubs);
  reply_kvi(&r, "bots", bots);
  reply_peer(state, &r, ti, false);

  char nm[64];
  reply_rec(&r, "hubref");
  if (state->hub_uuid[0]) reply_kv(&r, "uuid", state->hub_uuid);
  reply_kv(&r, "name", hub_display_name(state));
  reply_kv(&r, "state", peer_client(state, t) ? "up" : "down");
  reply_kvb(&r, "self", true);
  /* every other hub whose gossiped links name the target */
  for (int pass = 0; pass < 2; pass++) {
    for (int i = 0; i < (pass ? state->mesh_hub_count : state->peer_count); i++) {
      const char *uuid, *name;
      if (pass == 0) {
        if (i == ti) continue;
        uuid = state->peers[i].uuid;
        name = state->peers[i].friendly_name;
      } else {
        uuid = state->mesh_hubs[i].uuid;
        name = state->mesh_hubs[i].name;
        if (configured_peer_uuid(state, uuid)) continue;
      }
      if (!uuid[0] || strcmp(uuid, state->hub_uuid) == 0 ||
          (t->uuid[0] && strcmp(uuid, t->uuid) == 0))
        continue;
      const mesh_hub_t *m = mesh_hub_find(state, uuid);
      if (m && m->name[0]) name = m->name;
      refs_hub_name(name, uuid, nm, sizeof(nm));
      if (!m || !m->have_links) {
        reply_rec(&r, "hubunrep");
        reply_kv(&r, "uuid", uuid);
        reply_kv(&r, "name", nm);
        continue;
      }
      for (int l = 0; t->uuid[0] && l < m->link_count; l++) {
        if (strcmp(m->links[l].uuid, t->uuid) != 0) continue;
        reply_rec(&r, "hubref");
        reply_kv(&r, "uuid", uuid);
        reply_kv(&r, "name", nm);
        reply_kv(&r, "state", m->links[l].online ? "up" : "down");
        break;
      }
    }
  }

  /* Hubs a bot's fingerprints can name: this one and its keyed peers. */
  char self_fp[HL_FP_LEN + 1];
  hub_crypto_hl_fp(state->hub_ed25519_pub, self_fp);
  char peer_fp[MAX_PEERS][HL_FP_LEN + 1];
  for (int i = 0; i < state->peer_count; i++) {
    peer_fp[i][0] = '\0';
    if (state->peers[i].has_pubkey) hub_crypto_hl_fp(state->peers[i].ed_pub, peer_fp[i]);
  }

  for (int i = 0; i < state->bot_count; i++) {
    const bot_config_t *b = &state->bots[i];
    if (!b->is_active) continue;
    char nick[MAX_NICK];
    bot_nick_from_config(state, b->uuid, nick, sizeof(nick));
    const config_entry_t *hl = bot_entry_rec(b, "hl");
    if (!hl) {
      reply_rec(&r, "botunrep");
      reply_kv(&r, "uuid", b->uuid);
      if (nick[0]) reply_kv(&r, "nick", nick);
      continue;
    }
    if (!tfp[0] || !hub_hublist_valid(hl->value)) continue;
    /* the entry for the target, and the bot's other hubs */
    char addr[HL_ADDR_MAX + 1] = "", others[HL_VALUE_MAX + 1] = "";
    bool hit = false;
    size_t oo = 0;
    for (const char *p = hl->value; *p;) {
      const char *slash = strchr(p, '/');
      const char *end = strchr(p, ',');
      if (!end) end = p + strlen(p);
      char ea[HL_ADDR_MAX + 1], ef[HL_FP_LEN + 1];
      snprintf(ea, sizeof(ea), "%.*s", (int)(slash - p), p);
      snprintf(ef, sizeof(ef), "%.*s", (int)(end - slash - 1), slash + 1);
      if (!strcmp(ef, tfp)) {
        if (!hit) snprintf(addr, sizeof(addr), "%s", ea);
        hit = true;
      } else {
        char on[HL_ADDR_MAX + 2];
        if (!strcmp(ef, self_fp)) {
          snprintf(on, sizeof(on), "%s", hub_display_name(state));
        } else {
          int pk = -1;
          for (int k = 0; k < state->peer_count && pk < 0; k++)
            if (peer_fp[k][0] && !strcmp(peer_fp[k], ef)) pk = k;
          if (pk >= 0) {
            const mesh_hub_t *m = state->peers[pk].uuid[0] ? mesh_hub_find(state, state->peers[pk].uuid) : NULL;
            refs_hub_name(state->peers[pk].friendly_name[0] ? state->peers[pk].friendly_name
                          : m ? m->name : "",
                          state->peers[pk].uuid[0] ? state->peers[pk].uuid : state->peers[pk].ip,
                          on, sizeof(on));
          } else {
            snprintf(on, sizeof(on), "?%s", ea);
          }
        }
        int w = snprintf(others + oo, sizeof(others) - oo, "%s%s", oo ? "," : "", on);
        if (w > 0 && (size_t)w < sizeof(others) - oo) oo += (size_t)w;
      }
      p = *end ? end + 1 : end;
    }
    if (!hit) continue;
    hub_client_t *c = local_bot_client(state, b->uuid);
    const bot_roster_t *e = c ? NULL : roster_best(state, b->uuid);
    time_t seen = b->last_sync_time;
    const config_entry_t *s = bot_entry_rec(b, "seen");
    if (s && s->timestamp > seen) seen = s->timestamp;
    if (c && c->last_seen > seen) seen = c->last_seen;
    reply_rec(&r, "botref");
    reply_kv(&r, "uuid", b->uuid);
    if (nick[0]) reply_kv(&r, "nick", nick);
    if (c) {
      reply_kv(&r, "on", "local");
      if (state->hub_uuid[0]) reply_kv(&r, "on_uuid", state->hub_uuid);
      reply_kv(&r, "on_name", hub_display_name(state));
    } else if (e) {
      reply_kv(&r, "on", "peer");
      reply_kv(&r, "on_uuid", e->hub_uuid);
      refs_hub_name(e->hub_name, e->hub_uuid, nm, sizeof(nm));
      reply_kv(&r, "on_name", nm);
    }
    if (seen > 0) reply_kvi(&r, "seen", (long long)seen);
    if (addr[0]) reply_kv(&r, "addr", addr);
    if (others[0]) reply_kv(&r, "others", others);
  }
  return send_reply(state, client, &r);
}

static bool admin_list_peers(hub_state_t *state, hub_client_t *client,
                             const char *sel) {
  reply_t r;
  reply_init(&r);
  if (sel && sel[0]) {
    int i = peer_find(state, sel);
    if (i < 0) {
      char m[160];
      snprintf(m, sizeof(m), "no hub #%.40s, and none with that uuid or name", sel);
      return admin_err(state, client, "peer.not_found", m, "hub list");
    }
    reply_ok(&r, "peer.show");
    reply_peer(state, &r, i, true);
    if (state->peers[i].uuid[0]) reply_links_of(state, &r, state->peers[i].uuid);
    return send_reply(state, client, &r);
  }
  int up = 0;
  for (int i = 0; i < state->peer_count; i++)
    if (peer_client(state, &state->peers[i])) up++;
  reply_ok(&r, "peer.list");
  reply_kvi(&r, "configured", state->peer_count);
  reply_kvi(&r, "up", up);
  reply_rec(&r, "self");
  if (state->hub_uuid[0]) reply_kv(&r, "uuid", state->hub_uuid);
  reply_kv(&r, "name", hub_display_name(state));
  reply_kv(&r, "base", HUB_UPDATE_VARIANT);
  reply_kv(&r, "ver", HUB_VERSION);
  if (state->hub_started > 0) reply_kvi(&r, "started", (long long)state->hub_started);
  reply_kvi(&r, "bots", local_bot_count(state));
  reply_kv(&r, "bind_ip", state->bind_ip[0] ? state->bind_ip : "0.0.0.0");
  reply_kvi(&r, "port", state->port);
  if (state->public_ip[0]) reply_kv(&r, "public", state->public_ip);
  if (hub_update_cron_status()[0]) reply_kv(&r, "cron", hub_update_cron_status());
  {
    unsigned char pub64[64];
    char fp[KEY_FP_LEN + 1];
    memcpy(pub64, state->hub_ed25519_pub, 32);
    memcpy(pub64 + 32, state->hub_x25519_pub, 32);
    hub_crypto_key_fingerprint(pub64, fp);
    reply_kv(&r, "fp", fp);
  }
  for (int i = 0; i < state->peer_count; i++) reply_peer(state, &r, i, false);
  /* hubs only gossip tells about */
  for (int i = 0; i < state->mesh_hub_count; i++) {
    const mesh_hub_t *m = &state->mesh_hubs[i];
    if (!m->uuid[0] || strcmp(m->uuid, state->hub_uuid) == 0 ||
        configured_peer_uuid(state, m->uuid))
      continue;
    reply_rec(&r, "hub");
    reply_kv(&r, "uuid", m->uuid);
    if (m->name[0]) reply_kv(&r, "name", m->name);
    if (m->version[0]) reply_kv(&r, "ver", m->version);
    if (m->variant[0]) reply_kv(&r, "base", m->variant);
    reply_kv(&r, "known", "gossip");
  }
  /* links: ours first, then what every hub reports */
  for (int i = 0; i < state->peer_count; i++) {
    const hub_peer_config_t *p = &state->peers[i];
    if (!p->uuid[0]) continue;
    reply_rec(&r, "link");
    reply_kv(&r, "a", state->hub_uuid);
    reply_kv(&r, "b", p->uuid);
    if (p->friendly_name[0]) reply_kv(&r, "b_name", p->friendly_name);
    reply_kv(&r, "state", peer_client(state, p) ? "up" : "down");
  }
  for (int i = 0; i < state->mesh_hub_count; i++) {
    const mesh_hub_t *m = &state->mesh_hubs[i];
    if (m->uuid[0] && strcmp(m->uuid, state->hub_uuid) != 0)
      reply_links_of(state, &r, m->uuid);
  }
  /* issues: a configured peer that is down; a hub a linked peer links to
   * that this hub has no entry for */
  for (int i = 0; i < state->peer_count; i++) {
    const hub_peer_config_t *p = &state->peers[i];
    if (peer_client(state, p)) continue;
    reply_rec(&r, "issue");
    reply_kv(&r, "kind", "peer_down");
    reply_kvi(&r, "n", i + 1);
    if (p->uuid[0]) reply_kv(&r, "uuid", p->uuid);
    if (p->friendly_name[0]) reply_kv(&r, "name", p->friendly_name);
    reply_kv(&r, "ip", p->ip);
    reply_kvi(&r, "port", p->port);
    if (p->link_down_at > 0) reply_kvi(&r, "since", (long long)p->link_down_at);
  }
  bool full = configured_full_mesh(state);
  for (int i = 0; i < state->peer_count && full; i++) {
    const hub_peer_config_t *p = &state->peers[i];
    if (!p->uuid[0] || !peer_client(state, p)) continue;
    const mesh_hub_t *mh = mesh_hub_find(state, p->uuid);
    if (!mh || !mh->have_links) continue;
    for (int l = 0; l < mh->link_count; l++) {
      const mesh_link_t *L = &mh->links[l];
      if (!strcmp(L->uuid, state->hub_uuid) || configured_peer_uuid(state, L->uuid))
        continue;
      reply_rec(&r, "issue");
      reply_kv(&r, "kind", "unknown_hub");
      reply_kv(&r, "via", p->uuid);
      if (p->friendly_name[0]) reply_kv(&r, "via_name", p->friendly_name);
      reply_kv(&r, "uuid", L->uuid);
      if (L->name[0]) reply_kv(&r, "name", L->name);
    }
  }
  return send_reply(state, client, &r);
}

static void chan_modes_letters(int modes, char out[4]) {
  int o = 0;
  if (modes & 128) out[o++] = 'i';
  if (modes & 64) out[o++] = 'k';
  out[o] = '\0';
}

/* A managed channel's stored entry (active or a tombstone), or NULL. */
static config_entry_t *chan_entry(hub_state_t *state, const char *chan) {
  for (int i = 0; i < state->global_entry_count; i++) {
    config_entry_t *e = &state->global_entries[i];
    if (strcmp(e->key, "c") != 0) continue;
    char name[128];
    if (parse_global_channel_value(e->value, name, sizeof(name), NULL, 0, NULL,
                                   NULL, 0) &&
        hub_ascii_ieq(name, chan))
      return e;
  }
  return NULL;
}

/* chan|name|key|modes|ts — the generic channel record; a later setting
 * adds a set.<name>= key (docs/console.md §3.1). */
static bool reply_chan(const hub_state_t *state, reply_t *r, const config_entry_t *e) {
  char name[128] = "", key[64] = "", op[16] = "";
  int modes = 0;
  if (!parse_global_channel_value(e->value, name, sizeof(name), key, sizeof(key),
                                  &modes, op, sizeof(op)) ||
      !name[0] || strcmp(op, "del") == 0)
    return false;
  /* the key the bots join with and the +k/+i they saw (K|, when newer) */
  const hub_chan_learned_t *l = hub_learned_find(state, name);
  if (l) {
    modes = l->modes;
    if (l->ts > e->timestamp) snprintf(key, sizeof(key), "%s", l->key);
  }
  char ml[4];
  chan_modes_letters(modes, ml);
  reply_rec(r, "chan");
  reply_kv(r, "name", name);
  if (key[0]) reply_kv(r, "key", key);
  if (ml[0]) reply_kv(r, "modes", ml);
  reply_kvi(r, "ts", (long long)e->timestamp);
  return true;
}

/* A channel name the bots can JOIN: # or & first, no blank, comma, BEL or
 * control character, at most MAX_CHAN - 1 bytes. */
static bool chan_name_valid(const char *s) {
  size_t n = strlen(s);
  if (n < 2 || n >= MAX_CHAN || (s[0] != '#' && s[0] != '&')) return false;
  for (size_t i = 0; i < n; i++) {
    unsigned char c = (unsigned char)s[i];
    if (c <= 0x20 || c == ',' || c == 0x7f) return false;
  }
  return true;
}

/* Write a channel's key (add, re-add or channel set key): the same stored
 * line and sync both ways.  Returns the stamp written. */
static void chan_store(hub_state_t *state, const char *chan, const char *key) {
  /* Past the stored stamp: a remove in this same second would tie, and the
   * newest command must be the one that sticks. */
  time_t now = hub_lww_next_ts(hub_storage_global_ts(state, "c", chan));
  /* Carry forward any modes a bot previously reported for this channel: the
   * storage layer replaces the whole value once the timestamp wins, so a
   * re-add to change the key would otherwise wipe the recorded +i/+k. */
  int modes = global_channel_modes(state, chan);
  char extra[80];
  snprintf(extra, sizeof(extra), "%s|%d", key, modes);
  hub_storage_update_global_entry(state, "c", chan, extra, "add", now);
  state->config_dirty = true;
  char sync_msg[256];
  snprintf(sync_msg, sizeof(sync_msg), "c|%s|%s|%d|add|%ld\n", chan, key, modes,
           (long)now);
  hub_broadcast_config_to_bots(state, sync_msg);
  hub_broadcast_sync_to_peers(state, sync_msg, -1);
}

/* The active key of a channel ("" = none); false when it is not managed. */
static bool chan_active_key(hub_state_t *state, const char *chan, char *key,
                            size_t cap) {
  config_entry_t *e = chan_entry(state, chan);
  char op[16] = "";
  key[0] = '\0';
  if (!e) return false;
  parse_global_channel_value(e->value, NULL, 0, key, cap, NULL, op, sizeof(op));
  if (strcmp(op, "del") == 0) {
    key[0] = '\0';
    return false;
  }
  return true;
}

/* The key the bots join with: the newer of the admin's (c|) and the one they
 * learned on IRC (K|); a tie keeps the admin's.  False when not managed. */
static bool chan_effective_key(hub_state_t *state, const char *chan, char *key,
                               size_t cap) {
  if (!chan_active_key(state, chan, key, cap)) return false;
  const hub_chan_learned_t *l = hub_learned_find(state, chan);
  if (l && l->ts > hub_storage_global_ts(state, "c", chan))
    snprintf(key, cap, "%s", l->key);
  return true;
}

static hub_user_record_t *user_by_name(hub_state_t *state, const char *name) {
  for (int i = 0; i < state->user_record_count; i++)
    if (state->user_records[i].is_active &&
        strcasecmp(state->user_records[i].name, name) == 0)
      return &state->user_records[i];
  return NULL;
}

static int user_mask_count(const hub_state_t *state, const char *uuid) {
  int n = 0;
  for (int j = 0; j < state->mask_record_count; j++)
    if (state->mask_records[j].is_active && strcmp(state->mask_records[j].uuid, uuid) == 0)
      n++;
  return n;
}

/* Open consoles of an admin: they close when the record or its key goes. */
static int admin_console_sessions(const hub_state_t *state, const char *name) {
  int n = 0;
  for (int i = 0; i < state->client_count; i++) {
    const hub_client_t *c = state->clients[i];
    if (c->internal && c->type == CLIENT_ADMIN && strncmp(c->id, "ADMIN:", 6) == 0 &&
        strcasecmp(c->id + 6, name) == 0)
      n++;
  }
  return n;
}

/* user|name|role|fp|seen|masks|sessions, then mask|user|mask|used per mask. */
static void reply_user(hub_state_t *state, reply_t *r, const hub_user_record_t *u) {
  reply_rec(r, "user");
  reply_kv(r, "name", u->name);
  reply_kv(r, "role", u->type == 'a' ? "admin" : "oper");
  if (u->has_pubkey) {
    char kfp[KEY_FP_LEN + 1];
    hub_crypto_key_fingerprint_b64(u->pubkey_b64, kfp);
    reply_kv(r, "fp", kfp);
  }
  reply_kvi(r, "seen", (long long)u->last_seen);
  reply_kvi(r, "masks", user_mask_count(state, u->uuid));
  if (u->type == 'a') reply_kvi(r, "sessions", admin_console_sessions(state, u->name));
  /* user_flags plan U9: an admin's flags, an oper's channels ("*" = all) */
  if (u->type == 'a') {
    reply_kv(r, "flags", hub_user_flags(state, u->uuid));
  } else {
    char cl[512];
    hub_user_chans(state, u->uuid, cl, sizeof(cl));
    reply_kv(r, "chans", cl);
  }
  for (int j = 0; j < state->mask_record_count; j++) {
    const hub_mask_record_t *m = &state->mask_records[j];
    if (!m->is_active || strcmp(m->uuid, u->uuid) != 0) continue;
    reply_rec(r, "mask");
    reply_kv(r, "user", u->name);
    reply_kv(r, "mask", m->mask);
    reply_kvi(r, "used", (long long)m->last_used);
  }
}

/* type 0 = every role; name NULL = every user. */
static bool admin_list_users(hub_state_t *state, hub_client_t *client,
                             const char *code, char type, const char *name) {
  int admins = 0, opers = 0, masks = 0;
  for (int i = 0; i < state->user_record_count; i++) {
    const hub_user_record_t *u = &state->user_records[i];
    if (!u->is_active || (type && u->type != type) ||
        (name && strcasecmp(u->name, name) != 0))
      continue;
    if (u->type == 'a') admins++;
    else opers++;
    masks += user_mask_count(state, u->uuid);
  }
  if (name && admins + opers == 0) {
    char m[128];
    snprintf(m, sizeof(m), "no user called \"%.64s\"", name);
    return admin_err(state, client, "user.not_found", m, "user list");
  }
  reply_t r;
  reply_init(&r);
  reply_ok(&r, code);
  if (type) reply_kv(&r, "role", type == 'a' ? "admin" : "oper");
  reply_kvi(&r, "admins", admins);
  reply_kvi(&r, "opers", opers);
  reply_kvi(&r, "masks", masks);
  /* admins first, as the console sorts them too */
  for (int pass = 0; pass < 2; pass++)
    for (int i = 0; i < state->user_record_count; i++) {
      const hub_user_record_t *u = &state->user_records[i];
      if (!u->is_active || u->type != (pass == 0 ? 'a' : 'o') ||
          (type && u->type != type) || (name && strcasecmp(u->name, name) != 0))
        continue;
      reply_user(state, &r, u);
    }
  return send_reply(state, client, &r);
}

/* CMD_ADMIN_ADD/DEL_ALLOWLIST/DENYLIST (list 'w' or 'x').  The lists are
 * local to this hub: nothing is sent to peers or bots.  A change after which
 * the admin's own address could not connect is refused and rolled back; the
 * inbound connections a change refuses are closed by hub_maintenance. */
static unsigned long long acl_size(const hub_ip_acl_t *e) {
  return (unsigned long long)(~e->mask) + 1ull;
}

static bool admin_ip_acl_change(hub_state_t *state, hub_client_t *client,
                                char list, bool add, const char *payload) {
  const char *name = list == 'w' ? "allow" : "deny";
  char msg[200];
  hub_ip_acl_t e;

  if (!payload || !payload[0])
    return admin_err(state, client, "acl.usage", "say which address",
                     "acl add|del allow|deny <ip[/n]> [console]");
  /* "<pattern>" or "<pattern>|console" (D27: the entry applies only once the
   * first bytes say SSH).  Anything else after the pattern is refused. */
  char pat[IP_ACL_PATTERN_MAX + 2];
  bool console_scope = false;
  const char *bar = strchr(payload, '|');
  if (bar) {
    if (strcmp(bar + 1, "console") != 0 || (size_t)(bar - payload) >= sizeof(pat))
      return admin_err(state, client, "acl.bad_scope", "the only scope word is console",
                       "acl add allow <ip[/n]> console");
    memcpy(pat, payload, (size_t)(bar - payload));
    pat[bar - payload] = '\0';
    console_scope = true;
  } else {
    snprintf(pat, sizeof(pat), "%s", payload);
  }
  if (!hub_ip_acl_parse(pat, &e)) {
    snprintf(msg, sizeof(msg), "%.40s is not an IPv4 address or CIDR", pat);
    return admin_err(state, client, "acl.bad_pattern", msg, "1.2.3.4 or 1.2.3.0/24");
  }
  e.console = console_scope;

  hub_ip_acl_t *l = list == 'w' ? state->ip_allow : state->ip_deny;
  int *count = list == 'w' ? &state->ip_allow_count : &state->ip_deny_count;
  hub_ip_acl_t saved[MAX_IP_ACL_ENTRIES];
  int saved_count = *count;
  memcpy(saved, l, sizeof(saved));

  if (add) {
    e.added = time(NULL);
    ip_acl_add_t r = hub_ip_acl_add(state, list, &e);
    if (r != IP_ACL_ADDED) {
      if (r == IP_ACL_DUPLICATE) {
        snprintf(msg, sizeof(msg), "%s is already on the %s list%s", e.pattern, name,
                 console_scope ? " (console scope)" : "");
        return admin_err(state, client, "acl.exists", msg, "acl list");
      }
      snprintf(msg, sizeof(msg), "the %s list is full (%d entries)", name,
               MAX_IP_ACL_ENTRIES);
      return admin_err(state, client, "acl.full", msg, "acl del to make room");
    }
  } else if (!hub_ip_acl_remove(state, list, &e)) {
    snprintf(msg, sizeof(msg), "%s is not on the %s list%s", e.pattern, name,
             console_scope ? " with the console scope" : "");
    return admin_err(state, client, "acl.not_found", msg, "acl list");
  }

  /* The admin is on an SSH console: both scopes must let this address in. */
  if (!hub_ip_acl_permits(state, client->ip) ||
      !hub_ip_acl_permits_console(state, client->ip)) {
    memcpy(l, saved, sizeof(saved));
    *count = saved_count;
    snprintf(msg, sizeof(msg), "refused: this would lock out your own address %s",
             client->ip);
    return admin_err(state, client, "acl.self_lockout", msg,
                     list == 'w' ? "acl add allow <your address> first" : NULL);
  }

  int closing = 0;
  for (int i = 0; i < state->client_count; i++) {
    const hub_client_t *c = state->clients[i];
    if (c != client && c->inbound && !hub_ip_acl_permits(state, c->ip))
      closing++;
  }
  state->ip_acl_changed = true;
  state->config_dirty = true;
  hub_log_info("[ACCESS_CONTROL] %s %s %slist by %s\n", e.pattern,
               add ? "added to" : "removed from", name, hub_who_client(state, client));

  reply_t r;
  reply_init(&r);
  reply_ok(&r, add ? "acl.added" : "acl.removed");
  reply_kv(&r, "list", name);
  reply_kv(&r, "pattern", e.pattern);
  reply_kvu(&r, "size", acl_size(&e));
  if (console_scope) reply_kv(&r, "scope", "console");
  int in_scope = ip_acl_scope_count(l, *count, console_scope);
  if (list == 'w' && add && in_scope == 1) reply_kvb(&r, "first", true);
  if (list == 'w' && !add && in_scope == 0) reply_kvb(&r, "empty", true);
  reply_kvi(&r, "closing", closing);
  return send_reply(state, client, &r);
}

static bool admin_list_acl(hub_state_t *state, hub_client_t *client) {
  reply_t r;
  reply_init(&r);
  reply_ok(&r, "acl.list");
  reply_kvi(&r, "allow", state->ip_allow_count);
  reply_kvi(&r, "deny", state->ip_deny_count);
  reply_kv(&r, "self_ip", client->ip);
  reply_kv(&r, "self",
           !state->ip_allow_count && !state->ip_deny_count ? "open"
           : hub_ip_acl_permits(state, client->ip) &&
             hub_ip_acl_permits_console(state, client->ip)  ? "allowed"
                                                             : "denied");
  for (int pass = 0; pass < 2; pass++) {
    const hub_ip_acl_t *l = pass == 0 ? state->ip_allow : state->ip_deny;
    int n = pass == 0 ? state->ip_allow_count : state->ip_deny_count;
    for (int i = 0; i < n; i++) {
      reply_rec(&r, "acl");
      reply_kv(&r, "list", pass == 0 ? "allow" : "deny");
      reply_kvi(&r, "n", i + 1);
      reply_kv(&r, "pattern", l[i].pattern);
      reply_kvu(&r, "size", acl_size(&l[i]));
      if (l[i].console) reply_kv(&r, "scope", "console");
      if (l[i].added > 0) reply_kvi(&r, "ts", (long long)l[i].added);
    }
  }
  return send_reply(state, client, &r);
}

/* ok|hub.show: everything about this hub in one record. */
static bool admin_hub_show(hub_state_t *state, hub_client_t *client) {
  if (!state->hub_keys_loaded)
    return admin_err(state, client, "hub.no_key", "this hub has no key loaded", NULL);
  unsigned char pub64[64];
  memcpy(pub64, state->hub_ed25519_pub, 32);
  memcpy(pub64 + 32, state->hub_x25519_pub, 32);
  char *pub_b64 = base64_encode(pub64, 64);
  if (!pub_b64)
    return admin_err(state, client, "internal.encode", "encoding the key failed", NULL);
  char fp[KEY_FP_LEN + 1], ssh_fp[80];
  hub_crypto_key_fingerprint(pub64, fp);
  console_ssh_fingerprint(state->hub_ed25519_pub, ssh_fp, sizeof(ssh_fp));
  int peers_up = 0;
  for (int i = 0; i < state->peer_count; i++)
    if (peer_client(state, &state->peers[i])) peers_up++;
  int bots = 0;
  for (int i = 0; i < state->bot_count; i++)
    if (state->bots[i].is_active) bots++;
  int hubs_up = 0;
  const int hubs = network_hubs(state, &hubs_up);

  reply_t r;
  reply_init(&r);
  reply_ok(&r, "hub.show");
  reply_kv(&r, "name", hub_display_name(state));
  if (state->hub_uuid[0]) reply_kv(&r, "uuid", state->hub_uuid);
  reply_kv(&r, "ver", HUB_VERSION);
  reply_kv(&r, "base", HUB_UPDATE_VARIANT);
  if (state->hub_started > 0) reply_kvi(&r, "started", (long long)state->hub_started);
  const char *bind = state->bind_ip[0] ? state->bind_ip : "0.0.0.0";
  reply_kv(&r, "bind_ip", state->listen_ip[0] ? state->listen_ip : bind);
  reply_kvi(&r, "port", state->listen_port ? state->listen_port : state->port);
  if (state->listen_ip[0] && strcmp(state->listen_ip, bind) != 0)
    reply_kv(&r, "pending_bind_ip", bind);
  if (state->listen_port && state->listen_port != state->port)
    reply_kvi(&r, "pending_port", state->port);
  if (state->public_ip[0]) {
    reply_kv(&r, "public", state->public_ip);
    if (state->public_ip_at > 0) reply_kvi(&r, "public_at", (long long)state->public_ip_at);
  }
  reply_kv(&r, "key", pub_b64);
  reply_kv(&r, "fp", fp);
  reply_kv(&r, "ssh_fp", ssh_fp);
  reply_kvi(&r, "peers_up", peers_up);
  reply_kvi(&r, "peers", state->peer_count);
  if (hubs > 0) {
    reply_kvi(&r, "hubs_up", hubs_up);
    reply_kvi(&r, "hubs", hubs);
  }
  reply_kvi(&r, "bots_here", local_bot_count(state));
  reply_kvi(&r, "bots_online", network_bots_online(state));
  reply_kvi(&r, "bots", bots);
  reply_kvi(&r, "autopurge", state->purge_days_setting);
  reply_kvi(&r, "log_file", state->log_level);
  reply_kvi(&r, "log_console", state->console_log_level);
  reply_kvi(&r, "log_size",
            state->log_max_size > 0 ? state->log_max_size : HUB_LOG_FILE_SIZE);
  free(pub_b64);
  return send_reply(state, client, &r);
}

/* ok|hub.set|setting|old|value[|restart][|peers] */
static bool hub_set_reply(hub_state_t *state, hub_client_t *client,
                          const char *setting, const char *old, const char *value,
                          bool restart, int peers) {
  reply_t r;
  reply_init(&r);
  reply_ok(&r, "hub.set");
  reply_kv(&r, "setting", setting);
  reply_kv(&r, "old", old);
  reply_kv(&r, "value", value);
  reply_kvb(&r, "restart", restart);
  if (peers >= 0) reply_kvi(&r, "peers", peers);
  if (restart) {
    char lp[24];
    reply_kv(&r, "listen_ip", state->listen_ip[0] ? state->listen_ip : "0.0.0.0");
    snprintf(lp, sizeof(lp), "%d", state->listen_port ? state->listen_port : state->port);
    reply_kv(&r, "listen_port", lp);
  }
  return send_reply(state, client, &r);
}

/* ==========================================================================
 * Modes, channel settings, network defaults, bans (docs/modes.md §5.1)
 *
 * channel mode / channel set / ban / network set.  The store functions are
 * hub_modes.c's; this is the console's side: parse the (hostile) payload,
 * call them, answer in records.  Every payload field is length-checked into
 * a fixed buffer before it is looked at.
 * ========================================================================== */
#define MF_MAX_TOKENS 16
#define MF_BANS_LIST_MAX 600
#define MF_BANS_CHAN_MAX 128 /* >= MAX_BANS_PER_CHAN and MAX_GLOBAL_BANS */
#define MF_BAN_MINUTES_MAX 5256000L /* 10 years, the store's own ceiling */

static int mf_field_count(const char *s) {
  int n = 1;
  for (; s && *s; s++)
    if (*s == '|') n++;
  return n;
}

/* The name a console session logs in as ("ADMIN:admin" -> "admin"). */
static const char *mf_admin_name(const hub_client_t *c) {
  return strncmp(c->id, "ADMIN:", 6) == 0 ? c->id + 6 : c->id;
}


static bool mf_status_err(hub_state_t *state, hub_client_t *client, hub_modes_status_t st,
                          const char *what) {
  char msg[256];
  switch (st) {
  case HUB_MODES_FROZEN:
    return admin_err(state, client, "config.frozen",
                     "the config is frozen while an upgrade runs",
                     "upgrade status; a stale freeze is lifted with option set");
  case HUB_MODES_BAD_CHAN:
    return admin_err(state, client, "channel.bad_name",
                     "a channel name starts with # or & and has no spaces, commas or "
                     "control characters",
                     NULL);
  case HUB_MODES_NOT_MANAGED:
    snprintf(msg, sizeof(msg), "%.64s is not a managed channel", what ? what : "?");
    return admin_err(state, client, "channel.not_found", msg, "channel add <#chan>");
  case HUB_MODES_BAD_MODES:
    return admin_err(state, client, "channel.bad_mode", "that is not a valid mode string",
                     "channel mode <#chan> <+modes> [args]");
  case HUB_MODES_TOO_LONG:
    return admin_err(state, client, "channel.too_long",
                     "the settings would not fit the record (512 bytes)",
                     "reset some with <name> default");
  case HUB_MODES_BAD_SETTING:
    return admin_err(state, client, "channel.bad_value", "that setting value is not valid",
                     NULL);
  case HUB_MODES_BAD_MASK:
    return admin_err(state, client, "ban.bad_mask",
                     "a ban mask is 1-120 printable characters with no spaces, commas or |",
                     "ban add <#chan|*> nick!user@host");
  case HUB_MODES_BAD_REASON:
    return admin_err(state, client, "ban.bad_reason",
                     "a ban reason is at most 120 bytes with no control characters", NULL);
  case HUB_MODES_BAD_EXPIRY:
    return admin_err(state, client, "ban.bad_time",
                     "a ban lasts 1 minute to 10 years, or perm", "ban add <#chan|*> <mask> [<min>|perm]");
  case HUB_MODES_NOT_FOUND:
    return admin_err(state, client, "ban.not_found", "no such ban", "ban list [#chan|*]");
  case HUB_MODES_FULL:
    return admin_err(state, client, "ban.full",
                     "the record or ban table is full (100 bans per channel, 100 global)",
                     "ban del <#chan|*> <mask>");
  case HUB_MODES_PROTECTED:
  case HUB_MODES_OK:
    break;
  }
  return admin_err(state, client, "modes.failed", "the change was refused", NULL);
}

/* Whether a stored mode string ("+stnkl 20", "-i+t") sets `letter` on. */
static bool mf_modes_plus(const char *modes, char letter) {
  char sign = 0;
  for (; *modes && *modes != ' '; modes++) {
    if (*modes == '+' || *modes == '-') sign = *modes;
    else if (*modes == letter && sign == '+') return true;
  }
  return false;
}

/* The channel's mode card: stored string (""= network default), the string in
 * force and where it comes from, the modes a bot last reported live, whether
 * a key is set, and whether +l fights +dynamiclimit.  cname must be a live
 * channel. */
static void mf_mode_card_extra(hub_state_t *state, reply_t *r, const char *cname) {
  hub_chanset_t cs, ns;
  bool have = hub_chanset_get(state, cname, &cs);
  hub_netset_get(state, &ns);
  const char *eff = "+nt", *src = "built-in";
  if (have && cs.modes[0]) {
    eff = cs.modes;
    src = "chan";
  } else if (ns.modes[0]) {
    eff = ns.modes;
    src = "net";
  }
  reply_kv(r, "modes", have ? cs.modes : "");
  reply_kv(r, "effective", eff);
  reply_kv(r, "source", src);
  char key[64], ml[4], dyn[8];
  chan_effective_key(state, cname, key, sizeof(key));
  reply_kvb(r, "key_set", key[0] != '\0');
  secure_wipe(key, sizeof(key));
  chan_modes_letters(global_channel_modes(state, cname), ml);
  reply_kv(r, "live", ml);
  hub_setting_effective(state, cname, "dynamiclimit", dyn, sizeof(dyn));
  reply_kvb(r, "dynlimit", mf_modes_plus(eff, 'l') && strcmp(dyn, "1") == 0);
}

static void mf_mode_card(hub_state_t *state, reply_t *r, const char *cname) {
  reply_kv(r, "chan", cname);
  mf_mode_card_extra(state, r, cname);
}

/* Channel mode strings the console sends: "<+modes>|<arg>|<arg>".  Fills the
 * stored form (letters, then the limit) and the key to set / clear.  NULL on
 * success, else the message. */
static const char *mf_parse_modes(const char *modes, char args[][64], int nargs,
                                  char *stored, size_t cap, int *key_op, char *key,
                                  size_t keycap) {
  char sign = 0, limit[16] = "";
  bool seen[256] = {false};
  int ai = 0;
  bool plus_s = false, plus_p = false;
  *key_op = 0;
  key[0] = '\0';
  if (!modes[0]) return "say the modes, e.g. +nt";
  for (const char *p = modes; *p; p++) {
    unsigned char c = (unsigned char)*p;
    if (c == '+' || c == '-') {
      sign = (char)c;
      continue;
    }
    if (!strchr("imnpstkl", c) || !c) return "modes are i m n p s t k l";
    if (!sign) return "start the modes with + or -";
    if (seen[c]) return "a mode letter may appear only once";
    seen[c] = true;
    if (sign == '+' && c == 's') plus_s = true;
    if (sign == '+' && c == 'p') plus_p = true;
    if (c == 'k') {
      if (sign == '+') {
        if (ai >= nargs) return "+k needs a key";
        const char *k = args[ai++];
        size_t kl = strlen(k);
        if (kl < 1 || kl > 30) return "a key is 1-30 bytes";
        for (size_t i = 0; i < kl; i++)
          if ((unsigned char)k[i] <= 0x20 || k[i] == ',' || (unsigned char)k[i] == 0x7f)
            return "a key has no spaces, commas or control characters";
        snprintf(key, keycap, "%s", k);
        *key_op = 1;
      } else {
        *key_op = -1;
      }
    } else if (c == 'l' && sign == '+') {
      if (ai >= nargs) return "+l needs a limit";
      const char *l = args[ai++];
      size_t ll = strlen(l);
      if (ll < 1 || ll > 5) return "the limit is 1-99999";
      long v = 0;
      for (size_t i = 0; i < ll; i++) {
        if (l[i] < '0' || l[i] > '9') return "the limit is 1-99999";
        v = v * 10 + (l[i] - '0');
      }
      if (v < 1 || v > 99999) return "the limit is 1-99999";
      snprintf(limit, sizeof(limit), "%ld", v);
    }
  }
  if (ai != nargs) return "more arguments than +k and +l take";
  if (plus_s && plus_p) return "+s and +p cannot both be set";
  int w = snprintf(stored, cap, "%s%s%s", modes, limit[0] ? " " : "", limit);
  if (w < 0 || (size_t)w >= cap) return "the mode string is too long";
  if (hub_modes_check(stored) != HUB_MODES_OK) return "that is not a valid mode string";
  return NULL;
}

/* channel mode: #chan | #chan|<modes>|<arg>... | #chan|- */
static bool admin_chan_mode(hub_state_t *state, hub_client_t *client, const char *payload) {
  char chan[MAX_CHAN], cname[MAX_CHAN];
  if (!payload || !payload[0] || !wire_field(payload, 0, chan, sizeof(chan)))
    return admin_err(state, client, "channel.usage", "say which channel",
                     "channel mode <#chan> [<+modes> [args]]");
  if (!chan_name_valid(chan)) return mf_status_err(state, client, HUB_MODES_BAD_CHAN, chan);
  if (!hub_chan_live(state, chan, cname, sizeof(cname)))
    return mf_status_err(state, client, HUB_MODES_NOT_MANAGED, chan);
  int nf = mf_field_count(payload);
  reply_t r;
  if (nf == 1) {
    reply_init(&r);
    reply_ok(&r, "channel.mode");
    reply_kvb(&r, "view", true);
    mf_mode_card(state, &r, cname);
    return send_reply(state, client, &r);
  }
  if (nf > 5) return admin_err(state, client, "channel.bad_mode", "too many arguments",
                               "channel mode <#chan> <+modes> [key] [limit]");
  char modes[C_MODES_MAX + 2], stored[C_MODES_MAX + 1], args[3][64], key[64] = "";
  if (!wire_field(payload, 1, modes, sizeof(modes)))
    return admin_err(state, client, "channel.bad_mode", "the mode string is too long", NULL);
  int nargs = nf - 2, key_op = 0;
  for (int i = 0; i < nargs; i++)
    if (!wire_field(payload, 2 + i, args[i], sizeof(args[i])))
      return admin_err(state, client, "channel.bad_mode", "an argument is too long", NULL);
  if (strcmp(modes, "-") == 0 && nargs == 0) {
    stored[0] = '\0';
  } else {
    const char *why = mf_parse_modes(modes, args, nargs, stored, sizeof(stored), &key_op, key,
                                     sizeof(key));
    if (why) {
      secure_wipe(key, sizeof(key));
      secure_wipe(args, sizeof(args));
      return admin_err(state, client, "channel.bad_mode", why,
                       "channel mode <#chan> <+modes> [key] [limit]  (- = network default)");
    }
  }
  hub_chanset_t cs;
  hub_chanset_get(state, cname, &cs);
  hub_modes_status_t st = hub_chanset_put(state, cname, stored, cs.settings);
  if (st == HUB_MODES_OK && key_op) {
    char cur[64];
    chan_effective_key(state, cname, cur, sizeof(cur));
    const char *want = key_op > 0 ? key : "";
    if (strcmp(cur, want) != 0) chan_store(state, cname, want);
    secure_wipe(cur, sizeof(cur));
  }
  secure_wipe(key, sizeof(key));
  secure_wipe(args, sizeof(args));
  if (st != HUB_MODES_OK) return mf_status_err(state, client, st, cname);
  /* Apply once: the answer (channel.mode with who did it, or channel.nobody)
   * comes when the election ends. */
  if (!hub_chan_mode_apply(state, cname, client))
    return admin_err(state, client, "channel.busy",
                     "the modes are stored, but too many channel requests are in flight "
                     "to apply them now",
                     "channel mode <#chan> again in a few seconds");
  return true;
}

/* Effective value of `name` as seen from `work` (a settings string being
 * edited) with the network level below it; src 'c' / 'n' / 'b'. */
static int mf_eff(const hub_state_t *state, const char *work, bool net_target,
                  const char *name, char *out, size_t cap) {
  if (hub_settings_get(work, name, out, cap)) return net_target ? 'n' : 'c';
  return hub_setting_effective(state, NULL, name, out, cap);
}

static const char *mf_src_word(int s) { return s == 'c' ? "chan" : s == 'n' ? "net" : "built-in"; }

/* Canonical text of a validated value: numbers without leading zeros, floods
 * as N:S or off. */
static void mf_canon(const char *kind, char *value, size_t cap) {
  long a, b;
  if (strcmp(kind, "num") == 0 && sscanf(value, "%ld", &a) == 1) snprintf(value, cap, "%ld", a);
  else if ((strcmp(kind, "flood") == 0 && strcmp(value, "off") != 0 &&
            sscanf(value, "%ld:%ld", &a, &b) == 2) ||
           (strcmp(kind, "sendq") == 0 && sscanf(value, "%ld:%ld", &a, &b) == 2))
    snprintf(value, cap, "%ld:%ld", a, b);
}

static const char *mf_value_hint(const char *name, const char *kind, char *buf, size_t cap) {
  long lo, hi;
  if (strcmp(kind, "num") == 0 && hub_setting_range(name, &lo, &hi))
    snprintf(buf, cap, "%s is a whole number from %ld to %ld", name, lo, hi);
  else if (strcmp(kind, "sendq") == 0)
    snprintf(buf, cap, "%s takes B:I (B 1-100 lines, I 0-10000 ms)", name);
  else if (strcmp(kind, "flood") == 0)
    snprintf(buf, cap, "%s takes N:S (N 1-1000 events in S 1-3600 seconds), off or default", name);
  else
    snprintf(buf, cap, "%s is an on/off option: use +%s or -%s", name, name, name);
  return buf;
}

/* One edit of a settings string.  tok: "+name", "-name" or "name=value"
 * (value may be "default").  net: the target is D| (channel set default).
 * The change goes to `work`; the pieces of the reply to `chg`.  NULL on
 * success, else sets *code / returns the message. */
typedef struct {
  char name[48], kind[8], old[24], val[24];
  int old_src, src;
  bool reset;
} mf_chg_t;

static const char *mf_edit(const hub_state_t *state, char *work, size_t cap, bool net,
                           const char *tok, mf_chg_t *chg, const char **code,
                           char *msgbuf, size_t msgcap) {
  const char *eq = strchr(tok, '=');
  char name[48], value[48];
  bool signed_form = tok[0] == '+' || tok[0] == '-';
  if (signed_form) {
    snprintf(name, sizeof(name), "%.47s", tok + 1);
    snprintf(value, sizeof(value), "%s", tok[0] == '+' ? "1" : "0");
    if (strlen(tok + 1) >= sizeof(name) || eq) {
      *code = "channel.unknown_setting";
      return "that is not a setting name";
    }
  } else {
    size_t nl = eq ? (size_t)(eq - tok) : 0;
    if (!eq || nl == 0 || nl >= sizeof(name) || strlen(eq + 1) >= sizeof(value)) {
      *code = "channel.usage";
      return "say a value after the setting name";
    }
    memcpy(name, tok, nl);
    name[nl] = '\0';
    snprintf(value, sizeof(value), "%s", eq + 1);
  }
  for (const char *p = name; *p; p++)
    if (!((*p >= 'a' && *p <= 'z') || *p == ' ')) {
      *code = "channel.unknown_setting";
      snprintf(msgbuf, msgcap, "unknown setting \"%.40s\"", name);
      return msgbuf;
    }
  if (strcmp(name, "key") == 0) {
    *code = "channel.moved";
    return "the channel key is a mode now: use channel mode <#chan> +k <key>";
  }
  const char *kind = hub_setting_kind(name);
  if (!kind || hub_setting_net_only(name)) {
    *code = "channel.unknown_setting";
    snprintf(msgbuf, msgcap, "unknown setting \"%.40s\"", name);
    return msgbuf;
  }
  bool reset = strcmp(value, "default") == 0;
  if (!reset) {
    bool flag = strcmp(kind, "flag") == 0;
    if (flag != signed_form) {
      *code = "channel.bad_value";
      return mf_value_hint(name, kind, msgbuf, msgcap);
    }
    if (hub_setting_check(name, value, net) != HUB_MODES_OK) {
      *code = "channel.bad_value";
      return mf_value_hint(name, kind, msgbuf, msgcap);
    }
    mf_canon(kind, value, sizeof(value));
  }
  memset(chg, 0, sizeof(*chg));
  snprintf(chg->name, sizeof(chg->name), "%s", name);
  snprintf(chg->kind, sizeof(chg->kind), "%s", kind);
  chg->old_src = mf_eff(state, work, net, name, chg->old, sizeof(chg->old));
  hub_modes_status_t st = hub_settings_set(work, cap, name, reset ? NULL : value);
  if (st != HUB_MODES_OK) {
    *code = "channel.too_long";
    return "the settings would not fit the record (512 bytes)";
  }
  chg->src = mf_eff(state, work, net, name, chg->val, sizeof(chg->val));
  chg->reset = reset;
  return NULL;
}

static void mf_chg_rec(reply_t *r, const mf_chg_t *c, const char *shown) {
  reply_rec(r, "chg");
  reply_kv(r, "setting", shown);
  reply_kv(r, "kind", c->kind);
  reply_kv(r, "old", c->old);
  reply_kv(r, "old_src", mf_src_word(c->old_src));
  reply_kv(r, "value", c->val);
  reply_kv(r, "src", mf_src_word(c->src));
  reply_kvb(r, "reset", c->reset);
}

/* One `setting` row per table entry of the wanted class, with the value in
 * force and where it comes from. */
static void mf_setting_rows(const hub_state_t *state, reply_t *r, const char *cname,
                            bool net_rows) {
  for (int i = 0; i < hub_setting_count(); i++) {
    const char *n = hub_setting_name(i);
    if (hub_setting_net_only(n) != net_rows) continue;
    char v[24], shown[48];
    int s = hub_setting_effective(state, cname, n, v, sizeof(v));
    if (strncmp(n, "bflood ", 7) == 0) snprintf(shown, sizeof(shown), "flood %s", n + 7);
    else snprintf(shown, sizeof(shown), "%s", n);
    reply_rec(r, "setting");
    reply_kv(r, "name", shown);
    reply_kv(r, "kind", hub_setting_kind(n));
    reply_kv(r, "value", v);
    reply_kv(r, "src", mf_src_word(s));
  }
}

/* channel set <#chan|default> [tokens...] */
static bool admin_chan_set(hub_state_t *state, hub_client_t *client, const char *payload) {
  char target[MAX_CHAN], cname[MAX_CHAN] = "";
  if (!payload || !payload[0] || !wire_field(payload, 0, target, sizeof(target)))
    return admin_err(state, client, "channel.usage", "say which channel, or default",
                     "channel set <#chan|default> [+opt|-opt|<name> <value>]");
  bool net = strcmp(target, "default") == 0;
  hub_chanset_t cur;
  if (net) {
    hub_netset_get(state, &cur);
  } else {
    if (!chan_name_valid(target)) return mf_status_err(state, client, HUB_MODES_BAD_CHAN, target);
    if (!hub_chan_live(state, target, cname, sizeof(cname)))
      return mf_status_err(state, client, HUB_MODES_NOT_MANAGED, target);
    hub_chanset_get(state, cname, &cur);
  }
  int nf = mf_field_count(payload);
  reply_t r;
  if (nf == 1) { /* the view */
    reply_init(&r);
    reply_ok(&r, "channel.settings");
    reply_kv(&r, "name", net ? "default" : cname);
    const char *eff = "+nt", *src = "built-in";
    if (cur.modes[0]) {
      eff = cur.modes;
      src = net ? "net" : "chan";
    } else if (!net) {
      hub_chanset_t ns;
      if (hub_netset_get(state, &ns) && ns.modes[0]) {
        eff = ns.modes;
        src = "net";
      }
    }
    reply_kv(&r, "modes", cur.modes);
    reply_kv(&r, "effective", eff);
    reply_kv(&r, "source", src);
    reply_kvi(&r, "ts", (long long)cur.ts);
    mf_setting_rows(state, &r, net ? NULL : cname, false);
    return send_reply(state, client, &r);
  }
  if (nf - 1 > MF_MAX_TOKENS)
    return admin_err(state, client, "channel.usage", "too many settings in one line", NULL);
  char work[C_SETTINGS_MAX + 64];
  snprintf(work, sizeof(work), "%s", cur.settings);
  mf_chg_t chg[MF_MAX_TOKENS];
  int nchg = 0;
  for (int i = 1; i < nf; i++) {
    char tok[96], msg[200];
    const char *code = "channel.bad_value";
    if (!wire_field(payload, i, tok, sizeof(tok)) || !tok[0])
      return admin_err(state, client, "channel.bad_value", "a setting is too long or empty", NULL);
    const char *why = mf_edit(state, work, C_SETTINGS_MAX + 1, net, tok, &chg[nchg], &code, msg,
                              sizeof(msg));
    if (why) return admin_err(state, client, code, why,
                              strcmp(code, "channel.moved") == 0
                                  ? "channel mode <#chan> +k <key>"
                                  : "channel set <#chan|default> shows the settings");
    nchg++;
  }
  bool written = strcmp(work, cur.settings) != 0;
  if (written) {
    hub_modes_status_t st = net ? hub_netset_put(state, cur.modes, work)
                                : hub_chanset_put(state, cname, cur.modes, work);
    if (st != HUB_MODES_OK) return mf_status_err(state, client, st, cname);
  }
  reply_init(&r);
  reply_ok(&r, "channel.set");
  reply_kv(&r, "name", net ? "default" : cname);
  reply_kvi(&r, "changes", nchg);
  reply_kvb(&r, "written", written);
  reply_kvi(&r, "bots", local_bot_count(state));
  reply_kvi(&r, "peers", linked_peer_count(state));
  for (int i = 0; i < nchg; i++) mf_chg_rec(&r, &chg[i], chg[i].name);
  return send_reply(state, client, &r);
}

/* bot set (CMD_ADMIN_NET_SET): "" | flood|<cmd|msg|ctcp>|<N:S|off|default> | ignoretime|<min|default> | sendq|<B:I|default> */
static bool admin_cron_set(hub_state_t *state, hub_client_t *client, const char *payload);
static bool admin_net_set(hub_state_t *state, hub_client_t *client, const char *payload) {
  if (payload && (strncmp(payload, "botcron|", 8) == 0 || strncmp(payload, "hubcron|", 8) == 0))
    return admin_cron_set(state, client, payload);
  hub_chanset_t cur;
  hub_netset_get(state, &cur);
  reply_t r;
  if (!payload || !payload[0]) {
    reply_init(&r);
    reply_ok(&r, "network.settings");
    reply_kvi(&r, "ts", (long long)cur.ts);
    mf_setting_rows(state, &r, NULL, true);
    return send_reply(state, client, &r);
  }
  char sub[16], type[8] = "", value[48], name[24], shown[24];
  int nf = mf_field_count(payload);
  if (!wire_field(payload, 0, sub, sizeof(sub)))
    return admin_err(state, client, "network.usage", "unknown bot setting", NULL);
  if (strcmp(sub, "flood") == 0 && nf == 3) {
    if (!wire_field(payload, 1, type, sizeof(type)) ||
        !wire_field(payload, 2, value, sizeof(value)) ||
        (strcmp(type, "cmd") && strcmp(type, "msg") && strcmp(type, "ctcp")))
      return admin_err(state, client, "network.unknown_setting",
                       "flood types are cmd, msg and ctcp", "bot set flood <cmd|msg|ctcp> <N:S|off|default>");
    snprintf(name, sizeof(name), "bflood %s", type);
    snprintf(shown, sizeof(shown), "flood %s", type);
  } else if (strcmp(sub, "ignoretime") == 0 && nf == 2) {
    if (!wire_field(payload, 1, value, sizeof(value)))
      return admin_err(state, client, "network.bad_value", "that value is too long", NULL);
    snprintf(name, sizeof(name), "ignoretime");
    snprintf(shown, sizeof(shown), "ignoretime");
  } else if (strcmp(sub, "sendq") == 0 && nf == 2) {
    if (!wire_field(payload, 1, value, sizeof(value)))
      return admin_err(state, client, "network.bad_value", "that value is too long", NULL);
    snprintf(name, sizeof(name), "sendq");
    snprintf(shown, sizeof(shown), "sendq");
  } else {
    return admin_err(state, client, "network.unknown_setting",
                     "bot settings are flood <cmd|msg|ctcp>, ignoretime and sendq",
                     "bot set shows them");
  }
  const char *kind = hub_setting_kind(name);
  bool reset = strcmp(value, "default") == 0;
  char msg[160];
  if (!reset) {
    if (hub_setting_check(name, value, true) != HUB_MODES_OK)
      return admin_err(state, client, "network.bad_value",
                       mf_value_hint(shown, kind, msg, sizeof(msg)),
                       strcmp(sub, "flood") == 0 ? "bot set flood cmd 10:30"
                       : strcmp(sub, "sendq") == 0 ? "bot set sendq 10:100"
                                                   : "bot set ignoretime 10");
    mf_canon(kind, value, sizeof(value));
  }
  char work[D_SETTINGS_MAX + 64];
  snprintf(work, sizeof(work), "%s", cur.settings);
  mf_chg_t chg;
  memset(&chg, 0, sizeof(chg));
  snprintf(chg.kind, sizeof(chg.kind), "%s", kind);
  chg.old_src = mf_eff(state, work, true, name, chg.old, sizeof(chg.old));
  if (hub_settings_set(work, D_SETTINGS_MAX + 1, name, reset ? NULL : value) != HUB_MODES_OK)
    return mf_status_err(state, client, HUB_MODES_TOO_LONG, NULL);
  chg.src = mf_eff(state, work, true, name, chg.val, sizeof(chg.val));
  chg.reset = reset;
  bool written = strcmp(work, cur.settings) != 0;
  if (written) {
    hub_modes_status_t st = hub_netset_put(state, cur.modes, work);
    if (st != HUB_MODES_OK) return mf_status_err(state, client, st, NULL);
  }
  reply_init(&r);
  reply_ok(&r, "network.set");
  reply_kv(&r, "setting", shown);
  reply_kv(&r, "kind", chg.kind);
  reply_kv(&r, "old", chg.old);
  reply_kv(&r, "old_src", mf_src_word(chg.old_src));
  reply_kv(&r, "value", chg.val);
  reply_kv(&r, "src", mf_src_word(chg.src));
  reply_kvb(&r, "reset", reset);
  reply_kvb(&r, "written", written);
  reply_kvi(&r, "bots", local_bot_count(state));
  reply_kvi(&r, "peers", linked_peer_count(state));
  return send_reply(state, client, &r);
}

/* hub set ssh | hub set conn (CMD_ADMIN_SET_SSH, docs/modes.md §9.3, D35):
 *   "" | conn                       view of the ssh / conn group (ok|hub.show)
 *   <name>|<value|default>          ssh setting
 *   conn|<name>|<value|default>     shared connection limit
 * Local to this hub (.irchub.cnf, never synced).  A change reaches the console
 * thread as a fresh snapshot and applies to the next connection. */
static bool admin_set_ssh(hub_state_t *state, hub_client_t *client, const char *payload) {
  char f0[40] = "", f1[40] = "", f2[64] = "";
  int nf = payload && payload[0] ? mf_field_count(payload) : 0;
  if (nf > 3 || (nf > 0 && !wire_field(payload, 0, f0, sizeof(f0))) ||
      (nf > 1 && !wire_field(payload, 1, f1, sizeof(f1))) ||
      (nf > 2 && !wire_field(payload, 2, f2, sizeof(f2))))
    return admin_err(state, client, "hub.bad_value", "that setting line is malformed",
                     "hub set ssh <name> <value|default>");
  bool conn = nf >= 1 && strcmp(f0, "conn") == 0;
  int group = conn ? HUB_CONN_CONN : HUB_CONN_SSH;
  const char *gname = conn ? "conn" : "ssh";
  reply_t r;

  if (nf == 0 || (conn && nf == 1)) {
    reply_init(&r);
    reply_ok(&r, "hub.show");
    reply_kv(&r, "group", gname);
    for (int i = 0; i < hub_conn_cfg_count(group); i++) {
      const char *nm = hub_conn_cfg_name(group, i);
      char v[48], d[48], key[40];
      hub_conn_cfg_get(&state->conn_cfg, group, nm, v, sizeof(v));
      hub_conn_cfg_default(group, nm, d, sizeof(d));
      reply_kv(&r, nm, v);
      snprintf(key, sizeof(key), "%s_def", nm);
      reply_kv(&r, key, d);
    }
    return send_reply(state, client, &r);
  }

  const char *name = conn ? f1 : f0, *value = conn ? f2 : f1;
  if ((conn && nf != 3) || (!conn && nf != 2))
    return admin_err(state, client, "hub.bad_value", "say a setting and its value",
                     conn ? "hub set conn <perip|churn|authfail|startups> <value|default>"
                          : "hub set ssh <name> <value|default>");
  char old[48], now[48], why[160];
  if (!hub_conn_cfg_get(&state->conn_cfg, group, name, old, sizeof(old))) {
    snprintf(why, sizeof(why), "unknown %s setting \"%.30s\"", gname, name);
    return admin_err(state, client, "hub.unknown_setting", why,
                     conn ? "perip, churn, authfail, startups"
                          : "preauth, preauthip, sessions, grace, authtries, idle, authfail, "
                            "connect, block, cmdrate");
  }
  bool reset = strcmp(value, "default") == 0;
  hub_conn_cfg_t next = state->conn_cfg;
  if (hub_conn_cfg_set(&next, group, name, reset ? NULL : value, why, sizeof(why)) != HUB_CONN_OK)
    return admin_err(state, client, "hub.bad_value", why, "hub set ssh shows the settings");
  /* A new connect / churn limit the issuing admin's own address is already
   * over would lock the console out: refuse it. */
  {
    time_t t = time(NULL);
    bool loop = state->trust_loopback &&
                (strcmp(client->ip, "127.0.0.1") == 0 || strcmp(client->ip, "::1") == 0);
    int seen = 0, win = 0;
    if (!loop && !conn && strcmp(name, "connect") == 0) {
      const ssh_ip_t *e = hub_ssh_table_peek(state->ssh_ips, state->ssh_ip_count, client->ip);
      win = next.connect_s;
      if (e && t - e->win_start < win && e->conn_n > next.connect_n) seen = e->conn_n;
    } else if (!loop && conn && strcmp(name, "churn") == 0) {
      win = next.churn_s;
      for (int i = 0; i < state->ip_limits_count; i++) {
        const ip_rate_limit_t *e = &state->ip_limits[i];
        if (strcmp(e->ip, client->ip) == 0 && t - e->churn_window_start < win &&
            e->churn_count > next.churn_n)
          seen = e->churn_count;
      }
    }
    if (seen > 0) {
      snprintf(why, sizeof(why), "your own address made %d connections in the last %d s, "
               "over that limit", seen, win);
      return admin_err(state, client, "hub.bad_value", why,
                       "raise it, or wait for the window to pass");
    }
  }
  hub_conn_cfg_get(&next, group, name, now, sizeof(now));
  bool written = strcmp(old, now) != 0;
  if (written) {
    state->conn_cfg = next;
    state->config_dirty = true;
    hub_console_limits_changed(state);
    hub_log_info("[CONFIG] %s %s %s -> %s by %s\n", gname, name, old, now,
                 hub_who_client(state, client));
  }
  reply_init(&r);
  reply_ok(&r, "hub.set");
  char shown[64];
  snprintf(shown, sizeof(shown), "%s %s", gname, name);
  reply_kv(&r, "setting", shown);
  reply_kv(&r, "old", old);
  reply_kv(&r, "value", now);
  reply_kv(&r, "group", gname);
  reply_kvb(&r, "reset", reset);
  reply_kvb(&r, "written", written);
  reply_kvb(&r, "restart", false);
  return send_reply(state, client, &r);
}

/* ban: list|<#c|*|""> | add|<#c|*>|<mask>|<min|perm>|<sticky 0/1>|<reason> | del|<#c|*>|<mask> */
/* ---- server pool console (CMD_ADMIN_POOL, 2.5.4) ----------------------- */

/* "k=v,k=v": the value of `key` into out; true if present. */
static bool pool_kv(const char *list, const char *key, char *out, size_t cap) {
  size_t kl = strlen(key);
  for (const char *p = list; p && *p;) {
    const char *e = strchr(p, ',');
    size_t n = e ? (size_t)(e - p) : strlen(p);
    if (n > kl && strncmp(p, key, kl) == 0 && p[kl] == '=') {
      size_t vl = n - kl - 1;
      if (vl >= cap) vl = cap - 1;
      memcpy(out, p + kl + 1, vl);
      out[vl] = '\0';
      return true;
    }
    p = e ? e + 1 : NULL;
  }
  return false;
}

/* Every k of "k=v,..." is one of `allowed` (space separated). */
static bool pool_kv_known(const char *list, const char *allowed) {
  for (const char *p = list; p && *p;) {
    const char *e = strchr(p, ',');
    size_t n = e ? (size_t)(e - p) : strlen(p);
    const char *eq = memchr(p, '=', n);
    if (!eq || eq == p) return false;
    char k[16];
    size_t kl = (size_t)(eq - p);
    if (kl >= sizeof(k)) return false;
    memcpy(k, p, kl);
    k[kl] = '\0';
    bool ok = false;
    for (const char *a = allowed; *a && !ok;) {
      const char *sp = strchr(a, ' ');
      size_t al = sp ? (size_t)(sp - a) : strlen(a);
      ok = al == kl && strncmp(a, k, kl) == 0;
      a = sp ? sp + 1 : a + al;
    }
    if (!ok) return false;
    p = e ? e + 1 : NULL;
  }
  return true;
}

static bool pool_num(const char *v, int lo, int hi, int *out) {
  unsigned long n;
  if (!hub_parse_uint(v, (unsigned long)hi, &n) || (int)n < lo) return false;
  *out = (int)n;
  return true;
}

static void pool_rec_kv(reply_t *r, const pool_srv_t *s) {
  reply_kv(r, "uuid", s->uuid);
  reply_kv(r, "host", s->host);
  reply_kvi(r, "port", s->port);
  reply_kvi(r, "weight", s->weight);
  reply_kvi(r, "max", s->max);
  reply_kv(r, "state", pool_state_name(s->state));
  if (s->seen[0]) reply_kv(r, "seen", s->seen);
}

static bool pool_effects(hub_state_t *state, hub_client_t *client, reply_t *r) {
  reply_kvi(r, "bots", local_bot_count(state));
  reply_kvi(r, "peers", linked_peer_count(state));
  return send_reply(state, client, r);
}

static bool admin_pool(hub_state_t *state, hub_client_t *client, const char *payload) {
  char sub[16] = "", what[POOL_HOST_MAX + 16] = "", kv[256] = "";
  if (!payload || !wire_field(payload, 0, sub, sizeof(sub)))
    return admin_err(state, client, "pool.usage", "server list, add, set, del or clear", "help server");
  wire_field(payload, 1, what, sizeof(what));
  wire_field(payload, 2, kv, sizeof(kv));
  reply_t r;
  pool_net_t net;
  time_t net_ts;
  hub_pool_net_get(state, POOL_DEFAULT_NET, &net, &net_ts);

  if (!strcmp(sub, "list")) {
    static char view[(MAX_POOL_SERVERS + MAX_POOL_TOMBS) * POOL_VIEW_LINE_MAX + 16];
    int vl = hub_pool_view_text(state, view, sizeof(view));
    if (vl < 0) view[0] = '\0';
    reply_init(&r);
    reply_ok(&r, "pool.list");
    reply_kv(&r, "net", net.net_id);
    reply_kv(&r, "name", net.name);
    reply_kvi(&r, "usable", hub_pool_eligible_count(state, POOL_DEFAULT_NET));
    reply_kvi(&r, "idle", hub_pool_idle_bots(state));
    int count = 0;
    for (int i = 0; i < state->global_entry_count; i++) {
      pool_srv_t s;
      const config_entry_t *e = &state->global_entries[i];
      count += e->key[0] == 'S' && !e->key[1] && pool_srv_parse(e->value, &s) && !s.deleted;
    }
    reply_kvi(&r, "count", count); /* before the records: a kv after one lands in it */
    for (int i = 0; i < state->global_entry_count; i++) {
      const config_entry_t *e = &state->global_entries[i];
      pool_srv_t s;
      if (e->key[0] != 'S' || e->key[1] || !pool_srv_parse(e->value, &s) || s.deleted) continue;
      int up = 0, conn = 0;
      char needle[POOL_UUID_LEN + 4];
      snprintf(needle, sizeof(needle), "E|%s|", s.uuid);
      const char *at = strstr(view, needle);
      if (at) sscanf(at + strlen(needle), "%d|%d", &up, &conn);
      reply_rec(&r, "server");
      pool_rec_kv(&r, &s);
      reply_kvi(&r, "up", up);
      reply_kvi(&r, "connecting", conn);
      reply_kvi(&r, "assigned", hub_pool_order_first_count(s.uuid));
      reply_kvi(&r, "ts", (long long)e->timestamp);
    }
    return send_reply(state, client, &r);
  }

  if (!strcmp(sub, "net")) {
    reply_init(&r);
    reply_ok(&r, "pool.net");
    reply_kv(&r, "net", net.net_id);
    reply_kv(&r, "name", net.name);
    reply_kv(&r, "aliases", net.aliases);
    reply_kvi(&r, "pace", net.pace_gap);
    reply_kvi(&r, "usable", hub_pool_eligible_count(state, POOL_DEFAULT_NET));
    reply_kvi(&r, "idle", hub_pool_idle_bots(state));
    reply_kvi(&r, "ts", (long long)net_ts);
    return send_reply(state, client, &r);
  }

  if (!strcmp(sub, "netset")) {
    const char *k = what; /* netset|<k=v,...> */
    if (!k[0] || !pool_kv_known(k, "name alias pace"))
      return admin_err(state, client, "pool.usage",
                       "network set name=<NETWORK>, alias=<a,b,...> or pace=<0-600>",
                       "help network set");
    char nv[POOL_NET_NAME_MAX + 2], v[sizeof(net.aliases)];
    if (pool_kv(k, "name", nv, sizeof(nv))) {
      if (!pool_net_name_ok(nv))
        return admin_err(state, client, "pool.bad_value",
                         "a network name is 1-64 printable characters, no '|' or ','", NULL);
      memcpy(net.name, nv, strlen(nv) + 1);
    }
    if (pool_kv(k, "alias", v, sizeof(v))) {
      /* the aliases ride the k=v list's own ','; the UI sends them with ';' */
      for (char *q = v; *q; q++)
        if (*q == ';') *q = ',';
      if (!strcmp(v, "-")) v[0] = '\0';
      memcpy(net.aliases, v, strlen(v) + 1);
      char probe[POOL_N_LINE_MAX];
      if (pool_net_format(&net, probe, sizeof(probe)) < 0)
        return admin_err(state, client, "pool.bad_value",
                         "aliases: up to 8 network names, comma separated (- for none)", NULL);
    }
    char pv[16];
    if (pool_kv(k, "pace", pv, sizeof(pv)) && !pool_num(pv, 0, POOL_PACE_GAP_MAX, &net.pace_gap))
      return admin_err(state, client, "pool.bad_value",
                       "pace is 0 to 600 seconds (0 = no pacing)", NULL);
    net.deleted = false;
    if (!hub_pool_net_put(state, &net))
      return admin_err(state, client, "pool.bad_value", "not a valid network record", NULL);
    reply_init(&r);
    reply_ok(&r, "pool.netset");
    reply_kv(&r, "net", net.net_id);
    reply_kv(&r, "name", net.name);
    reply_kv(&r, "aliases", net.aliases);
    reply_kvi(&r, "pace", net.pace_gap);
    return pool_effects(state, client, &r);
  }

  if (!strcmp(sub, "order")) {
    /* order|[nick|uuid]: every bot's order (first server, slot), or one's */
    static char ids[MAX_BOTS][64];
    int n = hub_pool_order_bots(ids, MAX_BOTS);
    reply_init(&r);
    reply_ok(&r, "pool.order");
    reply_kvi(&r, "pace", net.pace_gap);
    int shown = 0;
    for (int i = 0; i < n; i++) {
      const bot_config_t *b = bot_by_uuid(state, ids[i]);
      const config_entry_t *ne = b ? bot_entry_rec(b, "n") : NULL;
      const char *nick = ne ? ne->value : NULL;
      if (what[0] && strcmp(what, ids[i]) != 0 && !(nick && !strcasecmp(nick, what))) continue;
      char first[POOL_UUID_LEN + 1], cur[POOL_UUID_LEN + 1];
      int slot = 0, slots = 1;
      if (!hub_pool_order_first(ids[i], first, sizeof(first), &slot, &slots)) continue;
      const char *w = hub_pool_bot_link(state, ids[i], cur, sizeof(cur));
      pool_srv_t fs, cs;
      bool have_f = hub_pool_srv_get(state, first, &fs);
      bool have_c = cur[0] && hub_pool_srv_get(state, cur, &cs);
      reply_rec(&r, "order");
      reply_kv(&r, "uuid", ids[i]);
      reply_kv(&r, "nick", nick ? nick : "");
      if (have_f) {
        reply_kv(&r, "first", fs.host);
        reply_kvi(&r, "first_port", fs.port);
      }
      reply_kvi(&r, "slot", slot);
      reply_kvi(&r, "slots", slots);
      reply_kv(&r, "link", w);
      if (have_c) {
        reply_kv(&r, "on", cs.host);
        reply_kvi(&r, "on_port", cs.port);
      }
      reply_kvi(&r, "off", strcmp(w, "up") == 0 && cur[0] && strcmp(cur, first) != 0);
      shown++;
    }
    if (what[0] && !shown)
      return admin_err(state, client, "pool.no_order", "no server order for that bot",
                       "server order");
    return send_reply(state, client, &r);
  }

  if (!strcmp(sub, "rebalance")) {
    /* rebalance|[force|stop]: preview, start the waves, or stop them */
    static char ids[MAX_BOTS][64];
    int n = hub_pool_order_bots(ids, MAX_BOTS), off = 0;
    for (int i = 0; i < n; i++) {
      char cur[POOL_UUID_LEN + 1], first[POOL_UUID_LEN + 1];
      off += rebalance_off_first(state, ids[i], cur, sizeof(cur), first, sizeof(first));
    }
    reply_init(&r);
    if (!strcmp(what, "stop")) {
      bool was = g_rebal.active;
      g_rebal.active = false;
      g_rebal.wn = 0;
      reply_ok(&r, "pool.rebalance");
      reply_kv(&r, "state", was ? "stopped" : "idle");
    } else if (!strcmp(what, "force")) {
      if (g_rebal.active)
        return admin_err(state, client, "pool.rebalancing", "a rebalance is already running here",
                         "server rebalance stop");
      memset(&g_rebal, 0, sizeof(g_rebal));
      if (off) {
        g_rebal.active = true;
        snprintf(g_rebal.by, sizeof(g_rebal.by), "%s", mf_admin_name(client));
        hub_log_info("[POOL] Rebalance started by %s: %d bot%s off their first server\n",
                     g_rebal.by, off, off == 1 ? "" : "s");
      }
      reply_ok(&r, "pool.rebalance");
      reply_kv(&r, "state", off ? "started" : "balanced");
    } else if (!what[0]) {
      reply_ok(&r, "pool.rebalance");
      reply_kv(&r, "state", g_rebal.active ? "running" : "preview");
    } else {
      return admin_err(state, client, "pool.usage", "server rebalance [force|stop]",
                       "help server rebalance");
    }
    reply_kvi(&r, "off", off);
    reply_kvi(&r, "bots", n);
    reply_kvi(&r, "pace", net.pace_gap);
    if (g_rebal.active) {
      reply_kvi(&r, "moved", g_rebal.moved);
      reply_kvi(&r, "waves", g_rebal.waves);
    }
    return send_reply(state, client, &r);
  }

  if (!what[0])
    return admin_err(state, client, "pool.usage", "name a server: host[:port] or its uuid",
                     "help server");

  if (!strcmp(sub, "add")) {
    pool_srv_t s;
    memset(&s, 0, sizeof(s));
    if (!pool_hostport_parse(what, s.host, sizeof(s.host), &s.port))
      return admin_err(state, client, "pool.bad_host", "not a host[:port]", "server add irc.example.net:6697");
    if (kv[0] && !pool_kv_known(kv, "weight max"))
      return admin_err(state, client, "pool.usage", "server add <host[:port]> [weight=<1-100>] [max=<0-100>]",
                       "help server add");
    snprintf(s.net_id, sizeof(s.net_id), "%s", POOL_DEFAULT_NET);
    pool_srv_uuid(s.net_id, s.host, s.port, s.uuid);
    pool_srv_t cur;
    bool have = hub_pool_srv_get(state, s.uuid, &cur);
    if (have && !cur.deleted)
      return admin_err(state, client, "pool.exists", "that server is already in the pool",
                       "server set to change it");
    s.weight = have ? cur.weight : 1;
    s.max = have ? cur.max : 0;
    char v[16];
    if (pool_kv(kv, "weight", v, sizeof(v)) && !pool_num(v, 1, POOL_WEIGHT_MAX, &s.weight))
      return admin_err(state, client, "pool.bad_value", "weight is 1 to 100", NULL);
    if (pool_kv(kv, "max", v, sizeof(v)) && !pool_num(v, 0, POOL_MAX_MAX, &s.max))
      return admin_err(state, client, "pool.bad_value", "max is 0 (none) to 100", NULL);
    s.state = POOL_OK;
    if (!hub_pool_srv_put(state, &s))
      return admin_err(state, client, "pool.full", "the pool is full (64 servers)", "server del one first");
    hub_pool_strikes_clear(s.uuid);
    reply_init(&r);
    reply_ok(&r, "pool.added");
    pool_rec_kv(&r, &s);
    reply_kvb(&r, "revived", have);
    return pool_effects(state, client, &r);
  }

  pool_srv_t s;
  if (!hub_pool_find(state, what, &s) || s.deleted)
    return admin_err(state, client, "pool.not_found", "no such server in the pool", "server list");

  if (!strcmp(sub, "set")) {
    if (!kv[0] || !pool_kv_known(kv, "weight max enabled"))
      return admin_err(state, client, "pool.usage",
                       "server set <host[:port]|uuid> weight=<1-100> max=<0-100> enabled=on|off",
                       "help server set");
    char v[16];
    if (pool_kv(kv, "weight", v, sizeof(v)) && !pool_num(v, 1, POOL_WEIGHT_MAX, &s.weight))
      return admin_err(state, client, "pool.bad_value", "weight is 1 to 100", NULL);
    if (pool_kv(kv, "max", v, sizeof(v)) && !pool_num(v, 0, POOL_MAX_MAX, &s.max))
      return admin_err(state, client, "pool.bad_value", "max is 0 (none) to 100", NULL);
    if (pool_kv(kv, "enabled", v, sizeof(v))) {
      if (strcmp(v, "on") && strcmp(v, "off"))
        return admin_err(state, client, "pool.bad_value", "enabled is on or off", NULL);
      bool off = !strcmp(v, "off");
      if (off && s.state == POOL_OK &&
          hub_pool_eligible_count(state, s.net_id) <= 1 && !strstr(kv, "force=1")) {
        char msg[320];
        snprintf(msg, sizeof(msg), "%.180s is the last usable server of network %s: disabling it "
                 "could take all bots off IRC", s.host, s.net_id);
        return admin_err(state, client, "pool.last", msg,
                         "add another server first, or repeat with force");
      }
      if (off) s.state = POOL_DISABLED;
      else if (s.state == POOL_DISABLED) s.state = POOL_OK;
    }
    if (!hub_pool_srv_put(state, &s))
      return admin_err(state, client, "pool.bad_value", "not a valid server record", NULL);
    reply_init(&r);
    reply_ok(&r, "pool.set");
    pool_rec_kv(&r, &s);
    return pool_effects(state, client, &r);
  }

  if (!strcmp(sub, "clear")) {
    if (s.state != POOL_WRONGNET)
      return admin_err(state, client, "pool.not_flagged", "that server is not flagged wrong network",
                       "server list");
    s.state = POOL_OK;
    s.seen[0] = '\0';
    if (!hub_pool_srv_put(state, &s))
      return admin_err(state, client, "pool.bad_value", "not a valid server record", NULL);
    hub_pool_strikes_clear(s.uuid);
    reply_init(&r);
    reply_ok(&r, "pool.cleared");
    pool_rec_kv(&r, &s);
    return pool_effects(state, client, &r);
  }

  if (!strcmp(sub, "del")) {
    bool force = !strcmp(kv, "1");
    bool last = s.state == POOL_OK && hub_pool_eligible_count(state, s.net_id) <= 1;
    if (last && !force) {
      char msg[320];
      snprintf(msg, sizeof(msg), "%.180s is the last usable server of network %s: removing it "
               "could take all bots off IRC", s.host, s.net_id);
      return admin_err(state, client, "pool.last", msg,
                       "add another server first, or repeat with force");
    }
    s.deleted = true;
    if (!hub_pool_srv_put(state, &s))
      return admin_err(state, client, "pool.bad_value", "not a valid server record", NULL);
    hub_pool_strikes_clear(s.uuid);
    reply_init(&r);
    reply_ok(&r, "pool.removed");
    pool_rec_kv(&r, &s);
    reply_kvb(&r, "last", last);
    return pool_effects(state, client, &r);
  }
  return admin_err(state, client, "pool.usage", "server list, add, set, del or clear", "help server");
}

static bool admin_ban(hub_state_t *state, hub_client_t *client, const char *payload) {
  char sub[8], chan[MAX_CHAN] = "", cname[MAX_CHAN] = "*", mask[BAN_MASK_MAX + 8];
  if (!payload || !wire_field(payload, 0, sub, sizeof(sub)))
    return admin_err(state, client, "ban.usage", "ban list, add or del", "help ban");
  int nf = mf_field_count(payload);
  bool list = strcmp(sub, "list") == 0, add = strcmp(sub, "add") == 0,
       del = strcmp(sub, "del") == 0;
  if (!(list && nf <= 2) && !(add && nf >= 6) && !(del && nf == 3))
    return admin_err(state, client, "ban.usage", "ban list, add or del", "help ban");
  if (nf > 1 && !wire_field(payload, 1, chan, sizeof(chan)))
    return mf_status_err(state, client, HUB_MODES_BAD_CHAN, chan);
  bool global = strcmp(chan, "*") == 0;
  if (!(list && !chan[0]) && !global) {
    if (!chan_name_valid(chan)) return mf_status_err(state, client, HUB_MODES_BAD_CHAN, chan);
    if (!list && !hub_chan_live(state, chan, cname, sizeof(cname)))
      return mf_status_err(state, client, HUB_MODES_NOT_MANAGED, chan);
    if (list) snprintf(cname, sizeof(cname), "%s", chan);
  }
  reply_t r;
  if (list) {
    hub_ban_t *b = malloc(sizeof(*b) * MF_BANS_LIST_MAX);
    if (!b) return admin_err(state, client, "internal.oom", "out of memory", NULL);
    int n = hub_ban_list(state, chan[0] ? cname : NULL, b, MF_BANS_LIST_MAX);
    reply_init(&r);
    reply_ok(&r, "ban.list");
    reply_kv(&r, "chan", chan[0] ? cname : "");
    reply_kvi(&r, "count", n);
    reply_kvb(&r, "truncated", n >= MF_BANS_LIST_MAX);
    for (int i = 0; i < n; i++) {
      reply_rec(&r, "ban");
      reply_kv(&r, "chan", b[i].chan);
      reply_kv(&r, "mask", b[i].mask);
      reply_kvi(&r, "expires", (long long)b[i].expires);
      reply_kvb(&r, "sticky", strchr(b[i].flags, 's') != NULL);
      reply_kv(&r, "setter", b[i].setter);
      reply_kv(&r, "reason", b[i].reason);
      reply_kvi(&r, "ts", (long long)b[i].ts);
      reply_kvi(&r, "used", (long long)b[i].last_used);
    }
    free(b);
    return send_reply(state, client, &r);
  }
  if (!wire_field(payload, 2, mask, sizeof(mask)))
    return mf_status_err(state, client, HUB_MODES_BAD_MASK, NULL);
  if (del) {
    hub_modes_status_t st = hub_ban_del(state, global ? "*" : cname, mask);
    if (st != HUB_MODES_OK) return mf_status_err(state, client, st, chan);
    reply_init(&r);
    reply_ok(&r, "ban.removed");
    reply_kv(&r, "chan", global ? "*" : cname);
    reply_kv(&r, "mask", mask);
    reply_kvi(&r, "bots", local_bot_count(state));
    reply_kvi(&r, "peers", linked_peer_count(state));
    return send_reply(state, client, &r);
  }
  /* add */
  char dur[16], sticky[4], reason[BAN_REASON_MAX + 8];
  if (!wire_field(payload, 3, dur, sizeof(dur)) || !wire_field(payload, 4, sticky, sizeof(sticky)))
    return mf_status_err(state, client, HUB_MODES_BAD_EXPIRY, NULL);
  if (!wire_tail(payload, 5, reason, sizeof(reason)) || strchr(reason, '|'))
    return mf_status_err(state, client, HUB_MODES_BAD_REASON, NULL);
  time_t now = time(NULL), expires = 0;
  if (strcmp(dur, "perm") != 0) {
    unsigned long mins;
    if (!hub_parse_uint(dur, (unsigned long)MF_BAN_MINUTES_MAX, &mins) || mins < 1)
      return mf_status_err(state, client, HUB_MODES_BAD_EXPIRY, NULL);
    expires = now + (time_t)mins * 60;
  }
  /* Whether this mask is already banned there (an update, not a new ban). */
  bool existed = false;
  {
    hub_ban_t *b = malloc(sizeof(*b) * MF_BANS_CHAN_MAX);
    if (!b) return admin_err(state, client, "internal.oom", "out of memory", NULL);
    int n = hub_ban_list(state, global ? "*" : cname, b, MF_BANS_CHAN_MAX);
    for (int i = 0; i < n; i++)
      if (hub_ascii_ieq(b[i].mask, mask)) existed = true;
    free(b);
  }
  char who[96];
  hub_modes_status_t st = hub_ban_add(state, global ? "*" : cname, mask, expires,
                                      strcmp(sticky, "1") == 0, mf_admin_name(client), reason,
                                      who, sizeof(who));
  if (st == HUB_MODES_PROTECTED) {
    char msg[256];
    snprintf(msg, sizeof(msg), "%.120s would also ban %.80s, who must never be banned", mask,
             who);
    reply_init(&r);
    reply_err(&r, "ban.protected", msg, "use a narrower mask");
    reply_kv(&r, "mask", mask);
    reply_kv(&r, "who", who);
    return send_reply(state, client, &r);
  }
  if (st != HUB_MODES_OK) return mf_status_err(state, client, st, chan);
  /* One channel: one opped bot sets it now (election kind "ban"), and the
   * answer goes out when it has.  `*` is left to every bot's sweep. */
  chan_elect_t *e = global ? NULL : ce_start(state, "ban", cname, "ADMIN", "", mask, client);
  if (e) {
    e->ban_expires = expires;
    e->ban_sticky = strcmp(sticky, "1") == 0;
    e->ban_existed = existed;
    snprintf(e->ban_reason, sizeof(e->ban_reason), "%.*s", BAN_REASON_MAX, reason);
    return true;
  }
  reply_init(&r);
  reply_ok(&r, "ban.added");
  reply_kv(&r, "chan", global ? "*" : cname);
  reply_kv(&r, "mask", mask);
  reply_kvi(&r, "expires", (long long)expires);
  reply_kvb(&r, "sticky", strcmp(sticky, "1") == 0);
  reply_kv(&r, "reason", reason);
  reply_kvb(&r, "existed", existed);
  reply_kvi(&r, "bots", local_bot_count(state));
  reply_kvi(&r, "peers", linked_peer_count(state));
  if (!global) { /* the election table was full: the sweep sets it */
    reply_kvb(&r, "placed", false);
    reply_kv(&r, "why", "too many channel requests in flight");
  }
  return send_reply(state, client, &r);
}

/* While an upgrade holds the config still, only the changing forms of the
 * four modes opcodes are refused; their views stay readable. */
static bool mf_payload_mutates(int cmd, const char *payload) {
  switch (cmd) {
  case CMD_ADMIN_CHAN_MODE:
  case CMD_ADMIN_CHAN_SET:
    return payload && strchr(payload, '|') != NULL;
  case CMD_ADMIN_BAN:
    return !payload || strncmp(payload, "list", 4) != 0;
  case CMD_ADMIN_POOL:
    /* read-only: list, net, order|<who>, the rebalance preview */
    return !payload || (strcmp(payload, "list") != 0 && strcmp(payload, "net") != 0 &&
                        strncmp(payload, "order|", 6) != 0 && strcmp(payload, "rebalance|") != 0);
  case CMD_ADMIN_NET_SET:
    return payload && payload[0];
  default:
    return true;
  }
}

/* hub_access_append keep filter: the records of one user (arg = its uuid). */
static bool access_same_user(hub_state_t *state, const char *uuid, void *arg) {
  (void)state;
  return strcmp(uuid, (const char *)arg) == 0;
}

/* The admin a console connection belongs to (its id is "ADMIN:<name>"), or
 * NULL when that record is gone or is not a live admin. */
static hub_user_record_t *admin_of_client(hub_state_t *state, const hub_client_t *client) {
  if (strncmp(client->id, "ADMIN:", 6) != 0) return NULL;
  hub_user_record_t *u = user_by_name(state, client->id + 6);
  return u && u->type == 'a' ? u : NULL;
}

/* The flag a user-record command needs for the user it names: 'a' for an
 * admin, 'o' for an oper (plan R1, U13); 0 when it names nobody (the handler
 * answers that).  The first field of the payload is the user's name. */
static char user_target_flag(hub_state_t *state, const char *payload) {
  char name[64];
  if (!payload || sscanf(payload, "%63[^|]", name) != 1) return 0;
  hub_user_record_t *t = user_by_name(state, name);
  return !t ? 0 : t->type == 'a' ? 'a' : 'o';
}

/* The admin flag an admin opcode needs (plan §2), or 0 for a view any admin
 * may run.  Mutating forms of the dual commands follow mf_payload_mutates. */
static char admin_flag_needed(hub_state_t *state, const hub_user_record_t *me, int cmd,
                              const char *payload) {
  switch (cmd) {
  case CMD_ADMIN_CREATE_BOT:      case CMD_ADMIN_DEL:
  case CMD_ADMIN_DISCONNECT_BOT:  case CMD_ADMIN_REKEY_BOT:
  case CMD_ADMIN_BOT_RESYNC:      case CMD_ADMIN_BOT_MOVE:
    return 'b';
  case CMD_ADMIN_NET_SET:
    if (payload && strncmp(payload, "hubcron|", 8) == 0) return 'h';
    return mf_payload_mutates(cmd, payload) ? 'b' : 0;
  case CMD_ADMIN_ADD_PEER:        case CMD_ADMIN_DEL_PEER:
  case CMD_ADMIN_SET_PEER_PUBKEY: case CMD_ADMIN_SYNC_MESH:
  case CMD_ADMIN_SET_PUBKEY:      case CMD_ADMIN_REGEN_KEYS:
  case CMD_ADMIN_SET_HUB_NAME:    case CMD_ADMIN_SET_BIND_IP:
  case CMD_ADMIN_SET_BIND_PORT:   case CMD_ADMIN_SET_LOG_SIZE:
  case CMD_ADMIN_SET_LOG_LEVEL:   case CMD_ADMIN_PURGE_TOMBSTONES:
  case CMD_ADMIN_SET_PURGE_DAYS:
  case CMD_ADMIN_ADD_ALLOWLIST:   case CMD_ADMIN_DEL_ALLOWLIST:
  case CMD_ADMIN_ADD_DENYLIST:    case CMD_ADMIN_DEL_DENYLIST:
    return 'h';
  case CMD_ADMIN_SET_SSH:
    /* "" and "conn" show the tables; a name and a value change one */
    return payload && payload[0] && mf_field_count(payload) > 1 ? 'h' : 0;
  case CMD_ADMIN_SET_OPT_FLAGS:
    return 'a';                    /* R5: opt h / F decide the security model */
  case CMD_ADMIN_ADD_CHANNEL:     case CMD_ADMIN_DEL_CHANNEL:
  case CMD_ADMIN_OP_USER:         case CMD_ADMIN_INVITE_USER:
  case CMD_ADMIN_KICK_USER:
    return 'c';
  case CMD_ADMIN_CHAN_MODE:       case CMD_ADMIN_CHAN_SET:
  case CMD_ADMIN_BAN:
    return mf_payload_mutates(cmd, payload) ? 'c' : 0;
  case CMD_ADMIN_POOL:
    return mf_payload_mutates(cmd, payload) ? 's' : 0;
  case CMD_ADMIN_UPGRADE_NET:
    return 'u';
  case CMD_ADMIN_UPGRADE_STATUS:
    return payload && (strcmp(payload, "abort") == 0 || strcmp(payload, "forget") == 0 ||
                       strcmp(payload, "continue") == 0 ||
                       strncmp(payload, "keep|", 5) == 0)
               ? 'u' : 0;
  case CMD_ADMIN_ADD_ADMIN:
    return 'a';
  case CMD_ADMIN_ADD_OPER_RECORD:
    return 'o';
  case CMD_ADMIN_USER_ACCESS:
    /* flags|… changes an admin, chan|… an oper */
    return payload && strncmp(payload, "flags|", 6) == 0 ? 'a' : 'o';
  case CMD_ADMIN_DEL_ADMIN:       case CMD_ADMIN_DEL_OPER_RECORD:  /* either role */
  case CMD_ADMIN_ADD_USERMASK:    case CMD_ADMIN_DEL_USERMASK:
    return user_target_flag(state, payload);
  case CMD_ADMIN_SET_USERKEY: {
    /* your own key: any admin */
    char name[64];
    if (me && payload && sscanf(payload, "%63[^|]", name) == 1 &&
        strcasecmp(name, me->name) == 0)
      return 0;
    return user_target_flag(state, payload);
  }
  default:
    return 0;
  }
}

/* Plan R2: whether uuid is the last live admin holding +a. */
static bool last_full_admin(hub_state_t *state, const char *uuid) {
  if (!strchr(hub_user_flags(state, uuid), 'a')) return false;
  for (int i = 0; i < state->user_record_count; i++) {
    const hub_user_record_t *u = &state->user_records[i];
    if (u->is_active && u->type == 'a' && strcmp(u->uuid, uuid) != 0 &&
        strchr(hub_user_flags(state, u->uuid), 'a'))
      return false;
  }
  return true;
}

/* CMD_ADMIN_USER_ACCESS (user_flags plan §4.1):
 *   flags|<name>|<spec>          an admin's flags (+c-u edits, chu / +a replaces)
 *   chan|add|<name>|<#chan|*>    an oper's channels (U10: * and channels exclude
 *   chan|del|<name>|<#chan|*>    each other; del * removes every binding)
 * Answers user.flags | name | old | flags | peers | bots
 *      or user.chan | name | action | chan | chans | peers | bots. */
static bool admin_user_access(hub_state_t *state, hub_client_t *client, const char *payload) {
  char kind[8] = "", f1[64] = "", f2[64] = "", f3[MAX_CHAN] = "";
  int nf = payload && payload[0] ? mf_field_count(payload) : 0;
  if (nf < 3 || !wire_field(payload, 0, kind, sizeof(kind)) ||
      !wire_field(payload, 1, f1, sizeof(f1)) || !wire_field(payload, 2, f2, sizeof(f2)) ||
      (nf > 3 && !wire_field(payload, 3, f3, sizeof(f3))))
    return admin_err(state, client, "user.usage", "say which user and what to change",
                     "user set <name> flags <+x-y> | user chan add|del <name> <#chan|*>");
  bool flags_cmd = strcmp(kind, "flags") == 0 && nf == 3;
  bool chan_cmd = strcmp(kind, "chan") == 0 && nf == 4 &&
                  (strcmp(f1, "add") == 0 || strcmp(f1, "del") == 0);
  if (!flags_cmd && !chan_cmd)
    return admin_err(state, client, "user.usage", "say which user and what to change",
                     "user set <name> flags <+x-y> | user chan add|del <name> <#chan|*>");
  const char *name = flags_cmd ? f1 : f2;
  char msg[160];
  hub_user_record_t *t = user_by_name(state, name);
  if (!t) {
    snprintf(msg, sizeof(msg), "no user called \"%.63s\"", name);
    return admin_err(state, client, "user.not_found", msg, "user list");
  }
  char sync[MAX_BUFFER] = "";
  reply_t r;
  if (flags_cmd) {
    if (t->type != 'a')
      return admin_err(state, client, "user.not_admin",
                       "flags are for admins; an oper has channels", "user chan add|del");
    char old[USER_FLAGS_MAX + 1], nw[USER_FLAGS_MAX + 1];
    snprintf(old, sizeof(old), "%s", hub_user_flags(state, t->uuid));
    if (!hub_uflags_edit(old, f2, nw, sizeof(nw)) || !nw[0])
      return admin_err(state, client, "user.bad_flags",
                       "flags are +a (full admin) or letters from bchou; +x-y changes some",
                       "+a, +chu, +b-u · help user set lists the flags");
    if (!strchr(nw, 'a') && last_full_admin(state, t->uuid))
      return admin_err(state, client, "user.last_admin",
                       "that is the last full admin (+a); the network needs one",
                       "make another admin +a first");
    bool written = strcmp(old, nw) != 0;
    if (written) {
      if (!hub_uflag_put(state, t->uuid, nw, hub_access_next_ts(state, t->uuid)))
        return admin_err(state, client, "user.full", "the flag table is full",
                         "hub purge removes old tombstones");
      int so = 0;
      hub_access_append(state, sync, (int)sizeof(sync), &so, access_same_user, t->uuid);
    }
    reply_init(&r);
    reply_ok(&r, "user.flags");
    reply_kv(&r, "name", t->name);
    reply_kv(&r, "old", old);
    reply_kv(&r, "flags", nw);
    reply_kvb(&r, "written", written);
  } else {
    if (t->type != 'o')
      return admin_err(state, client, "user.not_oper",
                       "channels are for opers; an admin has flags", "user set <name> flags");
    bool add = strcmp(f1, "add") == 0;
    if (!hub_uchan_name_ok(f3))
      return admin_err(state, client, "user.bad_chans",
                       "a channel is #name, or * for every channel", NULL);
    hub_uchan_record_t *cur = hub_uchan_find(state, t->uuid, f3);
    bool live = cur && cur->is_active;
    bool any_live = hub_user_chan_count(state, t->uuid, NULL) > 0;
    bool missing = strcmp(f3, "*") == 0 ? !any_live : !live;
    /* A binding to a channel nobody manages would be an orphan from the
     * start: the purge removes those (as channel mode / set / ban refuse). */
    if (add && strcmp(f3, "*") != 0 && !hub_chan_live(state, f3, NULL, 0))
      return mf_status_err(state, client, HUB_MODES_NOT_MANAGED, f3);
    if (!add && missing) {
      snprintf(msg, sizeof(msg), "%.63s has no %s", t->name,
               strcmp(f3, "*") == 0 ? "channels" : f3);
      return admin_err(state, client, "user.chan_not_found", msg, "user show <name>");
    }
    bool written = !(add && live && (strcmp(f3, "*") == 0 ||
                                     !hub_user_chan_ok(state, t->uuid, NULL)));
    if (written && hub_access_chan_change(state, t->uuid, add, f3, sync, sizeof(sync)) < 0)
      return admin_err(state, client, "user.full", "the channel binding table is full",
                       "hub purge removes old tombstones");
    char cl[512];
    hub_user_chans(state, t->uuid, cl, sizeof(cl));
    reply_init(&r);
    reply_ok(&r, "user.chan");
    reply_kv(&r, "name", t->name);
    reply_kv(&r, "action", f1);
    reply_kv(&r, "chan", f3);
    reply_kv(&r, "chans", cl);
    reply_kvb(&r, "written", written);
  }
  if (sync[0]) {
    state->config_dirty = true;
    hub_broadcast_config_to_bots(state, sync);
    hub_broadcast_sync_to_peers(state, sync, -1);
  }
  reply_kvi(&r, "peers", linked_peer_count(state));
  reply_kvi(&r, "bots", local_bot_count(state));
  return send_reply(state, client, &r);
}

static const char *admin_flag_word(char f) {
  switch (f) {
  case 'a': return "full admin";
  case 'b': return "bots";
  case 'c': return "channels";
  case 'h': return "hub";
  case 'o': return "opers";
  case 's': return "servers";
  case 'u': return "upgrades";
  default:  return "?";
  }
}

/* One "timer" record of CMD_ADMIN_STATS: seconds until the next run of a
 * job that runs every `every` s and last ran at `last` (-1 = off). */
static void stats_timer(reply_t *r, const char *name, long long every, time_t last, time_t now) {
  reply_rec(r, "timer");
  reply_kv(r, "name", name);
  reply_kvi(r, "every", every);
  if (last < 0) {
    reply_kv(r, "in", "off");
    return;
  }
  long long in = last > 0 ? every - (long long)(now - last) : every;
  reply_kvi(r, "in", in < 0 ? 0 : in);
}

/* The same for a job that keeps the time of its next run (`due`, 0 = now). */
static void stats_timer_due(reply_t *r, const char *name, long long every, time_t due, time_t now) {
  reply_rec(r, "timer");
  reply_kv(r, "name", name);
  reply_kvi(r, "every", every);
  long long in = due > now ? (long long)(due - now) : 0;
  reply_kvi(r, "in", in > every ? every : in);
}

/* upgrade start.  `roll_called`: the hubs have just answered a roll call, so
 * the gate is passed. */
static bool admin_upgrade_start(hub_state_t *state, hub_client_t *client, const char *payload,
                                bool roll_called) {
  /* Payload: target_ver|variant|kind|min_from|base|hub_ver|hub_base|sel —
   * everything past the version is optional ("" = let each node decide).
   * target_ver is the bots' (ircbot-releases); hub_ver is the hubs' own
   * (irchub-releases), and an empty hub_ver leaves every hub where it is.
   * The two base slots are no longer read: every node fetches from its own
   * compiled-in root, the only tree its pinned key verifies.  Only the
   * last field is a tail: the selection ("" = whole network),
   * comma-separated name-or-uuid[=c|rs] tokens. */
  char ver[64] = "", variant[8] = "", kind[8] = "", min_from[64] = "";
  char hub_ver[64] = "";
  char sel[MAX_UPGRADE_SELECT * 80] = "";
  {
    wire_field(payload, 0, ver, sizeof(ver));
    wire_field(payload, 1, variant, sizeof(variant));
    wire_field(payload, 2, kind, sizeof(kind));
    wire_field(payload, 3, min_from, sizeof(min_from));
    wire_field(payload, 5, hub_ver, sizeof(hub_ver));
    wire_tail(payload, 7, sel, sizeof(sel));
  }
  char why[640];
  /* One upgrade at a time, mesh-wide: every hub holds the copy of the one in flight,
   * between its steps and on hold too, when no freeze says so. */
  if (state->splan.active && strcmp(state->splan.driver, state->hub_uuid) != 0) {
    snprintf(why, sizeof(why), "an upgrade to %s driven by %s is in progress", state->splan.bot_target,
             hub_who(state, 'h', state->splan.driver));
    return admin_err(state, client, "upg.busy", why, "upgrade status; upgrade abort stops it");
  }
  /* An upgrade starts with every hub present.  One that drops later is the plan's
   * business: every hub already holds it.  The hubs are asked (a roll call); the
   * console is answered once they have, or ROLLCALL_WAIT ran out. */
  if (!state->upgrade.active && !state->plan.active && !roll_called) {
    if (state->upg_start_wait.active)
      return admin_err(state, client, "upg.busy", "another upgrade start is asking the hubs",
                       "start again in a few seconds");
    if (strlen(payload) < sizeof(state->upg_start_wait.payload) &&
        rollcall_begin(state, RC_FOR_START, state->upg_start_wait.rc) == 1) {
      state->upg_start_wait.active = true;
      state->upg_start_wait.admin_fd = client->fd;
      state->upg_start_wait.admin_serial = client->conn_serial;
      snprintf(state->upg_start_wait.payload, sizeof(state->upg_start_wait.payload), "%s",
               payload);
      return true;
    }
    /* No roll call possible (a peer that never linked, a full table): the
     * gossip decides. */
    char gone[320];
    int missing = upgrade_hubs_missing(state, gone, sizeof(gone));
    if (missing > 0) {
      snprintf(why, sizeof(why), "%d hub%s not linked: %s", missing, missing == 1 ? "" : "s",
               gone);
      return admin_err(state, client, "upg.hubs_missing", why,
                       "bring it back, or remove it with hub del; then start again");
    }
  }
  if (!hub_upgrade_plan_begin(state, client, ver, variant, kind, min_from,
                              hub_ver, sel, why, sizeof(why)))
    return admin_err(state, client, "upg.refused",
                     strncmp(why, "ERROR: ", 7) == 0 ? why + 7 : why,
                     "upgrade status · upgrade releases");
  const pending_upgrade_t *u = &state->upgrade;
  int bots = 0, hubs = 0;
  for (int i = 0; i < u->node_count; i++) {
    if (u->nodes[i].kind == 'b') bots++;
    else if (u->nodes[i].kind == 'h') hubs++;
  }
  reply_t r;
  reply_init(&r);
  reply_ok(&r, "upg.started");
  reply_kv(&r, "id", u->id);
  reply_kv(&r, "bot_ver", u->target_ver);
  if (u->hub_ver[0]) reply_kv(&r, "hub_ver", u->hub_ver);
  reply_kvi(&r, "selected", u->select_count);
  reply_kvi(&r, "bots", bots);
  reply_kvi(&r, "peers", hubs);
  const upgrade_plan_t *pl = &state->plan;
  if (pl->active && strcmp(pl->run_id, u->id) == 0) {
    reply_kvi(&r, "step", pl->step + 1);
    reply_kvi(&r, "steps", plan_steps(pl));
    reply_kv(&r, "bot_final", pl->bot_target);
    if (pl->hub_target[0]) reply_kv(&r, "hub_final", pl->hub_target);
  }
  return send_reply(state, client, &r);
}

static bool handle_admin_command(hub_state_t *state, hub_client_t *client,
                                 int cmd, char *payload, int payload_len) {
  char msg[512];

  /* Admin flags (plan R4): checked here for every opcode, whatever the
   * console already checked.  An admin whose record is gone runs views only. */
  {
    hub_user_record_t *me = admin_of_client(state, client);
    char need = admin_flag_needed(state, me, cmd, payload);
    if (need && (!me || !hub_user_has_flag(state, me->uuid, need))) {
      hub_log_warning("[ADMIN] %s refused 0x%02x: needs +%c\n", hub_who_client(state, client),
                      (unsigned)cmd, need);
      snprintf(msg, sizeof(msg), "this needs +%c (%s)", need, admin_flag_word(need));
      return admin_err(state, client, "user.no_flag", msg,
                       need == 'a' ? "ask a full admin (+a)" : "ask a full admin (+a) for the flag");
    }
  }

  /* Task 6: an upgrade run holds the config still.  One gate here covers
   * every mutator rather than a check inside each; queries and the opt-flag
   * command itself stay available (the latter is how a stuck freeze is
   * lifted by hand). */
  if (hub_config_frozen(state) && hub_admin_cmd_mutates_config(cmd) &&
      mf_payload_mutates(cmd, payload)) {
    hub_log_warning("[UPGRADE] Refused admin command 0x%02x: config frozen\n", (unsigned)cmd);
    return admin_err(state, client, "config.frozen",
                     "the config is frozen while an upgrade runs",
                     "upgrade status; a stale freeze is lifted with option set");
  }

  switch (cmd) {

  case CMD_ADMIN_UPGRADE_NET:
    return admin_upgrade_start(state, client, payload ? payload : "", false);

  case CMD_ADMIN_UPGRADE_STATUS: {
    /* "releases[|bot_ver|hub_ver|sel]": what the admin console offers to
     * pick from — the verified release manifests of both products and the
     * nodes a selective run could name — plus, when targets are given, the
     * path an `upgrade start` would take to them.  Read-only; allowed during
     * a run. */
    if (payload && strncasecmp(payload, "releases", 8) == 0 &&
        (payload[8] == '\0' || payload[8] == '|')) {
      reply_t r;
      reply_init(&r);
      hub_upgrade_releases(state, payload, &r);
      return send_reply(state, client, &r);
    }
    /* "history": the runs kept; "history|<id or prefix>": one with its nodes. */
    if (payload && strcmp(payload, "history") == 0) {
      reply_t r;
      reply_init(&r);
      reply_ok(&r, "upg.history");
      reply_kvi(&r, "keep", hub_uhist_keep(state));
      hub_uhist_reply_runs(state, &r);
      return send_reply(state, client, &r);
    }
    if (payload && strncmp(payload, "history|", 8) == 0) {
      reply_t r;
      reply_init(&r);
      int rc = hub_uhist_reply_one(state, payload + 8, &r);
      if (rc == 0) return send_reply(state, client, &r);
      reply_free(&r);
      return admin_err(state, client, rc == -2 ? "upg.run.ambiguous" : "upg.run.unknown",
                       rc == -2 ? "more than one run starts with that" : "no such run kept",
                       "upgrade history");
    }
    /* "keep|<n>": how many runs every hub keeps (hs|upgradehistory). */
    if (payload && strncmp(payload, "keep|", 5) == 0) {
      unsigned long n;
      if (!hub_parse_uint(payload + 5, MAX_UPGRADE_HISTORY, &n) || n < 1)
        return admin_err(state, client, "upg.bad_keep", "keep takes a number from 1 to 20",
                         "upgrade keep <n>");
      int old = hub_uhist_keep(state);
      hub_gsetting_set(state, "upgradehistory", (int)n);
      char line[HS_LINE_MAX];
      if (hub_gsetting_format(state, "upgradehistory", line, sizeof(line)) > 0)
        hub_broadcast_sync_to_peers(state, line, -1);
      reply_t r;
      reply_init(&r);
      reply_ok(&r, "upg.keep");
      reply_kvi(&r, "old", old);
      reply_kvi(&r, "new", (long long)n);
      reply_kvi(&r, "peers", linked_peer_count(state));
      return send_reply(state, client, &r);
    }
    /* A payload of "abort" stops a run in flight and rolls the mesh back,
     * and stops a multi-step upgrade for good — here, and (flooded) on the
     * hub driving it if that is another one. */
    /* A plan on hold, wherever its driver is. */
    if (payload && strcasecmp(payload, "continue") == 0) {
      const upgrade_plan_t *known = state->plan.active ? &state->plan : &state->splan;
      if (!known->active || known->single || !known->hold[0])
        return admin_err(state, client, "upg.not_held", "no upgrade is on hold", "upgrade status");
      long long id = (long long)known->started;
      char frame[96];
      snprintf(frame, sizeof(frame), "C|%lld|%lld", id, (long long)time(NULL));
      char key[96];
      snprintf(key, sizeof(key), "pc:%lld:%lld", id, (long long)time(NULL));
      op_forward_seen_check_and_add(state, key);
      if (state->plan.active) plan_continue(state, true);
      plan_send_all(state, frame, NULL);
      reply_t r;
      reply_init(&r);
      reply_ok(&r, "upg.continued");
      return send_reply(state, client, &r);
    }
    if (payload && strcasecmp(payload, "abort") == 0) {
      bool run = state->upgrade.active, plan = state->plan.active;
      int moved = 0;
      for (int i = 0; run && i < state->upgrade.node_count; i++)
        if (state->upgrade.nodes[i].state == UPG_NODE_DONE ||
            state->upgrade.nodes[i].state == UPG_NODE_COMMITTED)
          moved++;
      char id[64];
      snprintf(id, sizeof(id), "%s", run ? state->upgrade.id : "");
      int step = state->plan.step + 1, steps = plan_steps(&state->plan);
      if (run) hub_upgrade_abort(state, "aborted by admin");
      if (state->plan.active) {
        char why[96];
        snprintf(why, sizeof(why), "aborted by admin before step %d/%d", step,
                 steps);
        plan_stop(state, why);
      }
      int told = upgrade_cancel_flood(state);
      hub_plan_cancelled(state, time(NULL));
      reply_t r;
      reply_init(&r);
      if (!run && !plan) {
        /* Nothing here; whatever runs elsewhere has been told to stop. */
        reply_ok(&r, "upg.abort_sent");
        reply_kvi(&r, "peers", told);
        return send_reply(state, client, &r);
      }
      reply_ok(&r, "upg.aborted");
      if (id[0]) reply_kv(&r, "id", id);
      reply_kvi(&r, "rolled_back", moved);
      if (plan) {
        reply_kvi(&r, "step", step);
        reply_kvi(&r, "steps", steps);
      }
      reply_kvi(&r, "peers", told);
      return send_reply(state, client, &r);
    }
    /* "forget" drops the roll-up plan a finished run left behind, here and
     * (flooded) on every other hub. */
    if (payload && strcasecmp(payload, "forget") == 0) {
      if (state->upgrade.active || hub_config_frozen(state))
        return admin_err(state, client, "upg.running",
                         "an upgrade is running: the plan is kept until it ends",
                         "upgrade abort");
      bool had = state->rollup.have_plan;
      char had_bot[64] = "", had_hub[64] = "";
      if (had) {
        snprintf(had_bot, sizeof(had_bot), "%s", state->rollup.target);
        snprintf(had_hub, sizeof(had_hub), "%s", state->rollup.hub_target);
      }
      hub_rollup_forget(state, "forgotten by admin");
      char id[64], fwd[96];
      generate_request_id(id, sizeof(id));
      op_forward_seen_check_and_add(state, id);
      snprintf(fwd, sizeof(fwd), "%s|%lld", id, (long long)time(NULL));
      int told = 0;
      for (int i = 0; i < state->client_count; i++) {
        hub_client_t *c = state->clients[i];
        if (c->type == CLIENT_HUB && c->authenticated &&
            peer_send_urgent(state, c, CMD_UPGRADE_FORGET, fwd))
          told++;
      }
      reply_t r;
      reply_init(&r);
      reply_ok(&r, "upg.forgotten");
      reply_kvb(&r, "had", had);
      if (had_bot[0]) reply_kv(&r, "bot_ver", had_bot);
      if (had_hub[0]) reply_kv(&r, "hub_ver", had_hub);
      reply_kvi(&r, "peers", told);
      return send_reply(state, client, &r);
    }
    if (payload && payload[0])
      return admin_err(state, client, "upg.usage", "unknown upgrade request",
                       "upgrade status · releases · history · keep · abort · forget");
    reply_t r;
    reply_init(&r);
    hub_upgrade_status(state, &r);
    return send_reply(state, client, &r);
  }

  case CMD_ADMIN_LIST_SUMMARY: {
    reply_t r;
    reply_init(&r);
    int total = 0;
    for (int i = 0; i < state->bot_count; i++)
      if (state->bots[i].is_active) total++;
    reply_ok(&r, "bot.summary");
    reply_kvi(&r, "total", total);
    for (int i = 0; i < state->bot_count; i++) {
      const bot_config_t *b = &state->bots[i];
      if (!b->is_active) continue;
      const config_entry_t *n = bot_entry_rec(b, "n");
      reply_rec(&r, "bot");
      reply_kv(&r, "uuid", b->uuid);
      if (n && n->value[0]) reply_kv(&r, "nick", n->value);
    }
    return send_reply(state, client, &r);
  }

  case CMD_ADMIN_LIST_REVOKED: {
    /* bot revoked: every deleted bot that is wiped if it ever connects. */
    reply_t r;
    reply_init(&r);
    reply_ok(&r, "bot.revoked");
    reply_kvi(&r, "count", state->revoked_count);
    reply_kvi(&r, "max", MAX_REVOKED);
    for (int i = 0; i < state->revoked_count; i++) {
      const hub_revoked_t *rv = &state->revoked[i];
      reply_rec(&r, "revoked");
      reply_kv(&r, "uuid", rv->uuid);
      if (rv->nick[0]) reply_kv(&r, "nick", rv->nick);
      reply_kvi(&r, "deleted", (long long)rv->del_ts);
      reply_kvi(&r, "wiped", (long long)rv->wiped_ts);
    }
    return send_reply(state, client, &r);
  }

  case CMD_ADMIN_REKEY_BOT: {
    /* v3: per-bot independent keys.  Only the bot can rekey — it owns its
     * private key.  The bot's 'rekey' admin command regenerates the keypair
     * locally and pushes the new PUBLIC key to us over its authenticated
     * session (we store it as the bot's 'pub' entry and fan it out to peers
     * via auto-sync).  We deliberately do NOT disconnect the bot here: it
     * needs that active session to push the new pub, and it reconnects
     * itself with the new key as the final step of 'rekey'.  The console
     * prints the steps; the record says only which bot and its state. */
    if (!payload || !payload[0])
      return admin_err(state, client, "bot.usage", "say which bot", "bot rekey <uuid>");
    bot_config_t *b = bot_by_uuid(state, payload);
    if (b && !b->is_active) b = NULL;
    bool online = bot_online(state, payload);
    if (!b && !online)
      return admin_err(state, client, "bot.not_found", "no registered bot has that uuid",
                       "bot list");
    reply_t r;
    reply_init(&r);
    reply_ok(&r, "bot.rekey_howto");
    reply_kv(&r, "uuid", payload);
    const config_entry_t *n = b ? bot_entry_rec(b, "n") : NULL;
    if (n && n->value[0]) reply_kv(&r, "nick", n->value);
    reply_kvb(&r, "online", online);
    reply_kvb(&r, "local", local_bot_client(state, payload) != NULL);
    const config_entry_t *pub = b ? bot_entry_rec(b, "pub") : NULL;
    if (pub && pub->value[0]) {
      char fp[KEY_FP_LEN + 1];
      hub_crypto_key_fingerprint_b64(pub->value, fp);
      reply_kv(&r, "fp", fp);
    }
    return send_reply(state, client, &r);
  }

  case CMD_ADMIN_BOT_MOVE:
    return admin_bot_move(state, client, payload);

  case CMD_ADMIN_DISCONNECT_BOT: {
    if (!payload || !payload[0])
      return admin_err(state, client, "bot.usage", "say which bot", "bot kick <uuid>");
    char nick[MAX_NICK] = "";
    bot_nick_from_config(state, payload, nick, sizeof(nick));
    hub_client_t *c = local_bot_client(state, payload);
    if (!c) {
      const bot_roster_t *e = roster_best(state, payload);
      snprintf(msg, sizeof(msg), "%.64s is not connected to this hub",
               nick[0] ? nick : payload);
      if (e) {
        char hint[160];
        snprintf(hint, sizeof(hint), "it is on %.64s: kick it there", e->hub_name);
        reply_t r;
        reply_init(&r);
        reply_err(&r, "bot.not_local", msg, hint);
        reply_kv(&r, "hub_name", e->hub_name);
        return send_reply(state, client, &r);
      }
      return admin_err(state, client, "bot.not_local", msg, "bot list");
    }
    time_t since = c->connected_at;
    char ip[64];
    snprintf(ip, sizeof(ip), "%s", c->ip);
    hub_log_warning("[ADMIN] Disconnecting bot %s\n", payload);
    hub_disconnect_client(state, c);
    reply_t r;
    reply_init(&r);
    reply_ok(&r, "bot.kicked");
    reply_kv(&r, "uuid", payload);
    if (nick[0]) reply_kv(&r, "nick", nick);
    reply_kvi(&r, "since", (long long)since);
    reply_kv(&r, "ip", ip);
    return send_reply(state, client, &r);
  }

  case CMD_ADMIN_BOT_RESYNC: {
    /* bot resync <nick|uuid|all>: a full config push, here and on every hub. */
    if (!payload || !payload[0])
      return admin_err(state, client, "bot.usage", "say which bot", "bot resync <nick|uuid|all>");
    const char *target = "*";
    char nick[MAX_NICK] = "";
    bool all = strcasecmp(payload, "all") == 0;
    if (!all) {
      bot_config_t *hit = bot_by_uuid(state, payload);
      if (hit && !hit->is_active) hit = NULL;
      int matches = hit ? 1 : 0;
      if (!hit)
        for (int i = 0; i < state->bot_count; i++) {
          const config_entry_t *n = bot_entry_rec(&state->bots[i], "n");
          if (state->bots[i].is_active && n && strcasecmp(n->value, payload) == 0) {
            if (!hit) hit = &state->bots[i];
            matches++;
          }
        }
      if (!hit)
        return admin_err(state, client, "bot.not_found", "no registered bot has that nick or uuid",
                         "bot list");
      if (matches > 1)
        return admin_err(state, client, "bot.ambiguous", "more than one bot has that nick",
                         "bot resync <uuid>");
      target = hit->uuid;
      bot_nick_from_config(state, hit->uuid, nick, sizeof(nick));
    }
    int here = cfg_resync_local(state, target);
    char id[64], fwd[160];
    generate_request_id(id, sizeof(id));
    op_forward_seen_check_and_add(state, id);
    snprintf(fwd, sizeof(fwd), "%s|%lld|%s", id, (long long)time(NULL), target);
    /* A bot connected here needs no other hub; all, or one elsewhere, floods. */
    int told = (all || here == 0) ? cfg_resync_flood(state, NULL, fwd) : 0;
    hub_log_info("[ADMIN] Resync %s: full config queued to %d bot(s) here, %d hub(s) asked\n",
                 all ? "all bots" : target, here, told);
    reply_t r;
    reply_init(&r);
    reply_ok(&r, "bot.resync");
    reply_kv(&r, "uuid", all ? "all" : target);
    if (nick[0]) reply_kv(&r, "nick", nick);
    reply_kvi(&r, "here", here);
    reply_kvi(&r, "hubs", told);
    return send_reply(state, client, &r);
  }

  case CMD_ADMIN_DEL: {
    if (!payload || !payload[0])
      return admin_err(state, client, "bot.usage", "say which bot", "bot del <uuid>");
    char nick[MAX_NICK] = "";
    bot_nick_from_config(state, payload, nick, sizeof(nick));
    time_t del_ts = 0;
    if (!hub_storage_delete(state, payload, &del_ts))
      return admin_err(state, client, "bot.not_found", "no registered bot has that uuid",
                       "bot list");
    /* The tombstone put it on the revoke list (hub_storage_update_entry).
     * Connected here: told to wipe its config and exit; a hub that holds it
     * does the same when this delete reaches it. */
    bool was_online = hub_retire_revoked_bots(state) > 0;
    /* Peers store the same tombstone (same stamp); every bot gets a config
     * that no longer lists the deleted bot and ends in the T| marker, so
     * it drops the bot from its trusted list (no more ~B2 or op grants). */
    char sync[256 + RV_LINE_MAX];
    int sl = snprintf(sync, sizeof(sync), "b|%s|d|1|%lld\n", payload, (long long)del_ts);
    const hub_revoked_t *rv = hub_revoke_find(state, payload);
    if (rv && sl > 0 && sl < (int)sizeof(sync))
      hub_revoke_format(rv, sync + sl, sizeof(sync) - (size_t)sl);
    hub_broadcast_sync_to_peers(state, sync, -1);
    hub_broadcast_config_to_bots(state, sync);
    reply_t r;
    reply_init(&r);
    reply_ok(&r, "bot.deleted");
    reply_kv(&r, "uuid", payload);
    if (nick[0]) reply_kv(&r, "nick", nick);
    reply_kvb(&r, "was_online", was_online);
    reply_kvi(&r, "peers", linked_peer_count(state));
    reply_kvi(&r, "bots", local_bot_count(state));
    return send_reply(state, client, &r);
  }

  case CMD_ADMIN_LIST_FULL: {
    /* "" = every bot; a uuid or a nick = that one bot (bot show). */
    reply_t r;
    reply_init(&r);
    if (!payload || !payload[0]) {
      int total = 0, online = 0;
      for (int i = 0; i < state->bot_count; i++) {
        if (!state->bots[i].is_active) continue;
        total++;
        if (bot_online(state, state->bots[i].uuid)) online++;
      }
      reply_ok(&r, "bot.list");
      reply_kvi(&r, "total", total);
      reply_kvi(&r, "online", online);
      for (int i = 0; i < state->bot_count; i++)
        if (state->bots[i].is_active) reply_bot(state, &r, &state->bots[i]);
      return send_reply(state, client, &r);
    }
    bot_config_t *hit = bot_by_uuid(state, payload);
    if (hit && !hit->is_active) hit = NULL;
    int matches = hit ? 1 : 0;
    if (!hit) {
      for (int i = 0; i < state->bot_count; i++) {
        const config_entry_t *n = bot_entry_rec(&state->bots[i], "n");
        if (state->bots[i].is_active && n && strcasecmp(n->value, payload) == 0) {
          if (!hit) hit = &state->bots[i];
          matches++;
        }
      }
    }
    if (!hit) {
      snprintf(msg, sizeof(msg), "no registered bot is called or has the uuid \"%.64s\"",
               payload);
      return admin_err(state, client, "bot.not_found", msg, "bot list");
    }
    if (matches > 1) {
      snprintf(msg, sizeof(msg), "%d bots are called \"%.64s\"", matches, payload);
      reply_err(&r, "bot.ambiguous", msg, "bot show <uuid>");
      for (int i = 0; i < state->bot_count; i++) {
        const config_entry_t *n = bot_entry_rec(&state->bots[i], "n");
        if (!state->bots[i].is_active || !n || strcasecmp(n->value, payload) != 0)
          continue;
        reply_rec(&r, "bot");
        reply_kv(&r, "uuid", state->bots[i].uuid);
        reply_kv(&r, "nick", n->value);
        reply_kvb(&r, "online", bot_online(state, state->bots[i].uuid));
      }
      return send_reply(state, client, &r);
    }
    reply_ok(&r, "bot.show");
    reply_bot(state, &r, hit);
    /* the last upgrade run this hub drove, when it moved this bot */
    const pending_upgrade_t *u = &state->upgrade;
    for (int i = 0; u->id[0] && i < u->node_count; i++) {
      const upgrade_node_t *n = &u->nodes[i];
      if (n->kind != 'b' || strcmp(n->uuid, hit->uuid) != 0 || n->not_selected)
        continue;
      reply_rec(&r, "upg");
      reply_kv(&r, "id", u->id);
      reply_kv(&r, "state", upgrade_node_state_name(n->state));
      if (n->cur_version[0]) reply_kv(&r, "from", n->cur_version);
      reply_kv(&r, "to", u->target_ver);
      reply_kvi(&r, "started", (long long)u->started);
      break;
    }
    return send_reply(state, client, &r);
  }

  case CMD_ADMIN_SYNC_MESH: {
    /* Change 5: heap the full-state buffer (MAX_SYNC_PAYLOAD > stack budget). */
    char *full_sync = malloc(MAX_SYNC_PAYLOAD);
    if (!full_sync)
      return admin_err(state, client, "internal.oom", "out of memory building the sync",
                       NULL);
    hub_generate_sync_packet(state, full_sync, MAX_SYNC_PAYLOAD);
    hub_broadcast_sync_to_peers(state, full_sync, -1);
    long long records = 0;
    for (const char *p = full_sync; *p; p++)
      if (*p == '\n') records++;
    long long bytes = (long long)strlen(full_sync);
    free(full_sync);
    reply_t r;
    reply_init(&r);
    reply_ok(&r, "mesh.synced");
    reply_kvi(&r, "peers", linked_peer_count(state));
    reply_kvi(&r, "records", records);
    reply_kvi(&r, "bytes", bytes);
    for (int i = 0; i < state->peer_count; i++) {
      const hub_peer_config_t *p = &state->peers[i];
      reply_rec(&r, "peer");
      reply_kvi(&r, "n", i + 1);
      if (p->uuid[0]) reply_kv(&r, "uuid", p->uuid);
      if (p->friendly_name[0]) reply_kv(&r, "name", p->friendly_name);
      reply_kvb(&r, "sent", peer_client(state, p) != NULL);
    }
    return send_reply(state, client, &r);
  }

  case CMD_ADMIN_CREATE_BOT: {
    /* v3: bot-provided identity.  Payload: "NICK|UUID|PUBKEY_B64".
     * The hub no longer generates the bot keypair — the bot did, locally
     * during 'ircbot -setup'.  Only the public key reaches the hub. */
    char nick[64] = {0}, uuid_in[64] = {0}, pubkey_in[256] = {0};
    if (!payload || !*payload ||
        sscanf(payload, "%63[^|]|%63[^|]|%255s", nick, uuid_in, pubkey_in) < 3)
      return admin_err(state, client, "bot.usage",
                       "bot add needs a nick, a uuid and a key",
                       "bot add <nick> <uuid> <key>");
    if (!uuid_valid(uuid_in))
      return admin_err(state, client, "bot.bad_uuid", "that is not a valid uuid",
                       "8-4-4-4-12 hex digits");
    if (strlen(pubkey_in) != COMBINED_KEY_B64) {
      snprintf(msg, sizeof(msg), "the key must be %d base64 characters (got %zu)",
               COMBINED_KEY_B64, strlen(pubkey_in));
      return admin_err(state, client, "bot.bad_key", msg,
                       "the public key the bot's -setup printed");
    }
    {
      int dec_len = 0;
      unsigned char *dec = base64_decode(pubkey_in, &dec_len);
      bool ok = dec && dec_len == COMBINED_KEY_LEN;
      free(dec);
      if (!ok)
        return admin_err(state, client, "bot.bad_key",
                         "the key is not a valid 64-byte public key",
                         "the public key the bot's -setup printed");
    }
    if (hub_revoke_find(state, uuid_in))
      return admin_err(state, client, "bot.revoked",
                       "that uuid was deleted; run -setup on the bot's host for a new one",
                       "bot revoked");
    bot_config_t *old = bot_by_uuid(state, uuid_in);
    if (old) {
      if (!old->is_active)
        return admin_err(state, client, "bot.exists",
                         "that uuid belongs to a deleted bot",
                         "hub purge now removes its tombstone");
      const config_entry_t *n = bot_entry_rec(old, "n");
      snprintf(msg, sizeof(msg), "uuid already registered (%.63s)",
               n && n->value[0] ? n->value : "no nick");
      return admin_err(state, client, "bot.exists", msg, "bot list");
    }
    /* the table holds deleted bots' tombstones too: a full one used to answer
     * bot.added and store nothing (100-bot run, 2026-11-24) */
    if (state->bot_count >= MAX_BOTS) {
      snprintf(msg, sizeof(msg), "this network already holds %d bots, the most it can", MAX_BOTS);
      return admin_err(state, client, "bot.full", msg,
                       "bot del a bot first (hub purge now removes deleted bots' tombstones)");
    }
    hub_state_add_bot_memory(state, uuid_in, nick, pubkey_in);
    state->config_dirty = true;
    char fp[KEY_FP_LEN + 1];
    hub_crypto_key_fingerprint_b64(pubkey_in, fp);
    reply_t r;
    reply_init(&r);
    reply_ok(&r, "bot.added");
    reply_kv(&r, "uuid", uuid_in);
    reply_kv(&r, "nick", nick);
    reply_kv(&r, "fp", fp);
    return send_reply(state, client, &r);
  }

  case CMD_ADMIN_REGEN_KEYS: {
    /* Local-only hub rekey: generate a new Curve25519 keypair, save it
     * encrypted in .irchub.cnf, dump the new public key for re-distribution.
     * Independent per-hub keys: the new pubkey is NOT pushed to peers; each
     * peer hub must re-register it with 'peer set <uuid> key' in its console.
     * Bots that connect here must also re-learn it (+hub). */
    unsigned char priv64[64], pub64[64];
    if (!hub_crypto_generate_combined_keypair(priv64, pub64)) {
      secure_wipe(priv64, 64);
      hub_log_error("[AUDIT] Hub keypair regeneration by %s failed; the old "
                    "key stays\n", hub_who_client(state, client));
      return admin_err(state, client, "hub.keygen_failed",
                       "key generation failed; the old key stays", NULL);
    }
    char old_fp[KEY_FP_LEN + 1] = "", old_ssh[80] = "";
    if (state->hub_keys_loaded) {
      unsigned char old64[64];
      memcpy(old64, state->hub_ed25519_pub, 32);
      memcpy(old64 + 32, state->hub_x25519_pub, 32);
      hub_crypto_key_fingerprint(old64, old_fp);
      console_ssh_fingerprint(state->hub_ed25519_pub, old_ssh, sizeof(old_ssh));
    }
    char *pub_b64 = base64_encode(pub64, 64);
    if (!pub_b64) {
      secure_wipe(priv64, 64);
      return admin_err(state, client, "internal.encode", "base64 encoding failed", NULL);
    }
    hub_crypto_split_combined(priv64, state->hub_ed25519_priv, state->hub_x25519_priv);
    hub_crypto_split_combined(pub64, state->hub_ed25519_pub, state->hub_x25519_pub);
    secure_wipe(priv64, 64);
    state->hub_keys_loaded = true;
    state->config_dirty = true;
    char fp[KEY_FP_LEN + 1], ssh_fp[80];
    hub_crypto_key_fingerprint(pub64, fp);
    console_ssh_fingerprint(state->hub_ed25519_pub, ssh_fp, sizeof(ssh_fp));
    hub_log_warning("[AUDIT] Hub keypair regenerated by %s: new key %s; "
                    "peers and bots are disconnected and must re-learn it\n",
                    hub_who_client(state, client), fp);
    hub_console_hostkey_changed(state);  /* SSH host key follows, now */

    /* Disconnect peers + bots so they must reauthenticate (and rediscover
     * that this hub's pubkey changed). */
    int dropped_peers = 0, dropped_bots = 0;
    for (int i = 0; i < state->client_count; i++) {
      if (state->clients[i]->type == CLIENT_HUB ||
          state->clients[i]->type == CLIENT_BOT) {
        if (state->clients[i]->type == CLIENT_HUB) dropped_peers++;
        else dropped_bots++;
        hub_disconnect_client(state, state->clients[i]);
        i--;
      }
    }

    time_t now = time(NULL);
    struct tm *t = localtime(&now);
    char f[64] = "";
    if (t) strftime(f, sizeof(f), "%Y%m%d%H%M_pub.b64", t);
    bool written = false;
    if (f[0]) {
      FILE *fp_out = fopen(f, "w");
      if (fp_out) {
        written = fprintf(fp_out, "%s", pub_b64) > 0;
        fclose(fp_out);
      }
    }
    reply_t r;
    reply_init(&r);
    reply_ok(&r, "hub.rekeyed");
    reply_kv(&r, "name", hub_display_name(state));
    if (state->hub_uuid[0]) reply_kv(&r, "uuid", state->hub_uuid);
    reply_kvi(&r, "port", state->listen_port ? state->listen_port : state->port);
    reply_kv(&r, "key", pub_b64);
    if (old_fp[0]) reply_kv(&r, "old_fp", old_fp);
    reply_kv(&r, "fp", fp);
    if (old_ssh[0]) reply_kv(&r, "old_ssh_fp", old_ssh);
    reply_kv(&r, "ssh_fp", ssh_fp);
    if (written) reply_kv(&r, "file", f);
    reply_kvi(&r, "peers", dropped_peers);
    reply_kvi(&r, "bots", dropped_bots);
    free(pub_b64);
    return send_reply(state, client, &r);
  }

  case CMD_ADMIN_GET_PUBKEY:
    return admin_hub_show(state, client);

  case CMD_ADMIN_SET_PUBKEY: {
    if (!payload || !payload[0])
      return admin_err(state, client, "hub.usage", "say which key", "hub set pubkey <key>");
    unsigned char want[COMBINED_KEY_LEN];
    if (strlen(payload) != COMBINED_KEY_B64 || !hub_crypto_pubkey_b64_decode(payload, want))
      return admin_err(state, client, "hub.bad_key",
                       "the key must be 88 base64 characters of a 64-byte public key",
                       NULL);
    /* The public key is not a setting of its own: it is fixed by the private
     * key.  Storing any other key made every signature this hub produces
     * (admin logins, bot and peer handshakes) fail against what it announces
     * — an admin lockout.  Accept only the key the private key derives; a new
     * identity goes through hub rekey. */
    if (!state->hub_keys_loaded)
      return admin_err(state, client, "hub.no_key",
                       "no private key loaded; cannot verify the public key", NULL);
    unsigned char priv[64], derived[COMBINED_KEY_LEN];
    memcpy(priv, state->hub_ed25519_priv, 32);
    memcpy(priv + 32, state->hub_x25519_priv, 32);
    bool derived_ok = hub_crypto_combined_pub_from_priv(priv, derived);
    secure_wipe(priv, sizeof(priv));
    if (!derived_ok || CRYPTO_memcmp(derived, want, COMBINED_KEY_LEN) != 0)
      return admin_err(state, client, "hub.key_mismatch",
                       "that key does not belong to this hub's private key",
                       "to change the hub identity use hub rekey");
    hub_crypto_split_combined(derived, state->hub_ed25519_pub, state->hub_x25519_pub);
    state->config_dirty = true;
    char fp[KEY_FP_LEN + 1];
    hub_crypto_key_fingerprint(derived, fp);
    return hub_set_reply(state, client, "pubkey", NULL, fp, false, -1);
  }

  case CMD_ADMIN_ADD_PEER: {
    /* Parse: IP:PORT:UUID:NAME:PUBKEY_B64.  UUID and NAME may be empty;
     * PUBKEY_B64 is required — the peer is authenticated by its HUBv3
     * signature (there is no shared secret). */
    char ip[256] = "", uuid[64] = "", name[64] = "", pubkey_b64[128] = "";
    int port = 0;
    int args = payload ? sscanf(payload, "%255[^:]:%d:%63[^:]:%63[^:]:%127s",
                                ip, &port, uuid, name, pubkey_b64)
                       : 0;
    if (args < 2)
      return admin_err(state, client, "peer.usage", "hub add needs an address and a port",
                       "hub add <ip> <port> <uuid> <name|-> <key>");
    /* sscanf stops at an empty field: "ip:port::name:key" leaves the uuid
     * unread, so a missing one is read again field by field */
    if (args < 5 && payload) {
      char f[5][256];
      for (int k = 0; k < 5; k++) f[k][0] = '\0';
      const char *s = payload;
      for (int k = 0; k < 5 && s; k++) {
        const char *c = k < 4 ? strchr(s, ':') : NULL;
        size_t l = c ? (size_t)(c - s) : strlen(s);
        snprintf(f[k], sizeof(f[k]), "%.*s", (int)(l < 255 ? l : 255), s);
        s = c ? c + 1 : NULL;
      }
      snprintf(uuid, sizeof(uuid), "%.63s", f[2]);
      snprintf(name, sizeof(name), "%.63s", f[3]);
      snprintf(pubkey_b64, sizeof(pubkey_b64), "%.127s", f[4]);
    }
    if (port < 1 || port > 65535)
      return admin_err(state, client, "peer.bad_port", "port must be 1-65535", NULL);
    /* A duplicate is named as such even on a full table: "max peers" would
     * send the admin looking for a slot the add never needed. */
    for (int i = 0; uuid[0] && i < state->peer_count; i++)
      if (state->peers[i].uuid[0] && strcmp(state->peers[i].uuid, uuid) == 0) {
        snprintf(msg, sizeof(msg), "a hub with that uuid is already linked (#%d %.63s)",
                 i + 1, state->peers[i].friendly_name[0] ? state->peers[i].friendly_name
                                                          : state->peers[i].ip);
        return admin_err(state, client, "peer.exists", msg, "hub list");
      }
    if (state->peer_count >= MAX_PEERS) {
      snprintf(msg, sizeof(msg), "hub table full (MAX_PEERS = %d)", MAX_PEERS);
      return admin_err(state, client, "peer.full", msg, "hub del to make room");
    }
    if (!pubkey_b64[0])
      return admin_err(state, client, "peer.no_key", "a hub needs its public key",
                       "the 88-character key from that hub's hub show");
    unsigned char key[COMBINED_KEY_LEN];
    {
      int dec_len = 0;
      unsigned char *dec = base64_decode(pubkey_b64, &dec_len);
      bool ok = dec && dec_len == COMBINED_KEY_LEN;
      if (ok) memcpy(key, dec, COMBINED_KEY_LEN);
      if (dec) {
        secure_wipe(dec, (size_t)(dec_len > 0 ? dec_len : 0));
        free(dec);
      }
      if (!ok)
        return admin_err(state, client, "peer.bad_key",
                         "the key must be 88 base64 characters of a 64-byte public key",
                         "the key from that hub's hub show");
    }
    hub_peer_config_t *np = &state->peers[state->peer_count];
    memset(np, 0, sizeof(*np));
    snprintf(np->ip, sizeof(np->ip), "%.63s", ip);
    np->port = port;
    if (uuid[0]) snprintf(np->uuid, sizeof(np->uuid), "%s", uuid);
    if (name[0]) snprintf(np->friendly_name, sizeof(np->friendly_name), "%s", name);
    memcpy(np->ed_pub, key, ED25519_KEY_LEN);
    memcpy(np->x25519_pub, key + ED25519_KEY_LEN, X25519_KEY_LEN);
    np->has_pubkey = true;
    np->connected = false;
    np->fd = -1;
    state->peer_count++;
    state->config_dirty = true;
    char fp[KEY_FP_LEN + 1];
    hub_crypto_key_fingerprint(key, fp);
    reply_t r;
    reply_init(&r);
    reply_ok(&r, "peer.added");
    reply_kvi(&r, "n", state->peer_count);
    if (uuid[0]) reply_kv(&r, "uuid", uuid);
    if (name[0]) reply_kv(&r, "name", name);
    reply_kv(&r, "ip", np->ip);
    reply_kvi(&r, "port", port);
    reply_kv(&r, "fp", fp);
    return send_reply(state, client, &r);
  }

  case CMD_ADMIN_DEL_PEER: {
    /* The payload names the peer: its uuid or its name (the console sends
     * the uuid hub del's preview resolved), or its number in hub list. */
    if (!payload || !payload[0])
      return admin_err(state, client, "peer.usage", "say which hub", "hub del <uuid|name>");
    int target = peer_find(state, payload);
    if (target < 0) {
      snprintf(msg, sizeof(msg), "no hub %.60s: none with that uuid or name", payload);
      return admin_err(state, client, "peer.not_found", msg, "hub list");
    }
    hub_peer_config_t gone = state->peers[target];
    hub_client_t *c = peer_client(state, &state->peers[target]);
    bool was_up = c != NULL;
    if (state->peers[target].fd != -1) {
      int target_fd = state->peers[target].fd;
      for (int k = 0; k < state->client_count; k++)
        if (state->clients[k]->fd == target_fd) {
          hub_disconnect_client(state, state->clients[k]);
          break;
        }
    }
    for (int j = target; j < state->peer_count - 1; j++)
      state->peers[j] = state->peers[j + 1];
    state->peer_count--;
    state->config_dirty = true;
    reply_t r;
    reply_init(&r);
    reply_ok(&r, "peer.removed");
    reply_kvi(&r, "n", target + 1);
    if (gone.uuid[0]) reply_kv(&r, "uuid", gone.uuid);
    if (gone.friendly_name[0]) reply_kv(&r, "name", gone.friendly_name);
    reply_kv(&r, "ip", gone.ip);
    reply_kvi(&r, "port", gone.port);
    reply_kvb(&r, "was_up", was_up);
    secure_wipe(&gone, sizeof(gone));
    return send_reply(state, client, &r);
  }

  case CMD_ADMIN_SET_PEER_PUBKEY: {
    /* "<#|uuid|name>:<pubkey>" — peer set <peer> key <key>.  The link is
     * dropped at once so it comes back authenticated with the new key. */
    char sel[64] = "", pubkey_b64[128] = "";
    if (!payload || sscanf(payload, "%63[^:]:%127s", sel, pubkey_b64) != 2 ||
        !sel[0] || !pubkey_b64[0])
      return admin_err(state, client, "peer.usage", "say which hub and the key",
                       "hub set <#|uuid|name> key <key>");
    int pi = peer_find(state, sel);
    if (pi < 0) {
      snprintf(msg, sizeof(msg), "no hub #%.40s, and none with that uuid or name", sel);
      return admin_err(state, client, "peer.not_found", msg, "hub list");
    }
    int dec_len = 0;
    unsigned char *dec = base64_decode(pubkey_b64, &dec_len);
    if (!dec || dec_len != COMBINED_KEY_LEN) {
      if (dec) {
        secure_wipe(dec, (size_t)(dec_len > 0 ? dec_len : 0));
        free(dec);
      }
      return admin_err(state, client, "peer.bad_key",
                       "the key must be 88 base64 characters of a 64-byte public key",
                       "the key from that hub's hub show");
    }
    hub_peer_config_t *p = &state->peers[pi];
    char old_fp[KEY_FP_LEN + 1] = "", fp[KEY_FP_LEN + 1];
    if (p->has_pubkey) peer_key_fp(p, old_fp);
    memcpy(p->ed_pub, dec, ED25519_KEY_LEN);
    memcpy(p->x25519_pub, dec + ED25519_KEY_LEN, X25519_KEY_LEN);
    p->has_pubkey = true;
    secure_wipe(dec, (size_t)dec_len);
    free(dec);
    peer_key_fp(p, fp);
    state->config_dirty = true;
    hub_log_info("[HUB] %s pubkey set by %s\n", p->uuid[0] ? hub_who(state, 'h', p->uuid) : p->ip,
                 hub_who_client(state, client));
    char uuid[64], name[64];
    snprintf(uuid, sizeof(uuid), "%s", p->uuid);
    snprintf(name, sizeof(name), "%s", p->friendly_name);
    hub_client_t *c = peer_client(state, p);
    bool relinked = c != NULL;
    if (c) hub_disconnect_client(state, c);   /* D9: relink with the new key now */
    reply_t r;
    reply_init(&r);
    reply_ok(&r, "peer.set");
    reply_kvi(&r, "n", pi + 1);
    if (uuid[0]) reply_kv(&r, "uuid", uuid);
    if (name[0]) reply_kv(&r, "name", name);
    reply_kv(&r, "setting", "key");
    if (old_fp[0]) reply_kv(&r, "old", old_fp);
    reply_kv(&r, "value", fp);
    reply_kvb(&r, "relinked", relinked);
    return send_reply(state, client, &r);
  }

  case CMD_ADMIN_LIST_PEERS:
    return admin_list_peers(state, client, payload);
  case CMD_ADMIN_PEER_REFS:
    return admin_peer_refs(state, client, payload);

  case CMD_ADMIN_LIST_CHANNELS: {
    reply_t r;
    reply_init(&r);
    if (payload && payload[0]) {
      config_entry_t *e = chan_entry(state, payload);
      char op[16] = "";
      if (e) parse_global_channel_value(e->value, NULL, 0, NULL, 0, NULL, op, sizeof(op));
      if (!e || strcmp(op, "del") == 0) {
        snprintf(msg, sizeof(msg), "%.64s is not a managed channel", payload);
        return admin_err(state, client, "channel.not_found", msg, "channel list");
      }
      reply_ok(&r, "channel.show");
      reply_kvi(&r, "bots_online", network_bots_online(state));
      char cn[MAX_CHAN];
      {
        /* modes.md §5.1: the stored modes and where they come from, the
         * settings the channel overrides, and its ban count */
        hub_chanset_t cs, ns;
        if (!hub_chan_live(state, payload, cn, sizeof(cn))) cn[0] = '\0';
        if (!cn[0] || !hub_chanset_get(state, cn, &cs)) memset(&cs, 0, sizeof(cs));
        hub_netset_get(state, &ns);
        const char *eff = "+nt", *src = "built-in";
        if (cs.modes[0]) {
          eff = cs.modes;
          src = "chan";
        } else if (ns.modes[0]) {
          eff = ns.modes;
          src = "net";
        }
        reply_kv(&r, "want", eff);
        reply_kv(&r, "want_src", src);
        reply_kv(&r, "overrides", cs.settings);
        hub_ban_t *bl = malloc(sizeof(*bl) * MF_BANS_CHAN_MAX);
        int nb = bl && cn[0] ? hub_ban_list(state, cn, bl, MF_BANS_CHAN_MAX) : 0;
        free(bl);
        reply_kvi(&r, "bans", nb);
      }
      reply_chan(state, &r, e);
      /* every setting's effective value, so the view need not say only "all
       * default" */
      mf_setting_rows(state, &r, cn[0] ? cn : NULL, false);
      return send_reply(state, client, &r);
    }
    int count = 0;
    for (int i = 0; i < state->global_entry_count; i++) {
      config_entry_t *e = &state->global_entries[i];
      char op[16] = "", name[128] = "";
      if (strcmp(e->key, "c") == 0 &&
          parse_global_channel_value(e->value, name, sizeof(name), NULL, 0, NULL, op,
                                     sizeof(op)) &&
          name[0] && strcmp(op, "del") != 0)
        count++;
    }
    reply_ok(&r, "channel.list");
    reply_kvi(&r, "count", count);
    reply_kvi(&r, "bots_online", network_bots_online(state));
    for (int i = 0; i < state->global_entry_count; i++)
      if (strcmp(state->global_entries[i].key, "c") == 0)
        reply_chan(state, &r, &state->global_entries[i]);
    return send_reply(state, client, &r);
  }

  case CMD_ADMIN_ADD_CHANNEL: {
    /* "<#chan>|<key>" adds (or re-adds) a channel.  (The key as a setting
     * moved to channel mode +k; channel set is CMD_ADMIN_CHAN_SET.) */
    if (!payload || !payload[0])
      return admin_err(state, client, "channel.usage", "say which channel",
                       "channel add <#chan> [key]");
    char chan[128] = "", key[64] = "";
    wire_field(payload, 0, chan, sizeof(chan));
    wire_tail(payload, 1, key, sizeof(key));
    if (!chan_name_valid(chan))
      return admin_err(state, client, "channel.bad_name",
                       "a channel name starts with # or & and has no spaces, "
                       "commas or control characters",
                       "channel add #name [key]");
    for (const char *k = key; *k; k++)
      if ((unsigned char)*k <= 0x20 || *k == ',')
        return admin_err(state, client, "channel.bad_key",
                         "a channel key has no spaces, commas or control characters",
                         NULL);
    char old_key[64] = "";
    bool existed = chan_active_key(state, chan, old_key, sizeof(old_key));
    chan_store(state, chan, key);
    reply_t r;
    reply_init(&r);
    reply_ok(&r, "channel.added");
    reply_kv(&r, "name", chan);
    if (key[0]) reply_kv(&r, "key", key);
    if (old_key[0]) reply_kv(&r, "old_key", old_key);
    reply_kvb(&r, "existed", existed);
    {
      char ml[4];
      chan_modes_letters(global_channel_modes(state, chan), ml);
      if (ml[0]) reply_kv(&r, "modes", ml);
    }
    reply_kvi(&r, "bots", local_bot_count(state));
    reply_kvi(&r, "peers", linked_peer_count(state));
    return send_reply(state, client, &r);
  }

  case CMD_ADMIN_DEL_CHANNEL: {
    if (!payload || !payload[0])
      return admin_err(state, client, "channel.usage", "say which channel",
                       "channel del <#chan>");
    char old_key[64];
    bool existed = chan_active_key(state, payload, old_key, sizeof(old_key));
    secure_wipe(old_key, sizeof(old_key));
    /* One stamp past the channel's c|, C| and every B| line, so the delete
     * beats all of them: the settings and bans go with the channel. */
    time_t now = hub_chan_del_stamp(state, payload);
    hub_chan_cascade_del(state, payload, now, true);
    hub_storage_update_global_entry(state, "c", payload, "", "del", now);
    state->config_dirty = true;
    char sync_msg[256];
    snprintf(sync_msg, sizeof(sync_msg), "c|%s||del|%ld\n", payload, (long)now);
    hub_broadcast_config_to_bots(state, sync_msg);
    hub_broadcast_sync_to_peers(state, sync_msg, -1);
    reply_t r;
    reply_init(&r);
    reply_ok(&r, "channel.removed");
    reply_kv(&r, "name", payload);
    reply_kvb(&r, "existed", existed);
    reply_kvi(&r, "bots", local_bot_count(state));
    reply_kvi(&r, "peers", linked_peer_count(state));
    reply_kvi(&r, "purge_days", state->purge_days_setting);
    return send_reply(state, client, &r);
  }

  case CMD_ADMIN_OP_USER: {
    char nick[64], channel[64];
    if (!payload || sscanf(payload, "%63[^|]|%63s", nick, channel) != 2)
      return admin_err(state, client, "channel.usage", "say which channel and nick",
                       "channel op <#chan> <nick>");
    /* One bot does it (CMD_CHAN_PROBE); the answer goes out when the
     * election ends. */
    if (ce_start(state, "op", channel, "ADMIN", nick, "", client)) return true;
    return admin_err(state, client, "channel.busy", "too many channel requests in flight",
                     "try again in a few seconds");
  }

  case CMD_ADMIN_CHAN_MODE:
    return admin_chan_mode(state, client, payload);
  case CMD_ADMIN_CHAN_SET:
    return admin_chan_set(state, client, payload);
  case CMD_ADMIN_BAN:
    return admin_ban(state, client, payload);
  case CMD_ADMIN_POOL:
    return admin_pool(state, client, payload);
  case CMD_ADMIN_NET_SET:
    return admin_net_set(state, client, payload);
  case CMD_ADMIN_SET_SSH:
    return admin_set_ssh(state, client, payload);

  case CMD_CHAN_WHO: {
    /* #chan: one bot in the channel reports its topic, modes and members
     * (election kind "who"; no ops needed).  Read-only: no flag. */
    char channel[MAX_CHAN] = "";
    if (!payload || !wire_field(payload, 0, channel, sizeof(channel)) || !chan_name_valid(channel))
      return admin_err(state, client, "channel.usage", "say which channel", "channel who <#chan>");
    config_entry_t *ce = chan_entry(state, channel);
    char op[16] = "";
    if (ce) parse_global_channel_value(ce->value, NULL, 0, NULL, 0, NULL, op, sizeof(op));
    if (!ce || strcmp(op, "del") == 0) {
      snprintf(msg, sizeof(msg), "%.64s is not a managed channel", channel);
      return admin_err(state, client, "channel.not_found", msg, "channel list");
    }
    if (ce_start(state, "who", channel, "ADMIN", "", "", client)) return true;
    return admin_err(state, client, "channel.busy", "too many channel requests in flight",
                     "try again in a few seconds");
  }

  case CMD_ADMIN_KICK_USER: {
    /* nick|#chan|reason: one opped bot kicks (election kind "kick", the
     * reason in the hostmask slot).  The bot refuses a bot or an authorised
     * member (fail|protected) and a nick not in the channel (fail|absent). */
    char nick[MAX_NICK] = "", channel[MAX_CHAN] = "", reason[BAN_REASON_MAX + 8] = "";
    bool bad = !payload || !wire_field(payload, 0, nick, sizeof(nick)) ||
               !wire_field(payload, 1, channel, sizeof(channel)) || !nick[0] ||
               !chan_name_valid(channel);
    for (const char *p = nick; !bad && *p; p++)
      if ((unsigned char)*p <= 0x20 || *p == 0x7f) bad = true;
    if (bad)
      return admin_err(state, client, "channel.usage", "say which channel and nick",
                       "channel kick <#chan> <nick> [reason]");
    if (mf_field_count(payload) > 2 &&
        (!wire_tail(payload, 2, reason, sizeof(reason)) || strlen(reason) > BAN_REASON_MAX ||
         strchr(reason, '|')))
      return admin_err(state, client, "channel.bad_reason",
                       "a kick reason is at most 120 bytes and has no '|'", NULL);
    for (char *p = reason; *p; p++)
      if ((unsigned char)*p < 0x20 || *p == 0x7f) *p = ' ';
    if (ce_start(state, "kick", channel, "ADMIN", nick, reason, client)) return true;
    return admin_err(state, client, "channel.busy", "too many channel requests in flight",
                     "try again in a few seconds");
  }

  case CMD_ADMIN_INVITE_USER: {
    char nick[64], channel[64];
    if (!payload || sscanf(payload, "%63[^|]|%63s", nick, channel) != 2 ||
        (channel[0] != '#' && channel[0] != '&'))
      return admin_err(state, client, "channel.usage", "say which channel and nick",
                       "channel invite <#chan> <nick>");
    if (ce_start(state, "invite", channel, "ADMIN", nick, "", client)) return true;
    return admin_err(state, client, "channel.busy", "too many channel requests in flight",
                     "try again in a few seconds");
  }

  case CMD_ADMIN_PURGE_TOMBSTONES: {
    /* Payload: "immediate" -> cutoff=0 (purge all); "<N>" (days) -> cutoff =
     * now - N*86400.  Fail closed: only "immediate" purges everything; a
     * payload that is not a whole number of days >= 1 is refused. */
    time_t now = time(NULL);
    time_t cutoff = 0;
    int days = 0;
    if (!payload || strcmp(payload, "immediate") != 0) {
      unsigned long udays;
      if (!payload || !hub_parse_uint(payload, 36500, &udays) || udays == 0)
        return admin_err(state, client, "tomb.bad_arg",
                         "purge takes now or a number of days of at least 1",
                         "hub purge <now|days>");
      cutoff = now - ((time_t)udays * 86400);
      days = (int)udays;
    }
    reply_t tombs;
    reply_init(&tombs);
    int purged_count = hub_execute_purge(state, cutoff, &tombs);
    if (!hub_broadcast_purge(state, cutoff)) {
      reply_free(&tombs);
      snprintf(msg, sizeof(msg),
               "purged %d tombstones here, but the purge could not be sent to peers",
               purged_count);
      return admin_err(state, client, "tomb.not_sent", msg, NULL);
    }
    reply_t r;
    reply_init(&r);
    reply_ok(&r, "tomb.purged");
    reply_kvi(&r, "count", purged_count);
    reply_kvi(&r, "days", days);
    reply_kvi(&r, "peers", linked_peer_count(state));
    /* the tomb| records the purge collected, after the result line */
    const char *t = reply_text(&tombs);
    const char *head = reply_text(&r);
    size_t hl = strlen(head), tl = strlen(t);
    char *all = malloc(hl + 1 + tl + 1);
    bool ok;
    if (!all) {
      ok = send_response(state, client, head);
    } else {
      memcpy(all, head, hl);
      size_t o = hl;
      if (tl) {
        all[o++] = '\n';
        memcpy(all + o, t, tl);
        o += tl;
      }
      all[o] = '\0';
      ok = send_response(state, client, all);
      free(all);
    }
    reply_free(&r);
    reply_free(&tombs);
    return ok;
  }

  case CMD_ADMIN_SET_PURGE_DAYS: {
    unsigned long udays;
    if (!payload || !payload[0] || !hub_parse_uint(payload, 36500, &udays))
      return admin_err(state, client, "hub.bad_days",
                       "autopurge takes a whole number of days (0 = off)",
                       "hub set autopurge <days|0>");
    char old[16], val[16];
    snprintf(old, sizeof(old), "%d", state->purge_days_setting);
    /* Mesh-wide (hs|autopurge): every hub purges on the same schedule, the
     * elected leader runs it. */
    hub_gsetting_set(state, "autopurge", (int)udays);  /* 0 = disabled */
    char line[HS_LINE_MAX];
    if (hub_gsetting_format(state, "autopurge", line, sizeof(line)) > 0)
      hub_broadcast_sync_to_peers(state, line, -1);
    snprintf(val, sizeof(val), "%d", state->purge_days_setting);
    return hub_set_reply(state, client, "autopurge", old, val, false,
                         linked_peer_count(state));
  }

  case CMD_ADMIN_SET_BIND_IP: {
    struct in_addr test_addr;
    if (!payload || !payload[0] || inet_pton(AF_INET, payload, &test_addr) != 1)
      return admin_err(state, client, "hub.bad_ip", "not an IPv4 address",
                       "hub set bindip <a.b.c.d>");
    char old[64];
    snprintf(old, sizeof(old), "%s", state->bind_ip[0] ? state->bind_ip : "0.0.0.0");
    snprintf(state->bind_ip, sizeof(state->bind_ip), "%s", payload);
    state->config_dirty = true;
    time_t now = time(NULL);
    char sync_msg[256];
    snprintf(sync_msg, sizeof(sync_msg), "bind_ip|%s|%ld\n", payload, (long)now);
    hub_broadcast_sync_to_peers(state, sync_msg, -1);
    return hub_set_reply(state, client, "bindip", old, state->bind_ip, true,
                         linked_peer_count(state));
  }

  case CMD_ADMIN_SET_HUB_NAME: {
    /* The name is written into '|'-separated config lines and sent inside
     * handshakes and ':'/','-separated gossip: a newline or separator in it
     * forged config records ("x|203.0.113.77|0" became a denylist entry). */
    if (!payload || !payload[0] || !hub_name_valid(payload))
      return admin_err(state, client, "hub.bad_name",
                       "a hub name is 1-63 characters of A-Z a-z 0-9 . _ -", NULL);
    char old[64];
    snprintf(old, sizeof(old), "%s", hub_display_name(state));
    snprintf(state->hub_friendly_name, sizeof(state->hub_friendly_name), "%s", payload);
    state->config_dirty = true;
    /* Peers learn names from mesh-state gossip (process_mesh_state), not from
     * sync lines; gossip now. */
    state->mesh_state_dirty = true;
    return hub_set_reply(state, client, "name", old, state->hub_friendly_name, false,
                         linked_peer_count(state));
  }

  case CMD_ADMIN_SET_BIND_PORT: {
    unsigned long uport = 0;
    if (!payload || !payload[0] || !hub_parse_uint(payload, 65535, &uport) || uport < 1)
      return admin_err(state, client, "hub.bad_port", "port must be 1-65535", NULL);
    char old[16], val[16];
    snprintf(old, sizeof(old), "%d", state->port);
    state->port = (int)uport;
    state->config_dirty = true;
    time_t now = time(NULL);
    char sync_msg[256];
    snprintf(sync_msg, sizeof(sync_msg), "port|%d|%ld\n", state->port, (long)now);
    hub_broadcast_sync_to_peers(state, sync_msg, -1);
    snprintf(val, sizeof(val), "%d", state->port);
    return hub_set_reply(state, client, "port", old, val, true, linked_peer_count(state));
  }

  case CMD_ADMIN_LIST_ALLOWLIST:
  case CMD_ADMIN_LIST_DENYLIST:
    return admin_list_acl(state, client);

  case CMD_ADMIN_ADD_ALLOWLIST:
    return admin_ip_acl_change(state, client, 'w', true, payload);
  case CMD_ADMIN_DEL_ALLOWLIST:
    return admin_ip_acl_change(state, client, 'w', false, payload);
  case CMD_ADMIN_ADD_DENYLIST:
    return admin_ip_acl_change(state, client, 'x', true, payload);
  case CMD_ADMIN_DEL_DENYLIST:
    return admin_ip_acl_change(state, client, 'x', false, payload);

  case CMD_ADMIN_SET_LOG_LEVEL: {
    /* 1 byte: the file level.  2 bytes: <target><level>, target 0 = the log
     * file, 1 = the console log ring.  Level 0 is the byte 0x00, so the
     * frame length decides, never strlen. */
    if (!payload || (payload_len != 1 && payload_len != 2) ||
        (payload_len == 2 && (unsigned char)payload[0] > 1))
      return admin_err(state, client, "log.bad_payload", "invalid log level request",
                       "log set file|console <level>");
    bool ring = payload_len == 2 && payload[0] == 1;
    int level = (unsigned char)payload[payload_len - 1];
    if (level > LOG_DEBUG) level = LOG_DEBUG;
    if (level < LOG_NONE) level = LOG_NONE;
    int old = ring ? state->console_log_level : state->log_level;
    if (ring) state->console_log_level = level;
    else state->log_level = level;
    state->config_dirty = true;   /* the level survives a restart */
    reply_t r;
    reply_init(&r);
    reply_ok(&r, "log.set");
    reply_kv(&r, "setting", ring ? "console" : "file");
    reply_kvi(&r, "old", old);
    reply_kvi(&r, "value", level);
    reply_kv(&r, "file", HUB_LOG_FILE);
    reply_kvi(&r, "limit", state->log_max_size > 0 ? state->log_max_size : HUB_LOG_FILE_SIZE);
    return send_reply(state, client, &r);
  }

  case CMD_ADMIN_SET_LOG_SIZE: {
    /* Four raw bytes, network order: 10 MB is 00 A0 00 00. */
    if (!payload || payload_len != 4)
      return admin_err(state, client, "log.bad_payload", "invalid log size request",
                       "log set size <MB|nk|nb>");
    uint32_t size;
    memcpy(&size, payload, 4);
    size = ntohl(size);
    uint32_t asked = size;
    if (size < HUB_LOG_SIZE_MIN) size = HUB_LOG_SIZE_MIN;
    if (size > HUB_LOG_SIZE_MAX) size = HUB_LOG_SIZE_MAX;
    int old = state->log_max_size > 0 ? state->log_max_size : HUB_LOG_FILE_SIZE;
    state->log_max_size = (int)size;
    state->config_dirty = true;   /* log_size| survives a restart */
    reply_t r;
    reply_init(&r);
    reply_ok(&r, "log.set");
    reply_kv(&r, "setting", "size");
    reply_kvi(&r, "old", old);
    reply_kvi(&r, "value", state->log_max_size);
    reply_kvu(&r, "asked", asked);
    reply_kvi(&r, "file_level", state->log_level);
    return send_reply(state, client, &r);
  }

  case CMD_ADMIN_STATS: {
    /* Read-only snapshot of g_hub_stats; see CMD_ADMIN_STATS in hub.h. */
    const hub_stats_t *st = &g_hub_stats;
    reply_t r;
    reply_init(&r);
    reply_ok(&r, "stats");
    reply_kvi(&r, "up", (long long)(state->hub_started > 0 ? time(NULL) - state->hub_started : 0));
    reply_rec(&r, "cfg");
    reply_kvu(&r, "full", st->cfg_full);
    reply_kvu(&r, "full_bytes", st->cfg_full_bytes);
    reply_kvu(&r, "delta", st->cfg_delta);
    reply_kvu(&r, "delta_bytes", st->cfg_delta_bytes);
    reply_kvu(&r, "delta_of", st->cfg_delta_of);
    reply_kvu(&r, "same", st->cfg_same);
    reply_kvu(&r, "lost", st->cfg_lost);
    reply_kvu(&r, "pull", st->cfg_pull);
    reply_rec(&r, "tree");
    reply_kvu(&r, "full", st->tree_full);
    reply_kvu(&r, "full_bytes", st->tree_full_bytes);
    reply_kvu(&r, "delta", st->tree_delta);
    reply_kvu(&r, "delta_bytes", st->tree_delta_bytes);
    reply_kvu(&r, "delta_of", st->tree_delta_of);
    reply_kvu(&r, "pull", st->tree_pull);
    {
      /* server pool: live entries, usable ones, flagged ones, bots waiting */
      int live = 0, flagged = 0;
      for (int i = 0; i < state->global_entry_count; i++) {
        pool_srv_t ps;
        const config_entry_t *ge = &state->global_entries[i];
        if (ge->key[0] != 'S' || ge->key[1] || !pool_srv_parse(ge->value, &ps) || ps.deleted) continue;
        live++;
        flagged += ps.state == POOL_WRONGNET;
      }
      reply_rec(&r, "pool");
      reply_kvi(&r, "servers", live);
      reply_kvi(&r, "usable", hub_pool_eligible_count(state, POOL_DEFAULT_NET));
      reply_kvi(&r, "wrongnet", flagged);
      reply_kvi(&r, "idle", hub_pool_idle_bots(state));
      reply_kvu(&r, "reports", st->pool_reports);
      reply_kvu(&r, "flagged", st->pool_flagged);
      reply_kvu(&r, "orders", st->pool_orders);
    }
    reply_rec(&r, "elect");
    reply_kvi(&r, "in_flight", ce_in_flight(state));
    reply_kvi(&r, "slots", MAX_CHAN_ELECTIONS);
    reply_kvu(&r, "started", st->el_started);
    reply_kvu(&r, "batched", st->el_batched);
    reply_kvu(&r, "refused", st->el_refused);
    reply_kvu(&r, "ended", st->el_ended);
    reply_rec(&r, "sync");
    reply_kvu(&r, "frames", st->sync_frames);
    reply_kvu(&r, "noop", st->sync_noop);
    reply_kvu(&r, "records", st->sync_records);
    reply_kvu(&r, "applied", st->sync_applied);
    reply_kvu(&r, "digests", st->sd_tx);
    reply_kvu(&r, "digests_in", st->sd_rx);
    reply_kvu(&r, "matched", st->sd_match);
    reply_kvu(&r, "repaired", st->sd_kinds);
    reply_kvu(&r, "fallbacks", st->sd_full);
    /* Presence v2 (hub_presence2.c). */
    if (state->p2) {
      const p2_state_t *p = state->p2;
      reply_rec(&r, "p2");
      reply_kvi(&r, "ready", p->ready ? 1 : 0);
      reply_kvu(&r, "rx", p->c_rx);
      reply_kvu(&r, "bad", p->c_rx_bad);
      reply_kvu(&r, "tx", p->c_tx);
      reply_kvu(&r, "deltas", p->c_deltas);
      reply_kvu(&r, "snaps", p->c_snaps);
      reply_kvu(&r, "held", p->c_held);
      reply_kvu(&r, "pulls", p->c_pulls);
      reply_kvu(&r, "relays", p->c_relays);
      reply_kvu(&r, "miss", p->c_digest_miss);
      reply_kvu(&r, "heals", p->c_heals);
      reply_kvu(&r, "jumps", p->c_jumps);
      reply_kvu(&r, "drops", p->c_purges);
    }
    /* Client load and the maintenance countdowns (hub_maintenance). */
    time_t now = time(NULL);
    int bots = 0, peers = 0, consoles = 0, authing = 0;
    for (int i = 0; i < state->client_count; i++) {
      const hub_client_t *c = state->clients[i];
      if (c->type == CLIENT_BOT && c->authenticated) bots++;
      else if (c->type == CLIENT_HUB && c->authenticated) peers++;
      else if (c->type == CLIENT_ADMIN && c->authenticated) consoles++;
      else authing++;
    }
    reply_rec(&r, "load");
    reply_kvi(&r, "clients", state->client_count);
    reply_kvi(&r, "bots", bots);
    reply_kvi(&r, "peers", peers);
    reply_kvi(&r, "consoles", consoles);
    reply_kvi(&r, "authing", authing);
    reply_kvi(&r, "dirty", state->config_dirty ? 1 : 0);
    stats_timer(&r, "gossip", 300, state->last_mesh_gossip, now);
    stats_timer(&r, "entropy", MESH_ANTI_ENTROPY_INTERVAL, state->last_anti_entropy, now);
    stats_timer(&r, "scan", 5, state->last_client_scan, now);
    stats_timer(&r, "ipclean", 300, state->last_ip_cleanup, now);
    stats_timer(&r, "peers", PEER_RECONNECT_INTERVAL, state->last_peer_check, now);
    stats_timer(&r, "purge", 86400,
                state->purge_days_setting > 0 && state->last_purge > 0 ? state->last_purge : -1,
                now);
    stats_timer(&r, "roster", BOT_PRESENCE_INTERVAL, state->last_presence_gossip, now);
    if (state->p2) {
      /* Presence v2 keeps CLOCK_MONOTONIC milliseconds. */
      struct timespec ts;
      clock_gettime(CLOCK_MONOTONIC, &ts);
      int64_t mono = (int64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
      stats_timer_due(&r, "p2digest", P2_DIGEST_MS / 1000,
                      now + (time_t)((state->p2->next_digest_ms - mono + 999) / 1000), now);
      stats_timer_due(&r, "p2record", P2_FULL_EVERY_MS / 1000,
                      now + (time_t)((state->p2->next_full_ms - mono + 999) / 1000), now);
    }
    stats_timer(&r, "bansweep", BAN_SWEEP_INTERVAL, hub_bans_sweep_last(), now);
    stats_timer_due(&r, "cron", CRON_CHECK_SECS, hub_update_cron_next(), now);
    for (int op = 0; op < 256; op++) {
      if (!st->rx_frames[op] && !st->tx_frames[op]) continue;
      char code[8];
      snprintf(code, sizeof(code), "0x%02X", (unsigned)op);
      reply_rec(&r, "op");
      reply_kv(&r, "code", code);
      reply_kvu(&r, "rx_f", st->rx_frames[op]);
      reply_kvu(&r, "rx_b", st->rx_bytes[op]);
      reply_kvu(&r, "tx_f", st->tx_frames[op]);
      reply_kvu(&r, "tx_b", st->tx_bytes[op]);
    }
    return send_reply(state, client, &r);
  }

  case CMD_ADMIN_GET_OPT_FLAGS: {
    reply_t r;
    reply_init(&r);
    reply_ok(&r, "option.list");
    reply_kv(&r, "flags", state->opt_flags);
    if (state->opt_flags_ts > 0) reply_kvi(&r, "ts", (long long)state->opt_flags_ts);
    return send_reply(state, client, &r);
  }

  case CMD_ADMIN_SET_OPT_FLAGS: {
    /* Payload: bare flag string ([a-zA-Z0-9]+) or empty to clear. */
    char clean[MAX_OPT_FLAGS + 1] = {0};
    int w = 0;
    for (int i = 0; payload && payload[i] && w < MAX_OPT_FLAGS; i++) {
      char c = payload[i];
      if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9'))
        clean[w++] = c;
    }
    clean[w] = '\0';
    /* Dedupe (preserve insertion order). */
    char dedup[MAX_OPT_FLAGS + 1] = {0};
    int dw = 0;
    for (int i = 0; clean[i] && dw < MAX_OPT_FLAGS; i++) {
      bool seen = false;
      for (int j = 0; j < dw; j++)
        if (dedup[j] == clean[i]) { seen = true; break; }
      if (!seen) dedup[dw++] = clean[i];
    }
    dedup[dw] = '\0';
    char old[MAX_OPT_FLAGS + 1];
    snprintf(old, sizeof(old), "%s", state->opt_flags);
    snprintf(state->opt_flags, sizeof(state->opt_flags), "%s", dedup);
    /* Past the previous stamp: a set and a clear in the same second must not
     * tie, or peers keep whichever arrived and the mesh splits. */
    state->opt_flags_ts = hub_lww_next_ts(state->opt_flags_ts);
    state->config_dirty = true;
    char sync_pkt[64];
    snprintf(sync_pkt, sizeof(sync_pkt), "opt|%s|%ld\n", state->opt_flags,
             (long)state->opt_flags_ts);
    hub_broadcast_sync_to_peers(state, sync_pkt, -1);
    broadcast_full_config_to_all_bots(state);
    reply_t r;
    reply_init(&r);
    reply_ok(&r, "option.set");
    reply_kv(&r, "old", old);
    reply_kv(&r, "value", state->opt_flags);
    reply_kvi(&r, "peers", linked_peer_count(state));
    reply_kvi(&r, "bots", local_bot_count(state));
    return send_reply(state, client, &r);
  }

  /* ================================================================
   * Users: admins and opers (key-based records) and their usermasks
   * ================================================================ */

  case CMD_ADMIN_LIST_ADMINS:
    /* "" = admins, "*" = every user (user list) */
    return admin_list_users(state, client, "user.list",
                            payload && strcmp(payload, "*") == 0 ? 0 : 'a', NULL);
  case CMD_ADMIN_LIST_OPERS_V2:
    return admin_list_users(state, client, "user.list", 'o', NULL);
  case CMD_ADMIN_MATCH:
    if (!payload || !payload[0])
      return admin_err(state, client, "user.usage", "say which user",
                       "user show <name|*>");
    return admin_list_users(state, client, "user.show", 0,
                            strcmp(payload, "*") == 0 ? NULL : payload);

  case CMD_ADMIN_ADD_ADMIN:
  case CMD_ADMIN_ADD_OPER_RECORD: {
    /* Payload: name|pubkey_b64|mask|access.  The user generated their own
     * keypair (keygen) and only the public half arrives: the hub never mints
     * or delivers a user's private key.  access (user_flags plan U4/U5): an
     * admin's flags (+a, or letters from bchou), an oper's channels (* or
     * #a,#b) -- required, there is no default. */
    const bool is_admin = cmd == CMD_ADMIN_ADD_ADMIN;
    const char *usage = is_admin ? "user add admin <name> <key> <mask> <+a|flags>"
                                 : "user add oper <name> <key> <mask> <*|#chan,#chan>";
    char pname[64], ppub[COMBINED_KEY_B64 + 2], pmask[MAX_MASK_LEN], pacc[512] = "";
    if (!payload ||
        sscanf(payload, "%63[^|]|%89[^|]|%255[^|]|%511[^|]", pname, ppub, pmask, pacc) < 3)
      return admin_err(state, client, "user.usage", "user add needs a name, a key and a mask",
                       usage);
    if (!pacc[0])
      return admin_err(state, client, "user.usage",
                       is_admin ? "say the admin's flags: +a for a full admin, or letters from "
                                  "bchou (b bots, c channels, h hub, o opers, u upgrades)"
                                : "say the oper's channels: * for every channel, or #a,#b",
                       usage);
    char flags[USER_FLAGS_MAX + 1] = "";
    char chans[16][MAX_CHAN];
    int nchans = 0;
    if (is_admin) {
      if (!hub_uflags_edit("", pacc, flags, sizeof(flags)) || !flags[0])
        return admin_err(state, client, "user.bad_flags",
                         "flags are +a (full admin) or letters from bchou",
                         "+a, +chu, +b · help user add lists the flags");
    } else {
      char work[512];
      snprintf(work, sizeof(work), "%s", pacc);
      char *save = NULL;
      for (char *t = strtok_r(work, ",", &save); t; t = strtok_r(NULL, ",", &save)) {
        bool dup = false;
        for (int k = 0; k < nchans; k++) dup |= strcasecmp(chans[k], t) == 0;
        if (dup) continue;
        if (!hub_uchan_name_ok(t) || nchans >= 16)
          return admin_err(state, client, "user.bad_chans",
                           "channels are * (every channel) or up to 16 of #a,#b", usage);
        snprintf(chans[nchans++], MAX_CHAN, "%s", t);
      }
      bool star = false;
      for (int k = 0; k < nchans; k++) star |= strcmp(chans[k], "*") == 0;
      if (!nchans || (star && nchans > 1))
        return admin_err(state, client, "user.bad_chans",
                         "channels are * (every channel) or up to 16 of #a,#b", usage);
      /* a binding to a channel nobody manages would be an orphan from the
       * start (user chan add refuses it too) */
      for (int k = 0; k < nchans; k++)
        if (strcmp(chans[k], "*") != 0 && !hub_chan_live(state, chans[k], NULL, 0))
          return mf_status_err(state, client, HUB_MODES_NOT_MANAGED, chans[k]);
    }
    if (!pname[0] || strchr(pname, '|') || strchr(pname, ' '))
      return admin_err(state, client, "user.bad_name", "that is not a usable name", usage);
    unsigned char praw[COMBINED_KEY_LEN];
    if (!hub_crypto_pubkey_b64_decode(ppub, praw))
      return admin_err(state, client, "user.bad_key",
                       "the key must be the user's 88-character public key",
                       "the contents of their .public.b64");
    if (!strchr(pmask, '!') || !strchr(pmask, '@'))
      return admin_err(state, client, "user.bad_mask",
                       "a mask needs ! and @ (nick!user@host)", NULL);
    /* Name and key are unique across all records: console logins identify
     * the admin by key. */
    for (int i = 0; i < state->user_record_count; i++) {
      const hub_user_record_t *o = &state->user_records[i];
      if (!o->is_active) continue;
      if (strcasecmp(o->name, pname) == 0) {
        snprintf(msg, sizeof(msg), "the name %.63s is taken", pname);
        return admin_err(state, client, "user.name_taken", msg, "user list");
      }
      if (o->has_pubkey && strcmp(o->pubkey_b64, ppub) == 0) {
        snprintf(msg, sizeof(msg), "that key already belongs to %.63s", o->name);
        return admin_err(state, client, "user.key_taken", msg, NULL);
      }
    }
    if (state->user_record_count >= MAX_HUB_USER_RECORDS)
      return admin_err(state, client, "user.full", "the user table is full",
                       "hub purge removes old tombstones");
    if (state->mask_record_count >= MAX_HUB_USER_MASKS)
      return admin_err(state, client, "user.mask_full", "the usermask table is full",
                       "hub purge removes old tombstones");
    if ((is_admin && state->uflag_record_count >= MAX_HUB_USER_FLAGS) ||
        (!is_admin && state->uchan_record_count + nchans + 1 > MAX_HUB_CHAN_BINDS))
      return admin_err(state, client, "user.full", "the flag / channel table is full",
                       "hub purge removes old tombstones");
    time_t now = time(NULL);
    char new_uuid[37];
    generate_uuid_v4(new_uuid, sizeof(new_uuid));
    hub_user_record_t *u = &state->user_records[state->user_record_count++];
    memset(u, 0, sizeof(*u));
    snprintf(u->uuid, sizeof(u->uuid), "%s", new_uuid);
    snprintf(u->name, sizeof(u->name), "%s", pname);
    memcpy(u->pubkey_b64, ppub, COMBINED_KEY_B64);  /* validated: 88 chars */
    u->pubkey_b64[COMBINED_KEY_B64] = '\0';
    u->has_pubkey = true;
    u->type = (cmd == CMD_ADMIN_ADD_ADMIN) ? 'a' : 'o';
    u->is_active = true;
    u->last_seen = 0;
    u->timestamp = now;
    hub_mask_record_t *m = &state->mask_records[state->mask_record_count++];
    memset(m, 0, sizeof(*m));
    snprintf(m->uuid, sizeof(m->uuid), "%s", new_uuid);
    snprintf(m->mask, sizeof(m->mask), "%s", pmask);
    m->is_active = true;
    m->last_used = 0;
    m->timestamp = now;
    /* Flags / bindings at the user's own stamp; a channel-bound oper also
     * gets its "*" del (hub_access_migrate must never make it global). */
    if (is_admin) {
      hub_uflag_put(state, new_uuid, flags, now);
    } else {
      for (int k = 0; k < nchans; k++) hub_uchan_put(state, new_uuid, chans[k], true, now);
      if (strcmp(chans[0], "*") != 0) hub_uchan_put(state, new_uuid, "*", false, now);
    }
    state->config_dirty = true;
    /* Bots get fresh per-connection payloads (right shape per bot version);
     * peers get ONE sync: the record, its mask, its flags / bindings, in the
     * order a peer needs them. */
    char sync[MAX_BUFFER];
    int so = hub_format_user_record(u, sync, sizeof(sync));
    if (so < 0 || so >= (int)sizeof(sync)) so = 0;
    int w = snprintf(sync + so, sizeof(sync) - (size_t)so, "m|%s|%s|add|0|%ld\n", m->uuid,
                     m->mask, (long)now);
    if (w > 0 && w < (int)sizeof(sync) - so) so += w;
    hub_access_append(state, sync, (int)sizeof(sync), &so, access_same_user, new_uuid);
    hub_broadcast_config_to_bots(state, sync);
    hub_broadcast_sync_to_peers(state, sync, -1);
    char fp[KEY_FP_LEN + 1];
    hub_crypto_key_fingerprint(praw, fp);
    reply_t r;
    reply_init(&r);
    reply_ok(&r, "user.added");
    reply_kv(&r, "name", pname);
    reply_kv(&r, "role", u->type == 'a' ? "admin" : "oper");
    reply_kv(&r, "fp", fp);
    reply_kv(&r, "mask", pmask);
    if (is_admin) {
      reply_kv(&r, "flags", flags);
    } else {
      char cl[512];
      hub_user_chans(state, new_uuid, cl, sizeof(cl));
      reply_kv(&r, "chans", cl);
    }
    reply_kvi(&r, "peers", linked_peer_count(state));
    reply_kvi(&r, "bots", local_bot_count(state));
    reply_kvi(&r, "port", state->listen_port ? state->listen_port : state->port);
    return send_reply(state, client, &r);
  }

  case CMD_ADMIN_USER_ACCESS:
    return admin_user_access(state, client, payload);

  case CMD_ADMIN_DEL_ADMIN:
  case CMD_ADMIN_DEL_OPER_RECORD: {
    /* Either opcode removes the named user, whatever its role. */
    if (!payload || !*payload)
      return admin_err(state, client, "user.usage", "say which user", "user del <name>");
    hub_user_record_t *target = user_by_name(state, payload);
    if (!target) {
      snprintf(msg, sizeof(msg), "no user called \"%.64s\"", payload);
      return admin_err(state, client, "user.not_found", msg, "user list");
    }
    if (target->type == 'a' && last_full_admin(state, target->uuid))
      return admin_err(state, client, "user.last_admin",
                       "that is the last full admin (+a); the network needs one",
                       "make another admin +a first");
    /* Peers get ONE sync payload: the user tombstone, then a tombstone for
     * every mask the user owned.  No peer or bot cascades a user delete to
     * its masks, so a mask tombstone that is not sent leaves the mask live
     * there: an orphan holding a slot of the shared 200-mask table on every
     * other hub and on their bots.  One payload keeps the lines in order and
     * off the per-lane message cap (a user may own every mask slot). */
    size_t sync_cap = (size_t)USER_LINE_MAX + (size_t)MAX_HUB_USER_MASKS * MASK_LINE_MAX + 1;
    char *sync = malloc(sync_cap);
    if (!sync)
      return admin_err(state, client, "internal.oom", "out of memory", NULL);
    int sessions = target->type == 'a' ? admin_console_sessions(state, target->name) : 0;
    target->is_active = false;
    target->timestamp = hub_lww_next_ts(target->timestamp);
    state->config_dirty = true;
    char uline[USER_LINE_MAX];
    int sync_len = hub_format_user_record(target, uline, sizeof(uline));
    if (sync_len < 0 || sync_len >= (int)sizeof(uline)) sync_len = 0;
    memcpy(sync, uline, (size_t)sync_len);
    sync[sync_len] = '\0';
    int masks_dropped = 0;
    for (int i = 0; i < state->mask_record_count; i++) {
      hub_mask_record_t *mr = &state->mask_records[i];
      if (strcmp(mr->uuid, target->uuid) != 0 || !mr->is_active) continue;
      mr->is_active = false;
      mr->timestamp = hub_lww_next_ts(mr->timestamp);
      masks_dropped++;
      int w = snprintf(sync + sync_len, sync_cap - (size_t)sync_len,
                       "m|%s|%s|del|%lld|%lld\n", mr->uuid, mr->mask,
                       (long long)mr->last_used, (long long)mr->timestamp);
      /* cannot overflow: sync_cap holds a line for every mask slot */
      if (w > 0 && (size_t)w < sync_cap - (size_t)sync_len) sync_len += w;
    }
    hub_broadcast_config_to_bots(state, uline);   /* logs the user line only */
    hub_broadcast_sync_to_peers(state, sync, -1);
    hub_log_info("[ADMIN] %s %s removed with %d usermask(s)\n",
                 target->type == 'a' ? "Admin" : "Oper", target->name, masks_dropped);
    free(sync);
    reply_t r;
    reply_init(&r);
    reply_ok(&r, "user.removed");
    reply_kv(&r, "name", target->name);
    reply_kv(&r, "role", target->type == 'a' ? "admin" : "oper");
    reply_kvi(&r, "masks", masks_dropped);
    reply_kvi(&r, "peers", linked_peer_count(state));
    reply_kvi(&r, "bots", local_bot_count(state));
    reply_kvi(&r, "sessions", sessions);
    return send_reply(state, client, &r);
  }

  case CMD_ADMIN_ADD_USERMASK: {
    char pname[64], pmask[MAX_MASK_LEN];
    if (!payload || sscanf(payload, "%63[^|]|%255s", pname, pmask) < 2)
      return admin_err(state, client, "user.usage", "say which user and mask",
                       "user mask add <name> <mask>");
    if (!strchr(pmask, '!') || !strchr(pmask, '@'))
      return admin_err(state, client, "user.bad_mask",
                       "a mask needs ! and @ (nick!user@host)", NULL);
    hub_user_record_t *target = user_by_name(state, pname);
    if (!target) {
      snprintf(msg, sizeof(msg), "no user called \"%.63s\"", pname);
      return admin_err(state, client, "user.not_found", msg, "user list");
    }
    /* Duplicate active mask is an error; a tombstone for the same mask is
     * revived past its stamp (a second record could tie with the remove). */
    hub_mask_record_t *m = NULL;
    for (int i = 0; i < state->mask_record_count; i++) {
      if (strcmp(state->mask_records[i].uuid, target->uuid) != 0 ||
          strcasecmp(state->mask_records[i].mask, pmask) != 0)
        continue;
      if (state->mask_records[i].is_active) {
        snprintf(msg, sizeof(msg), "%.63s already has that mask", target->name);
        return admin_err(state, client, "user.mask_exists", msg, "user show <name>");
      }
      m = &state->mask_records[i];
    }
    if (m) {
      m->timestamp = hub_lww_next_ts(m->timestamp);
    } else {
      if (state->mask_record_count >= MAX_HUB_USER_MASKS)
        return admin_err(state, client, "user.mask_full", "the usermask table is full",
                         "hub purge removes old tombstones");
      char tuuid_add[37];
      snprintf(tuuid_add, sizeof(tuuid_add), "%s", target->uuid);
      m = &state->mask_records[state->mask_record_count++];
      memset(m, 0, sizeof(*m));
      snprintf(m->uuid, sizeof(m->uuid), "%s", tuuid_add);
      snprintf(m->mask, sizeof(m->mask), "%s", pmask);
      m->last_used = 0;
      m->timestamp = time(NULL);
    }
    m->is_active = true;
    state->config_dirty = true;
    char sync[MAX_BUFFER];
    snprintf(sync, sizeof(sync), "m|%s|%s|add|%lld|%lld\n", m->uuid, m->mask,
             (long long)m->last_used, (long long)m->timestamp);
    hub_broadcast_config_to_bots(state, sync);
    hub_broadcast_sync_to_peers(state, sync, -1);
    reply_t r;
    reply_init(&r);
    reply_ok(&r, "user.mask_added");
    reply_kv(&r, "name", target->name);
    reply_kv(&r, "mask", pmask);
    reply_kvi(&r, "masks", user_mask_count(state, target->uuid));
    reply_kvi(&r, "peers", linked_peer_count(state));
    reply_kvi(&r, "bots", local_bot_count(state));
    return send_reply(state, client, &r);
  }

  case CMD_ADMIN_DEL_USERMASK: {
    char pname[64], pmask[MAX_MASK_LEN];
    if (!payload || sscanf(payload, "%63[^|]|%255s", pname, pmask) < 2)
      return admin_err(state, client, "user.usage", "say which user and mask",
                       "user mask del <name> <mask>");
    hub_user_record_t *target = user_by_name(state, pname);
    if (!target) {
      snprintf(msg, sizeof(msg), "no user called \"%.63s\"", pname);
      return admin_err(state, client, "user.not_found", msg, "user list");
    }
    hub_mask_record_t *found = NULL;
    for (int i = 0; i < state->mask_record_count; i++)
      if (state->mask_records[i].is_active &&
          strcmp(state->mask_records[i].uuid, target->uuid) == 0 &&
          strcasecmp(state->mask_records[i].mask, pmask) == 0) {
        found = &state->mask_records[i];
        break;
      }
    if (!found) {
      snprintf(msg, sizeof(msg), "%.63s has no such mask", target->name);
      return admin_err(state, client, "user.mask_not_found", msg, "user show <name>");
    }
    found->is_active = false;
    found->timestamp = hub_lww_next_ts(found->timestamp);
    state->config_dirty = true;
    char sync[MAX_BUFFER];
    snprintf(sync, sizeof(sync), "m|%s|%s|del|%lld|%lld\n", found->uuid, found->mask,
             (long long)found->last_used, (long long)found->timestamp);
    hub_broadcast_config_to_bots(state, sync);
    hub_broadcast_sync_to_peers(state, sync, -1);
    reply_t r;
    reply_init(&r);
    reply_ok(&r, "user.mask_removed");
    reply_kv(&r, "name", target->name);
    reply_kv(&r, "mask", found->mask);
    reply_kvi(&r, "masks", user_mask_count(state, target->uuid));
    reply_kvi(&r, "peers", linked_peer_count(state));
    reply_kvi(&r, "bots", local_bot_count(state));
    return send_reply(state, client, &r);
  }

  case CMD_ADMIN_SET_USERKEY: {
    /* Payload: name|pubkey_b64 — replace a user's key (rotation, a lost key,
     * or giving a legacy keyless user one).  UUID, masks and history stay;
     * the old key stops working for the admin console and every bot at sync
     * speed. */
    char pname[64], ppub[COMBINED_KEY_B64 + 2];
    if (!payload || sscanf(payload, "%63[^|]|%89s", pname, ppub) < 2)
      return admin_err(state, client, "user.usage", "say which user and the key",
                       "user set <name> key <key>");
    unsigned char praw[COMBINED_KEY_LEN];
    if (!hub_crypto_pubkey_b64_decode(ppub, praw))
      return admin_err(state, client, "user.bad_key",
                       "the key must be the user's 88-character public key",
                       "the contents of their .public.b64");
    hub_user_record_t *target = user_by_name(state, pname);
    if (!target) {
      snprintf(msg, sizeof(msg), "no user called \"%.63s\"", pname);
      return admin_err(state, client, "user.not_found", msg, "user list");
    }
    for (int i = 0; i < state->user_record_count; i++) {
      hub_user_record_t *o = &state->user_records[i];
      if (o != target && o->is_active && o->has_pubkey && strcmp(o->pubkey_b64, ppub) == 0) {
        snprintf(msg, sizeof(msg), "that key already belongs to %.63s", o->name);
        return admin_err(state, client, "user.key_taken", msg, NULL);
      }
    }
    char old_fp[KEY_FP_LEN + 1] = "";
    if (target->has_pubkey) hub_crypto_key_fingerprint_b64(target->pubkey_b64, old_fp);
    int sessions = target->type == 'a' ? admin_console_sessions(state, target->name) : 0;
    memcpy(target->pubkey_b64, ppub, COMBINED_KEY_B64);  /* validated: 88 */
    target->pubkey_b64[COMBINED_KEY_B64] = '\0';
    target->has_pubkey = true;
    /* Bump timestamp so peers and bots see this update as newer than the
     * old record (otherwise replication compares ts and drops the change). */
    target->timestamp = hub_lww_next_ts(target->timestamp);
    state->config_dirty = true;
    char sync[MAX_BUFFER];
    hub_format_user_record(target, sync, sizeof(sync));
    hub_broadcast_config_to_bots(state, sync);
    hub_broadcast_sync_to_peers(state, sync, -1);
    char fp[KEY_FP_LEN + 1];
    hub_crypto_key_fingerprint(praw, fp);
    reply_t r;
    reply_init(&r);
    reply_ok(&r, "user.set");
    reply_kv(&r, "name", target->name);
    reply_kv(&r, "role", target->type == 'a' ? "admin" : "oper");
    reply_kv(&r, "setting", "key");
    if (old_fp[0]) reply_kv(&r, "old", old_fp);
    reply_kv(&r, "value", fp);
    reply_kvi(&r, "peers", linked_peer_count(state));
    reply_kvi(&r, "bots", local_bot_count(state));
    reply_kvi(&r, "sessions", sessions);
    return send_reply(state, client, &r);
  }

  default:
    return admin_err(state, client, "admin.unknown", "unknown admin command", NULL);
  }
}

// ========== OP Request Forwarding Helper Functions ==========

static void generate_request_id(char *out_id, size_t len) {
  unsigned char rand_bytes[16];
  RAND_bytes(rand_bytes, sizeof(rand_bytes));
  snprintf(out_id, len, "%02x%02x%02x%02x-%02x%02x-%02x%02x",
           rand_bytes[0], rand_bytes[1], rand_bytes[2], rand_bytes[3],
           rand_bytes[4], rand_bytes[5], rand_bytes[6], rand_bytes[7]);
}

/* Check if we have already processed this OP_FORWARD request_id.
 * Returns true (already seen — caller should drop the packet).
 * Returns false (first time — inserts into the LRU ring and caller processes).
 * Thread-safety: single-threaded event loop, no lock needed. */
static bool op_forward_seen_check_and_add(hub_state_t *state,
                                           const char *request_id) {
  /* Scan for existing entry. */
  for (int i = 0; i < MAX_SEEN_FORWARD_IDS; i++) {
    if (state->seen_forwards[i].request_id[0] != '\0' &&
        strcmp(state->seen_forwards[i].request_id, request_id) == 0) {
      return true; /* already seen */
    }
  }
  /* Not found — insert at ring head position and advance. */
  int slot = state->seen_forward_head;
  /* A copy, not snprintf: the id often lives in *state too (a roll call's),
   * which snprintf's restrict contract does not allow. */
  char *dst = state->seen_forwards[slot].request_id;
  size_t n = strnlen(request_id, SEEN_FORWARD_ID_MAX - 1);
  memmove(dst, request_id, n);
  dst[n] = '\0';
  state->seen_forwards[slot].seen_at = time(NULL);
  state->seen_forward_head = (slot + 1) % MAX_SEEN_FORWARD_IDS;
  return false; /* first time seeing this */
}

/* The conn_serial of the link on `fd` now, or 0 (none: -1, or no such link).
 * A reply table keeps it beside the fd, so an answer that comes back after
 * the link dropped and the fd was reused never reaches the newcomer. */
static uint64_t fd_conn_serial(const hub_state_t *state, int fd) {
  if (fd < 0) return 0;
  for (int i = 0; i < state->client_count; i++)
    if (state->clients[i]->fd == fd) return state->clients[i]->conn_serial;
  return 0;
}

static int add_pending_op_request(hub_state_t *state, const char *request_id,
                                   const char *requester_uuid,
                                   const char *target_uuid,
                                   const char *channel, int origin_fd) {
  // Find an empty slot
  for (int i = 0; i < MAX_PENDING_OP_REQUESTS; i++) {
    if (!state->pending_op_requests[i].active) {
      snprintf(state->pending_op_requests[i].request_id,
               sizeof(state->pending_op_requests[i].request_id), "%s",
               request_id);
      snprintf(state->pending_op_requests[i].requester_uuid,
               sizeof(state->pending_op_requests[i].requester_uuid), "%s",
               requester_uuid);
      snprintf(state->pending_op_requests[i].target_uuid,
               sizeof(state->pending_op_requests[i].target_uuid), "%s",
               target_uuid);
      snprintf(state->pending_op_requests[i].channel,
               sizeof(state->pending_op_requests[i].channel), "%s", channel);
      state->pending_op_requests[i].origin_fd = origin_fd;
      state->pending_op_requests[i].origin_serial = fd_conn_serial(state, origin_fd);
      state->pending_op_requests[i].timestamp = time(NULL);
      state->pending_op_requests[i].active = true;
      return i;
    }
  }
  return -1; // No space available
}

static pending_op_request_t *find_pending_op_request(hub_state_t *state,
                                                      const char *request_id) {
  for (int i = 0; i < MAX_PENDING_OP_REQUESTS; i++) {
    if (state->pending_op_requests[i].active &&
        strcmp(state->pending_op_requests[i].request_id, request_id) == 0) {
      return &state->pending_op_requests[i];
    }
  }
  return NULL;
}

static void remove_pending_op_request(hub_state_t *state,
                                       const char *request_id) {
  for (int i = 0; i < MAX_PENDING_OP_REQUESTS; i++) {
    if (state->pending_op_requests[i].active &&
        strcmp(state->pending_op_requests[i].request_id, request_id) == 0) {
      state->pending_op_requests[i].active = false;
      return;
    }
  }
}

static void forward_op_request_to_peers(hub_state_t *state,
                                         const char *request_id,
                                         const char *requester_uuid,
                                         const char *target_uuid,
                                         const char *channel,
                                         const char *requester_hostmask,
                                         int exclude_fd,
                                         time_t origin_ts, bool split) {
  /* Payload format (7 fields):
   *   request_id|requester_uuid|target_uuid|channel|requester_hostmask|origin_ts|how
   * `how` is newest: "F" = flooded to every peer the sender is linked to (a
   * receiver may apply the split horizon), "D" = sent to one peer only.  Old
   * hubs read a fixed field count and ignore it; a frame without it is
   * treated as "D" (no split horizon) — the old behaviour. */
  hub_client_t *route = strcmp(target_uuid, "ANY") != 0
                            ? op_route_peer(state, target_uuid, exclude_fd)
                            : NULL;
  char forward_payload[680];
  snprintf(forward_payload, sizeof(forward_payload), "%s|%s|%s|%s|%s|%ld|%s",
           request_id, requester_uuid, target_uuid, channel,
           requester_hostmask ? requester_hostmask : "",
           (long)(origin_ts > 0 ? origin_ts : time(NULL)), route ? "D" : "F");

  if (route) {
    /* Directed: the roster says which hub holds the target and it is one of
     * ours.  Flooding put ~hubs^2 copies on the mesh for one grant.  If the
     * roster was stale, that hub routes it on the same way (it excludes us),
     * so the request is still delivered, one hop later. */
    if (!peer_send_urgent(state, route, CMD_OP_FORWARD_REQUEST, forward_payload)) {
      hub_log_warning("[HUB] URGENT queue full forwarding OP_REQUEST to peer fd=%d — disconnecting\n",
              route->fd);
      hub_disconnect_client(state, route);
      return;
    }
    hub_log_debug("[HUB] Routed OP_FORWARD_REQUEST (id:%s) to peer fd=%d, the hub of %s\n",
            request_id, route->fd, hub_who(state, 'b', target_uuid));
    return;
  }

  /* Flood, with the split horizon when the sender flooded too: a peer the
   * sender is linked to got its copy straight from the sender. */
  const mesh_hub_t *sender = split ? split_horizon_sender(state, exclude_fd)
                                   : NULL;
  int queued_count = 0, skipped = 0;
  /* Route through URGENT lane — op grants must not be delayed by BULK sync. */
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type == CLIENT_HUB && c->authenticated && c->fd != exclude_fd) {
      if (sender && split_horizon_has(state, sender, c)) {
        skipped++;
        continue;
      }
      if (!peer_send_urgent(state, c, CMD_OP_FORWARD_REQUEST, forward_payload)) {
        hub_log_warning("[HUB] URGENT queue full forwarding OP_REQUEST to peer fd=%d — disconnecting\n",
                c->fd);
        hub_disconnect_client(state, c);
        i--;
        continue;
      }
      queued_count++;
      if (hub_log_on(LOG_DEBUG))
        hub_log_debug("[HUB] Queued OP_FORWARD_REQUEST (id:%s) URGENT to peer fd=%d\n",
              request_id, c->fd);
    }
  }
  if (queued_count > 0 || skipped > 0)
    hub_log_debug("[HUB] Forwarded OP_FORWARD_REQUEST (id:%s) to %d peer(s), %d skipped (split horizon)\n",
            request_id, queued_count, skipped);
}

// ========== End OP Request Forwarding Helper Functions ==========

// ========== Handlers for Forwarded OP Commands from Peer Hubs ==========

static void process_forward_op_request(hub_state_t *state,
                                        hub_client_t *client, char *payload) {
  /* Payload format (6 fields, 6th is new and optional for old senders):
   *   request_id|requester_uuid|target_uuid|channel|requester_hostmask|origin_ts|how */
  char request_id[64], requester_uuid[64], target_uuid[64], channel[MAX_CHAN];
  char carried_hostmask[MAX_MASK_LEN] = "";
  long long origin_ts = 0;

  int parsed = sscanf(payload,
                      "%63[^|]|%63[^|]|%63[^|]|%64[^|]|%255[^|]|%lld",
                      request_id, requester_uuid, target_uuid, channel,
                      carried_hostmask, &origin_ts);
  if (parsed < 4) {
    hub_log_warning("[HUB] Invalid OP_FORWARD_REQUEST payload from peer fd=%d\n",
            client->fd);
    return;
  }
  /* The trailing "F": the sender flooded it (see forward_op_request_to_peers).
   * Read from the end: an empty hostmask field stops the sscanf above early. */
  const char *how = strrchr(payload, '|');
  bool flooded = how && strcmp(how + 1, "F") == 0;

  /* ================================================================
   * DUPLICATE / STORM GUARD
   * Check TTL first (cheap), then seen-set (LRU ring scan).
   * Both checks are O(MAX_SEEN_FORWARD_IDS) = O(256) — negligible.
   * ================================================================ */

  /* 1. TTL: drop requests that are too old to be worth servicing. */
  if (origin_ts > 0) {
    long age = (long)(time(NULL) - (time_t)origin_ts);
    if (age > OP_FORWARD_TTL_SECONDS) {
      if (hub_log_on(LOG_DEBUG))
        hub_log_debug("[HUB] Dropping expired OP_FORWARD_REQUEST (id:%s, age=%lds > %ds TTL)\n",
                request_id, age, OP_FORWARD_TTL_SECONDS);
      return;
    }
  }

  /* 2. Dedup: drop if we have already processed this exact request_id.
   *    This is the primary defense against infinite re-broadcast storms:
   *    each hub processes a given request at most once, regardless of how
   *    many peers flood copies of it back. */
  if (op_forward_seen_check_and_add(state, request_id)) {
    if (hub_log_on(LOG_DEBUG))
      hub_log_debug("[HUB] Dropping duplicate OP_FORWARD_REQUEST (id:%s) -- already processed\n",
                  request_id);
    return;
  }

  hub_log_debug("[HUB] Received OP_FORWARD_REQUEST (id:%s) from peer fd=%d target=%s channel=%s\n",
          request_id, client->fd, hub_who(state, 'b', target_uuid), channel);

  // Handle admin requests specially (target_uuid = "ANY", requester_uuid = "ADMIN")
  if (strcmp(target_uuid, "ANY") == 0 && strcmp(requester_uuid, "ADMIN") == 0) {
    // Admin op request - decode nick:channel format
    char nick[64], chan[MAX_CHAN];
    if (sscanf(channel, "%63[^:]:%64s", nick, chan) == 2) {
      hub_log_info("[HUB] Admin OP_REQUEST for %s in %s - broadcasting to local bots\n",
              nick, chan);

      // Send op grant to all local bots (they'll filter if not in channel)
      int sent_count = 0;
      for (int i = 0; i < state->client_count; i++) {
        if (state->clients[i]->type == CLIENT_BOT &&
            state->clients[i]->authenticated) {
          char op_payload[256];
          snprintf(op_payload, sizeof(op_payload), "%s|%s", nick, chan);
          /* queued like every bot frame (a direct send could land inside a
           * part-sent one, and is outside the link's sequence: review 6) */
          if (send_cmd_to_bot(state, state->clients[i], CMD_OP_GRANT, op_payload))
            sent_count++;
        }
      }

      /* Forward to other peer hubs so they can deliver to their local bots.
       * The seen-set on each receiving hub ensures they process it only once
       * even if multiple peers forward copies. */
      forward_op_request_to_peers(state, request_id, requester_uuid, target_uuid,
                                  channel, "", client->fd, (time_t)origin_ts,
                                  flooded);
      hub_log_info("[HUB] Admin OP_REQUEST delivered to %d local bot(s), forwarding to peers\n",
              sent_count);
    }
    return;
  }

  // Search for target bot locally
  hub_client_t *target = NULL;
  for (int i = 0; i < state->client_count; i++) {
    if (state->clients[i]->type == CLIENT_BOT &&
        state->clients[i]->authenticated &&
        strcmp(state->clients[i]->id, target_uuid) == 0) {
      target = state->clients[i];
      break;
    }
  }

  if (target) {
    // Use hostmask carried in the forwarded payload; fall back to local storage.
    char requester_hostmask[MAX_MASK_LEN] = "";
    if (carried_hostmask[0] != '\0') {
      snprintf(requester_hostmask, sizeof(requester_hostmask), "%s",
               carried_hostmask);
    } else {
      for (int i = 0; i < state->bot_count; i++) {
        if (strcmp(state->bots[i].uuid, requester_uuid) == 0) {
          for (int j = 0; j < state->bots[i].entry_count; j++) {
            if (strcmp(state->bots[i].entries[j].key, "h") == 0) {
              snprintf(requester_hostmask, sizeof(requester_hostmask), "%.*s",
                       (int)(sizeof(requester_hostmask) - 1),
                       state->bots[i].entries[j].value);
              break;
            }
          }
          break;
        }
      }
    }

    if (requester_hostmask[0] == '\0') {
      hub_log_warning("[HUB] No hostmask for requester %s (not in payload or storage)\n",
              hub_who(state, 'b', requester_uuid));
      char fail_payload[256];
      snprintf(fail_payload, sizeof(fail_payload), "%s|No hostmask found",
               request_id);
      peer_send_urgent(state, client, CMD_OP_FORWARD_FAILED, fail_payload);
      return;
    }

    // Send OP_GRANT to local target bot
    char grant_payload[512];
    snprintf(grant_payload, sizeof(grant_payload), "%s|%s", requester_hostmask,
             channel);

    if (send_cmd_to_bot(state, target, CMD_OP_GRANT, grant_payload)) {
      hub_log_debug("[HUB] Sent OP_GRANT to local %s for request id:%s\n",
              hub_who(state, 'b', target_uuid), request_id);
      /* Forward grant confirmation back to origin peer via URGENT. */
      peer_send_urgent(state, client, CMD_OP_FORWARD_GRANT, request_id);
      hub_log_debug("[HUB] Queued OP_FORWARD_GRANT URGENT back to peer for id:%s\n",
              request_id);
    }
  } else {
    // Target not found locally - forward to other peers (exclude origin)
    hub_log_debug("[HUB] Target %s not found locally, forwarding to %d peer(s)\n",
            hub_who(state, 'b', target_uuid), state->client_count);
    forward_op_request_to_peers(state, request_id, requester_uuid, target_uuid,
                                 channel, carried_hostmask, client->fd, (time_t)origin_ts,
                                 flooded);
  }
}

static void process_forward_op_grant(hub_state_t *state, hub_client_t *client,
                                      char *payload) {
  (void)client; // Not used - response goes to original requester
  // Payload format: request_id
  char request_id[64];
  if (strlen(payload) >= sizeof(request_id)) {
    hub_log_warning("[HUB] OP_FORWARD_GRANT: oversized request_id, ignoring\n");
    return;
  }
  snprintf(request_id, sizeof(request_id), "%s", payload);

  hub_log_debug("[HUB] Received OP_FORWARD_GRANT from peer for request id:%s\n",
          request_id);

  // Find the pending request
  pending_op_request_t *req = find_pending_op_request(state, request_id);
  if (!req) {
    hub_log_warning("[HUB] No pending request found for id:%s\n", request_id);
    return;
  }

  // Find the original requester bot
  hub_client_t *requester = NULL;
  for (int i = 0; i < state->client_count; i++) {
    if (state->clients[i]->fd == req->origin_fd &&
        state->clients[i]->conn_serial == req->origin_serial &&
        state->clients[i]->type == CLIENT_BOT) {
      requester = state->clients[i];
      break;
    }
  }

  if (requester) {
    hub_log_debug("[HUB] OP_FORWARD_GRANT acknowledged for id:%s — requester learns via IRC MODE\n",
            request_id);
  }

  // Remove the pending request
  remove_pending_op_request(state, request_id);
}

static void process_forward_op_failed(hub_state_t *state, hub_client_t *client,
                                       char *payload) {
  (void)client; // Not used - response goes to original requester
  // Payload format: request_id|reason
  char request_id[64] = "", reason[256] = "";

  if (sscanf(payload, "%63[^|]|%255[^\n]", request_id, reason) < 1) {
    hub_log_warning("[HUB] Invalid OP_FORWARD_FAILED payload from peer\n");
    return;
  }

  hub_log_debug("[HUB] Received OP_FORWARD_FAILED from peer for request id:%s\n",
          request_id);

  // Find the pending request
  pending_op_request_t *req = find_pending_op_request(state, request_id);
  if (!req) {
    hub_log_warning("[HUB] No pending request found for id:%s\n", request_id);
    return;
  }

  // Find the original requester bot
  hub_client_t *requester = NULL;
  for (int i = 0; i < state->client_count; i++) {
    if (state->clients[i]->fd == req->origin_fd &&
        state->clients[i]->conn_serial == req->origin_serial &&
        state->clients[i]->type == CLIENT_BOT) {
      requester = state->clients[i];
      break;
    }
  }

  if (requester) {
    // Send failure notification to requester
    const char *fail_msg =
        (reason[0] != '\0') ? reason : "Target bot not found on network";
    if (send_cmd_to_bot(state, requester, CMD_OP_FAILED, fail_msg))
      hub_log_info("[HUB] Notified requester bot of failure for id:%s\n",
              request_id);
  }

  // Remove the pending request
  remove_pending_op_request(state, request_id);
}

// ========== End Handlers for Forwarded OP Commands ==========

// ========== Channel-Access Requests (unban / invite / key) ==========

/* Frame `payload` under `cmd` and write it to one authenticated bot. */
static bool send_cmd_to_bot(hub_state_t *state, hub_client_t *bot, uint8_t cmd,
                            const char *payload) {
  int pay_len = payload ? (int)strlen(payload) : 0;
  if (pay_len + 5 > MAX_BUFFER)
    return false;
  /* queued_msg_free wipes the payload copy (a CHAN_REPLY carries a key) */
  return hub_client_send(state, bot, cmd, payload);
}

/* A frame that acts on config the bot may not have yet (a `mode` job reads
 * the C| modes and c| key the console has just stored): send the owed config
 * push now, past the coalescing window, and queue the frame behind it in
 * LANE_BULK -- send_cmd_to_bot goes out on LANE_URGENT and would overtake a
 * config still waiting in the bot's queue. */
static bool send_cmd_to_bot_after_config(hub_state_t *state, hub_client_t *bot,
                                         uint8_t cmd, const char *payload) {
  if (state->bot_config_pending) send_owed_bot_config(state, time(NULL));
  if (!peer_has_pending_writes(bot)) return send_cmd_to_bot(state, bot, cmd, payload);
  queued_msg_t *m = queued_msg_new(cmd, LANE_BULK, (const unsigned char *)payload,
                                   payload ? (int)strlen(payload) : 0);
  return m && peer_enqueue(bot, m);
}

/* A bot's own request: unban / invite / key, and (2.5.4, with a rid) op. */
static bool chan_kind_valid(const char *kind) {
  return strcmp(kind, "unban") == 0 || strcmp(kind, "invite") == 0 ||
         strcmp(kind, "key") == 0 || strcmp(kind, "op") == 0;
}

static int add_pending_chan_request(hub_state_t *state, const char *request_id,
                                    const char *requester_uuid,
                                    const char *kind, const char *channel,
                                    int origin_fd) {
  time_t now = time(NULL);
  for (int i = 0; i < MAX_PENDING_CHAN_REQUESTS; i++) {
    pending_chan_request_t *p = &state->pending_chan_requests[i];
    /* Reuse a slot whose reply never came rather than filling the table. */
    if (p->active && now - p->timestamp > CHAN_REQUEST_TIMEOUT)
      p->active = false;
    if (!p->active) {
      snprintf(p->request_id, sizeof(p->request_id), "%s", request_id);
      snprintf(p->requester_uuid, sizeof(p->requester_uuid), "%s",
               requester_uuid);
      snprintf(p->kind, sizeof(p->kind), "%s", kind);
      snprintf(p->channel, sizeof(p->channel), "%s", channel);
      p->origin_fd = origin_fd;
      p->origin_serial = fd_conn_serial(state, origin_fd);
      p->timestamp = now;
      p->active = true;
      return i;
    }
  }
  return -1;
}

static pending_chan_request_t *find_pending_chan_request(hub_state_t *state,
                                                        const char *request_id) {
  for (int i = 0; i < MAX_PENDING_CHAN_REQUESTS; i++) {
    if (state->pending_chan_requests[i].active &&
        strcmp(state->pending_chan_requests[i].request_id, request_id) == 0)
      return &state->pending_chan_requests[i];
  }
  return NULL;
}

/* Look up one `key` of a stored bot record (e.g. "h" hostmask, "n" nick).
 * Returns false when the bot or the key is unknown. */
static bool hub_bot_entry(hub_state_t *state, const char *uuid, const char *key,
                          char *out, size_t out_len) {
  for (int i = 0; i < state->bot_count; i++) {
    if (strcmp(state->bots[i].uuid, uuid) != 0)
      continue;
    for (int j = 0; j < state->bots[i].entry_count; j++) {
      if (strcmp(state->bots[i].entries[j].key, key) == 0) {
        snprintf(out, out_len, "%s", state->bots[i].entries[j].value);
        return out[0] != '\0';
      }
    }
    return false;
  }
  return false;
}

static void forward_chan_request_to_peers(hub_state_t *state,
                                          const char *request_id,
                                          const char *requester_uuid,
                                          const char *kind, const char *channel,
                                          const char *nick,
                                          const char *hostmask, int exclude_fd) {
  /* request_id|requester_uuid|kind|channel|nick|hostmask */
  char fwd[MAX_MASK_LEN + 256];
  snprintf(fwd, sizeof(fwd), "%s|%s|%s|%s|%s|%s", request_id, requester_uuid,
           kind, channel, nick ? nick : "", hostmask ? hostmask : "");

  int queued = 0;
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type == CLIENT_HUB && c->authenticated && c->fd != exclude_fd) {
      if (!peer_send_urgent(state, c, CMD_CHAN_FWD_REQUEST, fwd)) {
        hub_log_warning("[HUB] URGENT queue full forwarding CHAN_REQUEST to peer "
                "fd=%d — disconnecting\n", c->fd);
        hub_disconnect_client(state, c);
        i--;
        continue;
      }
      queued++;
    }
  }
  if (queued > 0)
    hub_log_debug("[HUB] Forwarded CHAN_FWD_REQUEST (id:%s %s %s) to %d peer(s)\n",
            request_id, kind, channel, queued);
}

/* Push the action to every authenticated local bot except the requester and
 * the peer it arrived from.  Returns how many bots were told. */
static int broadcast_chan_action(hub_state_t *state, const char *request_id,
                                 const char *requester_uuid, const char *kind,
                                 const char *channel, const char *nick,
                                 const char *hostmask) {
  char action[MAX_MASK_LEN + 256];
  snprintf(action, sizeof(action), "%s|%s|%s|%s|%s|%s", request_id, kind,
           channel, requester_uuid, nick ? nick : "", hostmask ? hostmask : "");

  int sent = 0;
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *bc = state->clients[i];
    if (bc->type != CLIENT_BOT || !bc->authenticated)
      continue;
    if (strcmp(bc->id, requester_uuid) == 0)
      continue; /* never ask the locked-out bot to help itself */
    if (send_cmd_to_bot(state, bc, CMD_CHAN_ACTION, action))
      sent++;
    else
      hub_log_warning("[HUB] Failed to send CHAN_ACTION to %s\n", hub_who_client(state, bc));
  }
  return sent;
}

/* Entry point shared by a local bot's request and a peer-forwarded one.
 * `origin_fd` is the peer fd to route a reply back to, or -1 when the
 * requester is one of our own bots. */
static void chan_request_dispatch(hub_state_t *state, const char *request_id,
                                  const char *requester_uuid, const char *kind,
                                  const char *channel, const char *nick,
                                  const char *hostmask, int origin_fd) {
  /* Only `key` sends anything back, so only `key` needs a pending slot. */
  if (strcmp(kind, "key") == 0 &&
      add_pending_chan_request(state, request_id, requester_uuid, kind, channel,
                               origin_fd) < 0) {
    hub_log_warning("[HUB] Pending channel-request table full — dropping %s for %s\n",
            kind, channel);
    return;
  }

  int told = broadcast_chan_action(state, request_id, requester_uuid, kind,
                                   channel, nick, hostmask);
  forward_chan_request_to_peers(state, request_id, requester_uuid, kind,
                                channel, nick, hostmask, origin_fd);
  hub_log_debug("[HUB] CHAN_REQUEST %s for %s (id:%s) delivered to %d local bot(s)\n",
          kind, channel, request_id, told);
}

/* The answer to a bot's own request (rid set): CMD_USER_CHAN_RESULT
 * rid|ok|detail, rid|none|detail or rid|denied|detail. */
static void chan_own_answer(hub_state_t *state, hub_client_t *client, const char *rid,
                            const char *status, const char *detail) {
  if (!rid || !rid[0]) return;
  char res[256];
  snprintf(res, sizeof(res), "%s|%s|%s", rid, status, detail);
  send_cmd_to_bot(state, client, CMD_USER_CHAN_RESULT, res);
}

static void process_chan_request(hub_state_t *state, hub_client_t *client,
                                 char *payload) {
  /* Payload from a bot: `kind|channel`, or (2.5.4) `kind|channel|rid`, the
   * rid asking for an answer.  Everything that could be forged is resolved
   * here from the authenticated bot's own records. */
  char kind[8] = "", channel[MAX_CHAN] = "", rid[USER_CHAN_RID_MAX + 1] = "";
  int nf = payload ? mf_field_count(payload) : 0;
  if ((nf != 2 && nf != 3) || !wire_field(payload, 0, kind, sizeof(kind)) ||
      !wire_field(payload, 1, channel, sizeof(channel)) ||
      (nf == 3 && !wire_field(payload, 2, rid, sizeof(rid))) || !chan_kind_valid(kind)) {
    hub_log_warning("[HUB] Invalid CHAN_REQUEST payload from %s\n", hub_who_client(state, client));
    return;
  }
  for (const char *p = rid; *p; p++)
    if (!isalnum((unsigned char)*p) && *p != '-') {
      hub_log_warning("[HUB] CHAN_REQUEST from %s: bad request id\n",
                      hub_who_client(state, client));
      return;
    }
  /* op is the 2.5.4 election form only: a bot sends it with a rid */
  if (strcmp(kind, "op") == 0 && !rid[0]) {
    hub_log_warning("[HUB] CHAN_REQUEST op from %s without a request id\n",
                    hub_who_client(state, client));
    return;
  }
  if ((channel[0] != '#' && channel[0] != '&') || strchr(channel, ' ') || strchr(channel, ',')) {
    hub_log_warning("[HUB] CHAN_REQUEST from %s for non-channel '%s'\n",
                    hub_who_client(state, client),
            channel);
    chan_own_answer(state, client, rid, "denied", "not a channel");
    return;
  }

  char nick[MAX_NICK] = "", hostmask[MAX_MASK_LEN] = "";
  hub_bot_entry(state, client->id, "n", nick, sizeof(nick));
  hub_bot_entry(state, client->id, "h", hostmask, sizeof(hostmask));

  /* An unban can only be matched against a mask, an invite only sent to a
   * nick.  Without them the request is unserviceable, so say so rather than
   * flooding the mesh with something no bot can act on. */
  if (strcmp(kind, "unban") == 0 && hostmask[0] == '\0') {
    hub_log_warning("[HUB] No hostmask for %s — cannot service unban for %s\n",
            hub_who_client(state, client), channel);
    chan_own_answer(state, client, rid, "none", "no hostmask on file");
    return;
  }
  if ((strcmp(kind, "invite") == 0 || strcmp(kind, "op") == 0) && nick[0] == '\0') {
    hub_log_warning("[HUB] No nick for %s — cannot service %s for %s\n",
            hub_who_client(state, client), kind, channel);
    chan_own_answer(state, client, rid, "none", "no nick on file");
    return;
  }

  hub_log_info("[HUB] CHAN_REQUEST %s from %s for %s\n", kind, hub_who_client(state, client),
               channel);

  /* Own op, every hub new enough: one election serves every local bot that
   * asks within CHAN_ELECT_BATCH_WAIT s (a new channel: all of them). */
  if (strcmp(kind, "op") == 0 && rid[0] && ce_batch_ok(state)) {
    if (!ce_batch_join(state, client, channel, nick, hostmask, rid))
      chan_own_answer(state, client, rid, "none", "too many channel requests in flight");
    return;
  }

  /* One bot answers it (CMD_CHAN_PROBE). */
  chan_elect_t *e = ce_start(state, kind, channel, client->id, nick, hostmask, NULL);
  if (!e) {
    chan_own_answer(state, client, rid, "none", "too many channel requests in flight");
    return;
  }
  if (rid[0]) {
    e->reply_fd = client->fd;
    e->reply_serial = client->conn_serial;
    e->reply_own = true;
    snprintf(e->reply_rid, sizeof(e->reply_rid), "%s", rid);
  }
}

/* A bot answering a request (today only `key`).  Route it to the requester if
 * it is ours, otherwise back down the peer fd the request arrived on. */
static void process_chan_reply(hub_state_t *state, hub_client_t *client,
                               char *payload) {
  char request_id[64], kind[8], channel[MAX_CHAN], status[16];
  const char *data = "";

  /* Parsed straight out of `payload`: the %[^|] conversions do not write to
   * their source, so there is no second copy of the key to wipe afterwards. */
  if (sscanf(payload, "%63[^|]|%7[^|]|%64[^|]|%15[^|]", request_id, kind,
             channel, status) != 4) {
    hub_log_warning("[HUB] Invalid CHAN_REPLY payload from %s\n", hub_who_client(state, client));
    return;
  }
  /* The data field is the remainder after the 4th '|' — a channel key may
   * contain anything but whitespace, so it is never re-split. */
  int bars = 0;
  for (const char *p = payload; *p; p++) {
    if (*p == '|' && ++bars == 4) {
      data = p + 1;
      break;
    }
  }

  pending_chan_request_t *req = find_pending_chan_request(state, request_id);
  if (!req) {
    /* Late or duplicate answer — the first one already went home. */
    hub_log_warning("[HUB] CHAN_REPLY (id:%s) from %s matches no pending request\n",
            request_id, hub_who_client(state, client));
    return;
  }
  /* Bind the answer to what was actually asked: holding a request id must not
   * let a bot hand the requester a key for some other channel. */
  if (strcmp(req->kind, kind) != 0 || strcasecmp(req->channel, channel) != 0) {
    hub_log_warning("[HUB] CHAN_REPLY (id:%s) from %s answers %s/%s but the request "
            "was %s/%s — dropped\n", request_id, hub_who_client(state, client), kind, channel,
            req->kind, req->channel);
    return;
  }
  /* A bot answering its own request tells us nothing. */
  if (strcmp(client->id, req->requester_uuid) == 0)
    return;

  char out[MAX_BUFFER];
  snprintf(out, sizeof(out), "%s|%s|%s|%s|%s", request_id, kind, channel,
           status, data);

  if (req->origin_fd == -1) {
    hub_client_t *target = NULL;
    for (int i = 0; i < state->client_count; i++) {
      if (state->clients[i]->type == CLIENT_BOT &&
          state->clients[i]->authenticated &&
          strcmp(state->clients[i]->id, req->requester_uuid) == 0) {
        target = state->clients[i];
        break;
      }
    }
    if (target && send_cmd_to_bot(state, target, CMD_CHAN_REPLY, out))
      hub_log_info("[HUB] CHAN_REPLY %s for %s delivered to %s\n", kind, channel,
              hub_who(state, 'b', req->requester_uuid));
    else
      hub_log_warning("[HUB] CHAN_REPLY %s for %s undeliverable to %s\n", kind, channel,
              hub_who(state, 'b', req->requester_uuid));
  } else {
    for (int i = 0; i < state->client_count; i++) {
      hub_client_t *c = state->clients[i];
      if (c->type == CLIENT_HUB && c->authenticated &&
          c->fd == req->origin_fd && c->conn_serial == req->origin_serial) {
        if (!peer_send_urgent(state, c, CMD_CHAN_FWD_REPLY, out))
          hub_log_warning("[HUB] URGENT queue full routing CHAN_REPLY to peer fd=%d\n",
                  c->fd);
        else
          hub_log_debug("[HUB] CHAN_REPLY %s for %s sent back as CHAN_FWD_REPLY to "
                  "peer fd=%d\n", kind, channel, c->fd);
        break;
      }
    }
  }

  req->active = false;
  secure_wipe(out, sizeof(out));
}

static void process_forward_chan_request(hub_state_t *state,
                                         hub_client_t *client, char *payload) {
  char request_id[64], requester_uuid[64], kind[8], channel[MAX_CHAN];
  char nick[MAX_NICK] = "", hostmask[MAX_MASK_LEN] = "";

  int parsed = sscanf(payload, "%63[^|]|%63[^|]|%7[^|]|%64[^|]|%31[^|]|%255[^|]",
                      request_id, requester_uuid, kind, channel, nick, hostmask);
  if (parsed < 4 || !chan_kind_valid(kind)) {
    hub_log_warning("[HUB] Invalid CHAN_FWD_REQUEST from peer fd=%d\n", client->fd);
    return;
  }
  /* Second sighting of this id: another path already delivered it. */
  if (op_forward_seen_check_and_add(state, request_id))
    return;

  hub_log_debug("[HUB] CHAN_FWD_REQUEST %s for %s (id:%s) from peer fd=%d\n", kind,
          channel, request_id, client->fd);
  chan_request_dispatch(state, request_id, requester_uuid, kind, channel, nick,
                        hostmask, client->fd);
}

static void process_forward_chan_reply(hub_state_t *state, hub_client_t *client,
                                       char *payload) {
  char request_id[64];
  if (sscanf(payload, "%63[^|]", request_id) != 1) {
    hub_log_warning("[HUB] Invalid CHAN_FWD_REPLY from peer fd=%d\n", client->fd);
    return;
  }
  pending_chan_request_t *req = find_pending_chan_request(state, request_id);
  if (!req)
    return; /* not ours, or already answered */

  if (req->origin_fd == -1) {
    for (int i = 0; i < state->client_count; i++) {
      if (state->clients[i]->type == CLIENT_BOT &&
          state->clients[i]->authenticated &&
          strcmp(state->clients[i]->id, req->requester_uuid) == 0) {
        send_cmd_to_bot(state, state->clients[i], CMD_CHAN_REPLY, payload);
        hub_log_debug("[HUB] CHAN_FWD_REPLY (id:%s) from peer fd=%d delivered to %s\n",
                request_id, client->fd, hub_who(state, 'b', req->requester_uuid));
        break;
      }
    }
  } else {
    for (int i = 0; i < state->client_count; i++) {
      hub_client_t *c = state->clients[i];
      if (c->type == CLIENT_HUB && c->authenticated && c->fd == req->origin_fd &&
          c->conn_serial == req->origin_serial) {
        peer_send_urgent(state, c, CMD_CHAN_FWD_REPLY, payload);
        hub_log_debug("[HUB] CHAN_FWD_REPLY (id:%s) relayed on toward its origin "
                "(peer fd=%d)\n", request_id, c->fd);
        break;
      }
    }
  }
  req->active = false;
}

/* ========== Channel-request election (see CMD_CHAN_PROBE in hub.h) ==========
 * One bot acts.  This hub asks its own bots, hands the action to one that
 * said yes, and -- when it started the request and none of its own can --
 * asks the rest of the mesh the same question and hands it to one hub that
 * has a ready bot.  Every step is bounded by a wait in hub.h, so a console
 * waiting for the answer always gets one. */

static chan_elect_t *ce_find(hub_state_t *state, const char *id) {
  for (int i = 0; i < MAX_CHAN_ELECTIONS; i++)
    if (state->chan_elections[i].active && strcmp(state->chan_elections[i].id, id) == 0)
      return &state->chan_elections[i];
  return NULL;
}

/* End an election: the slot is free and a `who` answer's buffer and a
 * batch's targets go. */
static void ce_release(chan_elect_t *e) {
  chanwho_reset(&e->who);
  free(e->tg);
  e->tg = NULL;
  e->tg_n = 0;
  e->active = false;
}

static int ce_in_flight(const hub_state_t *state) {
  int n = 0;
  for (int i = 0; i < MAX_CHAN_ELECTIONS; i++) n += state->chan_elections[i].active;
  return n;
}

/* A bot's own request: the requester is neither the console nor a person. */
static bool ce_own_requester(const hub_state_t *state, const char *requester) {
  if (!requester[0] || strcmp(requester, "ADMIN") == 0) return false;
  for (int i = 0; i < state->user_record_count; i++)
    if (strcmp(state->user_records[i].uuid, requester) == 0) return false;
  return true;
}

/* "Election table full": the first refusal is logged, the rest are counted
 * and logged as one line every CHAN_ELECT_FULL_LOG s (ce_full_flush). */
static time_t g_ce_full_at;
static unsigned g_ce_full_n;

static void ce_full_flush(time_t now) {
  if (g_ce_full_n == 0 || now - g_ce_full_at < CHAN_ELECT_FULL_LOG) return;
  hub_log_warning("[CHANREQ] Election table full: %u more request(s) refused in the last %d s\n",
                  g_ce_full_n, CHAN_ELECT_FULL_LOG);
  g_ce_full_n = 0;
  g_ce_full_at = now;
}

static void ce_full_note(const hub_state_t *state, bool own, const char *kind,
                         const char *channel) {
  time_t now = time(NULL);
  g_hub_stats.el_refused++;
  if (g_ce_full_at && now - g_ce_full_at < CHAN_ELECT_FULL_LOG) {
    g_ce_full_n++;
    return;
  }
  g_ce_full_at = now;
  if (own)
    hub_log_warning("[CHANREQ] Election table full (%d in flight, %d kept for the console): "
                    "refused %s for %s; further refusals are counted\n",
                    ce_in_flight(state), CHAN_ELECT_RESERVE, kind, channel);
  else
    hub_log_warning("[CHANREQ] Election table full (%d in flight): refused %s for %s; "
                    "further refusals are counted\n",
                    ce_in_flight(state), kind, channel);
}

/* A free slot, or NULL (logged).  A bot's own request leaves the last
 * CHAN_ELECT_RESERVE slots to the console and to persons. */
static chan_elect_t *ce_alloc(hub_state_t *state, bool own, const char *kind,
                              const char *channel) {
  if (own && ce_in_flight(state) >= MAX_CHAN_ELECTIONS - CHAN_ELECT_RESERVE) {
    ce_full_note(state, own, kind, channel);
    return NULL;
  }
  for (int i = 0; i < MAX_CHAN_ELECTIONS; i++)
    if (!state->chan_elections[i].active) {
      chan_elect_t *e = &state->chan_elections[i];
      ce_release(e);
      memset(e, 0, sizeof(*e));
      e->from_fd = e->admin_fd = e->reply_fd = -1;
      e->created = e->phase_at = time(NULL);
      g_hub_stats.el_started++;
      return e;
    }
  ce_full_note(state, own, kind, channel);
  return NULL;
}

/* A hub version that takes ELECT_END and batched own-op elections. */
static bool ce_version_new(const char *v) {
  return v && v[0] && hub_update_version_cmp(v, CHAN_ELECT_BATCH_MIN_HUB) >= 0;
}

/* Every hub this one knows (gossip and its own links) runs
 * CHAN_ELECT_BATCH_MIN_HUB or newer: only then may own op be batched. */
static bool ce_batch_ok(hub_state_t *state) {
  for (int j = 0; j < state->mesh_hub_count; j++)
    if (strcmp(state->mesh_hubs[j].uuid, state->hub_uuid) != 0 &&
        !ce_version_new(state->mesh_hubs[j].version))
      return false;
  for (int i = 0; i < state->client_count; i++) {
    const hub_client_t *c = state->clients[i];
    if (c->type == CLIENT_HUB && c->authenticated && !ce_version_new(peer_version_str(state, c)))
      return false;
  }
  return true;
}

/* A known hub's version from gossip ("" when unknown). */
static const char *ce_hub_version(const hub_state_t *state, const char *uuid) {
  for (int j = 0; j < state->mesh_hub_count; j++)
    if (strcmp(state->mesh_hubs[j].uuid, uuid) == 0) return state->mesh_hubs[j].version;
  return "";
}

/* ELECT_END to every 2.5.4+ peer except `skip`, once per election (the seen
 * ring, key "end:<eid>"). */
static void ce_end_send(hub_state_t *state, const char *id, const hub_client_t *skip) {
  char key[SEEN_FORWARD_ID_MAX];
  snprintf(key, sizeof(key), "end:%s", id);
  if (op_forward_seen_check_and_add(state, key)) return;
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c != skip && c->type == CLIENT_HUB && c->authenticated &&
        ce_version_new(peer_version_str(state, c)))
      peer_send_urgent(state, c, CMD_CHAN_ELECT_END, id);
  }
}

/* A uniformly drawn index below n (n > 0). */
static int ce_pick(int n) {
  uint32_t r = 0;
  if (RAND_bytes((unsigned char *)&r, sizeof(r)) != 1) r = (uint32_t)time(NULL);
  return (int)(r % (uint32_t)n);
}

static hub_client_t *ce_peer(hub_state_t *state, int fd, uint64_t serial) {
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type == CLIENT_HUB && c->authenticated && c->fd == fd && c->conn_serial == serial)
      return c;
  }
  return NULL;
}

static hub_client_t *ce_bot(hub_state_t *state, const char *uuid) {
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type == CLIENT_BOT && c->authenticated && !c->superseded &&
        strcmp(c->id, uuid) == 0)
      return c;
  }
  return NULL;
}

static int ce_count(const chan_elect_t *e, char st) {
  int n = 0;
  for (int i = 0; i < e->bot_n; i++)
    if (e->bots[i].st == st) n++;
  return n;
}

/* The batch target `uuid`, or NULL. */
static chan_elect_target_t *ce_target(const chan_elect_t *e, const char *uuid) {
  for (int i = 0; i < e->tg_n; i++)
    if (strcmp(e->tg[i].uuid, uuid) == 0) return &e->tg[i];
  return NULL;
}

static int ce_tg_count(const chan_elect_t *e, char st) {
  int n = 0;
  for (int i = 0; i < e->tg_n; i++) n += e->tg[i].st == st;
  return n;
}

static void ce_done_up_id(hub_state_t *state, chan_elect_t *e, const char *id,
                          const char *bot_uuid, const char *bot_nick, const char *status,
                          const char *detail);
static void ce_finish(hub_state_t *state, chan_elect_t *e, const char *status,
                      const char *by_uuid, const char *by_nick, const char *hub_name,
                      const char *detail);
static void ce_local_exhausted(hub_state_t *state, chan_elect_t *e);

/* Tell batch target t its answer: rid|status|detail to its bot (origin). */
static void ce_tg_answer(hub_state_t *state, const chan_elect_target_t *t, const char *status,
                         const char *detail) {
  for (int i = 0; t->reply_fd >= 0 && i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type != CLIENT_BOT || !c->authenticated || c->fd != t->reply_fd ||
        c->conn_serial != t->reply_serial)
      continue;
    char res[256];
    snprintf(res, sizeof(res), "%s|%s|%s", t->rid, status, detail);
    send_cmd_to_bot(state, c, CMD_USER_CHAN_RESULT, res);
    return;
  }
}

/* Target t was served by bot `by` (ok) or refused for +bitch (!ok): the
 * origin answers its bot, a relay reports it toward the origin. */
static void ce_tg_served(hub_state_t *state, chan_elect_t *e, chan_elect_target_t *t, bool ok,
                         const char *by_uuid, const char *by_nick, const char *hub_name,
                         const char *detail) {
  t->st = ok ? 'o' : 'x';
  if (!e->origin) {
    char sub[sizeof(e->id) + sizeof(t->uuid) + 1];
    snprintf(sub, sizeof(sub), "%s.%s", e->id, t->uuid);
    ce_done_up_id(state, e, sub, by_uuid, by_nick, ok ? "ok" : "fail", ok ? detail : "bitch");
    return;
  }
  char d[200];
  if (ok)
    snprintf(d, sizeof(d), "op by %.31s on %.63s", by_nick && by_nick[0] ? by_nick : by_uuid,
             hub_name);
  else
    snprintf(d, sizeof(d), "not authorised on %.64s and +bitch is on", e->channel);
  ce_tg_answer(state, t, ok ? "ok" : "denied", d);
}

/* Hand every waiting target to one ready local bot: one CHAN_DO each, id
 * <eid>.<target>.  False when no ready bot is left. */
static bool ce_try_local_batch(hub_state_t *state, chan_elect_t *e) {
  for (;;) {
    int ready = ce_count(e, 'y');
    if (ready == 0) return false;
    int k = ce_pick(ready);
    chan_elect_bot_t *b = NULL;
    for (int i = 0; i < e->bot_n; i++)
      if (e->bots[i].st == 'y' && k-- == 0) {
        b = &e->bots[i];
        break;
      }
    if (!b) return false;
    b->st = 't';
    hub_client_t *c = ce_bot(state, b->uuid);
    int sent = 0;
    for (int i = 0; c && i < e->tg_n; i++) {
      chan_elect_target_t *t = &e->tg[i];
      if (t->st != 'p') continue;
      char act[MAX_MASK_LEN + 320];
      snprintf(act, sizeof(act), "%s.%s|op|%s|%s|%s|%s", e->id, t->uuid, e->channel, t->uuid,
               t->nick, t->hostmask);
      if (!send_cmd_to_bot(state, c, CMD_CHAN_DO, act)) break;
      t->st = 'd';
      sent++;
    }
    if (sent == 0) {
      snprintf(b->reason, sizeof(b->reason), "unreachable");
      continue;
    }
    snprintf(e->doing, sizeof(e->doing), "%s", b->uuid);
    e->phase = CE_LOCAL_DO;
    e->phase_at = time(NULL);
    return true;
  }
}

/* Nothing left to hand out: the origin ends, a relay reports "all served". */
static void ce_batch_complete(hub_state_t *state, chan_elect_t *e) {
  if (e->origin) {
    ce_finish(state, e, "ok", NULL, NULL, NULL, NULL);
    return;
  }
  ce_done_up_id(state, e, e->id, "", "", "ok", "batch done");
  e->doing[0] = '\0';
  e->phase = CE_ACKED;
  e->phase_at = time(NULL);
}

/* A batch's next step: done, the next ready local bot, or the mesh. */
static void ce_batch_next(hub_state_t *state, chan_elect_t *e) {
  if (ce_tg_count(e, 'p') == 0 && ce_tg_count(e, 'd') == 0) {
    ce_batch_complete(state, e);
    return;
  }
  if (!ce_try_local_batch(state, e)) ce_local_exhausted(state, e);
}

/* Ask every local bot except the requester. */
static void ce_probe_local(hub_state_t *state, chan_elect_t *e) {
  char probe[64 + 8 + MAX_CHAN + 4];
  snprintf(probe, sizeof(probe), "%s|%s|%s", e->id, e->kind, e->channel);
  e->bot_n = 0;
  for (int i = 0; i < state->client_count && e->bot_n < MAX_CLIENTS; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type != CLIENT_BOT || !c->authenticated) continue;
    if (strcmp(c->id, e->requester) == 0) continue; /* it cannot help itself */
    if (ce_target(e, c->id)) continue;               /* nor can a batch's bots */
    chan_elect_bot_t *b = &e->bots[e->bot_n++];
    snprintf(b->uuid, sizeof(b->uuid), "%s", c->id);
    bot_nick_from_config(state, c->id, b->nick, sizeof(b->nick));
    b->st = send_cmd_to_bot(state, c, CMD_CHAN_PROBE, probe) ? 'a' : 'n';
    if (b->st == 'n') snprintf(b->reason, sizeof(b->reason), "unreachable");
  }
  e->phase = CE_PROBE;
  e->phase_at = time(NULL);
}

/* Hand the action to one ready local bot.  False when none is left. */
static bool ce_try_local(hub_state_t *state, chan_elect_t *e) {
  if (e->tg) return ce_try_local_batch(state, e);
  for (;;) {
    int ready = ce_count(e, 'y');
    if (ready == 0) return false;
    int k = ce_pick(ready);
    chan_elect_bot_t *b = NULL;
    for (int i = 0; i < e->bot_n; i++)
      if (e->bots[i].st == 'y' && k-- == 0) {
        b = &e->bots[i];
        break;
      }
    if (!b) return false; /* k < ready: unreachable, but never deref NULL */
    b->st = 't';
    hub_client_t *c = ce_bot(state, b->uuid);
    char act[MAX_MASK_LEN + 256];
    bool mode = strcmp(e->kind, "mode") == 0, ban = strcmp(e->kind, "ban") == 0;
    if (mode)  /* the bot needs only eid|mode|channel */
      snprintf(act, sizeof(act), "%s|%s|%s", e->id, e->kind, e->channel);
    else
      snprintf(act, sizeof(act), "%s|%s|%s|%s|%s|%s", e->id, e->kind, e->channel,
               e->requester, ban && !e->nick[0] ? "*" : e->nick, e->hostmask);
    /* mode and ban act on records the bot must hold first (C|/c|, B|) */
    if (!c || !(mode || ban ? send_cmd_to_bot_after_config(state, c, CMD_CHAN_DO, act)
                            : send_cmd_to_bot(state, c, CMD_CHAN_DO, act))) {
      snprintf(b->reason, sizeof(b->reason), "unreachable");
      continue;
    }
    snprintf(e->doing, sizeof(e->doing), "%s", b->uuid);
    e->phase = CE_LOCAL_DO;
    e->phase_at = time(NULL);
    return true;
  }
}

/* "3 not opped, 1 not in channel" from our own bots' answers. */
static void ce_reasons(const chan_elect_t *e, char *out, size_t cap) {
  out[0] = '\0';
  bool used[MAX_CLIENTS] = {false};
  size_t o = 0;
  for (int i = 0; i < e->bot_n; i++) {
    if (used[i] || (e->bots[i].st != 'n' && e->bots[i].st != 't') || !e->bots[i].reason[0])
      continue;
    int n = 0;
    for (int j = i; j < e->bot_n; j++)
      if (!used[j] && (e->bots[j].st == 'n' || e->bots[j].st == 't') &&
          strcmp(e->bots[j].reason, e->bots[i].reason) == 0) {
        used[j] = true;
        n++;
      }
    int w = snprintf(out + o, cap - o, "%s%d %s", o ? ", " : "", n, e->bots[i].reason);
    if (w < 0 || (size_t)w >= cap - o) break;
    o += (size_t)w;
  }
}

static const char *ce_kind_word(const char *kind) {
  return strcmp(kind, "op") == 0       ? "op"
         : strcmp(kind, "invite") == 0 ? "invite"
         : strcmp(kind, "unban") == 0  ? "unban"
         : strcmp(kind, "mode") == 0   ? "mode"
         : strcmp(kind, "kick") == 0   ? "kick"
         : strcmp(kind, "ban") == 0    ? "ban"
         : strcmp(kind, "who") == 0    ? "who"
                                       : "key";
}

/* ---- `channel who` (kind "who", CMD_CHAN_WHO) ----------------------------- */

static void ce_up(hub_state_t *state, chan_elect_t *e, uint8_t cmd, const char *payload);

static void ce_who_answer(hub_state_t *state, hub_client_t *admin, chan_elect_t *e, bool ok,
                          const char *by_uuid, const char *by_nick, const char *hub_name,
                          const char *detail, int asked, int hubs) {
  char msg[256];
  if (!ok) {
    char why[160];
    ce_reasons(e, why, sizeof(why));
    if (!why[0] && detail && detail[0]) snprintf(why, sizeof(why), "%s", detail);
    if (!why[0] && asked > 0) snprintf(why, sizeof(why), "none is in the channel");
    int mw = snprintf(msg, sizeof(msg), "no bot could list %s: %d bot%s asked on %d hub%s%s%s",
                      e->channel, asked, asked == 1 ? "" : "s", hubs, hubs == 1 ? "" : "s",
                      why[0] ? "; " : "", why);
    if (mw < 0) msg[0] = '\0';
    admin_err(state, admin, "channel.nobody", msg,
              "a bot must be in the channel (it needs no ops)");
    return;
  }
  if (!chanwho_complete(&e->who)) {
    snprintf(msg, sizeof(msg), "%.31s answered for %.64s but its list did not arrive whole",
             by_nick && by_nick[0] ? by_nick : "a bot", e->channel);
    admin_err(state, admin, "channel.who_incomplete", msg, "channel who again");
    return;
  }
  chanwho_view_t v;
  if (chanwho_parse(e->who.buf, &v) < 0) {
    chanwho_view_free(&v);
    admin_err(state, admin, "internal.oom", "out of memory", NULL);
    return;
  }
  reply_t r;
  reply_init(&r);
  reply_ok(&r, "channel.who");
  reply_kv(&r, "chan", e->channel);
  reply_kv(&r, "by", by_nick && by_nick[0] ? by_nick : by_uuid);
  reply_kv(&r, "by_uuid", by_uuid);
  reply_kv(&r, "hub_name", hub_name);
  reply_kvi(&r, "asked", asked);
  reply_kvi(&r, "hubs", hubs);
  reply_kvb(&r, "topic_known", v.topic_known);
  reply_kv(&r, "topic", v.topic);
  reply_kv(&r, "topic_by", v.topic_by);
  reply_kvi(&r, "topic_at", v.topic_at);
  reply_kvb(&r, "modes_known", v.modes_known);
  reply_kv(&r, "modes", v.modes);
  reply_kvi(&r, "limit", v.limit);
  reply_kv(&r, "key", v.key);
  reply_kvi(&r, "total", v.n);
  reply_kvb(&r, "capped", v.capped);
  reply_kvi(&r, "ops", v.cnt[0]);
  reply_kvi(&r, "halfops", v.cnt[1]);
  reply_kvi(&r, "voices", v.cnt[2]);
  reply_kvi(&r, "normal", v.cnt[3]);
  static const char *const PFX[] = {"@", "%", "+", ""};
  for (int i = 0; i < v.n; i++) {
    reply_rec(&r, "nick");
    reply_kv(&r, "p", PFX[v.nicks[i].rank]);
    reply_kv(&r, "n", v.nicks[i].nick);
  }
  chanwho_view_free(&v);
  send_reply(state, admin, &r);
}

/* CHAN_WHO eid|seq|more|<chunk>: from the bot we picked, or from the peer on
 * the election's path.  A relay passes it up unchanged; the origin joins the
 * chunks (seq 0 starts afresh: a retry with the next bot). */
static void process_chan_who(hub_state_t *state, hub_client_t *client, const char *payload) {
  char id[64] = "", seqs[12] = "", more[4] = "";
  if (!payload || !wire_field(payload, 0, id, sizeof(id)) ||
      !wire_field(payload, 1, seqs, sizeof(seqs)) || !wire_field(payload, 2, more, sizeof(more)))
    return;
  const char *body = payload;
  for (int k = 0; k < 3; k++) {
    body = strchr(body, '|');
    if (!body) return;
    body++;
  }
  chan_elect_t *e = id[0] ? ce_find(state, id) : NULL;
  if (!e || strcmp(e->kind, "who") != 0) return;
  if (client->type == CLIENT_BOT) {
    if (e->phase != CE_LOCAL_DO || strcmp(e->doing, client->id) != 0) return;
  } else if (client->type == CLIENT_HUB) {
    if (!e->origin) {
      if (client->fd == e->from_fd && client->conn_serial == e->from_serial) return;
    } else {
      bool from_ok = false;
      for (int i = 0; e->phase == CE_MESH_DO && i < e->hub_n; i++)
        if (strcmp(e->hubs[i].uuid, e->doing) == 0 && e->hubs[i].fd == client->fd &&
            e->hubs[i].serial == client->conn_serial)
          from_ok = true;
      if (!from_ok) return;
    }
  } else {
    return;
  }
  if (!e->origin) {
    ce_up(state, e, CMD_CHAN_WHO, payload);
    return;
  }
  if (chanwho_add(&e->who, seqs, more, body, strlen(body)) == -2)
    hub_log_warning("[CHANREQ] channel who %s (id:%s): the answer is over %d bytes, dropped\n",
                    e->channel, e->id, CHAN_WHO_MAX);
}

/* The origin's end of an election: answer the console that asked, log, and
 * free the slot.  status: "ok" (one bot did it), "bitch" (refused, D12),
 * anything else = nobody could. */
/* A batched own op ends at the origin: every target still waiting gets
 * none (its bot may ask over IRC), one summary line, ELECT_END. */
static void ce_batch_finish(hub_state_t *state, chan_elect_t *e) {
  int asked = e->bot_n, hubs = 1;
  for (int i = 0; i < e->hub_n; i++) {
    asked += e->hubs[i].asked;
    hubs++;
  }
  char why[160], d[256];
  ce_reasons(e, why, sizeof(why));
  snprintf(d, sizeof(d), "no bot could: %d asked on %d hub%s%s%.120s", asked, hubs,
           hubs == 1 ? "" : "s", why[0] ? "; " : "", why);
  int left = 0;
  for (int i = 0; i < e->tg_n; i++)
    if (e->tg[i].st == 'p' || e->tg[i].st == 'd') {
      ce_tg_answer(state, &e->tg[i], "none", d);
      left++;
    }
  hub_log_info("[CHANREQ] own op for %d bot%s on %s (id:%s): %d opped, %d refused (+bitch), "
               "%d left to ask over IRC\n",
               e->tg_n, e->tg_n == 1 ? "" : "s", e->channel, e->id, ce_tg_count(e, 'o'),
               ce_tg_count(e, 'x'), left);
  if (e->flooded) ce_end_send(state, e->id, NULL);
  ce_release(e);
}

static void ce_finish(hub_state_t *state, chan_elect_t *e, const char *status,
                      const char *by_uuid, const char *by_nick, const char *hub_name,
                      const char *detail) {
  if (e->tg) {
    ce_batch_finish(state, e);
    return;
  }
  int asked = e->bot_n, hubs = 1;
  for (int i = 0; i < e->hub_n; i++) {
    asked += e->hubs[i].asked;
    hubs++;
  }
  bool ok = strcmp(status, "ok") == 0;
  bool bitch = strcmp(status, "bitch") == 0;
  /* a kick's target not in the channel, or a bot / authorised member: the
   * answer is about the nick, so no other bot was tried */
  bool absent = strcmp(status, "absent") == 0, prot = strcmp(status, "protected") == 0;
  bool ban = strcmp(e->kind, "ban") == 0;
  const char *tgt = strcmp(e->kind, "who") == 0 ? "members"
                    : e->nick[0]                ? e->nick
                    : ban && e->hostmask[0]     ? e->hostmask
                                                : e->requester;
  if (bitch)
    hub_log_info("[CHANREQ] %s %s on %s (id:%s): refused, not authorised and +bitch is on\n",
                 ce_kind_word(e->kind), tgt, e->channel,
                 e->id);
  else if (absent || prot)
    hub_log_info("[CHANREQ] %s %s on %s (id:%s): refused, %s\n", ce_kind_word(e->kind), tgt,
                 e->channel, e->id,
                 absent ? "not in the channel" : "a bot or an authorised member");
  else if (ok)
    hub_log_info("[CHANREQ] %s %s on %s (id:%s): done by %s on %s\n", ce_kind_word(e->kind),
                 tgt, e->channel, e->id,
                 by_uuid && by_uuid[0] ? hub_who(state, 'b', by_uuid) : by_nick, hub_name);
  else
    hub_log_info("[CHANREQ] %s %s on %s (id:%s): nobody could (%s)\n", ce_kind_word(e->kind),
                 tgt, e->channel, e->id,
                 detail && detail[0] ? detail : status);

  /* a person's request from a bot: the answer goes back to that bot */
  for (int i = 0; e->reply_fd >= 0 && i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type != CLIENT_BOT || !c->authenticated || c->fd != e->reply_fd ||
        c->conn_serial != e->reply_serial)
      continue;
    char res[256];
    if (e->reply_own) {
      /* a bot's own request: ok / denied (policy: no ~B2 around it) / none
       * (nobody on any hub could: the bot may ask over IRC) */
      if (ok)
        snprintf(res, sizeof(res), "%s|ok|%s by %.31s on %.63s", e->reply_rid,
                 ce_kind_word(e->kind), by_nick && by_nick[0] ? by_nick : by_uuid, hub_name);
      else if (bitch)
        snprintf(res, sizeof(res), "%s|denied|not authorised on %.64s and +bitch is on",
                 e->reply_rid, e->channel);
      else {
        char why[160];
        ce_reasons(e, why, sizeof(why));
        snprintf(res, sizeof(res), "%s|none|no bot could: %d asked on %d hub%s%s%.120s",
                 e->reply_rid, asked, hubs, hubs == 1 ? "" : "s", why[0] ? "; " : "", why);
      }
    } else if (bitch)
      snprintf(res, sizeof(res), "%s|fail|not authorised on %.64s and +bitch is on",
               e->reply_rid, e->channel);
    else if (ok)
      snprintf(res, sizeof(res), "%s|ok|%s by %.31s on %.63s", e->reply_rid,
               ce_kind_word(e->kind), by_nick && by_nick[0] ? by_nick : by_uuid, hub_name);
    else {
      char why[160];
      ce_reasons(e, why, sizeof(why));
      snprintf(res, sizeof(res), "%s|fail|no bot could: %d asked on %d hub%s%s%.120s",
               e->reply_rid, asked, hubs, hubs == 1 ? "" : "s", why[0] ? "; " : "", why);
    }
    send_cmd_to_bot(state, c, CMD_USER_CHAN_RESULT, res);
    break;
  }

  hub_client_t *admin = NULL;
  for (int i = 0; e->admin_fd >= 0 && i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->internal && c->fd == e->admin_fd && c->conn_serial == e->admin_serial) admin = c;
  }
  if (admin && strcmp(e->kind, "who") == 0) {
    ce_who_answer(state, admin, e, ok, by_uuid, by_nick, hub_name, detail, asked, hubs);
  } else if (admin && ban) {
    /* ban add / channel ban: the ban is stored whatever happened; the answer
     * says whether one bot set it now (placed) or why not (the bots' sweep
     * keeps trying) */
    reply_t r;
    reply_init(&r);
    reply_ok(&r, "ban.added");
    reply_kv(&r, "chan", e->channel);
    reply_kv(&r, "mask", e->hostmask);
    reply_kvi(&r, "expires", (long long)e->ban_expires);
    reply_kvb(&r, "sticky", e->ban_sticky);
    reply_kv(&r, "reason", e->ban_reason);
    reply_kvb(&r, "existed", e->ban_existed);
    reply_kvi(&r, "bots", local_bot_count(state));
    reply_kvi(&r, "peers", linked_peer_count(state));
    reply_kvb(&r, "placed", ok);
    if (strcmp(status, "dynamic") == 0) reply_kvb(&r, "dynamic", true);
    if (ok) {
      reply_kv(&r, "by", by_nick && by_nick[0] ? by_nick : by_uuid);
      reply_kv(&r, "by_uuid", by_uuid);
      reply_kv(&r, "hub_name", hub_name);
      if (detail && detail[0]) reply_kv(&r, "detail", detail);
    } else {
      char why[160];
      ce_reasons(e, why, sizeof(why));
      if (strcmp(status, "dynamic") == 0)
        snprintf(why, sizeof(why), "+dynamicbans: it goes on while someone it matches is there");
      if (!why[0] && detail && detail[0]) snprintf(why, sizeof(why), "%s", detail);
      if (!why[0]) snprintf(why, sizeof(why), "no bot is in the channel and opped");
      reply_kv(&r, "why", why);
    }
    reply_kvi(&r, "asked", asked);
    reply_kvi(&r, "hubs", hubs);
    send_reply(state, admin, &r);
  } else if (admin && (absent || prot)) {
    char msg[256], hint[160];
    if (absent) {
      snprintf(msg, sizeof(msg), "%.31s is not in %.64s", e->nick, e->channel);
      snprintf(hint, sizeof(hint), "check the nick: the bots see the channel's members");
    } else {
      snprintf(msg, sizeof(msg), "%.31s is a bot or an authorised user in %.64s", e->nick,
               e->channel);
      snprintf(hint, sizeof(hint), "the bots never kick their own or a known user");
    }
    admin_err(state, admin, absent ? "channel.not_present" : "channel.protected", msg, hint);
  } else if (admin && bitch) {
    /* A bot answered fail|bitch: the nick is not authorised on a +bitch
     * channel (D12).  Deterministic for that nick, so no other bot is tried. */
    char msg[256];
    snprintf(msg, sizeof(msg),
             "%.31s is not authorised on %.64s and +bitch is on", e->nick, e->channel);
    char hint[160];
    snprintf(hint, sizeof(hint),
             "add the user as an operator, or channel set %.64s -bitch", e->channel);
    admin_err(state, admin, "channel.not_authorised", msg, hint);
  } else if (admin) {
    char code[24];
    snprintf(code, sizeof(code), "channel.%s", e->kind);
    if (ok) {
      reply_t r;
      reply_init(&r);
      reply_ok(&r, code);
      if (e->nick[0] || strcmp(e->kind, "mode") != 0) reply_kv(&r, "nick", e->nick);
      reply_kv(&r, "chan", e->channel);
      reply_kv(&r, "by", by_nick && by_nick[0] ? by_nick : by_uuid);
      reply_kv(&r, "by_uuid", by_uuid);
      reply_kv(&r, "hub_name", hub_name);
      if (detail && detail[0]) reply_kv(&r, "detail", detail);
      if (strcmp(e->kind, "kick") == 0) reply_kv(&r, "reason", e->hostmask);
      reply_kvi(&r, "asked", asked);
      reply_kvi(&r, "hubs", hubs);
      if (strcmp(e->kind, "mode") == 0) {
        char cn[MAX_CHAN];
        if (hub_chan_live(state, e->channel, cn, sizeof(cn))) {
          /* the stored string and the warnings ride the apply answer: it is
           * the one reply channel mode gets */
          char eff_chan[MAX_CHAN];
          snprintf(eff_chan, sizeof(eff_chan), "%s", cn);
          mf_mode_card_extra(state, &r, eff_chan);
        }
      }
      send_reply(state, admin, &r);
    } else {
      char msg[256], why[160];
      ce_reasons(e, why, sizeof(why));
      /* Only our own bots' reasons travel; the other hubs send counts. */
      if (!why[0] && !(detail && detail[0]) && asked > 0)
        snprintf(why, sizeof(why), "none is in the channel and opped");
      /* A long reason list is cut at 255 bytes, as irchub.rs cuts it
       * (trunc_string(.., 256)); only an encoding error leaves no text. */
      int mw;
      if (strcmp(e->kind, "mode") == 0)
        mw = snprintf(msg, sizeof(msg), "no bot could apply the modes of %s: %d bot%s asked on %d hub%s%s%s",
                      e->channel, asked, asked == 1 ? "" : "s", hubs, hubs == 1 ? "" : "s",
                      why[0] || (detail && detail[0]) ? "; " : "",
                      why[0] ? why : (detail ? detail : ""));
      else
        mw = snprintf(msg, sizeof(msg), "no bot could %s %s on %s: %d bot%s asked on %d hub%s%s%s",
                      ce_kind_word(e->kind), e->nick, e->channel, asked, asked == 1 ? "" : "s", hubs,
                      hubs == 1 ? "" : "s", why[0] || (detail && detail[0]) ? "; " : "",
                      why[0] ? why : (detail ? detail : ""));
      if (mw < 0) msg[0] = '\0';
      if (strcmp(e->kind, "mode") == 0) {
        /* the modes were stored before the election: say so */
        reply_t er;
        reply_init(&er);
        reply_err(&er, "channel.nobody", msg,
                  "the modes are stored; a bot must be in the channel and opped there to "
                  "apply them (channel mode again)");
        reply_kvb(&er, "stored", true);
        send_reply(state, admin, &er);
      } else {
        admin_err(state, admin, "channel.nobody", msg,
                  "a bot must be in the channel and opped there");
      }
    }
  }
  if (e->flooded) ce_end_send(state, e->id, NULL); /* the relays free their copies */
  ce_release(e);
}

/* A relay hub's report back toward the origin. */
static void ce_up(hub_state_t *state, chan_elect_t *e, uint8_t cmd, const char *payload) {
  hub_client_t *p = ce_peer(state, e->from_fd, e->from_serial);
  if (p) peer_send_urgent(state, p, cmd, payload);
}

static void ce_done_up_id(hub_state_t *state, chan_elect_t *e, const char *id,
                          const char *bot_uuid, const char *bot_nick, const char *status,
                          const char *detail) {
  char buf[512];
  snprintf(buf, sizeof(buf), "%s|%s|%s|%s|%s|%s|%s", id, state->hub_uuid,
           hub_display_name(state), bot_uuid, bot_nick, status, detail);
  ce_up(state, e, CMD_CHAN_ELECT_DONE, buf);
}

static void ce_done_up(hub_state_t *state, chan_elect_t *e, const char *bot_uuid,
                       const char *bot_nick, const char *status, const char *detail) {
  ce_done_up_id(state, e, e->id, bot_uuid, bot_nick, status, detail);
}

/* Origin, nobody local can: the next hub with a ready bot, else nobody.  A
 * bot that never answered the probe is not handed a blind old-style request:
 * every bot the mesh admits (MESH_MIN_VERSION) answers probes, so silence
 * means busy or gone, and the old fan-out skipped +bitch (D12). */
static void ce_try_hub(hub_state_t *state, chan_elect_t *e) {
  int ready = 0;
  /* a batch goes only to a hub that reads its target list */
  for (int i = 0; i < e->hub_n; i++)
    if (e->tg && !ce_version_new(ce_hub_version(state, e->hubs[i].uuid))) e->hubs[i].tried = true;
  for (int i = 0; i < e->tg_n; i++)
    if (e->tg[i].st == 'd') e->tg[i].st = 'p'; /* the last hub's leftovers */
  if (e->tg && ce_tg_count(e, 'p') == 0) {
    ce_finish(state, e, "ok", NULL, NULL, NULL, NULL);
    return;
  }
  for (int i = 0; i < e->hub_n; i++)
    if (!e->hubs[i].tried && e->hubs[i].ready > 0) ready++;
  if (ready > 0) {
    int k = ce_pick(ready);
    for (int i = 0; i < e->hub_n; i++) {
      chan_elect_hub_t *h = &e->hubs[i];
      if (h->tried || h->ready <= 0 || k-- != 0) continue;
      h->tried = true;
      hub_client_t *p = ce_peer(state, h->fd, h->serial);
      char buf[160 + CHAN_ELECT_BATCH_MAX * 65];
      int n = snprintf(buf, sizeof(buf), "%s|%s|elect", e->id, h->uuid);
      bool first = true;
      for (int j = 0; e->tg && j < e->tg_n && n > 0 && (size_t)n < sizeof(buf); j++) {
        if (e->tg[j].st != 'p') continue;
        n += snprintf(buf + n, sizeof(buf) - (size_t)n, "%c%s", first ? '|' : ',',
                      e->tg[j].uuid);
        first = false;
      }
      if (!p || !peer_send_urgent(state, p, CMD_CHAN_ELECT_DO, buf)) break;
      for (int j = 0; j < e->tg_n; j++)
        if (e->tg[j].st == 'p') e->tg[j].st = 'd';
      snprintf(e->doing, sizeof(e->doing), "%s", h->uuid);
      e->phase = CE_MESH_DO;
      e->phase_at = time(NULL);
      return;
    }
    ce_try_hub(state, e); /* that hub's link went away: the next one */
    return;
  }
  ce_finish(state, e, "nobody", NULL, NULL, NULL, NULL);
}

/* Hubs this one knows, itself included: what its ELECT_ACK reports. */
static int ce_mesh_total(const hub_state_t *state) {
  int n = 1;
  for (int j = 0; j < state->mesh_hub_count; j++)
    if (strcmp(state->mesh_hubs[j].uuid, state->hub_uuid) != 0) n++;
  return n;
}

/* True while this hub's picture of the mesh is still being built: it started
 * moments ago and configured peers are not all linked yet, or a peer linked
 * moments ago has not yet named its version (no sync exchanged).  An origin
 * that asked the mesh then would take a few neighbours for all of it. */
static bool ce_mesh_settling(const hub_state_t *state, time_t now) {
  if (state->hub_started > 0 && now - state->hub_started < CHAN_ELECT_SETTLE &&
      linked_peer_count(state) < state->peer_count)
    return true;
  for (int i = 0; i < state->client_count; i++) {
    const hub_client_t *c = state->clients[i];
    if (c->type == CLIENT_HUB && c->authenticated && c->sync_held &&
        now - c->connected_at < CHAN_ELECT_SETTLE)
      return true;
  }
  return false;
}

/* A bot authenticated here that the election has not asked yet. */
static bool ce_new_local_bot(const hub_state_t *state, const chan_elect_t *e) {
  for (int i = 0; i < state->client_count; i++) {
    const hub_client_t *c = state->clients[i];
    if (c->type != CLIENT_BOT || !c->authenticated || strcmp(c->id, e->requester) == 0 ||
        ce_target(e, c->id))
      continue;
    bool asked = false;
    for (int j = 0; j < e->bot_n && !asked; j++) asked = strcmp(e->bots[j].uuid, c->id) == 0;
    if (!asked) return true;
  }
  return false;
}

/* Nothing (more) to do locally: the origin asks the mesh, a relay says so. */
static void ce_local_exhausted(hub_state_t *state, chan_elect_t *e) {
  if (!e->origin) {
    ce_done_up(state, e, "", "", "fail", "no ready bot");
    e->phase = CE_ACKED;
    return;
  }
  time_t now = time(NULL);
  /* Held once, not re-sent: the one election waits for the mesh view and
   * then runs; the requester is answered either way, nothing is repeated. */
  if (!e->held && e->phase != CE_MESH_DO && e->hub_n == 0 && ce_mesh_settling(state, now)) {
    e->held = true;
    e->phase = CE_HOLD;
    e->phase_at = now;
    hub_log_debug("[CHANREQ] Election %s: mesh view still settling, held up to %d s\n", e->id,
                  CHAN_ELECT_HOLD_MAX);
    return;
  }
  if (e->phase == CE_MESH_DO || e->hub_n > 0) { /* the mesh was asked already */
    ce_try_hub(state, e);
    return;
  }
  if (linked_peer_count(state) == 0) {
    ce_try_hub(state, e);
    return;
  }
  char fwd[MAX_MASK_LEN + 320];
  snprintf(fwd, sizeof(fwd), "%s|%s|%s|%s|%s|%s|%s|%lld", e->id, state->hub_uuid,
           e->kind, e->channel, e->requester, e->nick, e->hostmask, (long long)time(NULL));
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type == CLIENT_HUB && c->authenticated)
      peer_send_urgent(state, c, CMD_CHAN_ELECT_FWD, fwd);
  }
  e->flooded = true;
  e->phase = CE_MESH_WAIT;
  e->phase_at = time(NULL);
}

/* Start an election on this hub (the origin).  admin: the console owed the
 * answer, or NULL.  False when the table is full (nothing was sent). */
static chan_elect_t *ce_start_x(hub_state_t *state, const char *kind, const char *channel,
                                const char *requester, const char *nick, const char *hostmask,
                                const hub_client_t *admin, bool gather) {
  chan_elect_t *e = ce_alloc(state, ce_own_requester(state, requester), kind, channel);
  if (!e) return NULL;
  if (strcmp(kind, "key") == 0) {
    char rid[64];
    generate_request_id(rid, sizeof(rid));
    if (add_pending_chan_request(state, rid, requester, kind, channel, -1) < 0) return NULL;
    snprintf(e->id, sizeof(e->id), "%s", rid);
  } else {
    generate_request_id(e->id, sizeof(e->id));
  }
  op_forward_seen_check_and_add(state, e->id);
  e->active = true;
  e->origin = true;
  /* The answer is bound to this connection, not just its fd: a console that
   * closes and a new one that takes over the fd must never meet. */
  e->admin_fd = admin ? admin->fd : -1;
  e->admin_serial = admin ? admin->conn_serial : 0;
  snprintf(e->kind, sizeof(e->kind), "%s", kind);
  snprintf(e->channel, sizeof(e->channel), "%s", channel);
  snprintf(e->requester, sizeof(e->requester), "%s", requester);
  snprintf(e->nick, sizeof(e->nick), "%s", nick ? nick : "");
  snprintf(e->hostmask, sizeof(e->hostmask), "%s", hostmask ? hostmask : "");
  if (gather) {
    e->phase = CE_GATHER;
    e->phase_at = time(NULL);
    hub_log_debug("[CHANREQ] Election %s: own op on %s, gathering %d s\n", e->id, channel,
                  CHAN_ELECT_BATCH_WAIT);
    return e;
  }
  ce_probe_local(state, e);
  hub_log_debug("[CHANREQ] Election %s: %s %s on %s, %d local bot(s) asked\n", e->id, kind,
                e->nick[0] ? e->nick : requester, channel, e->bot_n);
  return e;
}

static chan_elect_t *ce_start(hub_state_t *state, const char *kind, const char *channel,
                              const char *requester, const char *nick, const char *hostmask,
                              const hub_client_t *admin) {
  return ce_start_x(state, kind, channel, requester, nick, hostmask, admin, false);
}

/* A local bot's own op: into the batch gathering for that channel, else a
 * new one.  False when the table is full. */
static bool ce_batch_join(hub_state_t *state, hub_client_t *client, const char *channel,
                          const char *nick, const char *hostmask, const char *rid) {
  chan_elect_t *e = NULL;
  for (int i = 0; i < MAX_CHAN_ELECTIONS && !e; i++) {
    chan_elect_t *x = &state->chan_elections[i];
    if (x->active && x->origin && x->tg && x->phase == CE_GATHER &&
        strcasecmp(x->channel, channel) == 0 &&
        (x->tg_n < CHAN_ELECT_BATCH_MAX || ce_target(x, client->id)))
      e = x;
  }
  bool fresh = !e;
  if (fresh) {
    e = ce_start_x(state, "op", channel, client->id, nick, hostmask, NULL, true);
    if (!e) return false;
    e->tg = calloc(CHAN_ELECT_BATCH_MAX, sizeof(*e->tg));
    if (!e->tg) {
      ce_release(e);
      return false;
    }
  }
  chan_elect_target_t *t = ce_target(e, client->id);
  if (!t) {
    t = &e->tg[e->tg_n++];
    if (!fresh) g_hub_stats.el_batched++;
  }
  snprintf(t->uuid, sizeof(t->uuid), "%s", client->id);
  snprintf(t->nick, sizeof(t->nick), "%s", nick);
  snprintf(t->hostmask, sizeof(t->hostmask), "%s", hostmask);
  snprintf(t->rid, sizeof(t->rid), "%s", rid);
  t->reply_fd = client->fd;
  t->reply_serial = client->conn_serial;
  t->st = 'p';
  return true;
}

/* A field of a person's request: 1..max-1 bytes, no blank, '|' or control. */
static bool uchan_field_ok(const char *s, size_t max) {
  size_t n = strlen(s);
  if (n == 0 || n >= max) return false;
  for (const char *p = s; *p; p++)
    if ((unsigned char)*p <= 0x20 || *p == 0x7f || *p == '|') return false;
  return true;
}

/* CMD_USER_CHAN_REQUEST (user_flags plan §5): rid|kind|#chan|user_uuid|nick|
 * nick!user@host from a bot that could not act itself.  The bot is
 * authenticated but not trusted with policy: the user's rights are checked
 * again here (an admin +c / +a, or an oper bound to the channel or *).  The
 * nick and hostmask are what the IRC server showed the bot. */
static void process_user_chan_request(hub_state_t *state, hub_client_t *client,
                                      const char *payload) {
  char rid[USER_CHAN_RID_MAX + 1] = "", kind[8] = "", chan[MAX_CHAN] = "", uuid[40] = "";
  char nick[MAX_NICK] = "", mask[MAX_MASK_LEN] = "";
  time_t now = time(NULL);
  if (now - client->uchan_req_window >= USER_CHAN_REQ_WINDOW) {
    client->uchan_req_window = now;
    client->uchan_req_count = 0;
  }
  if (++client->uchan_req_count > USER_CHAN_REQ_MAX) {
    if (client->uchan_req_count == USER_CHAN_REQ_MAX + 1)
      hub_log_warning("[CHANREQ] %s sends too many user requests; dropping\n",
                      hub_who_client(state, client));
    return;
  }
  if (!payload || mf_field_count(payload) != 6 || !wire_field(payload, 0, rid, sizeof(rid)) ||
      !wire_field(payload, 1, kind, sizeof(kind)) || !wire_field(payload, 2, chan, sizeof(chan)) ||
      !wire_field(payload, 3, uuid, sizeof(uuid)) || !wire_field(payload, 4, nick, sizeof(nick)) ||
      !wire_field(payload, 5, mask, sizeof(mask))) {
    hub_log_warning("[CHANREQ] Malformed USER_CHAN_REQUEST from %s\n",
                    hub_who_client(state, client));
    return;
  }
  for (const char *p = rid; *p; p++)
    if (!isalnum((unsigned char)*p) && *p != '-') rid[0] = '\0';
  char res[256];
  if (!rid[0]) {
    hub_log_warning("[CHANREQ] Bad request id from %s\n", hub_who_client(state, client));
    return;
  }
#define UCR_FAIL(...)                                                         \
  do {                                                                        \
    int n_ = snprintf(res, sizeof(res), "%s|fail|", rid);                     \
    if (n_ > 0 && (size_t)n_ < sizeof(res))                                   \
      snprintf(res + n_, sizeof(res) - (size_t)n_, __VA_ARGS__);              \
    send_cmd_to_bot(state, client, CMD_USER_CHAN_RESULT, res);                       \
    return;                                                                   \
  } while (0)
  if (strcmp(kind, "op") != 0 && strcmp(kind, "invite") != 0 && strcmp(kind, "unban") != 0)
    UCR_FAIL("unknown request");
  if (!hub_uchan_name_ok(chan) || strcmp(chan, "*") == 0) UCR_FAIL("not a channel");
  /* the mask is the person's live identity, never a pattern: the bot that
   * acts checks the nick against it, and an unban matches bans to it */
  if (!uchan_field_ok(nick, sizeof(nick)) || !uchan_field_ok(mask, sizeof(mask)) ||
      !strchr(mask, '!') || !strchr(mask, '@') || !hub_hostmask_literal(mask))
    UCR_FAIL("bad nick or hostmask");
  const hub_user_record_t *u = NULL;
  for (int i = 0; i < state->user_record_count && !u; i++)
    if (state->user_records[i].is_active && strcmp(state->user_records[i].uuid, uuid) == 0)
      u = &state->user_records[i];
  bool allowed = u && (u->type == 'a' ? hub_user_has_flag(state, u->uuid, 'c')
                                      : hub_user_chan_ok(state, u->uuid, chan));
  if (!allowed) {
    hub_log_warning("[CHANREQ] %s asked %s %s on %s for %s: refused (no rights there)\n",
                    hub_who_client(state, client), kind, nick, chan, hub_who(state, 'u', uuid));
    UCR_FAIL("no rights on %s", chan);
  }
  if (!hub_chan_live(state, chan, NULL, 0)) UCR_FAIL("%s is not a managed channel", chan);
  hub_log_info("[CHANREQ] %s for %s (%s) on %s, from %s\n", kind, nick, u->name, chan,
               hub_who_client(state, client));
  chan_elect_t *e = ce_start(state, kind, chan, u->uuid, nick, mask, NULL);
  if (!e) UCR_FAIL("too many channel requests in flight; try again");
  e->reply_fd = client->fd;
  e->reply_serial = client->conn_serial;
  snprintf(e->reply_rid, sizeof(e->reply_rid), "%s", rid);
#undef UCR_FAIL
}

/* A local bot's answer to PROBE: eid|1| or eid|0|reason. */
static void process_chan_probe_ack(hub_state_t *state, hub_client_t *client,
                                   const char *payload) {
  char id[64] = "", okf[4] = "", reason[CHAN_ELECT_REASON_MAX] = "";
  wire_field(payload, 0, id, sizeof(id));
  wire_field(payload, 1, okf, sizeof(okf));
  wire_tail(payload, 2, reason, sizeof(reason));
  chan_elect_t *e = id[0] ? ce_find(state, id) : NULL;
  if (!e || e->phase != CE_PROBE) return;
  for (int i = 0; i < e->bot_n; i++) {
    chan_elect_bot_t *b = &e->bots[i];
    if (b->st != 'a' || strcmp(b->uuid, client->id) != 0) continue;
    b->st = okf[0] == '1' ? 'y' : 'n';
    roster_clean(b->reason, sizeof(b->reason), b->st == 'y' ? "" : reason[0] ? reason : "cannot");
    return;
  }
}

/* A failure that is about the target, not the bot: no other bot is tried.
 * A ban's "dynamic": +dynamicbans keeps a non-sticky ban off the channel
 * while no member it matches is there. */
static bool ce_final_fail(const chan_elect_t *e, const char *detail) {
  if (strcmp(e->kind, "op") == 0) return strcmp(detail, "bitch") == 0;
  if (strcmp(e->kind, "kick") == 0)
    return strcmp(detail, "absent") == 0 || strcmp(detail, "protected") == 0;
  if (strcmp(e->kind, "ban") == 0) return strcmp(detail, "dynamic") == 0;
  return false;
}

/* The bot we handed the action to reports: eid|ok|detail or eid|fail|detail. */
static void process_chan_done(hub_state_t *state, hub_client_t *client,
                              const char *payload) {
  char id[64] = "", status[8] = "", detail[96] = "";
  wire_field(payload, 0, id, sizeof(id));
  wire_field(payload, 1, status, sizeof(status));
  wire_tail(payload, 2, detail, sizeof(detail));
  char *dot = strchr(id, '.'); /* a batch: <eid>.<target uuid> */
  if (dot) *dot++ = '\0';
  chan_elect_t *e = id[0] ? ce_find(state, id) : NULL;
  if (!e || e->phase != CE_LOCAL_DO || strcmp(e->doing, client->id) != 0) return;
  if ((dot != NULL) != (e->tg != NULL)) return;
  char clean[96];
  roster_clean(clean, sizeof(clean), detail);
  if (dot) {
    chan_elect_target_t *t = ce_target(e, dot);
    if (!t || t->st != 'd') return;
    char bn[MAX_NICK] = "";
    for (int i = 0; i < e->bot_n; i++)
      if (strcmp(e->bots[i].uuid, client->id) == 0) snprintf(bn, sizeof(bn), "%s", e->bots[i].nick);
    if (strcmp(status, "ok") == 0)
      ce_tg_served(state, e, t, true, client->id, bn, hub_display_name(state), clean);
    else if (strcmp(status, "fail") == 0 && ce_final_fail(e, clean))
      ce_tg_served(state, e, t, false, client->id, bn, hub_display_name(state), clean);
    else {
      t->st = 'p'; /* the next ready bot gets it */
      for (int i = 0; i < e->bot_n; i++)
        if (strcmp(e->bots[i].uuid, client->id) == 0)
          roster_clean(e->bots[i].reason, sizeof(e->bots[i].reason), clean[0] ? clean : "failed");
    }
    if (ce_tg_count(e, 'd') == 0) {
      e->doing[0] = '\0';
      ce_batch_next(state, e);
    }
    return;
  }
  chan_elect_bot_t *b = NULL;
  for (int i = 0; i < e->bot_n; i++)
    if (strcmp(e->bots[i].uuid, client->id) == 0) b = &e->bots[i];
  if (strcmp(status, "ok") == 0) {
    if (e->origin)
      ce_finish(state, e, "ok", client->id, b ? b->nick : "", hub_display_name(state), clean);
    else {
      ce_done_up(state, e, client->id, b ? b->nick : "", "ok", clean);
      e->phase = CE_ACKED;
    }
    return;
  }
  /* fail|bitch: not authorised on a +bitch channel (D12); a kick's
   * fail|absent / fail|protected.  The answer is about the nick, not the
   * bot, so it ends the election. */
  if (strcmp(status, "fail") == 0 && ce_final_fail(e, clean)) {
    if (e->origin)
      ce_finish(state, e, clean, client->id, b ? b->nick : "", hub_display_name(state),
                clean);
    else {
      ce_done_up(state, e, client->id, b ? b->nick : "", "fail", clean);
      e->phase = CE_ACKED;
    }
    return;
  }
  if (b) roster_clean(b->reason, sizeof(b->reason), clean[0] ? clean : "failed");
  e->doing[0] = '\0';
  if (!ce_try_local(state, e)) ce_local_exhausted(state, e);
}

/* ELECT_FWD from a peer: eid|origin_hub|kind|channel|requester|nick|hostmask|ts */
static void process_chan_elect_fwd(hub_state_t *state, hub_client_t *client,
                                   const char *payload) {
  char id[64] = "", origin[64] = "", kind[8] = "", channel[MAX_CHAN] = "";
  char requester[64] = "", nick[MAX_NICK] = "", hostmask[MAX_MASK_LEN] = "", ts[24] = "";
  if (!wire_field(payload, 0, id, sizeof(id)) || !wire_field(payload, 1, origin, sizeof(origin)) ||
      !wire_field(payload, 2, kind, sizeof(kind)) ||
      !wire_field(payload, 3, channel, sizeof(channel)) ||
      !wire_field(payload, 4, requester, sizeof(requester)) || !id[0] ||
      (!chan_kind_valid(kind) && strcmp(kind, "op") != 0 && strcmp(kind, "mode") != 0 &&
       strcmp(kind, "kick") != 0 && strcmp(kind, "ban") != 0 && strcmp(kind, "who") != 0) ||
      (channel[0] != '#' && channel[0] != '&')) {
    hub_log_warning("[CHANREQ] Malformed CHAN_ELECT_FWD from peer fd=%d\n", client->fd);
    return;
  }
  wire_field(payload, 5, nick, sizeof(nick));
  wire_field(payload, 6, hostmask, sizeof(hostmask));
  wire_field(payload, 7, ts, sizeof(ts));
  long long t = atoll(ts); /* saturates: age only for a positive stamp */
  long long age = t > 0 ? (long long)time(NULL) - t : 0;
  if (t <= 0 || age > CHAN_ELECT_TTL || age < -CHAN_ELECT_TTL) return;
  if (op_forward_seen_check_and_add(state, id)) return; /* another path got here first */

  chan_elect_t *e = ce_alloc(state, ce_own_requester(state, requester), kind, channel);
  if (!e) {
    /* logged; the origin hears no answer from us, but the hubs behind us
     * still get the question */
    for (int i = 0; i < state->client_count; i++) {
      hub_client_t *c = state->clients[i];
      if (c->type == CLIENT_HUB && c->authenticated && c != client)
        peer_send_urgent(state, c, CMD_CHAN_ELECT_FWD, payload);
    }
    return;
  }
  /* A key travels home as CHAN_REPLY through the pending table, hop by hop. */
  if (strcmp(kind, "key") == 0)
    add_pending_chan_request(state, id, requester, kind, channel, client->fd);
  e->active = true;
  e->from_fd = client->fd;
  e->from_serial = client->conn_serial;
  snprintf(e->id, sizeof(e->id), "%s", id);
  snprintf(e->kind, sizeof(e->kind), "%s", kind);
  snprintf(e->channel, sizeof(e->channel), "%s", channel);
  snprintf(e->requester, sizeof(e->requester), "%s", requester);
  snprintf(e->nick, sizeof(e->nick), "%s", nick);
  snprintf(e->hostmask, sizeof(e->hostmask), "%s", hostmask);
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type == CLIENT_HUB && c->authenticated && c != client)
      peer_send_urgent(state, c, CMD_CHAN_ELECT_FWD, payload);
  }
  ce_probe_local(state, e);
  hub_log_debug("[CHANREQ] Election %s from peer fd=%d: %s %s on %s, %d local bot(s) asked\n",
                e->id, client->fd, kind, nick[0] ? nick : requester, channel, e->bot_n);
}

/* ELECT_ACK: eid|hub_uuid|hub_name|asked|ready|silent|mesh.  mesh (2.5.3+:
 * every hub the mesh admits sends it) is how many hubs the answering hub knows, itself
 * included.  The origin records it; a relay remembers which peer leads to
 * that hub and passes it on unchanged. */
static void process_chan_elect_ack(hub_state_t *state, hub_client_t *client,
                                   const char *payload) {
  char id[64] = "", hub[64] = "", name[64] = "", a[12] = "", r[12] = "", m[12] = "";
  wire_field(payload, 0, id, sizeof(id));
  wire_field(payload, 1, hub, sizeof(hub));
  wire_field(payload, 2, name, sizeof(name));
  wire_field(payload, 3, a, sizeof(a));
  wire_field(payload, 4, r, sizeof(r));
  wire_field(payload, 6, m, sizeof(m));
  chan_elect_t *e = id[0] && hub[0] ? ce_find(state, id) : NULL;
  if (!e || e->hub_n >= MAX_MESH_HUBS) return;
  int known = atoi(m); /* bounded: a wild count can only cost MESH_WAIT */
  if (known > MAX_MESH_HUBS) known = MAX_MESH_HUBS;
  if (known > e->mesh_known) e->mesh_known = known;
  for (int i = 0; i < e->hub_n; i++)
    if (strcmp(e->hubs[i].uuid, hub) == 0) return; /* second copy */
  chan_elect_hub_t *h = &e->hubs[e->hub_n++];
  roster_clean(h->uuid, sizeof(h->uuid), hub);
  roster_clean(h->name, sizeof(h->name), name[0] ? name : hub);
  h->fd = client->fd;
  h->serial = client->conn_serial;
  h->asked = atoi(a) > 0 ? atoi(a) : 0;
  h->ready = atoi(r) > 0 ? atoi(r) : 0;
  if (!e->origin) ce_up(state, e, CMD_CHAN_ELECT_ACK, payload);
}

/* ELECT_DO: eid|hub_uuid|elect.  Ours: act; else route it on. */
static void process_chan_elect_do(hub_state_t *state, hub_client_t *client,
                                  const char *payload) {
  char id[64] = "", hub[64] = "", mode[8] = "";
  wire_field(payload, 0, id, sizeof(id));
  wire_field(payload, 1, hub, sizeof(hub));
  wire_field(payload, 2, mode, sizeof(mode));
  chan_elect_t *e = id[0] ? ce_find(state, id) : NULL;
  if (!e || e->origin || client->fd != e->from_fd || client->conn_serial != e->from_serial) return;
  if (strcmp(hub, state->hub_uuid) != 0) {
    for (int i = 0; i < e->hub_n; i++)
      if (strcmp(e->hubs[i].uuid, hub) == 0) {
        hub_client_t *p = ce_peer(state, e->hubs[i].fd, e->hubs[i].serial);
        if (p) peer_send_urgent(state, p, CMD_CHAN_ELECT_DO, payload);
        return;
      }
    return;
  }
  if (strcmp(mode, "elect") != 0) return;
  /* a batch: the targets still waiting, as bot uuids; their nick and mask
   * come from our own copy of each bot's record */
  char list[CHAN_ELECT_BATCH_MAX * 65 + 1] = "";
  wire_field(payload, 3, list, sizeof(list));
  if (list[0]) {
    free(e->tg);
    e->tg_n = 0;
    e->tg = calloc(CHAN_ELECT_BATCH_MAX, sizeof(*e->tg));
    if (!e->tg) {
      ce_local_exhausted(state, e);
      return;
    }
    for (char *tok = strtok(list, ","); tok && e->tg_n < CHAN_ELECT_BATCH_MAX;
         tok = strtok(NULL, ",")) {
      if (strlen(tok) >= sizeof(e->tg[0].uuid) || strspn(tok, "0123456789abcdefABCDEF-") != strlen(tok) ||
          ce_target(e, tok))
        continue;
      chan_elect_target_t *t = &e->tg[e->tg_n];
      snprintf(t->uuid, sizeof(t->uuid), "%s", tok);
      hub_bot_entry(state, tok, "n", t->nick, sizeof(t->nick));
      hub_bot_entry(state, tok, "h", t->hostmask, sizeof(t->hostmask));
      if (!t->nick[0]) continue; /* not a bot we know */
      t->reply_fd = -1;
      t->st = 'p';
      e->tg_n++;
    }
    if (e->tg_n == 0) {
      ce_local_exhausted(state, e);
      return;
    }
    ce_batch_next(state, e);
    return;
  }
  if (!ce_try_local(state, e)) ce_local_exhausted(state, e);
}

/* ELECT_DONE: eid|hub_uuid|hub_name|bot_uuid|bot_nick|status|detail. */
static void process_chan_elect_done(hub_state_t *state, hub_client_t *client,
                                    const char *payload) {
  (void)client;
  char id[64] = "", hub[64] = "", name[64] = "", bot[64] = "", nick[MAX_NICK] = "";
  char status[8] = "", detail[96] = "";
  wire_field(payload, 0, id, sizeof(id));
  wire_field(payload, 1, hub, sizeof(hub));
  wire_field(payload, 2, name, sizeof(name));
  wire_field(payload, 3, bot, sizeof(bot));
  wire_field(payload, 4, nick, sizeof(nick));
  wire_field(payload, 5, status, sizeof(status));
  wire_tail(payload, 6, detail, sizeof(detail));
  char *dot = strchr(id, '.'); /* a batch target's own report */
  if (dot) *dot++ = '\0';
  chan_elect_t *e = id[0] ? ce_find(state, id) : NULL;
  if (!e) return;
  if (!e->origin) {
    ce_up(state, e, CMD_CHAN_ELECT_DONE, payload);
    return;
  }
  if (e->phase != CE_MESH_DO || strcmp(e->doing, hub) != 0) return;
  if ((dot != NULL) && !e->tg) return;
  char cn[64], cb[64], ck[MAX_NICK], cd[96];
  roster_clean(cn, sizeof(cn), name[0] ? name : hub);
  roster_clean(cb, sizeof(cb), bot);
  roster_clean(ck, sizeof(ck), nick);
  roster_clean(cd, sizeof(cd), detail);
  if (dot) {
    chan_elect_target_t *t = ce_target(e, dot);
    if (!t || t->st != 'd') return;
    if (strcmp(status, "ok") == 0)
      ce_tg_served(state, e, t, true, cb, ck, cn, cd);
    else if (strcmp(status, "fail") == 0 && ce_final_fail(e, cd))
      ce_tg_served(state, e, t, false, cb, ck, cn, cd);
    else
      t->st = 'p';
    return;
  }
  if (e->tg) { /* that hub is through: the next one for what is left */
    ce_try_hub(state, e);
    return;
  }
  if (strcmp(status, "ok") == 0)
    ce_finish(state, e, "ok", cb, ck, cn, cd);
  else if (strcmp(status, "fail") == 0 && ce_final_fail(e, cd))
    ce_finish(state, e, cd, cb, ck, cn, cd);
  else
    ce_try_hub(state, e);
}

/* ELECT_END: eid.  The origin's election is over: free our copy (a relay's;
 * the origin freed its own) and pass it on once. */
static void process_chan_elect_end(hub_state_t *state, hub_client_t *client,
                                   const char *payload) {
  char id[64] = "";
  if (!wire_field(payload, 0, id, sizeof(id)) || !id[0] || strchr(id, '.')) return;
  chan_elect_t *e = ce_find(state, id);
  if (e && !e->origin) {
    ce_release(e);
    g_hub_stats.el_ended++;
  }
  ce_end_send(state, id, client);
}

/* Console entry point: apply a channel's stored modes once (kind "mode").
 * One elected bot reads the stored C| modes and the c| key and sends the MODE
 * line(s); the answer reaches `admin` when the election ends. */
bool hub_chan_mode_apply(hub_state_t *state, const char *channel,
                         const hub_client_t *admin) {
  if (!channel || (channel[0] != '#' && channel[0] != '&')) return false;
  return ce_start(state, "mode", channel, "ADMIN", "", "", admin);
}

/* A console disconnected: the elections it waits on still finish and log,
 * but answer nobody. */
void hub_chan_elect_forget_admin(hub_state_t *state, const hub_client_t *c) {
  for (int i = 0; i < MAX_CHAN_ELECTIONS; i++) {
    chan_elect_t *e = &state->chan_elections[i];
    if (e->active && e->admin_fd >= 0 && e->admin_serial == c->conn_serial) {
      e->admin_fd = -1;
      e->admin_serial = 0;
    }
  }
}

/* Drive every election one step.  Runs on every maintenance pass. */
void hub_chan_elect_tick(hub_state_t *state, time_t now) {
  ce_full_flush(now);
  for (int i = 0; i < MAX_CHAN_ELECTIONS; i++) {
    chan_elect_t *e = &state->chan_elections[i];
    if (!e->active) continue;
    if (now - e->created > CHAN_ELECT_TTL) {
      if (e->origin) ce_finish(state, e, "timeout", NULL, NULL, NULL, "timed out");
      ce_release(e);
      continue;
    }
    switch (e->phase) {
    case CE_PROBE:
      if (ce_count(e, 'a') > 0 && now - e->phase_at < CHAN_ELECT_PROBE_WAIT) break;
      /* still silent: a no, with the reason the answer gives */
      for (int j = 0; j < e->bot_n; j++)
        if (e->bots[j].st == 'a') {
          e->bots[j].st = 'n';
          snprintf(e->bots[j].reason, sizeof(e->bots[j].reason), "no answer");
        }
      if (!e->origin) {
        char ack[256];
        snprintf(ack, sizeof(ack), "%s|%s|%s|%d|%d|%d|%d", e->id, state->hub_uuid,
                 hub_display_name(state), e->bot_n, ce_count(e, 'y'), ce_count(e, 'a'),
                 ce_mesh_total(state));
        ce_up(state, e, CMD_CHAN_ELECT_ACK, ack);
        e->phase = CE_ACKED;
        e->phase_at = now;
        break;
      }
      if (!ce_try_local(state, e)) ce_local_exhausted(state, e);
      break;
    case CE_LOCAL_DO:
      if (now - e->phase_at < CHAN_ELECT_DO_WAIT) break;
      for (int j = 0; j < e->bot_n; j++)
        if (strcmp(e->bots[j].uuid, e->doing) == 0)
          snprintf(e->bots[j].reason, sizeof(e->bots[j].reason), "no answer");
      e->doing[0] = '\0';
      if (e->tg) {
        for (int j = 0; j < e->tg_n; j++)
          if (e->tg[j].st == 'd') e->tg[j].st = 'p';
        ce_batch_next(state, e);
        break;
      }
      if (!ce_try_local(state, e)) ce_local_exhausted(state, e);
      break;
    case CE_GATHER:
      if (now - e->phase_at < CHAN_ELECT_BATCH_WAIT) break;
      ce_probe_local(state, e);
      hub_log_debug("[CHANREQ] Election %s: own op for %d bot(s) on %s, %d local bot(s) asked\n",
                    e->id, e->tg_n, e->channel, e->bot_n);
      break;
    case CE_MESH_WAIT: {
      /* every other hub we know of, or that any answer says exists */
      int expect = ce_mesh_total(state) - 1;
      if (e->mesh_known - 1 > expect) expect = e->mesh_known - 1;
      if (e->hub_n < expect && now - e->phase_at < CHAN_ELECT_MESH_WAIT) break;
      ce_try_hub(state, e);
      break;
    }
    case CE_HOLD:
      if (ce_mesh_settling(state, now) && now - e->phase_at < CHAN_ELECT_HOLD_MAX) break;
      if (ce_new_local_bot(state, e)) ce_probe_local(state, e); /* attached meanwhile */
      else ce_local_exhausted(state, e);
      break;
    case CE_MESH_DO:
      if (now - e->phase_at < CHAN_ELECT_HUB_WAIT) break;
      ce_try_hub(state, e);
      break;
    case CE_ACKED:
      /* A relay with no ready bot that routed no other hub's answer is never
       * handed the action and has nothing to route: free its copy once the
       * other hubs' answers can no longer arrive through it. */
      if (!e->origin && e->hub_n == 0 && ce_count(e, 'y') == 0 && e->doing[0] == '\0' &&
          now - e->phase_at >= CHAN_ELECT_MESH_WAIT)
        ce_release(e);
      break;
    }
  }
}

// ========== End Channel-Access Requests ==========

/* ======================================================================
 * Network upgrade orchestration (CMD_ADMIN_UPGRADE_NET → CMD_UPGRADE_*)
 *
 * The admin console asks this hub to move the whole network to a version.  The hub
 * freezes the config, asks every node whether it could take that build
 * (PREPARE → READY/UNABLE), then commits them in a rolling plan: bots in
 * waves so a channel never loses all its bots at once, peer hubs afterwards
 * one at a time so the mesh never fully drops, and this hub last of all.
 *
 * The ack routing mirrors pending_op_request_t: one id per run, replies
 * matched by that id, status routed home down origin_fd.  Unlike an op grant
 * a committed node DISCONNECTS (it execs a new binary), so success is
 * normally observed as "it came back announcing the target version" — the
 * CMD_UPGRADE_RESULT frame is a faster confirmation, not the only one.
 * ====================================================================== */

/* Add or replace a flag in the replicated opt record, stamped and pushed the
 * same way CMD_ADMIN_SET_OPT_FLAGS does it. */
static void hub_opt_flag_set(hub_state_t *state, char flag, bool on) {
  char cur[MAX_OPT_FLAGS + 1];
  snprintf(cur, sizeof(cur), "%s", state->opt_flags);
  bool present = (strchr(cur, flag) != NULL);
  if (present == on) return;

  char next[MAX_OPT_FLAGS + 1] = {0};
  int w = 0;
  for (int i = 0; cur[i] && w < MAX_OPT_FLAGS; i++)
    if (cur[i] != flag) next[w++] = cur[i];
  if (on && w < MAX_OPT_FLAGS) next[w++] = flag;
  next[w] = '\0';

  snprintf(state->opt_flags, sizeof(state->opt_flags), "%s", next);
  /* Past the previous stamp: a set and a clear in the same second must not
   * tie, or peers keep whichever arrived and the mesh splits. */
  state->opt_flags_ts = hub_lww_next_ts(state->opt_flags_ts);
  state->config_dirty = true;

  char sync_pkt[64];
  snprintf(sync_pkt, sizeof(sync_pkt), "opt|%s|%ld\n", state->opt_flags,
           (long)state->opt_flags_ts);
  hub_broadcast_sync_to_peers(state, sync_pkt, -1);
  broadcast_full_config_to_all_bots(state);
  hub_log_info("[UPGRADE] opt flags now '%s'\n",
          state->opt_flags[0] ? state->opt_flags : "(none)");
}

/* Task 6: while a run holds the freeze, config mutations are refused.  The
 * flag replicates like any other opt, so peer hubs refuse them too. */
static bool hub_config_frozen(const hub_state_t *state) {
  return state && strchr(state->opt_flags, OPT_CONFIG_FROZEN) != NULL;
}

/* The admin opcodes an SSH console may send (docs/console.md §2) -- every
 * command the console offers and nothing else.  The hub's private key never
 * leaves it and is never set from outside (GET/SET_PRIVKEY are retired: back
 * up .irchub.cnf instead), and the retired password and legacy global mask
 * opcodes have no console command. */
static bool console_admin_op(int cmd) {
  switch (cmd) {
  case CMD_ADMIN_LIST_FULL:       case CMD_ADMIN_LIST_SUMMARY:
  case CMD_ADMIN_LIST_REVOKED:    case CMD_ADMIN_CREATE_BOT:
  case CMD_ADMIN_BOT_MOVE:
  case CMD_ADMIN_DEL:             case CMD_ADMIN_DISCONNECT_BOT:
  case CMD_ADMIN_REKEY_BOT:       case CMD_ADMIN_LIST_PEERS:
  case CMD_ADMIN_ADD_PEER:        case CMD_ADMIN_DEL_PEER:
  case CMD_ADMIN_PEER_REFS:
  case CMD_ADMIN_SET_PEER_PUBKEY: case CMD_ADMIN_SYNC_MESH:
  case CMD_ADMIN_GET_PUBKEY:      case CMD_ADMIN_SET_PUBKEY:
  case CMD_ADMIN_REGEN_KEYS:      case CMD_ADMIN_SET_HUB_NAME:
  case CMD_ADMIN_SET_BIND_IP:     case CMD_ADMIN_SET_BIND_PORT:
  case CMD_ADMIN_SET_LOG_SIZE:    case CMD_ADMIN_PURGE_TOMBSTONES:
  case CMD_ADMIN_SET_PURGE_DAYS:  case CMD_ADMIN_SET_LOG_LEVEL:
  case CMD_ADMIN_STATS:
  case CMD_ADMIN_LIST_ALLOWLIST:  case CMD_ADMIN_ADD_ALLOWLIST:
  case CMD_ADMIN_DEL_ALLOWLIST:   case CMD_ADMIN_LIST_DENYLIST:
  case CMD_ADMIN_ADD_DENYLIST:    case CMD_ADMIN_DEL_DENYLIST:
  case CMD_ADMIN_GET_OPT_FLAGS:   case CMD_ADMIN_SET_OPT_FLAGS:
  case CMD_ADMIN_LIST_ADMINS:     case CMD_ADMIN_ADD_ADMIN:
  case CMD_ADMIN_DEL_ADMIN:       case CMD_ADMIN_LIST_OPERS_V2:
  case CMD_ADMIN_ADD_OPER_RECORD: case CMD_ADMIN_DEL_OPER_RECORD:
  case CMD_ADMIN_ADD_USERMASK:    case CMD_ADMIN_DEL_USERMASK:
  case CMD_ADMIN_SET_USERKEY:     case CMD_ADMIN_MATCH:
  case CMD_ADMIN_USER_ACCESS:
  case CMD_ADMIN_LIST_CHANNELS:   case CMD_ADMIN_ADD_CHANNEL:
  case CMD_ADMIN_DEL_CHANNEL:     case CMD_ADMIN_OP_USER:
  case CMD_ADMIN_INVITE_USER:     case CMD_ADMIN_KICK_USER:
  case CMD_ADMIN_CHAN_MODE:       case CMD_ADMIN_CHAN_SET:
  case CMD_ADMIN_BAN:             case CMD_ADMIN_NET_SET:
  case CMD_ADMIN_POOL:
  case CMD_ADMIN_SET_SSH:
  case CMD_ADMIN_UPGRADE_NET:     case CMD_ADMIN_UPGRADE_STATUS:
  case CMD_ADMIN_BOT_RESYNC:
  case CMD_CHAN_WHO:
    return true;
  default:
    return false;
  }
}

/* Admin commands that write the replicated store or change which nodes exist.
 * Read-only queries and the local operational settings stay available, and so
 * does CMD_ADMIN_SET_OPT_FLAGS deliberately: it is the manual escape hatch
 * that lifts a freeze a crashed run left behind. */
static bool hub_admin_cmd_mutates_config(int cmd) {
  switch (cmd) {
  case CMD_ADMIN_DEL:
  case CMD_ADMIN_REGEN_KEYS:
  case CMD_ADMIN_ADD_PEER:
  case CMD_ADMIN_DEL_PEER:
  case CMD_ADMIN_SET_PUBKEY:
  case CMD_ADMIN_REKEY_BOT:
  case CMD_ADMIN_CREATE_BOT:
  case CMD_ADMIN_ADD_CHANNEL:
  case CMD_ADMIN_DEL_CHANNEL:
  case CMD_ADMIN_ADD_MASK:
  case CMD_ADMIN_DEL_MASK:
  case CMD_ADMIN_ADD_OPER:
  case CMD_ADMIN_DEL_OPER:
  case CMD_ADMIN_PURGE_TOMBSTONES:
  case CMD_ADMIN_SET_PURGE_DAYS:
  case CMD_ADMIN_ADD_ADMIN:
  case CMD_ADMIN_DEL_ADMIN:
  case CMD_ADMIN_ADD_OPER_RECORD:
  case CMD_ADMIN_DEL_OPER_RECORD:
  case CMD_ADMIN_ADD_USERMASK:
  case CMD_ADMIN_DEL_USERMASK:
  case CMD_ADMIN_SET_PEER_PUBKEY:
  case CMD_ADMIN_SET_USERKEY:
  case CMD_ADMIN_USER_ACCESS:
  case CMD_ADMIN_CHAN_MODE:   /* the changing forms only: mf_payload_mutates */
  case CMD_ADMIN_CHAN_SET:
  case CMD_ADMIN_BAN:
  case CMD_ADMIN_NET_SET:
  case CMD_ADMIN_POOL:
    return true;
  default:
    return false;
  }
}

static const char *upgrade_node_state_name(upgrade_node_state_t s) {
  switch (s) {
  case UPG_NODE_PENDING:   return "pending";
  case UPG_NODE_READY:     return "ready";
  case UPG_NODE_UNABLE:    return "unable";
  case UPG_NODE_COMMITTED: return "committing";
  case UPG_NODE_DONE:      return "done";
  case UPG_NODE_FAILED:    return "failed";
  }
  return "?";
}

static const char *upgrade_phase_name(upgrade_phase_t p) {
  switch (p) {
  case UPG_IDLE:    return "idle";
  case UPG_PREPARE: return "preparing";
  case UPG_ROLLING: return "rolling";
  case UPG_STAGING: return "staging";
  case UPG_PARTIAL: return "partial";
  case UPG_DONE:    return "done";
  case UPG_FAILED:  return "failed";
  case UPG_ABORTED: return "aborted";
  }
  return "?";
}

static upgrade_node_t *upgrade_find_node(pending_upgrade_t *u,
                                         const char *uuid) {
  if (!uuid || !uuid[0]) return NULL;
  for (int i = 0; i < u->node_count; i++)
    if (strcmp(u->nodes[i].uuid, uuid) == 0) return &u->nodes[i];
  return NULL;
}

static upgrade_node_t *upgrade_add_node(pending_upgrade_t *u, const char *uuid,
                                        char kind, int fd, const char *ver) {
  if (u->node_count >= MAX_UPGRADE_NODES) return NULL;
  if (!uuid || !uuid[0]) return NULL; /* the table is keyed by uuid */
  upgrade_node_t *n = &u->nodes[u->node_count++];
  memset(n, 0, sizeof(*n));
  snprintf(n->uuid, sizeof(n->uuid), "%s", uuid);
  n->kind = kind;
  n->fd = fd;
  n->state = UPG_NODE_PENDING;
  if (ver) snprintf(n->cur_version, sizeof(n->cur_version), "%s", ver);
  u->last_added = time(NULL);
  return n;
}

/* Relayed-bot READYs still owed: what the hub nodes said they relayed to,
 * less the remote bots already in the table.  Bounded by the PREPARE timeout
 * like every other wait. */
static int upgrade_relays_owed(const pending_upgrade_t *u) {
  int promised = 0, seen = 0;
  for (int i = 0; i < u->node_count; i++) {
    const upgrade_node_t *n = &u->nodes[i];
    if (n->kind == 'h') promised += n->relayed;
    else if (n->kind == 'b' && n->via[0]) seen++;
  }
  return promised > seen ? promised - seen : 0;
}

static int upgrade_count(const pending_upgrade_t *u, upgrade_node_state_t st,
                         char kind) {
  int n = 0;
  for (int i = 0; i < u->node_count; i++)
    if (u->nodes[i].state == st && (kind == 0 || u->nodes[i].kind == kind)) n++;
  return n;
}

/* The uuid a peer hub knows ITSELF by.  A peer connection's client->id is the
 * peer's FRIENDLY NAME — that is what the roster, the logs and the admin console show
 * — while every upgrade frame a peer sends is keyed by its hub uuid.  The two
 * have to be bridged, or the driver never matches a peer's own UPGRADE_READY
 * to the node it created for it and files the answer as a brand-new bot.
 * Returns "" when the connection is not a known peer. */
static const char *upgrade_peer_uuid(const hub_state_t *state,
                                     const hub_client_t *c) {
  if (!c || c->type != CLIENT_HUB) return "";
  for (int i = 0; i < state->peer_count; i++)
    if (state->peers[i].connected && state->peers[i].fd == c->fd)
      return state->peers[i].uuid;
  return "";
}

/* The peer connection belonging to a hub uuid (the inverse of the above). */
static hub_client_t *upgrade_find_peer(hub_state_t *state, const char *uuid) {
  if (!uuid || !uuid[0]) return NULL;
  for (int i = 0; i < state->peer_count; i++) {
    if (!state->peers[i].connected) continue;
    if (strcmp(state->peers[i].uuid, uuid) != 0) continue;
    for (int j = 0; j < state->client_count; j++) {
      hub_client_t *c = state->clients[j];
      if (c->type == CLIENT_HUB && c->authenticated &&
          c->fd == state->peers[i].fd)
        return c;
    }
  }
  return NULL;
}

static hub_client_t *upgrade_find_client(hub_state_t *state, const char *uuid,
                                         client_type_t type) {
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type == type && c->authenticated && !c->superseded && strcmp(c->id, uuid) == 0)
      return c;
  }
  return NULL;
}

/* Strip '|' and control bytes: reasons come back from nodes and travel on
 * through a '|'-delimited status frame into an admin's terminal. */
static void upgrade_clean(char *dst, size_t cap, const char *src) {
  size_t o = 0;
  for (const char *p = src ? src : ""; *p && o + 1 < cap; p++) {
    unsigned char c = (unsigned char)*p;
    if (c == '|') c = '/';
    if (c < 0x20 || c == 0x7f) c = ' ';
    dst[o++] = (char)c;
  }
  dst[o] = '\0';
}

/* The run this hub drives, as a history record.  See hub_uhist.c. */
static const char *upgrade_node_target(const pending_upgrade_t *u, const upgrade_node_t *n);

static const char *upgrade_history_node_state(const pending_upgrade_t *u,
                                              const upgrade_node_t *n) {
  const char *to = upgrade_node_target(u, n);
  const char *want = upgrade_node_variant(u, n);
  if (n->kind != 'b' && !u->hub_ver[0] && (n->not_selected || n->state == UPG_NODE_UNABLE))
    return "idle";
  if (n->not_selected) return "skipped";
  if (n->state == UPG_NODE_UNABLE && to[0] && n->cur_version[0] &&
      hub_update_version_cmp(n->cur_version, to) == 0 &&
      (!want[0] || strcmp(want, n->variant) == 0))
    return "already";
  return upgrade_node_state_name(n->state);
}

static const char *upgrade_history_result(const pending_upgrade_t *u) {
  if (u->active) return "running";
  if (u->phase == UPG_ABORTED) return "aborted";
  if (u->phase == UPG_FAILED) return "failed";
  int moved = 0, missed = 0;
  for (int i = 0; i < u->node_count; i++) {
    const upgrade_node_t *n = &u->nodes[i];
    const char *st = upgrade_history_node_state(u, n);
    if (!strcmp(st, "done") || (n->kind == 's' && !strcmp(st, "committing"))) moved++;
    else if (!strcmp(st, "failed") || !strcmp(st, "unable")) missed++;
  }
  return !moved ? "noop" : missed ? "partial" : "done";
}

static void upgrade_history_note(hub_state_t *state) {
  const pending_upgrade_t *u = &state->upgrade;
  uhist_view_t *v = calloc(1, sizeof(*v));
  uhist_node_t *nodes = u->node_count ? calloc((size_t)u->node_count, sizeof(*nodes)) : NULL;
  if (!v || (u->node_count && !nodes)) {
    hub_log_error("[UPGRADE] OOM recording upgrade %s\n", u->id);
    free(v);
    free(nodes);
    return;
  }
  snprintf(v->id, sizeof(v->id), "%s", u->id);
  snprintf(v->driver_uuid, sizeof(v->driver_uuid), "%s", state->hub_uuid);
  snprintf(v->driver_name, sizeof(v->driver_name), "%s", state->hub_friendly_name);
  snprintf(v->by, sizeof(v->by), "%s", u->by);
  v->started = (long long)u->started;
  v->rolling_at = (long long)u->rolling_at;
  v->ended = u->active ? 0 : (long long)time(NULL);
  snprintf(v->result, sizeof(v->result), "%s", upgrade_history_result(u));
  snprintf(v->bot_ver, sizeof(v->bot_ver), "%s", u->target_ver);
  snprintf(v->hub_ver, sizeof(v->hub_ver), "%s", u->hub_ver);
  snprintf(v->variant, sizeof(v->variant), "%s", u->variant);
  snprintf(v->kind, sizeof(v->kind), "%s", u->kind);
  snprintf(v->min_from, sizeof(v->min_from), "%s", u->min_from);
  v->plan_id = u->plan_id;
  v->step = u->plan_step;
  v->steps = u->plan_steps;
  snprintf(v->sel, sizeof(v->sel), "%s", u->sel_wire);
  snprintf(v->summary, sizeof(v->summary), "%s", u->summary);
  v->nodes = nodes;
  v->node_count = u->node_count;
  for (int i = 0; i < u->node_count; i++) {
    const upgrade_node_t *n = &u->nodes[i];
    uhist_node_t *o = &nodes[i];
    o->kind[0] = n->kind;
    snprintf(o->state, sizeof(o->state), "%s", upgrade_history_node_state(u, n));
    snprintf(o->uuid, sizeof(o->uuid), "%s", n->uuid);
    /* The nick now: the bot may be gone by the time anyone reads this. */
    char nick[MAX_NICK] = "";
    if (!n->name[0] && n->kind == 'b') bot_nick_from_config(state, n->uuid, nick, sizeof(nick));
    snprintf(o->name, sizeof(o->name), "%s",
             n->name[0] ? n->name : nick[0] ? nick
             : n->kind == 's' ? state->hub_friendly_name : "");
    snprintf(o->from, sizeof(o->from), "%s", n->cur_version);
    snprintf(o->to, sizeof(o->to), "%s", upgrade_node_target(u, n));
    snprintf(o->base, sizeof(o->base), "%s", n->variant);
    snprintf(o->want, sizeof(o->want), "%s", n->want_variant);
    snprintf(o->arch, sizeof(o->arch), "%s", n->arch);
    snprintf(o->libc, sizeof(o->libc), "%s", n->libc);
    o->committed = (long long)n->committed_at;
    o->back = (long long)n->back_at;
    o->done = (long long)n->done_at;
    snprintf(o->reason, sizeof(o->reason), "%s", n->reason);
    snprintf(o->code, sizeof(o->code), "%s", n->stage_code);
    snprintf(o->build, sizeof(o->build), "%s", n->is_src ? "src" : n->staged ? "bin" : "");
    o->stage_s = n->staged_at && n->stage_sent ? (long long)(n->staged_at - n->stage_sent) : 0;
  }
  hub_uhist_put_own(state, v);
  free(nodes);
  free(v);
}

/* End the run: lift the freeze and record why it stopped.  The table stays
 * behind so CMD_ADMIN_UPGRADE_STATUS can still explain what happened. */
static void upgrade_finish(hub_state_t *state, upgrade_phase_t phase,
                           const char *summary) {
  pending_upgrade_t *u = &state->upgrade;
  /* Keep the plan of a run that actually got somewhere: a node that was down
   * or homed elsewhere while it went through is walked up to this target when
   * it comes back (see hub_rollup_*).  An aborted run left the mesh where it
   * was, so there is nothing to catch up to.  A selective run leaves the
   * plan alone either way: moving three named bots says nothing about what
   * every other bot should run. */
  if (u->select_count > 0) {
    /* no roll-up plan change */
  } else if ((phase == UPG_DONE || phase == UPG_PARTIAL) &&
             (upgrade_count(u, UPG_NODE_DONE, 0) > 0 ||
              upgrade_count(u, UPG_NODE_COMMITTED, 's') > 0)) {
    /* Only a run that moved something (a node done, or this hub committing
     * itself last): one where every node declined must not replace the plan
     * an earlier, real run left. */
    pending_rollup_t *r = &state->rollup;
    r->have_plan = true;
    snprintf(r->target, sizeof(r->target), "%s", u->target_ver);
    snprintf(r->variant, sizeof(r->variant), "%s", u->variant);
    snprintf(r->kind, sizeof(r->kind), "%s", u->kind);
    snprintf(r->min_from, sizeof(r->min_from), "%s", u->min_from);
    snprintf(r->hub_target, sizeof(r->hub_target), "%s", u->hub_ver);
    r->plan_set = time(NULL);
    state->rollup_try_count = 0;
    hub_config_write(state); /* the plan survives a restart (Task 13) */
  } else if (phase == UPG_ABORTED) {
    state->rollup.have_plan = false;
    hub_config_write(state);
  }
  u->active = false;
  u->phase = phase;
  upgrade_clean(u->summary, sizeof(u->summary), summary);
  upgrade_history_note(state); /* before this hub can replace itself */
  hub_opt_flag_set(state, OPT_CONFIG_FROZEN, false);
  hub_log_info("[UPGRADE] Run %s %s: %s\n", u->id, upgrade_phase_name(phase),
          u->summary);
  hub_plan_single_end(state);
  /* A step of a multi-step upgrade: decide whether the next one follows.
   * Before this hub restarts onto the step itself, so the decision is on
   * disk when the new build boots. */
  plan_note_run_end(state, phase);
}

/* Tell every node that already moved (or is moving) to go back, then end the
 * run.  Rolling the finished nodes back too is the point: a half-upgraded
 * mesh is worse than one that never started. */
static void hub_upgrade_abort(hub_state_t *state, const char *reason) {
  pending_upgrade_t *u = &state->upgrade;
  char msg[256];
  snprintf(msg, sizeof(msg), "%s|", u->id);
  upgrade_clean(msg + strlen(msg), sizeof(msg) - strlen(msg), reason);

  int told = 0;
  for (int i = 0; i < u->node_count; i++) {
    upgrade_node_t *n = &u->nodes[i];
    /* READY too: still staging, nothing changed for them, and nothing will. */
    if (n->state != UPG_NODE_COMMITTED && n->state != UPG_NODE_DONE && n->state != UPG_NODE_READY)
      continue;
    if (n->via[0]) {
      /* A node below a peer hub: send that peer an id|uuid|reason frame.  Each
       * hop relays it on, and the last one turns it into the plain id|reason
       * ABORT its local bot understands. */
      hub_client_t *peer = upgrade_find_peer(state, n->via);
      char relay[320];
      snprintf(relay, sizeof(relay), "%s|%s|", u->id, n->uuid);
      upgrade_clean(relay + strlen(relay), sizeof(relay) - strlen(relay), reason);
      if (peer && peer_send_urgent(state, peer, CMD_UPGRADE_ABORT, relay)) told++;
    } else if (n->kind == 'b') {
      hub_client_t *c = upgrade_find_client(state, n->uuid, CLIENT_BOT);
      if (c && send_cmd_to_bot(state, c, CMD_UPGRADE_ABORT, msg)) told++;
    } else if (n->kind == 'h') {
      /* Peer hub as a self-node: id||reason (empty uuid = "you, not a bot"). */
      hub_client_t *c = upgrade_find_peer(state, n->uuid);
      char relay[320];
      snprintf(relay, sizeof(relay), "%s||", u->id);
      upgrade_clean(relay + strlen(relay), sizeof(relay) - strlen(relay), reason);
      if (c && peer_send_urgent(state, c, CMD_UPGRADE_ABORT, relay)) told++;
    }
  }
  hub_update_stage_clear();
  hub_log_info("[UPGRADE] Abort %s sent to %d node(s): %s\n", u->id, told, reason);
  upgrade_finish(state, UPG_ABORTED, reason);
}

/* The version a node of this run is being moved to: the bots' target for a
 * bot, the hubs' own for a hub.  Never mixed — the two are separate products
 * on separate version lines. */
static const char *upgrade_node_target(const pending_upgrade_t *u,
                                       const upgrade_node_t *n) {
  return n->kind == 'b' ? u->target_ver : u->hub_ver;
}

/* ---- Selective runs ------------------------------------------------------
 * An admin may move a handful of nodes instead of the whole network, each
 * optionally onto the other build ("optiplex=c").  Names are resolved here,
 * once, against everything this hub knows a node by — the stored bot records
 * (so an offline bot can still be named and ends "no answer to PREPARE"),
 * the live roster, and every hub heard from — and the run itself only ever
 * carries uuids. */
typedef struct {
  char uuid[64];
  char name[64];
  char kind; /* 'b' bot, 'h' hub, 's' this hub */
} upgrade_cand_t;

static void upgrade_cand_add(upgrade_cand_t *c, int *n, int max,
                             const char *uuid, const char *name, char kind) {
  if (!uuid || !uuid[0] || strcmp(uuid, "-") == 0) return;
  for (int i = 0; i < *n; i++) {
    if (strcmp(c[i].uuid, uuid) != 0) continue;
    if (!c[i].name[0] && name && name[0])
      snprintf(c[i].name, sizeof(c[i].name), "%s", name);
    return;
  }
  if (*n >= max) return;
  snprintf(c[*n].uuid, sizeof(c[*n].uuid), "%s", uuid);
  snprintf(c[*n].name, sizeof(c[*n].name), "%s", name ? name : "");
  c[*n].kind = kind;
  (*n)++;
}

#define UPGRADE_CAND_MAX                                                       \
  (1 + MAX_MESH_HUBS + MAX_PEERS + MAX_BOTS + MAX_BOT_ROSTER + MAX_CLIENTS)

/* Every node this hub could name.  Caller frees. */
static upgrade_cand_t *upgrade_candidates(hub_state_t *state, int *count) {
  upgrade_cand_t *c = calloc(UPGRADE_CAND_MAX, sizeof(*c));
  *count = 0;
  if (!c) return NULL;
  int n = 0;
  upgrade_cand_add(c, &n, UPGRADE_CAND_MAX, state->hub_uuid,
                   state->hub_friendly_name, 's');
  for (int i = 0; i < state->peer_count; i++)
    upgrade_cand_add(c, &n, UPGRADE_CAND_MAX, state->peers[i].uuid,
                     state->peers[i].friendly_name, 'h');
  for (int i = 0; i < state->mesh_hub_count; i++)
    upgrade_cand_add(c, &n, UPGRADE_CAND_MAX, state->mesh_hubs[i].uuid,
                     state->mesh_hubs[i].name, 'h');
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *cl = state->clients[i];
    if (cl->type != CLIENT_BOT || !cl->authenticated) continue;
    char nick[64] = "";
    hub_bot_entry(state, cl->id, "n", nick, sizeof(nick));
    upgrade_cand_add(c, &n, UPGRADE_CAND_MAX, cl->id, nick, 'b');
  }
  for (int i = 0; i < state->roster_count; i++)
    upgrade_cand_add(c, &n, UPGRADE_CAND_MAX, state->roster[i].bot_uuid,
                     state->roster[i].nick, 'b');
  for (int i = 0; i < state->bot_count; i++) {
    if (!state->bots[i].is_active) continue;
    char nick[64] = "";
    hub_bot_entry(state, state->bots[i].uuid, "n", nick, sizeof(nick));
    upgrade_cand_add(c, &n, UPGRADE_CAND_MAX, state->bots[i].uuid, nick, 'b');
  }
  *count = n;
  return c;
}

/* One token: a full uuid, else an exact name (case-insensitive), else a uuid
 * prefix of at least 4 characters.  Anything matching two different nodes is
 * refused rather than guessed. */
static const upgrade_cand_t *upgrade_resolve(const upgrade_cand_t *c, int n,
                                             const char *tok, char *err,
                                             size_t err_size) {
  for (int i = 0; i < n; i++)
    if (strcasecmp(c[i].uuid, tok) == 0) return &c[i];
  const upgrade_cand_t *hit = NULL;
  for (int i = 0; i < n; i++) {
    if (!c[i].name[0] || strcasecmp(c[i].name, tok) != 0) continue;
    if (hit) {
      snprintf(err, err_size, "'%s' names more than one node (%s, %s) — use a uuid",
               tok, hit->uuid, c[i].uuid);
      return NULL;
    }
    hit = &c[i];
  }
  if (hit) return hit;
  size_t tl = strlen(tok);
  if (tl >= 4) {
    for (int i = 0; i < n; i++) {
      if (strncasecmp(c[i].uuid, tok, tl) != 0) continue;
      if (hit) {
        snprintf(err, err_size, "uuid prefix '%s' is ambiguous (%s, %s)", tok,
                 hit->uuid, c[i].uuid);
        return NULL;
      }
      hit = &c[i];
    }
    if (hit) return hit;
  }
  snprintf(err, err_size, "no node known as '%s'", tok);
  return NULL;
}

/* Is `uuid` in this run's selection?  Always true for a whole-network run. */
static bool upgrade_selected(const pending_upgrade_t *u, const char *uuid,
                             const char **variant) {
  if (variant) *variant = "";
  if (u->select_count == 0) return true;
  for (int i = 0; i < u->select_count; i++) {
    if (strcmp(u->select[i].uuid, uuid) != 0) continue;
    if (variant) *variant = u->select[i].variant;
    return true;
  }
  return false;
}

/* Look `uuid` up in a peer PREPARE's resolved selection ("uuid[=v],...").
 * Returns false when it is not listed; `variant` gets its "=v" or "". */
static bool upgrade_sel_lookup(const char *sel, const char *uuid, char *variant,
                               size_t variant_size) {
  if (variant && variant_size) variant[0] = '\0';
  size_t ul = strlen(uuid);
  if (!ul) return false;
  for (const char *p = sel; p && *p;) {
    const char *end = strchr(p, ',');
    size_t len = end ? (size_t)(end - p) : strlen(p);
    if (len >= ul && strncmp(p, uuid, ul) == 0 &&
        (len == ul || p[ul] == '=')) {
      if (len > ul + 1 && variant && variant_size)
        snprintf(variant, variant_size, "%.*s", (int)(len - ul - 1), p + ul + 1);
      return true;
    }
    p = end ? end + 1 : NULL;
  }
  return false;
}

/* The variant a node is being moved onto: its own override in a selective
 * run, else the run's ("" = keep its own). */
static const char *upgrade_node_variant(const pending_upgrade_t *u,
                                        const upgrade_node_t *n) {
  return n->want_variant[0] ? n->want_variant : u->variant;
}

/* Send one node its CMD_UPGRADE_COMMIT.  A node that dropped off in the
 * meantime is marked unable rather than failing the run — Task 7 rolls it up
 * when it reconnects. */
static bool upgrade_commit_node(hub_state_t *state, upgrade_node_t *n) {
  pending_upgrade_t *u = &state->upgrade;
  const char *ver = upgrade_node_target(u, n);
  const char *variant = upgrade_node_variant(u, n);
  char payload[192];
  snprintf(payload, sizeof(payload), "%s|%s|%s", u->id, ver, variant);

  /* Never through a hub that has already restarted: its run state (follow_id
   * and the COMMIT routes) went with the old process, so the frame could only
   * come back as a failure — and one a pre-2.4.3 follower files under its own
   * uuid.  Hubs go after bots, so this only catches a straggler; it stays out
   * of the run, unharmed. */
  if (n->via[0]) {
    const upgrade_node_t *hop = upgrade_find_node(u, n->via);
    if (hop && (hop->state == UPG_NODE_COMMITTED ||
                hop->state == UPG_NODE_DONE || hop->state == UPG_NODE_FAILED)) {
      n->state = UPG_NODE_UNABLE;
      snprintf(n->reason, sizeof(n->reason),
               "its hub restarted before it could be committed");
      hub_log_warning("[UPGRADE] Not committing %s: hub %s already restarted\n",
                      hub_who(state, 0, n->uuid), n->via);
      return false;
    }
  }

  if (n->kind == 's') {
    /* This hub is the last node of its own run, so there is no frame and no
     * ack: hub_update_commit() either does not return (the process is
     * replaced and the marker file carries the run into it) or it fails here
     * with nothing touched.  Either way the run is over — a successful
     * restart lands in UPG_ABORTED/DONE nowhere, because the table is
     * volatile; the freeze is lifted BEFORE the exec so the network is not
     * left frozen by a hub that never comes back. */
    n->state = UPG_NODE_COMMITTED;
    n->committed_at = time(NULL);
    hub_log_info("[UPGRADE] COMMIT %s -> this hub (%s)\n", u->id, ver);
    char done_msg[192];
    snprintf(done_msg, sizeof(done_msg),
             "%d node(s) on %s; this hub is restarting onto it last",
             upgrade_count(u, UPG_NODE_DONE, 0), u->target_ver);
    /* The step is not over until this hub is seen on it: the next boot decides. */
    if (state->plan.active)
      snprintf(state->plan.self_target, sizeof(state->plan.self_target), "%s", ver);
    upgrade_finish(state, UPG_DONE, done_msg);

    const char *err = NULL;
    if (!hub_update_commit(state, u->id, ver, variant, &err)) {
      /* The other nodes are already on the target and the freeze is lifted;
       * only this hub stayed behind.  Say so in the summary rather than
       * leaving the run reading "done" with no explanation. */
      n->state = UPG_NODE_FAILED;
      snprintf(n->reason, sizeof(n->reason), "%s", err ? err : "failed");
      char why[192];
      snprintf(why, sizeof(why),
               "%d node(s) upgraded, but this hub stayed on %s: %s",
               upgrade_count(u, UPG_NODE_DONE, 0), HUB_VERSION,
               err ? err : "unknown error");
      upgrade_clean(u->summary, sizeof(u->summary), why);
      u->phase = UPG_FAILED;
      n->done_at = time(NULL);
      upgrade_history_note(state);
      hub_log_warning("[UPGRADE] This hub could not take %s: %s\n", ver,
              err ? err : "unknown error");
      if (state->plan.active) {
        state->plan.self_target[0] = '\0';
        plan_hold(state, why, true, "", "");
      }
      return false;
    }
    return true; /* unreachable: hub_update_commit() exec'd */
  }

  bool sent = false;
  if (n->via[0]) {
    /* A node somewhere below a peer hub — a bot homed on it, or a hub further
     * out in the mesh.  Route COMMIT through that peer, naming the node in a
     * 4th field; each hop either recognises the uuid (itself or one of its
     * own bots) or forwards the frame on along the route it learned at
     * PREPARE time. */
    hub_client_t *peer = upgrade_find_peer(state, n->via);
    char relay[256];
    snprintf(relay, sizeof(relay), "%s|%s", payload, n->uuid);
    sent = peer && peer_send_urgent(state, peer, CMD_UPGRADE_COMMIT, relay);
  } else if (n->kind == 'b') {
    hub_client_t *c = upgrade_find_client(state, n->uuid, CLIENT_BOT);
    sent = c && send_cmd_to_bot(state, c, CMD_UPGRADE_COMMIT, payload);
  } else if (n->kind == 'h') {
    hub_client_t *c = upgrade_find_peer(state, n->uuid);
    sent = c && peer_send_urgent(state, c, CMD_UPGRADE_COMMIT, payload);
  }
  if (!sent) {
    n->state = UPG_NODE_UNABLE;
    snprintf(n->reason, sizeof(n->reason), "disconnected before commit");
    return false;
  }
  n->state = UPG_NODE_COMMITTED;
  n->committed_at = time(NULL);
  hub_log_info("[UPGRADE] COMMIT %s -> %s (%s)\n", u->id, hub_who(state, 0, n->uuid), ver);
  return true;
}

/* The admin console asked for a network upgrade.  Freeze the config, enumerate the
 * nodes and fan PREPARE out; the rolling plan itself runs on the maintenance
 * tick.  Returns false with `msg` filled in when the run could not start.
 * `sel` is the admin's selection ("" = whole network): comma-separated
 * name-or-uuid tokens, each optionally "=c" / "=rs" to switch that node's
 * build.  It is resolved to uuids here, before anything is frozen or sent,
 * so a typo refuses the run instead of quietly moving nothing. */
static bool hub_upgrade_start(hub_state_t *state, hub_client_t *admin,
                              const char *target_ver, const char *variant,
                              const char *kind, const char *min_from,
                              const char *hub_ver, const char *sel,
                              char *msg, size_t msg_size) {
  pending_upgrade_t *u = &state->upgrade;
  if (u->active) {
    snprintf(msg, msg_size, "ERROR: upgrade %s already running (%s)", u->id,
             upgrade_phase_name(u->phase));
    return false;
  }
  /* The freeze replicates, so it is how this hub knows a run driven from
   * anywhere else in the mesh is still in flight.  Two plans moving the same
   * nodes is what the one-run-at-a-time rule exists to prevent. */
  if (hub_config_frozen(state)) {
    snprintf(msg, msg_size,
             "ERROR: config is frozen — an upgrade is already in flight "
             "somewhere in the mesh (if none is, clear opt flag 'F')");
    return false;
  }
  if (!target_ver || !target_ver[0] || !hub_upgrade_plan_field_ok(target_ver) ||
      strlen(target_ver) >= sizeof(u->target_ver)) {
    snprintf(msg, msg_size, "ERROR: bad target version");
    return false;
  }
  if (variant && variant[0] && strcmp(variant, "c") != 0 &&
      strcmp(variant, "rs") != 0) {
    snprintf(msg, msg_size, "ERROR: variant must be c or rs");
    return false;
  }
  if (kind && kind[0] && strcmp(kind, "bin") != 0 && strcmp(kind, "src") != 0) {
    snprintf(msg, msg_size, "ERROR: kind must be bin or src");
    return false;
  }
  if (min_from && min_from[0] && (!hub_upgrade_plan_field_ok(min_from) ||
                                  strlen(min_from) >= sizeof(u->min_from))) {
    snprintf(msg, msg_size, "ERROR: bad min_from version");
    return false;
  }
  if (hub_ver && (strlen(hub_ver) >= sizeof(u->hub_ver) ||
                  strpbrk(hub_ver, "|;&`$ \t\r\n"))) {
    snprintf(msg, msg_size, "ERROR: bad hub target version");
    return false;
  }

  /* Resolve the selection into a scratch copy first: an error must leave the
   * last run's table (and its status) untouched. */
  struct {
    char uuid[64];
    char variant[8];
    char kind;
  } pick[MAX_UPGRADE_SELECT];
  int picks = 0;
  if (sel && sel[0]) {
    int nc = 0;
    upgrade_cand_t *cands = upgrade_candidates(state, &nc);
    if (!cands) {
      snprintf(msg, msg_size, "ERROR: out of memory");
      return false;
    }
    char work[MAX_UPGRADE_SELECT * 80];
    snprintf(work, sizeof(work), "%s", sel);
    char *save = NULL;
    for (char *tok = strtok_r(work, ", ", &save); tok;
         tok = strtok_r(NULL, ", ", &save)) {
      char *eq = strchr(tok, '=');
      const char *want = "";
      if (eq) {
        *eq = '\0';
        want = eq + 1;
        if (strcmp(want, "c") != 0 && strcmp(want, "rs") != 0) {
          snprintf(msg, msg_size, "ERROR: '%s=%s': the build must be c or rs",
                   tok, want);
          free(cands);
          return false;
        }
      }
      char err[256];
      const upgrade_cand_t *c = upgrade_resolve(cands, nc, tok, err, sizeof(err));
      if (!c) {
        snprintf(msg, msg_size, "ERROR: %s", err);
        free(cands);
        return false;
      }
      bool dup = false;
      for (int k = 0; k < picks && !dup; k++) dup = !strcmp(pick[k].uuid, c->uuid);
      if (dup) continue;
      if (picks >= MAX_UPGRADE_SELECT) {
        snprintf(msg, msg_size,
                 "ERROR: at most %d nodes per selective run — run the whole "
                 "network instead",
                 MAX_UPGRADE_SELECT);
        free(cands);
        return false;
      }
      if (c->kind != 'b' && (!hub_ver || !hub_ver[0])) {
        snprintf(msg, msg_size,
                 "ERROR: '%s' is a hub, and this run has no hub target", tok);
        free(cands);
        return false;
      }
      snprintf(pick[picks].uuid, sizeof(pick[picks].uuid), "%s", c->uuid);
      snprintf(pick[picks].variant, sizeof(pick[picks].variant), "%s", want);
      pick[picks].kind = c->kind;
      picks++;
    }
    free(cands);
    if (picks == 0) {
      snprintf(msg, msg_size, "ERROR: the selection names no node");
      return false;
    }
  }

  /* One spelling of a version everywhere a run compares it with strcmp —
   * what nodes announce ("2.4.4"), not what manifests write ("v2.4.4"). */
  if (target_ver[0] == 'v' && isdigit((unsigned char)target_ver[1])) target_ver++;
  if (hub_ver && hub_ver[0] == 'v' && isdigit((unsigned char)hub_ver[1])) hub_ver++;

  memset(u, 0, sizeof(*u));
  generate_request_id(u->id, sizeof(u->id));
  /* Seed the PREPARE seen-ring: our own PREPARE coming back to us around a
   * cycle of peers is then dropped silently instead of being answered. */
  op_forward_seen_check_and_add(state, u->id);
  snprintf(u->target_ver, sizeof(u->target_ver), "%s", target_ver);
  snprintf(u->variant, sizeof(u->variant), "%s", variant ? variant : "");
  snprintf(u->kind, sizeof(u->kind), "%s", kind ? kind : "");
  snprintf(u->min_from, sizeof(u->min_from), "%s",
           (min_from && min_from[0]) ? min_from : "*");
  snprintf(u->hub_ver, sizeof(u->hub_ver), "%s", hub_ver ? hub_ver : "");
  u->select_count = picks;
  int sw = 0;
  for (int k = 0; k < picks; k++) {
    /* bounded copy: snprintf("%s") here reads as unbounded to gcc, which
     * sizes pick[k] by the rest of the array */
    size_t ul = strnlen(pick[k].uuid, sizeof(u->select[k].uuid) - 1);
    memcpy(u->select[k].uuid, pick[k].uuid, ul);
    u->select[k].uuid[ul] = '\0';
    snprintf(u->select[k].variant, sizeof(u->select[k].variant), "%s",
             pick[k].variant);
    int w = snprintf(u->sel_wire + sw, sizeof(u->sel_wire) - (size_t)sw,
                     "%s%s%s%s", k ? "," : "", pick[k].uuid,
                     pick[k].variant[0] ? "=" : "", pick[k].variant);
    if (w > 0 && w < (int)sizeof(u->sel_wire) - sw) sw += w;
  }
  u->origin_fd = admin ? admin->fd : -1;
  u->started = u->phase_started = time(NULL);
  if (state->plan.active) {
    u->plan_id = (long long)state->plan.started;
    u->plan_step = state->plan.step + 1;
    u->plan_steps = plan_steps(&state->plan);
  }
  if (admin && strncmp(admin->id, "ADMIN:", 6) == 0)
    snprintf(u->by, sizeof(u->by), "%s", admin->id + 6);
  else if (u->plan_id)
    hub_uhist_plan_by(state, u->plan_id, u->by, sizeof(u->by));
  u->phase = UPG_PREPARE;
  u->active = true;
  hub_plan_single_start(state);

  /* Freeze first: a config change that lands between PREPARE and the last
   * COMMIT would reach half the mesh on one build and half on another. */
  hub_opt_flag_set(state, OPT_CONFIG_FROZEN, true);

  /* Two shapes of the same PREPARE.  A bot gets the six fields it has always
   * read; a peer hub also needs the hubs' own target, appended so the bot
   * prefix stays byte-identical and a follower can relay it on, and — in a
   * selective run — the resolved selection, which tells it which of its own
   * bots to ask and whether it is itself part of the run.  Both base slots
   * are reserved and always empty (fields are positional): each node reads
   * its own compiled-in root. */
  char prepare_peer[600 + sizeof(u->sel_wire)];
  snprintf(prepare_peer, sizeof(prepare_peer), "%s|%s|%s|%s|%s||%s|%s%s",
           u->id, u->target_ver, u->variant, u->kind, u->min_from,
           u->hub_ver, u->sel_wire[0] ? "|" : "", u->sel_wire);

  int bots = 0, peers = 0;
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (!c->authenticated) continue;
    if (c->type == CLIENT_BOT) {
      const char *want = "";
      if (!upgrade_selected(u, c->id, &want)) continue;
      upgrade_node_t *n =
          upgrade_add_node(u, c->id, 'b', c->fd, c->bot_version);
      if (!n) break;
      snprintf(n->want_variant, sizeof(n->want_variant), "%s", want);
      /* The variant this bot is asked about is ITS target build, so a bot
       * told "=c" checks the C manifest at PREPARE, not its own. */
      char prepare[1024];
      snprintf(prepare, sizeof(prepare), "%s|%s|%s|%s|%s|", u->id,
               u->target_ver, upgrade_node_variant(u, n), u->kind, u->min_from);
      if (send_cmd_to_bot(state, c, CMD_UPGRADE_PREPARE, prepare)) {
        bots++;
      } else {
        n->state = UPG_NODE_UNABLE;
        snprintf(n->reason, sizeof(n->reason), "could not deliver PREPARE");
      }
    } else if (c->type == CLIENT_HUB) {
      /* No version to seed: a peer's version lives on hub_peer_config_t, not
       * on the connection.  Its READY ack carries the authoritative one. */
      /* Keyed by the peer's OWN hub uuid: that is what its UPGRADE_READY and
       * UPGRADE_RESULT carry.  c->id (the friendly name) is kept for display
       * only — see upgrade_peer_uuid(). */
      const char *puuid = upgrade_peer_uuid(state, c);
      if (!puuid[0]) {
        hub_log_warning("[UPGRADE] %s has no uuid yet — left out of run %s\n",
                hub_who_client(state, c), u->id);
        continue;
      }
      upgrade_node_t *n = upgrade_add_node(u, puuid, 'h', c->fd, NULL);
      if (!n) break;
      snprintf(n->name, sizeof(n->name), "%s", c->id);
      const char *want = "";
      if (upgrade_selected(u, puuid, &want))
        snprintf(n->want_variant, sizeof(n->want_variant), "%s", want);
      if (peer_send_urgent(state, c, CMD_UPGRADE_PREPARE, prepare_peer)) {
        peers++;
      } else {
        n->state = UPG_NODE_UNABLE;
        snprintf(n->reason, sizeof(n->reason), "could not deliver PREPARE");
      }
    }
  }
  /* This hub goes last, and answers its own PREPARE without a round trip. */
  upgrade_node_t *self =
      upgrade_add_node(u, state->hub_uuid, 's', -1, HUB_VERSION);
  if (self) {
    snprintf(self->name, sizeof(self->name), "%s", state->hub_friendly_name);
    char why[192] = "";
    const char *want = "";
    bool picked = upgrade_selected(u, state->hub_uuid, &want);
    snprintf(self->want_variant, sizeof(self->want_variant), "%s", want);
    bool can = false;
    if (!picked)
      snprintf(why, sizeof(why), "not selected");
    else if (!u->hub_ver[0])
      snprintf(why, sizeof(why), "no hub target in this run");
    else
      can = hub_update_can_take(u->hub_ver, upgrade_node_variant(u, self),
                                u->min_from, why, sizeof(why));
    self->not_selected = !picked;
    self->state = can ? UPG_NODE_READY : UPG_NODE_UNABLE;
    /* Explicit precision: a long reason is truncated on purpose. */
    snprintf(self->reason, sizeof(self->reason), "%.*s",
             (int)sizeof(self->reason) - 1, why);
    snprintf(self->variant, sizeof(self->variant), "%s",
             hub_update_host_variant());
    hub_update_host_arch(self->arch, sizeof(self->arch));
    hub_update_host_libc(self->libc, sizeof(self->libc));
  }
  /* A selected node this hub did not just ask directly is somewhere below a
   * peer (or offline).  Seed it as pending: its READY fills it in, and one
   * that never answers ends "no answer to PREPARE" instead of vanishing from
   * the status an admin is watching. */
  for (int k = 0; k < u->select_count; k++) {
    if (upgrade_find_node(u, u->select[k].uuid)) continue;
    upgrade_node_t *n = upgrade_add_node(u, u->select[k].uuid,
                                         pick[k].kind == 'b' ? 'b' : 'h', -1,
                                         NULL);
    if (!n) break;
    snprintf(n->want_variant, sizeof(n->want_variant), "%s",
             u->select[k].variant);
  }

  hub_log_info("[UPGRADE] Run %s -> %s: PREPARE to %d bot(s) and %d peer hub(s)%s%s; "
          "this hub is %s\n", u->id, u->target_ver, bots, peers,
          u->select_count ? "; selection " : "", u->sel_wire,
          self ? upgrade_node_state_name(self->state) : "not in the run");
  if (u->select_count)
    snprintf(msg, msg_size,
             "OK:upgrade %s started for %d selected node(s) -> %s%s%s; config "
             "frozen until it finishes", u->id, u->select_count, u->target_ver,
             u->hub_ver[0] ? ", hubs -> " : "", u->hub_ver);
  else
    snprintf(msg, msg_size,
             "OK:upgrade %s started for %s — %d bot(s) and %d peer hub(s) asked "
             "to prepare, this hub last; config frozen until it finishes", u->id,
             u->target_ver, bots, peers);
  upgrade_history_note(state);
  return true;
}

/* CMD_UPGRADE_READY: id|uuid|cur_ver|variant|arch|libc|ready|reason */
static void hub_upgrade_note_ready(hub_state_t *state, const char *payload,
                                   hub_client_t *from_peer) {
  pending_upgrade_t *u = &state->upgrade;
  char id[64] = "", uuid[64] = "", cur[64] = "", variant[8] = "";
  /* Sized above what a node can send (upgrade_clean caps a reason at 192), so
   * an honest long reason is truncated into node->reason rather than rejected
   * as a malformed field. */
  char arch[32] = "", libc[16] = "", okbuf[8] = "", reason[200] = "";
  if (!wire_field(payload, 0, id, sizeof(id)) ||
      !wire_field(payload, 1, uuid, sizeof(uuid)) ||
      !wire_field(payload, 2, cur, sizeof(cur)) ||
      !wire_field(payload, 3, variant, sizeof(variant)) ||
      !wire_field(payload, 4, arch, sizeof(arch)) ||
      !wire_field(payload, 5, libc, sizeof(libc)) ||
      !wire_field(payload, 6, okbuf, sizeof(okbuf)) ||
      !id[0] || !uuid[0] || !okbuf[0]) {
    hub_log_warning("[UPGRADE] Malformed UPGRADE_READY\n");
    return;
  }
  wire_field(payload, 7, reason, sizeof(reason));
  char kindbuf[8] = "", relbuf[8] = "";
  wire_field(payload, 8, kindbuf, sizeof(kindbuf));
  wire_field(payload, 9, relbuf, sizeof(relbuf));
  if (hub_rollup_note_ready(state, payload)) return;
  if (!u->active || strcmp(u->id, id) != 0) {
    hub_log_debug("[UPGRADE] READY for unknown run %s from %s — ignoring\n", id,
                  hub_who(state, 0, uuid));
    return;
  }
  upgrade_node_t *node = upgrade_find_node(u, uuid);
  if (!node) {
    /* A READY the origin has not seen this uuid for, forwarded up a peer
     * link, is a bot homed on that peer: the peer PREPARE'd it for us.  Add
     * it as a remote node reached through the peer so the rolling plan drives
     * it and CMD_ADMIN_UPGRADE_STATUS accounts for it network-wide. */
    if (from_peer) {
      char nkind = (kindbuf[0] == 'h') ? 'h' : 'b';
      node = upgrade_add_node(u, uuid, nkind, -1, cur);
      if (!node) {
        hub_log_warning("[UPGRADE] No room for remote %s in run %s\n", hub_who(state, 0, uuid),
                        id);
        return;
      }
      snprintf(node->via, sizeof(node->via), "%.63s",
               upgrade_peer_uuid(state, from_peer));
    } else {
      hub_log_warning("[UPGRADE] READY from %s which is not in run %s\n", hub_who(state, 0, uuid),
                      id);
      return;
    }
  } else if (from_peer && !node->via[0] && node->kind != 's') {
    /* Learned locally first, then forwarded: remember the route. */
    snprintf(node->via, sizeof(node->via), "%s",
             upgrade_peer_uuid(state, from_peer));
  }
  /* A READY answers PREPARE, once.  A second copy (a relay loop, a bot that
   * reconnected and was re-asked by a follower) must not move a node that is
   * already committed or finished back to "ready" — that re-commits it. */
  if (node->state != UPG_NODE_PENDING) {
    hub_log_debug("[UPGRADE] Duplicate READY from %s (%s) — ignored\n", hub_who(state, 0, uuid),
                  upgrade_node_state_name(node->state));
    return;
  }
  /* Explicit precision: a version longer than the roster field is truncated
   * on purpose, exactly as roster_clean does it for the tree. */
  snprintf(node->cur_version, sizeof(node->cur_version), "%.*s",
           (int)sizeof(node->cur_version) - 1, cur);
  snprintf(node->variant, sizeof(node->variant), "%s", variant);
  snprintf(node->arch, sizeof(node->arch), "%s", arch);
  snprintf(node->libc, sizeof(node->libc), "%s", libc);
  upgrade_clean(node->reason, sizeof(node->reason), reason);
  node->state = (okbuf[0] == '1') ? UPG_NODE_READY : UPG_NODE_UNABLE;
  if (node->ready_seq == 0) node->ready_seq = ++u->ready_seq_next;
  /* The plan is fixed when PREPARE closes.  An answer that arrives later —
   * a bot a follower relayed to, whose READY lost the race — is recorded but
   * never committed: by then the hub it sits behind may already be
   * restarting, and a COMMIT sent through it would come back as a failure
   * that aborts a healthy run (run 83aac614). */
  if (node->state == UPG_NODE_READY && u->phase != UPG_PREPARE) {
    /* Only if the hub it sits behind may be restarting.  Otherwise it joins: it
     * could not stage, so it takes the old path at COMMIT. */
    const upgrade_node_t *hop = node->via[0] ? upgrade_find_node(u, node->via) : NULL;
    if (hop && (hop->state == UPG_NODE_COMMITTED || hop->state == UPG_NODE_DONE)) {
      node->state = UPG_NODE_UNABLE;
      snprintf(node->reason, sizeof(node->reason),
               "answered after the plan was fixed — run again to include it");
    } else {
      node->can_stage = false;
    }
  }
  /* A whole-network follower (or an older one) asks every bot it has; a
   * selective run only moves what the admin named. */
  if (!upgrade_selected(u, uuid, NULL)) {
    node->state = UPG_NODE_UNABLE;
    node->not_selected = true;
    snprintf(node->reason, sizeof(node->reason), "not selected");
  }
  if (node->kind == 'h' && relbuf[0]) {
    long rel = strtol(relbuf, NULL, 10);
    node->relayed = (rel > 0 && rel <= MAX_UPGRADE_NODES) ? (int)rel : 0;
  }
  hub_log_debug("[UPGRADE] %s is %s (%s %s/%s)%s%s\n", hub_who(state, 0, uuid),
          upgrade_node_state_name(node->state), cur, arch, libc,
          node->reason[0] ? ": " : "", node->reason);
}

/* CMD_UPGRADE_RESULT: id|uuid|status|version|detail */
static void hub_upgrade_note_result(hub_state_t *state, const char *payload) {
  pending_upgrade_t *u = &state->upgrade;
  char id[64] = "", uuid[64] = "", status[32] = "", ver[64] = "";
  char detail[128] = "";
  if (!wire_field(payload, 0, id, sizeof(id)) ||
      !wire_field(payload, 1, uuid, sizeof(uuid)) ||
      !wire_field(payload, 2, status, sizeof(status)) ||
      !wire_field(payload, 3, ver, sizeof(ver)) ||
      !id[0] || !uuid[0] || !status[0]) {
    hub_log_warning("[UPGRADE] Malformed UPGRADE_RESULT\n");
    return;
  }
  wire_tail(payload, 4, detail, sizeof(detail));
  if (hub_rollup_note_result(state, payload)) return;
  if (strcmp(u->id, id) != 0) return;
  upgrade_node_t *node = upgrade_find_node(u, uuid);
  if (!node) return;

  /* A RESULT answers a COMMIT.  Anything for a node that is not committed —
   * a duplicate, a late reply from a hub that restarted, the answer to our
   * own ABORT — is logged and dropped: a finished node must never be turned
   * back into a failure by noise (run 83aac614's eb04). */
  if (node->state != UPG_NODE_COMMITTED) {
    /* A node already finished: most often a restarted hub's RESULT sent
     * again on another link (UPGRADE_RESULT_RESEND) — a copy, not news. */
    bool settled = node->state == UPG_NODE_DONE || node->state == UPG_NODE_FAILED ||
                   node->state == UPG_NODE_UNABLE;
    if (settled)
      hub_log_debug("[UPGRADE] %s reports %s (%s) while %s — ignored%s%s\n",
                    hub_who(state, 0, uuid), status, ver, upgrade_node_state_name(node->state),
                    detail[0] ? ": " : "", detail);
    else
      hub_log_info("[UPGRADE] %s reports %s (%s) while %s — ignored%s%s\n",
                   hub_who(state, 0, uuid), status, ver, upgrade_node_state_name(node->state),
                   detail[0] ? ": " : "", detail);
    return;
  }
  /* "back": a follower saw this bot return on the target; it is not done
   * until it reports ready itself (or UPGRADE_OPS_GRACE runs out). */
  if (strcmp(status, "back") == 0) {
    if (!node->back_at) node->back_at = time(NULL);
    hub_log_info("[UPGRADE] %s is back (%s); waiting for it to report ready\n",
                 hub_who(state, 0, uuid), ver);
    return;
  }
  upgrade_clean(node->reason, sizeof(node->reason), detail);
  if (strcmp(status, "ok") == 0) {
    node->state = UPG_NODE_DONE;
    node->done_at = time(NULL);
  } else if (strcmp(status, "skip") == 0) {
    /* Nothing on that node changed and it is healthy on its current build:
     * it leaves the run, the run goes on.  Abort is for harm, not noise. */
    node->state = UPG_NODE_UNABLE;
    node->done_at = time(NULL);
    if (!node->reason[0])
      snprintf(node->reason, sizeof(node->reason), "skipped");
  } else {
    node->state = UPG_NODE_FAILED;
    node->done_at = time(NULL);
    if (!node->reason[0])
      snprintf(node->reason, sizeof(node->reason), "%s", status);
  }
  hub_log_info("[UPGRADE] %s reports %s (%s)%s%s\n", hub_who(state, 0, uuid), status, ver,
          node->reason[0] ? ": " : "", node->reason);
}

/* A bot that just announced its version may be a committed node coming back
 * on the new build — that, not the RESULT frame, is the authoritative signal
 * (the RESULT can be lost, the presence cannot: without it the bot is not on
 * the mesh at all). */
static void hub_upgrade_note_presence(hub_state_t *state, const char *uuid,
                                      const char *version,
                                      const char *variant) {
  pending_upgrade_t *u = &state->upgrade;
  if (!u->active || u->phase != UPG_ROLLING || !version) return;
  upgrade_node_t *node = upgrade_find_node(u, uuid);
  if (!node) return;
  const char *target = upgrade_node_target(u, node);
  bool on_target = hub_update_version_cmp(version, target) == 0;

  /* A node that reported done and then shows up on another build fell back:
   * its upgrade script's watchdog put the old binary back because the new
   * one would not stay up.  That is the one signal a bad build gives.
   * Bots only: their presence comes straight off their own connection,
   * while a hub's header may be a relayed copy older than its restart. */
  if (node->state == UPG_NODE_DONE) {
    if (!on_target && node->kind == 'b') {
      node->state = UPG_NODE_FAILED;
      node->done_at = time(NULL);
      snprintf(node->reason, sizeof(node->reason),
               "came back on %.40s after reporting done", version);
      hub_log_warning("[UPGRADE] %s fell back to %s after reporting done\n",
                      hub_who(state, 0, uuid), version);
    }
    return;
  }
  /* Failed for lateness, and here it is on the target: the record says so. */
  if (node->state == UPG_NODE_FAILED && on_target && node->kind == 'b' && !node->staged_at) {
    node->state = UPG_NODE_DONE;
    node->done_at = time(NULL);
    snprintf(node->reason, sizeof(node->reason), "came back late");
    return;
  }
  if (node->state != UPG_NODE_COMMITTED) return;
  if (!on_target) return;
  /* A build switch at the same version is only proven by the variant: the
   * old process announced this very version before it restarted.  Without
   * a variant to compare (a hub's header line), wait for the RESULT. */
  const char *want = upgrade_node_variant(u, node);
  if (want[0] && strcmp(want, node->variant) != 0 &&
      (!variant || strcmp(variant, want) != 0))
    return;
  /* A bot that reports ready itself (once re-opped where it was) is only
   * "back" here: the next wave waits for its ok, or UPGRADE_OPS_GRACE. */
  if (node->kind == 'b') {
    if (!node->back_at) {
      node->back_at = time(NULL);
      hub_log_info("[UPGRADE] %s is back on %s; waiting for it to report ready\n",
                   hub_who(state, 0, uuid), version);
    }
    return;
  }
  node->state = UPG_NODE_DONE;
  node->done_at = time(NULL);
  hub_log_info("[UPGRADE] %s is back on %s\n", hub_who(state, 0, uuid), version);
}

bool hub_upgrade_plan_field_ok(const char *s) {
  return s && strlen(s) < 512 && !strpbrk(s, "|;&`$ \t\r\n");
}

/* A roll-up only chases a target the mesh is demonstrably running: some bot
 * other than the one being considered announces it — locally, or through the
 * presence gossip.  A follower learns the plan at PREPARE, before it can know
 * how the run ends, and only committed nodes are told of an abort; without
 * this gate an aborted run's target (a bad artifact, say) would be chased by
 * every follower the moment the freeze lifted, and — now that the plan is
 * persisted — again after every restart.  An aborted run leaves no bot on its
 * target (they roll back, or never installed it), so nothing is chased. */
static bool hub_rollup_target_proven(const hub_state_t *state,
                                     const char *target, const char *except) {
  for (int i = 0; i < state->client_count; i++) {
    const hub_client_t *c = state->clients[i];
    if (c->type == CLIENT_BOT && c->authenticated &&
        strcmp(c->id, except) != 0 && strcmp(c->bot_version, target) == 0)
      return true;
  }
  for (int i = 0; i < state->roster_count; i++) {
    const bot_roster_t *e = &state->roster[i];
    if (strcmp(e->bot_uuid, except) != 0 && strcmp(e->version, target) == 0)
      return true;
  }
  return false;
}

/* The hubs' counterpart: some hub other than `except` — this one, or any in
 * the mesh map — announces the hub target. */
static bool hub_rollup_hub_target_proven(hub_state_t *state, const char *target,
                                         const char *except) {
  if (strcmp(state->hub_uuid, except) != 0 &&
      hub_update_version_cmp(HUB_VERSION, target) == 0)
    return true;
  for (int i = 0; i < state->mesh_hub_count; i++) {
    const mesh_hub_t *m = &state->mesh_hubs[i];
    if (strcmp(m->uuid, except) != 0 && m->version[0] &&
        hub_update_version_cmp(m->version, target) == 0)
      return true;
  }
  return false;
}

/* ---- Offline roll-up ---------------------------------------------------
 * A node that was down, or homed on a hub the run never reached, comes back
 * on the old build.  Rather than making an admin notice and re-run the whole
 * thing, the hub walks that ONE node up to the last completed run's target on
 * its own: a single-node PREPARE/COMMIT, no config freeze (a late bot is not
 * a reason to hold the whole network's config still) and a hard retry bound,
 * or a node that cannot take the build is re-committed on every reconnect.
 * When the node sits below the target's min_from_version the walk is taken
 * one release at a time, reading the steps out of the manifest. */

static rollup_try_t *rollup_try_for(hub_state_t *state, const char *uuid,
                                    bool create) {
  for (int i = 0; i < state->rollup_try_count; i++)
    if (strcmp(state->rollup_tries[i].uuid, uuid) == 0)
      return &state->rollup_tries[i];
  if (!create) return NULL;
  if (state->rollup_try_count >= MAX_ROLLUP_TRIES) {
    /* The ledger is a bound, not a record: drop the oldest attempt so a
     * long-lived hub keeps rolling recent arrivals up. */
    memmove(&state->rollup_tries[0], &state->rollup_tries[1],
            sizeof(state->rollup_tries[0]) * (size_t)(MAX_ROLLUP_TRIES - 1));
    state->rollup_try_count = MAX_ROLLUP_TRIES - 1;
  }
  rollup_try_t *t = &state->rollup_tries[state->rollup_try_count++];
  memset(t, 0, sizeof(*t));
  snprintf(t->uuid, sizeof(t->uuid), "%s", uuid);
  return t;
}

/* End the attempt in flight and charge it to the node's ledger. */
static void hub_rollup_end(hub_state_t *state, const char *why, bool charge) {
  pending_rollup_t *r = &state->rollup;
  if (!r->active) return;
  if (charge) {
    rollup_try_t *t = rollup_try_for(state, r->uuid, true);
    if (t) {
      t->tries++;
      t->last_try = time(NULL);
    }
  }
  /* The last attempt, charged or not, for upgrade status. */
  rollup_try_t *last = rollup_try_for(state, r->uuid, true);
  if (last) {
    snprintf(last->step, sizeof(last->step), "%s", r->step);
    upgrade_clean(last->note, sizeof(last->note), why);
    if (!charge) last->last_try = time(NULL);
  }
  hub_log_info("[ROLLUP] %s -> %s: %s\n", hub_who(state, 0, r->uuid), r->step, why);
  r->active = false;
  r->committed = false;
  r->staging = false;
  r->ready_at = 0;
  r->id[0] = r->uuid[0] = r->step[0] = '\0';
}

/* Drop the roll-up plan (and any attempt in flight) from memory and from
 * .irchub.cnf.  Returns true when there was a plan to drop. */
static bool hub_rollup_forget(hub_state_t *state, const char *why) {
  pending_rollup_t *r = &state->rollup;
  hub_rollup_end(state, why, false);
  bool had = r->have_plan;
  if (had)
    hub_log_info("[ROLLUP] Plan %s (hubs %s) dropped: %s\n", r->target,
            r->hub_target[0] ? r->hub_target : "-", why);
  memset(r, 0, sizeof(*r));
  state->rollup_try_count = 0;
  if (had) hub_config_write(state);
  return had;
}

/* `bot resync`: a forced full config push to this hub's bot `target` (a uuid),
 * or to every one of its bots for "*".  The count queued. */
static int cfg_resync_local(hub_state_t *state, const char *target) {
  int n = 0;
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type != CLIENT_BOT || !c->authenticated || c->superseded || c->retiring) continue;
    if (strcmp(target, "*") != 0 && strcmp(c->id, target) != 0) continue;
    send_config_to_bot(state, c, true);
    n++;
  }
  return n;
}

/* CMD_CFG_RESYNC "<id>|<ts>|<uuid or *>" to every linked hub but `skip`. */
static int cfg_resync_flood(hub_state_t *state, hub_client_t *skip, const char *payload) {
  int told = 0;
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type == CLIENT_HUB && c->authenticated && c != skip &&
        peer_send_urgent(state, c, CMD_CFG_RESYNC, payload))
      told++;
  }
  return told;
}

/* ---- server rebalance (server order plan §7) ----------------------------- */

/* CMD_BOT_MOVE to our bot `uuid` (a pool bot): true when it was ours. */
static bool bot_move_local(hub_state_t *state, const char *uuid) {
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type != CLIENT_BOT || !c->authenticated || c->superseded || c->retiring ||
        strcmp(c->id, uuid) != 0 || !hub_bot_version_takes_pool(c->bot_version))
      continue;
    /* the bot's own uuid: a frame with an empty payload never reaches its dispatch */
    queued_msg_t *m = queued_msg_new(CMD_BOT_MOVE, LANE_URGENT, (const unsigned char *)c->id,
                                     (int)strlen(c->id));
    if (m && !peer_enqueue(c, m)) queued_msg_free(m);
    return true;
  }
  return false;
}

static void bot_move_flood(hub_state_t *state, hub_client_t *skip, const char *payload) {
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type == CLIENT_HUB && c->authenticated && c != skip && peer_takes_pool(state, c))
      peer_send_urgent(state, c, CMD_BOT_MOVE, payload);
  }
}

/* Move one bot, wherever it is linked. */
static void bot_move(hub_state_t *state, const char *uuid) {
  if (bot_move_local(state, uuid)) return;
  char id[40], payload[160];
  generate_uuid_v4(id, sizeof(id));
  snprintf(payload, sizeof(payload), "%s|%lld|%s", id, (long long)time(NULL), uuid);
  op_forward_seen_check_and_add(state, id);
  bot_move_flood(state, NULL, payload);
}

static void process_peer_bot_move(hub_state_t *state, hub_client_t *peer, const char *payload) {
  char id[64] = "", ts[24] = "", target[64] = "";
  if (!wire_field(payload, 0, id, sizeof(id)) || !wire_field(payload, 1, ts, sizeof(ts)) ||
      !wire_field(payload, 2, target, sizeof(target)) || !id[0] ||
      !hub_upgrade_plan_field_ok(id) || !uuid_valid(target)) {
    hub_log_warning("[HUB] Malformed BOT_MOVE from peer %s\n", peer->ip);
    return;
  }
  long long t = atoll(ts);
  long long age = t > 0 ? (long long)time(NULL) - t : 0;
  if (t <= 0 || age > CFG_RESYNC_TTL || age < -CFG_RESYNC_TTL) return;
  if (op_forward_seen_check_and_add(state, id)) return;
  if (!bot_move_local(state, target)) bot_move_flood(state, peer, payload);
}

/* The driver: the bots off their first server, moved in waves of at most
 * REBALANCE_WAVE_MAX (and a quarter of the bots up), one per origin; the next
 * wave when every bot of the last is up again (or REBALANCE_WAVE_WAIT) and a
 * pace gap has passed.  Only the hub where it was typed drives it; it ends
 * there with that hub. */

/* A bot up on IRC on an entry that is not its first: true, and both. */
static bool rebalance_off_first(const hub_state_t *state, const char *uuid, char *cur, size_t ccap,
                                char *first, size_t fcap) {
  if (!hub_pool_order_first(uuid, first, fcap, NULL, NULL)) return false;
  const char *w = hub_pool_bot_link(state, uuid, cur, ccap);
  return strcmp(w, "up") == 0 && cur[0] && strcmp(cur, first) != 0;
}

static int rebalance_up_count(const hub_state_t *state) {
  static char ids[MAX_BOTS][64];
  int n = hub_pool_order_bots(ids, MAX_BOTS), up = 0;
  char e[POOL_UUID_LEN + 1];
  for (int i = 0; i < n; i++) up += strcmp(hub_pool_bot_link(state, ids[i], e, sizeof(e)), "up") == 0;
  return up;
}

void hub_rebalance_tick(hub_state_t *state, time_t now) {
  rebalance_t *rb = &g_rebal;
  if (!rb->active) return;
  pool_net_t net;
  time_t nts;
  hub_pool_net_get(state, POOL_DEFAULT_NET, &net, &nts);
  if (rb->wn) {
    /* back = up on its first server again */
    bool back = true;
    for (int i = 0; i < rb->wn && back; i++) {
      char cur[POOL_UUID_LEN + 1], first[POOL_UUID_LEN + 1];
      back = !rebalance_off_first(state, rb->wave[i], cur, sizeof(cur), first, sizeof(first)) &&
             strcmp(hub_pool_bot_link(state, rb->wave[i], cur, sizeof(cur)), "up") == 0;
    }
    long long since = (long long)(now - rb->wave_at);
    if (since < net.pace_gap || since < 2 || (!back && since < REBALANCE_WAVE_WAIT)) return;
    rb->wn = 0;
  }
  static char ids[MAX_BOTS][64];
  int n = hub_pool_order_bots(ids, MAX_BOTS);
  int size = rebalance_up_count(state) / 4;
  if (size < 1) size = 1;
  if (size > REBALANCE_WAVE_MAX) size = REBALANCE_WAVE_MAX;
  char origins[REBALANCE_WAVE_MAX][MAX_MASK_LEN];
  for (int i = 0; i < n && rb->wn < size; i++) {
    char cur[POOL_UUID_LEN + 1], first[POOL_UUID_LEN + 1], org[MAX_MASK_LEN];
    if (!rebalance_off_first(state, ids[i], cur, sizeof(cur), first, sizeof(first))) continue;
    bool again = false;
    for (int k = 0; k < rb->ndone && !again; k++) again = strcmp(rb->done[k], ids[i]) == 0;
    if (again) continue; /* moved once and still off: its first is not taking it */
    hub_pool_bot_origin(state, ids[i], org, sizeof(org));
    bool dup = false;
    for (int k = 0; k < rb->wn && !dup; k++) dup = org[0] && strcmp(origins[k], org) == 0;
    if (dup) continue;
    snprintf(origins[rb->wn], sizeof(origins[0]), "%s", org);
    memcpy(rb->wave[rb->wn++], ids[i], sizeof(rb->wave[0]));
  }
  if (!rb->wn) {
    hub_log_info("[POOL] Rebalance by %s done: %d bot%s moved in %d wave%s\n", rb->by, rb->moved,
                 rb->moved == 1 ? "" : "s", rb->waves, rb->waves == 1 ? "" : "s");
    rb->active = false;
    return;
  }
  for (int i = 0; i < rb->wn; i++) {
    hub_log_info("[POOL] Rebalance wave %d: moving %s to its first server\n", rb->waves + 1,
                 hub_who(state, 'b', rb->wave[i]));
    bot_move(state, rb->wave[i]);
    if (rb->ndone < MAX_BOTS) memcpy(rb->done[rb->ndone++], rb->wave[i], sizeof(rb->done[0]));
  }
  rb->moved += rb->wn;
  rb->waves++;
  rb->wave_at = now;
}

/* CMD_CFG_RESYNC from a peer: resync our matching bots, pass it on. */
static void process_peer_cfg_resync(hub_state_t *state, hub_client_t *peer, const char *payload) {
  char id[64] = "", ts[24] = "", target[64] = "";
  if (!wire_field(payload, 0, id, sizeof(id)) || !wire_field(payload, 1, ts, sizeof(ts)) ||
      !wire_field(payload, 2, target, sizeof(target)) || !id[0] ||
      !hub_upgrade_plan_field_ok(id) || (strcmp(target, "*") != 0 && !uuid_valid(target))) {
    hub_log_warning("[HUB] Malformed CFG_RESYNC from peer %s\n", peer->ip);
    return;
  }
  long long t = atoll(ts);
  long long age = t > 0 ? (long long)time(NULL) - t : 0;
  if (t <= 0 || age > CFG_RESYNC_TTL || age < -CFG_RESYNC_TTL) return;
  if (op_forward_seen_check_and_add(state, id)) return;
  int n = cfg_resync_local(state, target);
  if (n) hub_log_info("[HUB] Resync from another hub: full config queued to %d bot(s)\n", n);
  cfg_resync_flood(state, peer, payload);
}

/* CMD_UPGRADE_FORGET from a peer: drop our plan and pass it on. */
static void process_peer_upgrade_forget(hub_state_t *state, hub_client_t *peer,
                                        const char *payload) {
  char id[64] = "", ts[24] = "";
  if (!wire_field(payload, 0, id, sizeof(id)) ||
      !wire_field(payload, 1, ts, sizeof(ts)) || !id[0] ||
      !hub_upgrade_plan_field_ok(id)) {
    hub_log_warning("[ROLLUP] Malformed UPGRADE_FORGET from peer %s\n", peer->ip);
    return;
  }
  long long t = atoll(ts); /* saturates: age only for a positive stamp */
  long long age = t > 0 ? (long long)time(NULL) - t : 0;
  if (t <= 0 || age > UPGRADE_FORGET_TTL || age < -UPGRADE_FORGET_TTL)
    return;
  if (op_forward_seen_check_and_add(state, id)) return;
  char flag[4] = "", issued_s[24] = "";
  wire_field(payload, 2, flag, sizeof(flag));
  wire_field(payload, 3, issued_s, sizeof(issued_s));
  if (strcmp(flag, "A") == 0) {
    /* `upgrade abort` typed on another hub: stop whatever this hub drives —
     * a run in flight, and a multi-step plan between its steps — unless it
     * started after the admin typed it (a re-sent abort meeting a new run).
     * Remembered, so a peer that comes up in the next UPGRADE_CANCEL_HOLD
     * seconds hears it too. */
    time_t issued = (time_t)(issued_s[0] ? atoll(issued_s) : atoll(ts));
    snprintf(state->upgrade_cancel_id, sizeof(state->upgrade_cancel_id), "%s", id);
    state->upgrade_cancel_issued = issued;
    state->upgrade_cancel_seen = time(NULL);
    /* A run that carries on a plan begun before the abort is stopped too: a hub that
     * took the plan over after the admin typed it still drives that plan. */
    if (state->upgrade.active &&
        (state->upgrade.started <= issued || (state->plan.active && state->plan.started <= issued)))
      hub_upgrade_abort(state, "aborted by an admin on another hub");
    if (state->plan.active && state->plan.started <= issued)
      plan_stop(state, "aborted by an admin on another hub");
    hub_plan_cancelled(state, issued);
  } else if (!state->upgrade.active && !hub_config_frozen(state)) {
    /* A plan is never dropped under a run: the freeze is replicated, so
     * every hub sees the same answer the admin's own hub gave. */
    hub_rollup_forget(state, "forgotten by an admin on another hub");
  }
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type == CLIENT_HUB && c->authenticated && c != peer)
      peer_send_urgent(state, c, CMD_UPGRADE_FORGET, payload);
  }
}

/* Is this uuid a node worth catching up, and may we try it now? */
static bool hub_rollup_may_try(hub_state_t *state, const char *uuid,
                               char node_kind, const char *version) {
  pending_rollup_t *r = &state->rollup;
  if (!r->have_plan || r->active) return false;
  if (state->upgrade.active) return false; /* a real run owns the mesh */
  /* ...and so does a multi-step upgrade between its steps: the next step
   * moves every node anyway, and a straggler is caught up after the last. */
  if (state->plan.active && !(state->plan.hold_uuid[0] && uuid &&
                              strcmp(state->plan.hold_uuid, uuid) == 0))
    return false;
  /* Any hub, while a plan is out: the freeze lifts between steps, this does not.
   * The one exception is the node a plan is on hold for. */
  if (state->splan.active && !state->splan.single &&
      !(state->splan.hold_uuid[0] && uuid && strcmp(state->splan.hold_uuid, uuid) == 0))
    return false;
  /* The freeze is the mesh-wide "a run is in flight" signal: it is set at
   * PREPARE, replicated with the rest of the opt record, and lifted when the
   * run ends.  A follower learns a run finished from it — nothing else tells
   * it — and neither end may chase a straggler while it holds. */
  if (hub_config_frozen(state)) return false;
  if (!uuid || !uuid[0] || !version || !version[0]) return false;
  if (node_kind == 'h') {
    if (!r->hub_target[0] ||
        hub_update_version_cmp(version, r->hub_target) >= 0 ||
        !hub_rollup_hub_target_proven(state, r->hub_target, uuid))
      return false;
  } else if (hub_update_version_cmp(version, r->target) >= 0 ||
             !hub_rollup_target_proven(state, r->target, uuid)) {
    return false;
  }
  time_t now = time(NULL);
  if (now - r->plan_set < ROLLUP_SETTLE) return false;
  const rollup_try_t *t = rollup_try_for(state, uuid, false);
  if (!t) return true;
  if (t->tries >= ROLLUP_MAX_TRIES) return false;
  return now - t->last_try >= ROLLUP_COOLDOWN;
}

/* A node announced a version older than the last completed run's target.
 * Start a single-node PREPARE for the next step it can take. */
static void hub_rollup_consider(hub_state_t *state, const char *uuid,
                                char node_kind, const char *version) {
  pending_rollup_t *r = &state->rollup;
  if (!hub_rollup_may_try(state, uuid, node_kind, version)) return;

  /* Stepping: when the node is below the target's min_from it cannot jump
   * straight there, so ask the manifest for the highest release it may take
   * from where it is.  A manifest this hub cannot read (no curl, no key, no
   * network) is not fatal — aim straight at the target and let the node's own
   * updater refuse if it must. */
  /* Read the node's OWN product tree for its own build: a bot steps along
   * ircbot-releases, a hub along this hub's irchub tree. */
  char step[64], why[192] = "";
  const char *target = node_kind == 'h' ? r->hub_target : r->target;
  const char *step_variant;
  if (node_kind == 'h') {
    const mesh_hub_t *m = mesh_hub_find(state, uuid);
    step_variant = (m && m->variant[0]) ? m->variant : hub_update_host_variant();
  } else {
    hub_client_t *bc = upgrade_find_client(state, uuid, CLIENT_BOT);
    step_variant = r->variant[0]                ? r->variant
                   : (bc && bc->bot_variant[0]) ? bc->bot_variant
                                                : "c";
  }
  if (!hub_update_next_step(node_kind == 'h' ? NULL : hub_update_bot_root(),
                            step_variant, version, target, step, sizeof(step),
                            why, sizeof(why))) {
    snprintf(step, sizeof(step), "%s", target);
    if (why[0])
      hub_log_info("[ROLLUP] No step read for %s (%s); aiming at %s\n", hub_who(state, 0, uuid),
                   why,
              target);
  }
  if (step[0] == 'v' && isdigit((unsigned char)step[1]))
    memmove(step, step + 1, strlen(step));

  r->active = true;
  r->committed = false;
  r->node_kind = node_kind;
  generate_request_id(r->id, sizeof(r->id));
  snprintf(r->uuid, sizeof(r->uuid), "%s", uuid);
  snprintf(r->step, sizeof(r->step), "%s", step);
  r->started = time(NULL);

  /* min_from is "*": the step was already chosen against the manifest, and a
   * second check at the node would only re-answer the same question. */
  char prepare[1024];
  bool sent;
  if (node_kind == 'h') {
    /* A directly linked hub gets the peer shape of a SELECTIVE run naming
     * only itself: it checks its own hub target, asks none of its bots, and
     * whatever it relays on is answered "not selected" and ignored here.  A
     * selective PREPARE leaves no roll-up plan behind on anyone, and our own
     * copy coming back around a cycle is dropped by the seen-ring. */
    snprintf(prepare, sizeof(prepare), "%s|%s|%s|%s|*||%s||%s", r->id,
             r->target, r->variant, r->kind, r->step, uuid);
    op_forward_seen_check_and_add(state, r->id);
    hub_client_t *pc = upgrade_find_peer(state, uuid);
    sent = pc && peer_send_urgent(state, pc, CMD_UPGRADE_PREPARE, prepare);
  } else {
    /* Local bots only for the bot side: the run's bot PREPARE carries no
     * selection, so sent to a peer it would be fanned mesh-wide. */
    snprintf(prepare, sizeof(prepare), "%s|%s|%s|%s|*|", r->id, r->step,
             r->variant, r->kind);
    hub_client_t *c = upgrade_find_client(state, uuid, CLIENT_BOT);
    sent = c && send_cmd_to_bot(state, c, CMD_UPGRADE_PREPARE, prepare);
  }
  if (!sent) {
    hub_rollup_end(state, "could not deliver PREPARE", true);
    return;
  }
  hub_log_info("[ROLLUP] %s is on %s, the network is on %s: PREPARE %s -> %s\n",
          hub_who(state, 0, uuid), version, target, r->id, r->step);
}

/* CMD_UPGRADE_READY carrying a roll-up id.  Returns true when it was one. */
static bool hub_rollup_note_ready(hub_state_t *state, const char *payload) {
  pending_rollup_t *r = &state->rollup;
  char id[64] = "", uuid[64] = "", okbuf[8] = "", reason[200] = "";
  wire_field(payload, 0, id, sizeof(id));
  if (!r->active || !id[0] || strcmp(r->id, id) != 0) return false;
  wire_field(payload, 1, uuid, sizeof(uuid));
  wire_field(payload, 6, okbuf, sizeof(okbuf));
  wire_field(payload, 7, reason, sizeof(reason));
  if (strcmp(uuid, r->uuid) != 0) return true; /* not the node we asked */

  if (okbuf[0] != '1') {
    hub_rollup_end(state, reason[0] ? reason : "node cannot take it", true);
    return true;
  }
  /* Its progress frame says whether it can stage; one that says nothing is an older
   * build, and hub_rollup_tick commits it the old way. */
  r->ready_at = time(NULL);
  return true;
}

/* The node is ready, staged or never able to be: go. */
static void hub_rollup_commit(hub_state_t *state) {
  pending_rollup_t *r = &state->rollup;
  r->ready_at = 0;
  r->staging = false;
  char commit[256];
  bool sent;
  if (r->node_kind == 'h') {
    /* addressed to the hub itself (4th field), as a run commits a hub */
    snprintf(commit, sizeof(commit), "%s|%s||%s", r->id, r->step, r->uuid);
    hub_client_t *pc = upgrade_find_peer(state, r->uuid);
    sent = pc && peer_send_urgent(state, pc, CMD_UPGRADE_COMMIT, commit);
  } else {
    snprintf(commit, sizeof(commit), "%s|%s|%s", r->id, r->step, r->variant);
    hub_client_t *c = upgrade_find_client(state, r->uuid, CLIENT_BOT);
    sent = c && send_cmd_to_bot(state, c, CMD_UPGRADE_COMMIT, commit);
  }
  if (!sent) {
    hub_rollup_end(state, "disconnected before commit", true);
    return;
  }
  r->committed = true;
  r->started = time(NULL);
  hub_log_info("[ROLLUP] COMMIT %s -> %s (%s)\n", r->id, hub_who(state, 0, r->uuid), r->step);
}

/* CMD_UPGRADE_PROGRESS carrying a roll-up id.  True when it was one. */
static bool hub_rollup_note_progress(hub_state_t *state, const char *payload) {
  pending_rollup_t *r = &state->rollup;
  char id[64] = "", uuid[64] = "", phase[16] = "", code[16] = "", note[160] = "";
  wire_field(payload, 0, id, sizeof(id));
  if (!r->active || !id[0] || strcmp(r->id, id) != 0) return false;
  wire_field(payload, 1, uuid, sizeof(uuid));
  if (strcmp(uuid, r->uuid) != 0) return true;
  wire_field(payload, 2, phase, sizeof(phase));
  wire_field(payload, 3, code, sizeof(code));
  wire_field(payload, 4, note, sizeof(note));
  r->stage_last = time(NULL);
  if (strcmp(phase, "ready") == 0) {
    char frame[80];
    snprintf(frame, sizeof(frame), "%s", r->id);
    bool sent;
    if (r->node_kind == 'h') {
      hub_client_t *pc = upgrade_find_peer(state, r->uuid);
      sent = pc && peer_send_urgent(state, pc, CMD_UPGRADE_STAGE, frame);
    } else {
      hub_client_t *c = upgrade_find_client(state, r->uuid, CLIENT_BOT);
      sent = c && send_cmd_to_bot(state, c, CMD_UPGRADE_STAGE, frame);
    }
    if (sent) {
      r->staging = true;
      r->ready_at = 0;
      r->started = time(NULL);
    }
  } else if (strcmp(phase, "staged") == 0) {
    hub_rollup_commit(state);
  } else if (strcmp(phase, "failed") == 0) {
    char why[192];
    snprintf(why, sizeof(why), "%s: %s", code[0] ? code : "stage", note);
    hub_rollup_end(state, why, true);
  }
  return true;
}

/* A bot restarted by a roll-up can come back on any hub, and its done report
 * reaches only that one.  An id that is not this hub's to answer is passed on,
 * once, to every other peer, so the hub that asked hears it.  False = not
 * relayed.  A peer on an older build ignores it, and the attempt times out. */
static bool hub_upgrade_result_relay(hub_state_t *state, hub_client_t *from,
                                     const char *payload) {
  char id[64] = "", uuid[64] = "", status[32] = "", key[64];
  if (strlen(payload) > UPGRADE_RESULT_RELAY_MAX ||
      !wire_field(payload, 0, id, sizeof(id)) ||
      !wire_field(payload, 1, uuid, sizeof(uuid)) ||
      !wire_field(payload, 2, status, sizeof(status)) || !id[0] || !uuid[0] ||
      !status[0])
    return false;
  if (strcmp(state->follow_id, id) == 0 || strcmp(state->upgrade.id, id) == 0 ||
      (state->rollup.active && strcmp(state->rollup.id, id) == 0))
    return false;
  snprintf(key, sizeof(key), "ur:%.59s", id);
  if (op_forward_seen_check_and_add(state, key)) return false;
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c != from && c->type == CLIENT_HUB && c->authenticated)
      peer_send_urgent(state, c, CMD_UPGRADE_RESULT, payload);
  }
  return true;
}

/* CMD_UPGRADE_RESULT carrying a roll-up id.  Returns true when it was one. */
static bool hub_rollup_note_result(hub_state_t *state, const char *payload) {
  pending_rollup_t *r = &state->rollup;
  char id[64] = "", uuid[64] = "", status[32] = "", ver[64] = "", detail[128] = "";
  wire_field(payload, 0, id, sizeof(id));
  if (!r->active || !id[0] || strcmp(r->id, id) != 0) return false;
  wire_field(payload, 1, uuid, sizeof(uuid));
  if (strcmp(uuid, r->uuid) != 0) return true; /* not the node we asked */
  wire_field(payload, 2, status, sizeof(status));
  wire_field(payload, 3, ver, sizeof(ver));
  wire_field(payload, 4, detail, sizeof(detail));
  if (strcmp(status, "ok") != 0) {
    hub_rollup_end(state, detail[0] ? detail : status, true);
    return true;
  }
  /* "ok" with a detail: the bot waited UPGRADE_OPS_WAIT and is on the step, but
   * not back on IRC or not re-opped everywhere. */
  if (detail[0])
    hub_log_warning("[ROLLUP] %s installed %s: %s\n", hub_who(state, 0, uuid),
                    r->step, detail);
  hub_rollup_end(state, detail[0] ? "reports done, with a problem" : "reports done",
                 false);
  /* A walk of several releases keeps going from the new version, here if the
   * bot came back here; else the hub it is on takes it from its presence. */
  if (ver[0] && upgrade_find_client(state, uuid, CLIENT_BOT))
    hub_rollup_consider(state, uuid, 'b', ver);
  return true;
}

/* An attempt on a bot ends on its done report (hub_rollup_note_result), not on
 * its presence: presence comes as soon as it has a hub link, and "done" means
 * back on IRC and re-opped.  Presence only starts the next attempt. */
static void hub_rollup_note_presence(hub_state_t *state, const char *uuid,
                                     char node_kind, const char *version) {
  hub_rollup_consider(state, uuid, node_kind, version);
}

/* The newest version this hub knows a bot runs: its live link here, or any
 * hub's presence report.  NULL when nobody reports it (it is down). */
static const char *rollup_bot_version(const hub_state_t *state, const char *uuid) {
  const char *best = NULL;
  for (int i = 0; i < state->client_count; i++) {
    const hub_client_t *c = state->clients[i];
    if (c->type == CLIENT_BOT && c->authenticated && !c->superseded && c->bot_version[0] &&
        strcmp(c->id, uuid) == 0)
      best = c->bot_version;
  }
  for (int i = 0; i < state->roster_count; i++) {
    const bot_roster_t *e = &state->roster[i];
    if (e->version[0] && strcmp(e->bot_uuid, uuid) == 0 &&
        (!best || hub_update_version_cmp(e->version, best) > 0))
      best = e->version;
  }
  return best;
}

static bool rollup_hub_on(const hub_state_t *state, const char *uuid,
                          const char *target) {
  if (!uuid[0]) return false; /* a peer never heard from */
  if (state->hub_uuid[0] && strcmp(uuid, state->hub_uuid) == 0)
    return hub_update_version_cmp(HUB_VERSION, target) >= 0;
  for (int i = 0; i < state->mesh_hub_count; i++)
    if (strcmp(state->mesh_hubs[i].uuid, uuid) == 0)
      return state->mesh_hubs[i].version[0] &&
             hub_update_version_cmp(state->mesh_hubs[i].version, target) >= 0;
  return false;
}

/* Is anybody still owed the plan?  Every registered bot heard from on the
 * target or later and, when the run moved hubs, this hub, every configured
 * peer and every hub in the mesh map on the hub target.  A node that is down
 * is unknown here, so it keeps the plan alive -- that is what it is for. */
static bool hub_rollup_owed(const hub_state_t *state) {
  const pending_rollup_t *r = &state->rollup;
  for (int i = 0; i < state->bot_count; i++) {
    const bot_config_t *b = &state->bots[i];
    if (!b->is_active || !bot_entry_rec(b, "pub")) continue;
    const char *v = rollup_bot_version(state, b->uuid);
    if (!v || hub_update_version_cmp(v, r->target) < 0) return true;
  }
  if (!r->hub_target[0]) return false;
  if (!rollup_hub_on(state, state->hub_uuid, r->hub_target)) return true;
  for (int i = 0; i < state->peer_count; i++)
    if (!rollup_hub_on(state, state->peers[i].uuid, r->hub_target)) return true;
  for (int i = 0; i < state->mesh_hub_count; i++)
    if (!rollup_hub_on(state, state->mesh_hubs[i].uuid, r->hub_target)) return true;
  return false;
}

/* Drop a plan nobody is owed any more, or one past ROLLUP_PLAN_TTL.  Never
 * under a run or the freeze that announces one: a follower holds the driver's
 * plan from PREPARE on, long before the nodes have moved. */
static void hub_rollup_settle(hub_state_t *state, time_t now) {
  pending_rollup_t *r = &state->rollup;
  if (!r->have_plan || r->active || state->upgrade.active ||
      hub_config_frozen(state))
    return;
  if (r->plan_set > 0 && now - r->plan_set > ROLLUP_PLAN_TTL)
    hub_rollup_forget(state, "expired: the stragglers never came back within 7 days");
  else if (!hub_rollup_owed(state))
    hub_rollup_forget(state, "complete: every bot and hub is on the target");
}

/* Hubs have no presence frame of their own here: the mesh gossip carries
 * each hub's version.  So once a maintenance tick, (a) end a hub attempt
 * whose hub is back on the step, and (b) consider ONE directly linked hub
 * that is behind the plan's hub target.  Of the hubs linked to a lagging
 * hub, only the one with the lowest uuid walks it, so two neighbours never
 * prepare it at once; a hub whose links are not known yet is walked by any. */
static void hub_rollup_scan_hubs(hub_state_t *state) {
  pending_rollup_t *r = &state->rollup;
  if (!r->have_plan || !r->hub_target[0]) return;
  if (r->active) {
    if (r->node_kind != 'h') return;
    const mesh_hub_t *m = mesh_hub_find(state, r->uuid);
    if (m && m->version[0] && hub_update_version_cmp(m->version, r->step) >= 0) {
      char uuid[64], ver[ROSTER_VERSION_MAX + 1];
      snprintf(uuid, sizeof(uuid), "%s", r->uuid);
      snprintf(ver, sizeof(ver), "%s", m->version);
      hub_rollup_end(state, "back on the step it was given", false);
      hub_rollup_consider(state, uuid, 'h', ver);
    }
    return;
  }
  for (int i = 0; i < state->peer_count; i++) {
    const hub_peer_config_t *p = &state->peers[i];
    if (!p->connected || !p->uuid[0]) continue;
    const mesh_hub_t *m = mesh_hub_find(state, p->uuid);
    if (!m || !m->version[0] ||
        hub_update_version_cmp(m->version, r->hub_target) >= 0)
      continue;
    bool mine = true;
    for (int k = 0; k < m->link_count && mine; k++)
      if (m->links[k].online && strcmp(m->links[k].uuid, state->hub_uuid) < 0)
        mine = false;
    if (!mine) continue;
    hub_rollup_consider(state, p->uuid, 'h', m->version);
    if (r->active) return;
  }
}

/* Time out an attempt that went nowhere, and drop a plan nobody is owed.
 * Runs on the maintenance clock. */
static void hub_rollup_tick(hub_state_t *state, time_t now) {
  pending_rollup_t *r = &state->rollup;
  hub_rollup_settle(state, now);
  hub_rollup_scan_hubs(state);
  if (!r->active) return;
  /* READY, and no word that it can stage: an older build. */
  if (r->ready_at && now - r->ready_at >= ROLLUP_STAGE_WAIT) {
    hub_rollup_commit(state);
    return;
  }
  if (r->staging) {
    if (now - r->stage_last > UPGRADE_STAGE_SILENCE) {
      hub_rollup_end(state, "stage: no word from it", true);
    } else if (now - r->started > UPGRADE_BUILD_SECS) {
      hub_rollup_end(state, "stage: past its limit", true);
    }
    return;
  }
  if (now - r->started <= ROLLUP_TIMEOUT) return;
  /* On the step, but no done report: it came through a hub that cannot relay
   * it, or was lost.  The bot is not behind, so charge it nothing. */
  const char *ver = r->node_kind == 'b' ? rollup_bot_version(state, r->uuid) : NULL;
  if (r->committed && ver && hub_update_version_cmp(ver, r->step) >= 0) {
    hub_log_warning("[ROLLUP] %s is on %s, but no done report reached this hub\n",
                    hub_who(state, 0, r->uuid), r->step);
    hub_rollup_end(state, "on the step, no done report", false);
    return;
  }
  hub_rollup_end(state, r->committed ? "did not come back on the step in time"
                                     : "no answer to PREPARE", true);
}

/* ---- Multi-step upgrades -------------------------------------------------
 * `upgrade start` to a version some node cannot reach in one go — it sits
 * below that release's min_from — takes the intermediate releases the signed
 * manifests name, one ordinary run per step.  The path is planned once, up
 * front, from the oldest node of each product; each step's target is the
 * newest release the previous one may install (hub_update_next_step), so a
 * release that floors nothing is skipped.  Every node finishes a step before
 * any starts the next: a release's min_from is also what keeps a newer mesh
 * from refusing nodes still on an older one (MESH_MIN_VERSION).
 *
 * Only this hub knows the plan, and it restarts onto each step itself, so the
 * plan lives in its .irchub.cnf (uplan|, see hub_config_write).  Nothing new
 * goes on the wire: each step is a run like any other, which is what lets it
 * move 2.4.x nodes that know nothing about plans. */

static int plan_steps(const upgrade_plan_t *pl) {
  return pl->bot_steps > pl->hub_steps ? pl->bot_steps : pl->hub_steps;
}

/* `path` is a char[n][64] passed flat, so a const plan needs no cast */
static void plan_path_csv(const char *path, int n, char *out, size_t cap) {
  size_t o = 0;
  out[0] = '\0';
  for (int i = 0; i < n; i++) {
    int w = snprintf(out + o, cap - o, "%s%s", i ? "," : "", path + (size_t)i * 64);
    if (w < 0 || (size_t)w >= cap - o) break;
    o += (size_t)w;
  }
}

static void strip_v(char *v) {
  if (v[0] == 'v' && isdigit((unsigned char)v[1])) memmove(v, v + 1, strlen(v));
}

/* The admin's selection resolved to "uuid,uuid,...", or "" for the whole
 * network.  A token that does not resolve is left out here: hub_upgrade_start
 * resolves the selection again and refuses it with the reason. */
static void plan_sel_uuids(hub_state_t *state, const char *sel, char *out,
                           size_t cap) {
  out[0] = '\0';
  if (!sel || !sel[0]) return;
  int nc = 0;
  upgrade_cand_t *cands = upgrade_candidates(state, &nc);
  if (!cands) return;
  char work[MAX_UPGRADE_SELECT * 80];
  snprintf(work, sizeof(work), "%s", sel);
  size_t o = 0;
  char *save = NULL;
  for (char *tok = strtok_r(work, ", ", &save); tok;
       tok = strtok_r(NULL, ", ", &save)) {
    char *eq = strchr(tok, '=');
    if (eq) *eq = '\0';
    char err[256];
    const upgrade_cand_t *c = upgrade_resolve(cands, nc, tok, err, sizeof(err));
    if (!c) continue;
    int w = snprintf(out + o, cap - o, "%s%s", o ? "," : "", c->uuid);
    if (w < 0 || (size_t)w >= cap - o) break;
    o += (size_t)w;
  }
  free(cands);
}

/* The oldest version (and its build) among the nodes of one product a run
 * would move: 'b' bots — local and those the roster gossip reports — or 'h'
 * hubs, this one included.  "" when no version is known. */
static void plan_oldest(hub_state_t *state, char kind, const char *uuids,
                        char *ver, size_t vcap, char *var, size_t varcap) {
  ver[0] = var[0] = '\0';
#define PLAN_CONSIDER(u, v, b)                                                 \
  do {                                                                         \
    if ((v)[0] && (!uuids[0] || upgrade_sel_lookup(uuids, (u), NULL, 0)) &&   \
        (!ver[0] || hub_update_version_cmp((v), ver) < 0)) {                   \
      snprintf(ver, vcap, "%s", (v));                                          \
      snprintf(var, varcap, "%s", (b));                                        \
    }                                                                          \
  } while (0)
  if (kind == 'h') {
    PLAN_CONSIDER(state->hub_uuid, HUB_VERSION, hub_update_host_variant());
    for (int i = 0; i < state->mesh_hub_count; i++) {
      const mesh_hub_t *m = &state->mesh_hubs[i];
      if (m->uuid[0] && strcmp(m->uuid, state->hub_uuid) != 0)
        PLAN_CONSIDER(m->uuid, m->version, m->variant);
    }
  } else {
    for (int i = 0; i < state->client_count; i++) {
      const hub_client_t *c = state->clients[i];
      if (c->type == CLIENT_BOT && c->authenticated)
        PLAN_CONSIDER(c->id, c->bot_version, c->bot_variant);
    }
    for (int i = 0; i < state->roster_count; i++) {
      const bot_roster_t *e = &state->roster[i];
      PLAN_CONSIDER(e->bot_uuid, e->version, e->variant);
    }
  }
#undef PLAN_CONSIDER
}

/* The steps from `from` to `target` along one release tree: each one the
 * newest release the previous may install.  Returns the count (0 = nothing
 * to do), or -1 with `why` set when the path cannot be walked or is longer
 * than MAX_UPGRADE_STEPS.  A manifest this hub cannot read gives the one-step
 * path a run always took: the nodes still check min_from themselves. */
static int plan_path(const char *root, const char *variant, const char *from,
                     const char *target, char path[][64], char *why,
                     size_t why_size) {
  why[0] = '\0';
  if (!from[0]) {
    snprintf(path[0], 64, "%s", target);
    return 1;
  }
  if (hub_update_version_cmp(from, target) >= 0) return 0;
  char cur[64];
  snprintf(cur, sizeof(cur), "%s", from);
  int n = 0;
  while (hub_update_version_cmp(cur, target) < 0) {
    char step[64], err[192] = "";
    if (!hub_update_next_step(root, variant, cur, target, step, sizeof(step),
                              err, sizeof(err))) {
      if (n == 0) {
        snprintf(path[0], 64, "%s", target);
        return 1;
      }
      /* A long manifest error is cut to fit (gcc 8 wants the result read). */
      if (snprintf(why, why_size, "no step from %s towards %s: %s", cur, target,
                   err[0] ? err : "manifest unreadable") >= (int)why_size)
        hub_log_debug("[UPDATE] step error cut to %zu bytes\n", why_size - 1);
      return -1;
    }
    strip_v(step);
    if (hub_update_version_cmp(step, cur) <= 0) {
      snprintf(why, why_size, "no release in the manifest can be installed over %s",
               cur);
      return -1;
    }
    if (n >= MAX_UPGRADE_STEPS) {
      snprintf(why, why_size,
               "the path from %s to %s takes more than %d steps — upgrade to "
               "an intermediate release first", from, target, MAX_UPGRADE_STEPS);
      return -1;
    }
    snprintf(path[n++], 64, "%s", step);
    snprintf(cur, sizeof(cur), "%s", step);
  }
  return n;
}

/* Plan both products' paths into `pl` (not yet active).  False with `why`. */
static bool plan_compute(hub_state_t *state, const char *bot_ver,
                         const char *hub_ver, const char *variant,
                         const char *sel, upgrade_plan_t *pl, char *why,
                         size_t why_size) {
  memset(pl, 0, sizeof(*pl));
  snprintf(pl->bot_target, sizeof(pl->bot_target), "%s", bot_ver);
  strip_v(pl->bot_target);
  snprintf(pl->hub_target, sizeof(pl->hub_target), "%s", hub_ver ? hub_ver : "");
  strip_v(pl->hub_target);
  char uuids[MAX_UPGRADE_SELECT * 72], var[16];
  plan_sel_uuids(state, sel, uuids, sizeof(uuids));
  plan_oldest(state, 'b', uuids, pl->bot_from, sizeof(pl->bot_from), var, sizeof(var));
  int n = plan_path(hub_update_bot_root(),
                    variant && variant[0] ? variant : var[0] ? var : "c",
                    pl->bot_from, pl->bot_target, pl->bot_path, why, why_size);
  if (n < 0) return false;
  pl->bot_steps = n;
  if (pl->hub_target[0]) {
    plan_oldest(state, 'h', uuids, pl->hub_from, sizeof(pl->hub_from), var, sizeof(var));
    n = plan_path(NULL, variant && variant[0] ? variant : var[0] ? var : "c",
                  pl->hub_from, pl->hub_target, pl->hub_path, why, why_size);
    if (n < 0) return false;
    pl->hub_steps = n;
  }
  return true;
}

/* The targets of step `i`.  A product whose path is shorter sits the later
 * steps out: its final target, which every node of it already runs. */
static void plan_step_targets(const upgrade_plan_t *pl, int i, char *bot,
                              char *hub) {
  if (pl->bot_steps == 0) snprintf(bot, 64, "%s", pl->bot_target);
  else snprintf(bot, 64, "%s", pl->bot_path[i < pl->bot_steps ? i : pl->bot_steps - 1]);
  if (!pl->hub_target[0]) hub[0] = '\0';
  else if (pl->hub_steps == 0) snprintf(hub, 64, "%s", pl->hub_target);
  else snprintf(hub, 64, "%s", pl->hub_path[i < pl->hub_steps ? i : pl->hub_steps - 1]);
}

static void plan_stop(hub_state_t *state, const char *summary) {
  upgrade_plan_t *pl = &state->plan;
  if (!pl->active) return;
  pl->active = false;
  pl->run_id[0] = '\0';
  upgrade_clean(pl->summary, sizeof(pl->summary), summary);
  hub_log_info("[UPGRADE] Multi-step upgrade to %s%s%s stopped: %s\n",
               pl->bot_target, pl->hub_target[0] ? " / hubs " : "",
               pl->hub_target, pl->summary);
  plan_publish(state);
  hub_config_write(state);
}

/* A plan on hold: the network stays at the last closed step, every hub says why,
 * and it resumes when the named node reaches the step or on upgrade continue. */
static void plan_hold(hub_state_t *state, const char *why, bool rerun, const char *uuid,
                      const char *ver) {
  upgrade_plan_t *pl = &state->plan;
  if (!pl->active) return;
  upgrade_clean(pl->hold, sizeof(pl->hold), why);
  for (char *c = pl->hold; *c; c++)
    if (*c == '|') *c = '/';
  pl->hold_rerun = rerun;
  snprintf(pl->hold_uuid, sizeof(pl->hold_uuid), "%s", uuid ? uuid : "");
  snprintf(pl->hold_ver, sizeof(pl->hold_ver), "%s", ver ? ver : "");
  pl->run_id[0] = '\0';
  pl->progressed = time(NULL);
  pl->next_at = 0;
  hub_log_warning("[UPGRADE] Upgrade to %s on hold at step %d/%d: %s\n", pl->bot_target,
                  pl->step + 1, plan_steps(pl), pl->hold);
  plan_publish(state);
  hub_config_write(state);
}

/* The step is really finished: move on, or end. */
static void plan_close_step(hub_state_t *state) {
  upgrade_plan_t *pl = &state->plan;
  int steps = plan_steps(pl);
  pl->reruns = 0;
  pl->progressed = time(NULL);
  if (pl->step + 1 >= steps) {
    char why[96];
    snprintf(why, sizeof(why), "done: all %d steps completed", steps);
    plan_stop(state, why);
    return;
  }
  pl->step++;
  pl->next_at = time(NULL) + UPGRADE_PLAN_SETTLE;
  pl->mesh_until = 0;
  plan_publish(state);
  hub_config_write(state);
  hub_log_info("[UPGRADE] Step %d/%d done; step %d starts in %d s\n", pl->step, steps,
               pl->step + 1, UPGRADE_PLAN_SETTLE);
}

/* What the mesh says a node runs right now, "" if it is not here. */
static const char *plan_node_version(const hub_state_t *state, const char *uuid) {
  for (int i = 0; i < state->client_count; i++) {
    const hub_client_t *c = state->clients[i];
    if (c->type == CLIENT_BOT && c->authenticated && strcmp(c->id, uuid) == 0)
      return c->bot_version;
  }
  /* A bot that moved hubs has an entry under each until the old one ages out: the
   * newest report is what it runs now. */
  const bot_roster_t *best = NULL;
  for (int i = 0; i < state->roster_count; i++)
    if (strcmp(state->roster[i].bot_uuid, uuid) == 0 &&
        (!best || state->roster[i].reported_at >= best->reported_at))
      best = &state->roster[i];
  if (best) return best->version;
  for (int i = 0; i < state->peer_count; i++)
    if (strcmp(state->peers[i].uuid, uuid) == 0) return state->peers[i].remote_version;
  return "";
}

/* Has every node the last step finished come back?  It reads the step's record,
 * because the run table went with this hub's own restart. */
static bool plan_mesh_ready(hub_state_t *state, int *missing) {
  *missing = 0;
  for (int i = 0; i < state->peer_count; i++)
    if (state->peers[i].uuid[0] && !peer_is_linked(state, &state->peers[i])) (*missing)++;
  int at = state->plan.last_run[0] ? hub_uhist_find(state, state->plan.last_run) : -1;
  if (at >= 0) {
    uhist_view_t *v = calloc(1, sizeof(*v));
    if (v && hub_uhist_parse(state->uhist[at].body, v)) {
      for (int i = 0; i < v->node_count; i++) {
        const uhist_node_t *n = &v->nodes[i];
        if (n->kind[0] == 'b' && strcmp(n->state, "done") == 0 &&
            !plan_node_version(state, n->uuid)[0])
          (*missing)++;
      }
    }
    if (v) hub_uhist_view_free(v);
    free(v);
  }
  return *missing == 0;
}

/* What history says about one node: its class and its usual times, newest record
 * first.  History orders and times.  It never decides: preflight asks the host. */
typedef struct {
  int records, bad;   /* records seen, and how many of the last 3 went wrong */
  long long restart;  /* its slowest usual restart, seconds */
  long long stage_bin, stage_src;
  char code[16];
  char arch[32], libc[16], base[8], last[32];
} node_past_t;

static void node_past(const hub_state_t *state, const char *uuid, node_past_t *p) {
  memset(p, 0, sizeof(*p));
  /* Oldest first in the store: walk it backwards. */
  for (int r = state->uhist_count - 1; r >= 0 && p->records < UPGRADE_CLASS_RECORDS; r--) {
    uhist_view_t *v = calloc(1, sizeof(*v));
    if (!v) return;
    if (hub_uhist_parse(state->uhist[r].body, v)) {
      for (int i = 0; i < v->node_count; i++) {
        const uhist_node_t *n = &v->nodes[i];
        if (strcmp(n->uuid, uuid) != 0) continue;
        if (!strcmp(n->state, "already") || !strcmp(n->state, "skipped") || !strcmp(n->state, "idle"))
          break;
        if (!p->records) {
          snprintf(p->arch, sizeof(p->arch), "%s", n->arch);
          snprintf(p->libc, sizeof(p->libc), "%s", n->libc);
          snprintf(p->base, sizeof(p->base), "%s", n->base);
          snprintf(p->last, sizeof(p->last), "%.31s", !strcmp(n->state, "done") ? n->to : n->from);
        }
        p->records++;
        bool bad = !strcmp(n->state, "failed") || n->code[0];
        if (bad && p->records <= 3) {
          p->bad++;
          if (!p->code[0]) snprintf(p->code, sizeof(p->code), "%s", n->code);
        }
        if (n->back > n->committed && n->committed && p->records <= 3 &&
            n->back - n->committed > p->restart)
          p->restart = n->back - n->committed;
        long long *st = !strcmp(n->build, "src") ? &p->stage_src : &p->stage_bin;
        if (n->stage_s > *st && p->records <= 3) *st = n->stage_s;
        break;
      }
    }
    hub_uhist_view_free(v);
    free(v);
  }
}

static char node_class(const node_past_t *p) {
  if (p->bad) return 'p';
  if (p->restart > UPGRADE_SLOW_RESTART || p->stage_src > 0) return 's';
  if (p->records >= 3) return 'f';
  return 'u';
}

/* Limits from its own record: 3x its slowest, between a floor and the agreed ceiling.
 * With too little to go on, the ceiling.  A known slow host is not failed for being
 * slow, and a fast host's failure shows sooner. */
static void upgrade_apply_history(hub_state_t *state) {
  pending_upgrade_t *u = &state->upgrade;
  for (int i = 0; i < u->node_count; i++) {
    upgrade_node_t *n = &u->nodes[i];
    node_past_t p;
    node_past(state, n->uuid, &p);
    n->cls = node_class(&p);
    long long bin = p.stage_bin * 3, src = p.stage_src * 3;
    n->stage_limit = !p.stage_bin ? UPGRADE_STAGE_GATE
                     : bin < UPGRADE_STAGE_FLOOR ? UPGRADE_STAGE_FLOOR
                     : bin > UPGRADE_STAGE_GATE ? UPGRADE_STAGE_GATE : (int)bin;
    n->build_limit = !p.stage_src ? UPGRADE_BUILD_SECS
                     : src < UPGRADE_BUILD_FLOOR ? UPGRADE_BUILD_FLOOR
                     : src > UPGRADE_BUILD_SECS ? UPGRADE_BUILD_SECS : (int)src;
  }
}

/* Does every step have a build for this node's shape?  Only a shape history has seen
 * can be checked; anything else finds out at its PREPARE.  A step the node already
 * runs, or is past, needs nothing from it. */
static bool plan_node_blocked(char kind, const node_past_t *p, const char *cur,
                              const upgrade_plan_t *pl, char *why, size_t why_size) {
  if (!p->arch[0] || !p->base[0]) return false;
  const char *root = kind == 'b' ? hub_update_bot_root() : NULL;
  const char *paths = kind == 'b' ? &pl->bot_path[0][0] : &pl->hub_path[0][0];
  int n = kind == 'b' ? pl->bot_steps : pl->hub_steps;
  for (int s = 0; s < n; s++) {
    const char *ver = paths + (size_t)s * 64;
    if (cur && cur[0] && hub_update_version_cmp(cur, ver) >= 0) continue;
    if (hub_update_has_build(root, p->base, ver, p->arch, p->libc)) continue;
    snprintf(why, why_size, "no %s build for %s/%s, and no source", ver, p->arch, p->libc);
    return true;
  }
  return false;
}

/* ---- The shared plan ------------------------------------------------------
 * Every hub keeps what the driver last published, so any of them can say what is
 * going on, a restarted hub can carry on, and no hub chases a straggler between
 * steps.  The driver alone changes it while it lives.  Older hubs drop the opcode
 * and behave as they did, and are never asked to take over. */
static void plan_send_all(hub_state_t *state, const char *frame, const hub_client_t *skip) {
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type == CLIENT_HUB && c->authenticated && c != skip)
      peer_send_urgent(state, c, CMD_UPGRADE_PLAN, frame);
  }
}

static void plan_flood(hub_state_t *state, const upgrade_plan_t *pl, const hub_client_t *skip) {
  char frame[HUB_PLAN_LINE_MAX + 4];
  frame[0] = 'P';
  frame[1] = '|';
  if (hub_plan_format(pl, frame + 2, sizeof(frame) - 2) > 0) plan_send_all(state, frame, skip);
}

/* This hub directs `pl`.  Its name rides along: a hub that boots mid-plan logs the
 * director before any link has told it who that is. */
static void plan_stamp_driver(const hub_state_t *state, upgrade_plan_t *pl) {
  snprintf(pl->driver, sizeof(pl->driver), "%s", state->hub_uuid);
  snprintf(pl->driver_name, sizeof(pl->driver_name), "%s",
           hub_upgrade_plan_field_ok(state->hub_friendly_name) ? state->hub_friendly_name : "");
}

static void plan_publish(hub_state_t *state) {
  upgrade_plan_t *pl = &state->plan;
  plan_stamp_driver(state, pl);
  /* Clock-based: a driver the failback rolled back has an older config and an older
   * rev.  A plain +1 could land on one the mesh already holds, and the hold it is
   * reporting would be dropped as old news. */
  time_t now = time(NULL);
  pl->rev = (long long)now > pl->rev ? (long long)now : pl->rev + 1;
  state->splan = *pl;
  state->splan_seen = time(NULL);
  plan_flood(state, pl, NULL);
}

/* A plain run is published too, so a lost driver cannot leave the mesh frozen. */
static void hub_plan_single_start(hub_state_t *state) {
  if (state->plan.active) return;
  const pending_upgrade_t *u = &state->upgrade;
  upgrade_plan_t *s = &state->splan;
  long long rev = s->rev;
  memset(s, 0, sizeof(*s));
  s->active = s->single = true;
  snprintf(s->bot_target, sizeof(s->bot_target), "%s", u->target_ver);
  snprintf(s->hub_target, sizeof(s->hub_target), "%s", u->hub_ver);
  snprintf(s->variant, sizeof(s->variant), "%s", u->variant);
  snprintf(s->kind, sizeof(s->kind), "%s", u->kind);
  snprintf(s->run_id, sizeof(s->run_id), "%s", u->id);
  plan_stamp_driver(state, s);
  s->started = u->started;
  s->rev = rev + 1;
  state->splan_seen = time(NULL);
  plan_flood(state, s, NULL);
}

static void hub_plan_single_end(hub_state_t *state) {
  upgrade_plan_t *s = &state->splan;
  if (!s->active || !s->single || strcmp(s->driver, state->hub_uuid) != 0) return;
  s->active = false;
  s->rev++;
  plan_flood(state, s, NULL);
}

/* `upgrade abort` from anywhere ends the shared copy too: its driver may be gone. */
/* Stop this hub's copy of a plan another hub drives, and say so to the rest.  The
 * director hears it too, on the next digest if not now: a stopped copy beats a running
 * one, so it stops as well.  Nothing is rolled back and nobody takes over. */
static void splan_stop(hub_state_t *state, const char *why) {
  upgrade_plan_t *s = &state->splan;
  if (!s->active) return;
  time_t now = time(NULL);
  s->active = false;
  s->rev = (long long)now > s->rev ? (long long)now : s->rev + 1;
  upgrade_clean(s->summary, sizeof(s->summary), why);
  state->splan_seen = now;
  state->follow_id[0] = '\0';
  if (hub_config_frozen(state)) hub_opt_flag_set(state, OPT_CONFIG_FROZEN, false);
  hub_log_warning("[UPGRADE] The upgrade to %s driven by %s stopped here: %s\n", s->bot_target,
                  hub_who(state, 'h', s->driver), s->summary);
  plan_flood(state, s, NULL);
  hub_config_write(state);
}

static void hub_plan_cancelled(hub_state_t *state, time_t issued) {
  upgrade_plan_t *s = &state->splan;
  if (!s->active || s->started > issued || strcmp(s->driver, state->hub_uuid) == 0) return;
  splan_stop(state, "aborted by an admin");
}

static void hub_plan_send_digest(hub_state_t *state, hub_client_t *c) {
  char frame[64];
  snprintf(frame, sizeof(frame), "D|%lld|%lld", (long long)state->splan.started, state->splan.rev);
  peer_send_urgent(state, c, CMD_UPGRADE_PLAN, frame);
}

/* Which copy of a plan stands, `a` over `b`.  The same plan (same start): a stopped copy
 * beats a running one, since a stop is final wherever it was decided, then the higher
 * rev.  Two different plans both running, only from a race or a split: the one begun
 * first stands.  Otherwise the later plan replaces an older one. */
static bool plan_beats(const upgrade_plan_t *a, const upgrade_plan_t *b) {
  if (!b->driver[0]) return true;
  if (a->started == b->started) {
    if (a->active != b->active) return !a->active;
    return a->rev > b->rev;
  }
  if (a->active && b->active) return a->started < b->started;
  return a->started > b->started;
}

/* A restarted hub picks up the run its copy names: it can carry COMMITs and "back"
 * reports again with no fresh PREPARE. */
void hub_plan_boot(hub_state_t *state) {
  upgrade_plan_t *s = &state->splan;
  state->splan_seen = time(NULL);
  if (!s->active || !s->run_id[0] || !s->driver[0] ||
      strcmp(s->driver, state->hub_uuid) == 0 || state->follow_id[0])
    return;
  char bot[64], hub[64];
  if (s->single) {
    snprintf(bot, sizeof(bot), "%s", s->bot_target);
    snprintf(hub, sizeof(hub), "%s", s->hub_target);
  } else {
    plan_step_targets(s, s->step, bot, hub);
  }
  snprintf(state->follow_id, sizeof(state->follow_id), "%s", s->run_id);
  snprintf(state->follow_origin, sizeof(state->follow_origin), "%s", s->driver);
  snprintf(state->follow_target, sizeof(state->follow_target), "%s", bot);
  snprintf(state->follow_hub_target, sizeof(state->follow_hub_target), "%s", hub);
  snprintf(state->follow_variant, sizeof(state->follow_variant), "%s", s->variant);
  snprintf(state->follow_bot_variant, sizeof(state->follow_bot_variant), "%s", s->variant);
  state->follow_self_ready = false;
  state->follow_prepared = time(NULL);
  hub_log_info("[UPGRADE] Back in run %s, driven by %s\n", s->run_id,
               hub_who(state, 'h', s->driver));
}

/* True when upgrade continue already accepted leaving this node behind. */
static bool plan_left_has(const upgrade_plan_t *pl, const char *uuid) {
  size_t len = strlen(uuid);
  for (const char *p = pl->left; len && *p;) {
    const char *end = strchr(p, ',');
    size_t n = end ? (size_t)(end - p) : strlen(p);
    if (n == len && memcmp(p, uuid, len) == 0) return true;
    p += n + (end ? 1 : 0);
  }
  return false;
}

/* Remember the admin's word for the rest of the plan.  A list that is full, or a
 * uuid that does not fit, only means that node can hold the plan again. */
static void plan_left_add(upgrade_plan_t *pl, const char *uuid) {
  int count = pl->left[0] ? 1 : 0;
  for (const char *p = pl->left; *p; p++)
    if (*p == ',') count++;
  size_t have = strlen(pl->left), len = strlen(uuid);
  if (!len || plan_left_has(pl, uuid) || count >= MAX_PLAN_LEFT ||
      have + len + 2 > sizeof(pl->left))
    return;
  snprintf(pl->left + have, sizeof(pl->left) - have, "%s%s", have ? "," : "", uuid);
}

/* Resume on the driver: an admin's word, or the held node reaching the step. */
static void plan_continue(hub_state_t *state, bool by_admin) {
  upgrade_plan_t *pl = &state->plan;
  if (!pl->active || !pl->hold[0]) return;
  bool rerun = pl->hold_rerun;
  hub_log_info("[UPGRADE] Upgrade to %s resumes: %s\n", pl->bot_target,
               rerun ? "running the step again"
                     : (by_admin ? "leaving that node behind" : "that node reached the step"));
  if (by_admin && !rerun) plan_left_add(pl, pl->hold_uuid);
  pl->hold[0] = pl->hold_uuid[0] = pl->hold_ver[0] = '\0';
  pl->hold_rerun = false;
  pl->reruns = 0;
  if (rerun) {
    pl->next_at = time(NULL) + UPGRADE_PLAN_SETTLE;
    pl->mesh_until = 0;
    plan_publish(state);
    hub_config_write(state);
  } else {
    plan_close_step(state);
  }
}

static void hub_plan_process(hub_state_t *state, hub_client_t *peer, const char *payload) {
  peer->plan_capable = true;
  if (!payload || payload[0] == '\0' || payload[1] != '|') return;
  upgrade_plan_t *s = &state->splan;
  const char *rest = payload + 2;
  char a[24] = "", b[24] = "", c[24] = "";
  wire_field(rest, 0, a, sizeof(a));
  wire_field(rest, 1, b, sizeof(b));
  wire_field(rest, 2, c, sizeof(c));
  switch (payload[0]) {
  case 'D':
    /* A different copy: send ours, and they send theirs.  Each keeps what plan_beats()
     * says stands, so both ends settle on the same one. */
    if (s->driver[0] && ((long long)s->started != atoll(a) || s->rev != atoll(b)))
      plan_flood(state, s, NULL);
    break;
  case 'B': {
    if ((long long)s->started != atoll(a) || s->rev != atoll(b)) break;
    char key[96];
    snprintf(key, sizeof(key), "pb:%s:%s", s->driver, c);
    if (op_forward_seen_check_and_add(state, key)) break;
    state->splan_seen = time(NULL);
    plan_send_all(state, payload, peer);
    break;
  }
  case 'C': {
    char key[96];
    snprintf(key, sizeof(key), "pc:%s:%s", a, b);
    if (op_forward_seen_check_and_add(state, key)) break;
    if ((long long)state->plan.started == atoll(a)) plan_continue(state, true);
    plan_send_all(state, payload, peer);
    break;
  }
  case 'P': {
    upgrade_plan_t *t = calloc(1, sizeof(*t));
    if (!t) break;
    if (hub_plan_parse(rest, t) && t->driver[0] && plan_beats(t, s)) {
      upgrade_plan_t *pl = &state->plan;
      if (pl->active) {
        if (pl->started == t->started && !t->active) {
          /* Stopped elsewhere (an admin, or the director given up for lost): stopped
           * here too.  A run in flight finishes; no next step follows it. */
          hub_log_warning("[UPGRADE] The upgrade to %s was stopped elsewhere (%s); it stops here "
                          "too\n", pl->bot_target, t->summary);
          memset(pl, 0, sizeof(*pl));
        } else if (pl->started != t->started && t->active) {
          /* Two plans begun at once: the first one stands, and this one goes back. */
          hub_log_warning("[UPGRADE] An upgrade to %s from %s began first; the upgrade to %s stops\n",
                          t->bot_target, hub_who(state, 'h', t->driver), pl->bot_target);
          memset(pl, 0, sizeof(*pl));
          if (state->upgrade.active) hub_upgrade_abort(state, "another upgrade began first");
        }
      }
      *s = *t;
      state->splan_seen = time(NULL);
      hub_config_write(state);
      plan_flood(state, t, peer);
    }
    free(t);
    break;
  }
  default:
    break;
  }
}

/* The driver has gone quiet: the reachable hub with the lowest uuid carries on.  A
 * partition can make one on each side, both walking the same path; rev settles it. */
static void hub_plan_watch(hub_state_t *state, time_t now) {
  upgrade_plan_t *s = &state->splan;
  if (!s->active || !s->driver[0]) return;
  if (strcmp(s->driver, state->hub_uuid) == 0) {
    if (now - state->plan_beat >= UPGRADE_PLAN_BEAT) {
      char frame[96];
      state->plan_beat = now;
      snprintf(frame, sizeof(frame), "B|%lld|%lld|%lld", (long long)s->started, s->rev,
               (long long)now);
      plan_send_all(state, frame, NULL);
    }
    return;
  }
  int silence = UPGRADE_DRIVER_SILENCE;
#ifdef IRC_TEST_HOOKS
  /* A sandbox cannot wait 15 minutes for each run of its test. */
  const char *hook = getenv("IRCHUB_TEST_DRIVER_SILENCE");
  if (hook && atoi(hook) > 0) silence = atoi(hook);
#endif
  if (state->plan.active || now - state->splan_seen < silence) return;
  /* Linked to the director after all: its beats are only late. */
  const char *reach[HUBS_MAX];
  int nr = hub_reached(state, reach);
  for (int k = 0; k < nr; k++)
    if (strcmp(reach[k], s->driver) == 0) return;
  /* One director: nobody takes over.  The plan stops; upgrade start carries on. */
  char why[160];
  if (s->single)
    snprintf(why, sizeof(why), "director %.60s lost", hub_who(state, 'h', s->driver));
  else
    snprintf(why, sizeof(why), "director %.60s lost at step %d/%d; upgrade start carries on",
             hub_who(state, 'h', s->driver), s->step + 1, plan_steps(s));
  splan_stop(state, why);
}

/* A bot that links during a run joins it, wherever it landed.  One still further
 * back answers unable, and the end of the step deals with that. */
static void hub_upgrade_prepare_late(hub_state_t *state, hub_client_t *client,
                                     const char *version) {
  if (client->late_prepared || !version[0]) return;
  pending_upgrade_t *u = &state->upgrade;
  char frame[512];
  if (u->active && u->select_count == 0 && (u->phase == UPG_PREPARE || u->phase == UPG_ROLLING)) {
    if (upgrade_find_node(u, client->id) || hub_update_version_cmp(version, u->target_ver) >= 0)
      return;
    client->late_prepared = true;
    upgrade_add_node(u, client->id, 'b', client->fd, version);
    snprintf(frame, sizeof(frame), "%s|%s|%s|%s|%s|", u->id, u->target_ver, u->variant, u->kind,
             u->min_from);
    send_cmd_to_bot(state, client, CMD_UPGRADE_PREPARE, frame);
  } else if (state->follow_id[0] && hub_config_frozen(state) && !state->follow_sel[0] &&
             state->follow_target[0] &&
             hub_update_version_cmp(version, state->follow_target) < 0) {
    client->late_prepared = true;
    snprintf(frame, sizeof(frame), "%s|%s|%s||*|", state->follow_id, state->follow_target,
             state->follow_bot_variant);
    send_cmd_to_bot(state, client, CMD_UPGRADE_PREPARE, frame);
  }
}

/* The hubs an upgrade would miss: every hub known here, from its own peers and from what
 * the others report, less those reached over live links from here.  Writes their names
 * and returns how many. */
static bool hub_uuid_listed(const char *const *list, int n, const char *uuid) {
  for (int i = 0; i < n; i++)
    if (strcmp(list[i], uuid) == 0) return true;
  return false;
}

/* The hubs reached from here over live links, direct or through other hubs, by what
 * each reports of its own links.  Fills `reached` (pointers into state) and returns
 * how many. */
static int hub_reached(hub_state_t *state, const char *reached[HUBS_MAX]) {
  int nr = 0;
  for (int i = 0; i < state->peer_count; i++)
    if (state->peers[i].uuid[0] && peer_is_linked(state, &state->peers[i]) && nr < HUBS_MAX)
      reached[nr++] = state->peers[i].uuid;
  for (int r = 0; r < nr; r++) {
    const mesh_hub_t *mh = mesh_hub_find(state, reached[r]);
    if (!mh) continue;
    for (int l = 0; l < mh->link_count; l++) {
      const mesh_link_t *L = &mh->links[l];
      if (L->online && L->uuid[0] && strcmp(L->uuid, "-") != 0 &&
          strcmp(L->uuid, state->hub_uuid) != 0 && !hub_uuid_listed(reached, nr, L->uuid) &&
          nr < HUBS_MAX)
        reached[nr++] = L->uuid;
    }
  }
  return nr;
}

static int upgrade_hubs_missing(hub_state_t *state, char *names, size_t size) {
  const char *reached[HUBS_MAX], *named[HUBS_MAX];
  int nr = hub_reached(state, reached), nn = 0, missing = 0;
  size_t used = 0;
  names[0] = '\0';
  for (int i = 0; i < state->peer_count; i++) {
    const hub_peer_config_t *p = &state->peers[i];
    if (p->uuid[0] && hub_uuid_listed(reached, nr, p->uuid)) continue;
    if (p->uuid[0] && nn < HUBS_MAX) named[nn++] = p->uuid;
    missing++;
    if (used < size) {
      int w = snprintf(names + used, size - used, "%s%s", used ? ", " : "",
                       p->friendly_name[0] ? p->friendly_name : p->ip);
      if (w > 0) used += (size_t)w;
    }
  }
  for (int m = 0; m < state->mesh_hub_count; m++) {
    const mesh_hub_t *mh = &state->mesh_hubs[m];
    for (int l = 0; l < mh->link_count; l++) {
      const mesh_link_t *L = &mh->links[l];
      if (!L->uuid[0] || strcmp(L->uuid, "-") == 0 || strcmp(L->uuid, state->hub_uuid) == 0 ||
          hub_uuid_listed(reached, nr, L->uuid) || hub_uuid_listed(named, nn, L->uuid))
        continue;
      if (nn < HUBS_MAX) named[nn++] = L->uuid;
      missing++;
      if (used < size) {
        int w = snprintf(names + used, size - used, "%s%s", used ? ", " : "",
                         L->name[0] ? L->name : L->uuid);
        if (w > 0) used += (size_t)w;
      }
    }
  }
  return missing;
}

/* ---- Hub roll call (CMD_HUB_ROLLCALL, see hub.h) ------------------------ */

static hub_rollcall_t *rc_find(hub_state_t *state, const char *id) {
  for (int i = 0; i < MAX_ROLLCALLS; i++)
    if (state->rollcalls[i].active && strcmp(state->rollcalls[i].id, id) == 0)
      return &state->rollcalls[i];
  return NULL;
}

/* A free slot; a relay entry past its routing window counts as free. */
static hub_rollcall_t *rc_alloc(hub_state_t *state, time_t now) {
  for (int i = 0; i < MAX_ROLLCALLS; i++) {
    hub_rollcall_t *rc = &state->rollcalls[i];
    if (!rc->active || (!rc->origin && now - rc->started > ROLLCALL_KEEP)) {
      memset(rc, 0, sizeof(*rc));
      rc->from_fd = -1;
      rc->started = now;
      return rc;
    }
  }
  return NULL;
}

static bool rc_id_ok(const char *s) {
  size_t n = strlen(s);
  if (n < 8 || n >= ROLLCALL_ID_LEN) return false;
  for (size_t i = 0; i < n; i++)
    if (!isxdigit((unsigned char)s[i])) return false;
  return true;
}

static void rc_want(hub_rollcall_t *rc, const char *uuid, const char *name, bool *full) {
  for (int i = 0; i < rc->want_n; i++)
    if (strcmp(rc->want[i], uuid) == 0) return;
  if (rc->want_n >= MAX_MESH_HUBS) {
    *full = true;
    return;
  }
  snprintf(rc->want[rc->want_n], sizeof(rc->want[0]), "%s", uuid);
  snprintf(rc->want_name[rc->want_n], sizeof(rc->want_name[0]), "%s", name && name[0] ? name : uuid);
  rc->want_n++;
}

/* Ask every hub known here: the configured peers and every hub the others
 * report a link to (the same set upgrade_hubs_missing counts).  Returns 1 when
 * the roll call is out (its end comes through rollcall_end), 0 when the gossip
 * check has to decide instead: a configured peer that has never linked (no
 * uuid, nobody can ask it), a full table, or no hub to ask at all.  Every hub
 * the mesh admits answers (MESH_MIN_VERSION), so one presence dropped as
 * unreachable, or a linked peer that has not gossiped yet, is asked too. */
static int rollcall_begin(hub_state_t *state, rollcall_purpose_t purpose, char *id_out) {
  time_t now = time(NULL);
  id_out[0] = '\0';
  hub_rollcall_t *rc = rc_alloc(state, now);
  if (!rc) return 0;
  bool full = false;
  for (int i = 0; i < state->peer_count; i++) {
    const hub_peer_config_t *p = &state->peers[i];
    if (!p->uuid[0]) return 0;
    rc_want(rc, p->uuid, p->friendly_name[0] ? p->friendly_name : p->ip, &full);
  }
  for (int m = 0; m < state->mesh_hub_count; m++) {
    const mesh_hub_t *mh = &state->mesh_hubs[m];
    for (int l = 0; l < mh->link_count; l++) {
      const mesh_link_t *L = &mh->links[l];
      if (!L->uuid[0] || strcmp(L->uuid, "-") == 0 || strcmp(L->uuid, state->hub_uuid) == 0)
        continue;
      rc_want(rc, L->uuid, L->name, &full);
    }
  }
  if (full || rc->want_n == 0) return 0;
  unsigned char rb[16];
  if (RAND_bytes(rb, sizeof(rb)) != 1) return 0;
  for (size_t i = 0; i < sizeof(rb); i++) snprintf(rc->id + 2 * i, 3, "%02x", rb[i]);
  secure_wipe(rb, sizeof(rb));
  (void)op_forward_seen_check_and_add(state, rc->id); /* our own, back around a cycle */
  rc->active = true;
  rc->origin = true;
  rc->purpose = purpose;
  char frame[160];
  snprintf(frame, sizeof(frame), "%s|%s|%lld", rc->id, state->hub_uuid, (long long)now);
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type == CLIENT_HUB && c->authenticated)
      peer_send_urgent(state, c, CMD_HUB_ROLLCALL, frame);
  }
  hub_log_debug("[UPGRADE] Roll call %s: asking %d hub(s)\n", rc->id, rc->want_n);
  snprintf(id_out, ROLLCALL_ID_LEN, "%s", rc->id);
  return 1;
}

static void upgrade_start_resume(hub_state_t *state, int missing, const char *gone);

/* The roll call is over: every hub answered, or ROLLCALL_WAIT ran out. */
static void rollcall_end(hub_state_t *state, hub_rollcall_t *rc) {
  char gone[320] = "";
  size_t used = 0;
  int missing = 0;
  for (int i = 0; i < rc->want_n; i++) {
    if (rc->got[i]) continue;
    missing++;
    if (used < sizeof(gone)) {
      int w = snprintf(gone + used, sizeof(gone) - used, "%s%s", used ? ", " : "", rc->want_name[i]);
      if (w > 0) used += (size_t)w;
    }
  }
  hub_log_debug("[UPGRADE] Roll call %s: %d of %d hub(s) answered\n", rc->id,
                rc->want_n - missing, rc->want_n);
  rollcall_purpose_t purpose = rc->purpose;
  char id[ROLLCALL_ID_LEN];
  snprintf(id, sizeof(id), "%s", rc->id);
  rc->active = false;
  if (purpose == RC_FOR_START && state->upg_start_wait.active &&
      strcmp(state->upg_start_wait.rc, id) == 0) {
    upgrade_start_resume(state, missing, gone);
  } else if (purpose == RC_FOR_STEP && strcmp(state->step_rollcall.rc, id) == 0) {
    state->step_rollcall.rc[0] = '\0';
    state->step_rollcall.outcome = missing ? 2 : 1;
    state->step_rollcall.missing = missing;
    state->step_rollcall.at = time(NULL);
    snprintf(state->step_rollcall.gone, sizeof(state->step_rollcall.gone), "%s", gone);
  }
}

/* ROLLCALL from a peer: rid|origin_uuid|origin_ts.  Pass it on, remember the
 * way back, answer. */
static void process_hub_rollcall(hub_state_t *state, hub_client_t *peer, const char *payload) {
  char id[ROLLCALL_ID_LEN] = "", origin[64] = "", ts[24] = "";
  if (!wire_field(payload, 0, id, sizeof(id)) || !wire_field(payload, 1, origin, sizeof(origin)) ||
      !wire_field(payload, 2, ts, sizeof(ts)) || !rc_id_ok(id) || !uuid_valid(origin)) {
    hub_log_warning("[UPGRADE] Malformed HUB_ROLLCALL from peer %s\n", peer->ip);
    return;
  }
  long long t = atoll(ts); /* saturates: age only for a positive stamp */
  long long age = t > 0 ? (long long)time(NULL) - t : 0;
  if (t <= 0 || age > ROLLCALL_TTL || age < -ROLLCALL_TTL) return;
  if (strcmp(origin, state->hub_uuid) == 0) return;
  if (op_forward_seen_check_and_add(state, id)) return; /* another path got here first */
  hub_rollcall_t *rc = rc_alloc(state, time(NULL));
  if (rc) {
    rc->active = true;
    snprintf(rc->id, sizeof(rc->id), "%s", id);
    rc->from_fd = peer->fd;
    rc->from_serial = peer->conn_serial;
  } else {
    /* No way back for the hubs past this one: they read as missing and the
     * gate refuses, which is the safe answer. */
    hub_log_warning("[UPGRADE] Roll call table full: not passing %s on\n", id);
  }
  for (int i = 0; rc && i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type == CLIENT_HUB && c->authenticated && c != peer)
      peer_send_urgent(state, c, CMD_HUB_ROLLCALL, payload);
  }
  char ack[160];
  snprintf(ack, sizeof(ack), "%s|%s", id, state->hub_uuid);
  peer_send_urgent(state, peer, CMD_HUB_ROLLCALL_ACK, ack);
}

/* ROLLCALL_ACK: rid|hub_uuid.  The asking hub ticks it off; a relay routes it
 * back down the link the roll call came in on. */
static void process_hub_rollcall_ack(hub_state_t *state, hub_client_t *peer, const char *payload) {
  char id[ROLLCALL_ID_LEN] = "", hub[64] = "";
  if (!wire_field(payload, 0, id, sizeof(id)) || !wire_field(payload, 1, hub, sizeof(hub)) ||
      !rc_id_ok(id) || !uuid_valid(hub)) {
    hub_log_warning("[UPGRADE] Malformed HUB_ROLLCALL_ACK from peer %s\n", peer->ip);
    return;
  }
  hub_rollcall_t *rc = rc_find(state, id);
  if (!rc) return;
  if (!rc->origin) {
    if (time(NULL) - rc->started > ROLLCALL_KEEP) return;
    for (int i = 0; i < state->client_count; i++) {
      hub_client_t *c = state->clients[i];
      if (c->type == CLIENT_HUB && c->authenticated && c->fd == rc->from_fd &&
          c->conn_serial == rc->from_serial) {
        peer_send_urgent(state, c, CMD_HUB_ROLLCALL_ACK, payload);
        break;
      }
    }
    return;
  }
  bool all = true;
  for (int i = 0; i < rc->want_n; i++) {
    if (strcmp(rc->want[i], hub) == 0) rc->got[i] = true;
    if (!rc->got[i]) all = false;
  }
  if (all) rollcall_end(state, rc);
}

/* Ends the roll calls whose wait ran out and frees the relays' entries.  Runs
 * on every maintenance pass. */
void hub_rollcall_tick(hub_state_t *state, time_t now) {
  for (int i = 0; i < MAX_ROLLCALLS; i++) {
    hub_rollcall_t *rc = &state->rollcalls[i];
    if (!rc->active) continue;
    if (rc->origin && now - rc->started > ROLLCALL_WAIT) rollcall_end(state, rc);
    else if (!rc->origin && now - rc->started > ROLLCALL_KEEP) rc->active = false;
  }
}

/* The upgrade start that waited on its roll call: answer the console that
 * asked, if it is still there. */
static void upgrade_start_resume(hub_state_t *state, int missing, const char *gone) {
  hub_client_t *admin = NULL;
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->fd == state->upg_start_wait.admin_fd &&
        c->conn_serial == state->upg_start_wait.admin_serial)
      admin = c;
  }
  char payload[sizeof(state->upg_start_wait.payload)];
  snprintf(payload, sizeof(payload), "%s", state->upg_start_wait.payload);
  secure_wipe(&state->upg_start_wait, sizeof(state->upg_start_wait));
  if (!admin) {
    hub_log_info("[UPGRADE] The console that asked for the start is gone; nothing started\n");
    return;
  }
  if (missing > 0) {
    char why[512];
    snprintf(why, sizeof(why), "%d hub%s did not answer: %s", missing, missing == 1 ? "" : "s",
             gone);
    (void)admin_err(state, admin, "upg.hubs_missing", why,
                    "bring it back, or remove it with hub del; then start again");
    return;
  }
  (void)admin_upgrade_start(state, admin, payload, true);
}

/* The step gate: every hub answered, or how many did not.  False while its
 * roll call is still out. */
static bool plan_hubs_answered(hub_state_t *state, int *missing, char *gone, size_t size) {
  time_t now = time(NULL);
  if (state->step_rollcall.outcome && now - state->step_rollcall.at <= ROLLCALL_WAIT + 2) {
    *missing = state->step_rollcall.outcome == 2 ? state->step_rollcall.missing : 0;
    snprintf(gone, size, "%s", state->step_rollcall.gone);
    state->step_rollcall.outcome = 0;
    return true;
  }
  state->step_rollcall.outcome = 0;
  if (state->step_rollcall.rc[0]) return false;
  if (rollcall_begin(state, RC_FOR_STEP, state->step_rollcall.rc) == 1) return false;
  *missing = upgrade_hubs_missing(state, gone, size);
  return true;
}

/* Start step `pl->step` as an ordinary run.  False when it could not start
 * (the plan is stopped with the reason). */
static bool plan_start_step(hub_state_t *state, hub_client_t *admin,
                            const char *min_from, char *msg, size_t msg_size) {
  upgrade_plan_t *pl = &state->plan;
  char bot[64], hub[64];
  plan_step_targets(pl, pl->step, bot, hub);
  if (!hub_upgrade_start(state, admin, bot, pl->variant, pl->kind, min_from,
                         hub, pl->sel, msg, msg_size))
    return false;
  snprintf(pl->run_id, sizeof(pl->run_id), "%s", state->upgrade.id);
  pl->progressed = time(NULL);
  pl->next_at = 0;
  pl->mesh_until = 0;
  plan_publish(state);
  hub_config_write(state);
  hub_log_info("[UPGRADE] Step %d/%d of the upgrade to %s: run %s (bots -> %s%s%s)\n",
               pl->step + 1, plan_steps(pl), pl->bot_target, pl->run_id, bot,
               hub[0] ? ", hubs -> " : "", hub);
  return true;
}

/* CMD_ADMIN_UPGRADE_NET: plan the path, then start its first step.  A
 * one-step path is exactly the run `upgrade start` always was, and keeps no
 * plan. */
static bool hub_upgrade_plan_begin(hub_state_t *state, hub_client_t *admin,
                                   const char *target_ver, const char *variant,
                                   const char *kind, const char *min_from,
                                   const char *hub_ver, const char *sel,
                                   char *msg, size_t msg_size) {
  upgrade_plan_t *pl = &state->plan;
  if (pl->active) {
    snprintf(msg, msg_size,
             "ERROR: a multi-step upgrade to %s is in progress (step %d/%d) — "
             "upgrade abort stops it", pl->bot_target, pl->step + 1,
             plan_steps(pl));
    return false;
  }
  if (!target_ver || !target_ver[0] || !hub_upgrade_plan_field_ok(target_ver) ||
      strlen(target_ver) >= 64 ||
      (hub_ver && (strlen(hub_ver) >= 64 || !hub_upgrade_plan_field_ok(hub_ver) ||
                   strchr(hub_ver, ',')))) {
    /* let the run refuse it with its own words */
    return hub_upgrade_start(state, admin, target_ver ? target_ver : "", variant,
                             kind, min_from, hub_ver, sel, msg, msg_size);
  }
  upgrade_plan_t np;
  char why[256];
  if (!plan_compute(state, target_ver, hub_ver, variant, sel, &np, why,
                    sizeof(why))) {
    snprintf(msg, msg_size, "ERROR: %s", why);
    return false;
  }
  /* A build missing for a host history knows: refused now, not part way up. */
  {
    int nc = 0;
    upgrade_cand_t *cands = upgrade_candidates(state, &nc);
    bool whole = !sel || !sel[0];
    for (int i = 0; whole && cands && i < nc; i++) {
      node_past_t p;
      node_past(state, cands[i].uuid, &p);
      char why2[192] = "";
      if (cands[i].kind != 'b' && !(hub_ver && hub_ver[0])) continue;
      const char *cur = cands[i].kind == 's' ? HUB_VERSION : plan_node_version(state, cands[i].uuid);
      if (plan_node_blocked(cands[i].kind, &p, cur, &np, why2, sizeof(why2))) {
        snprintf(msg, msg_size, "ERROR: %.60s (on %.24s): %s",
                 cands[i].name[0] ? cands[i].name : cands[i].uuid, cur[0] ? cur : "?", why2);
        free(cands);
        return false;
      }
    }
    free(cands);
  }
  if (plan_steps(&np) <= 1)
    return hub_upgrade_start(state, admin, target_ver, variant, kind, min_from,
                             hub_ver, sel, msg, msg_size);
  if ((variant && strlen(variant) >= sizeof(np.variant)) ||
      (kind && strlen(kind) >= sizeof(np.kind)) ||
      (sel && (strlen(sel) >= sizeof(np.sel) || !hub_upgrade_plan_field_ok(sel)))) {
    snprintf(msg, msg_size, "ERROR: bad variant, kind or selection");
    return false;
  }
  snprintf(np.variant, sizeof(np.variant), "%s", variant ? variant : "");
  snprintf(np.kind, sizeof(np.kind), "%s", kind ? kind : "");
  snprintf(np.sel, sizeof(np.sel), "%s", sel ? sel : "");
  np.started = time(NULL);
  np.active = true;
  *pl = np;
  if (!plan_start_step(state, admin, min_from, msg, msg_size)) {
    memset(pl, 0, sizeof(*pl));
    return false;
  }
  return true;
}

/* A run ended; if it was a step of the plan, decide what follows.
 *   - A run that failed goes on hold: the network stays where the run put it back.
 *   - A node that answered but could not take the step, and sits below what the
 *     next step can reach, holds the plan: moving on would lock it out.  One the
 *     next step can still reach is simply walked up later.
 *   - A node that never answered cannot be helped by waiting.  It gets a warning.
 * The step closes here only if this hub is not about to restart onto it: then the
 * next boot closes it, once it has seen itself on the step. */
static void plan_note_run_end(hub_state_t *state, upgrade_phase_t phase) {
  upgrade_plan_t *pl = &state->plan;
  pending_upgrade_t *u = &state->upgrade;
  if (!pl->active || !pl->run_id[0] || strcmp(pl->run_id, u->id) != 0) return;
  int steps = plan_steps(pl);
  char why[320];
  snprintf(pl->last_run, sizeof(pl->last_run), "%s", pl->run_id);
  pl->run_id[0] = '\0';
  pl->progressed = time(NULL);
  if ((phase != UPG_DONE && phase != UPG_PARTIAL) || u->build_stopped) {
    snprintf(why, sizeof(why), "step %d/%d %s: %s", pl->step + 1, steps,
             upgrade_phase_name(phase), u->summary);
    pl->self_target[0] = '\0';
    plan_hold(state, why, true, "", "");
    return;
  }
  bool last = pl->step + 1 >= steps;
  for (int i = 0; i < u->node_count && !last; i++) {
    const upgrade_node_t *n = &u->nodes[i];
    if (n->not_selected || plan_left_has(pl, n->uuid)) continue;
    const char *to = upgrade_node_target(u, n);
    if (n->state == UPG_NODE_UNABLE && !n->cur_version[0]) {
      hub_log_warning("[UPGRADE] %s never answered step %d/%d; if the next step leaves it below "
                      "its floor it must be upgraded by hand\n", hub_who(state, n->kind == 'b' ? 'b' : 'h', n->uuid),
                      pl->step + 1, steps);
      continue;
    }
    if ((n->state != UPG_NODE_UNABLE && n->state != UPG_NODE_FAILED) || !to[0] ||
        hub_update_version_cmp(n->cur_version, to) >= 0)
      continue;
    char bot[64], hub[64], next[64] = "", err[192] = "";
    plan_step_targets(pl, pl->step + 1, bot, hub);
    const char *want = n->kind == 'b' ? bot : hub;
    const char *final = n->kind == 'b' ? pl->bot_target : pl->hub_target;
    bool reach = want[0] &&
                 hub_update_next_step(n->kind == 'b' ? hub_update_bot_root() : NULL,
                                      pl->variant[0] ? pl->variant : (n->variant[0] ? n->variant : "c"),
                                      n->cur_version, final, next, sizeof(next), err, sizeof(err));
    if (reach) {
      strip_v(next);
      reach = hub_update_version_cmp(next, want) >= 0;
    }
    if (!reach) {
      snprintf(why, sizeof(why), "step %d/%d left %.40s behind on %.20s (%.60s), and the next step "
               "would lock it out", pl->step + 1, steps, n->name[0] ? n->name : n->uuid,
               n->cur_version, n->reason);
      plan_hold(state, why, false, n->uuid, to);
      return;
    }
  }
  if (pl->self_target[0]) {
    plan_publish(state);
    hub_config_write(state);
    return;
  }
  plan_close_step(state);
}

static void hub_plan_tick(hub_state_t *state, time_t now) {
  hub_plan_watch(state, now);
  upgrade_plan_t *pl = &state->plan;
  if (!pl->active || state->upgrade.active) return;
  if (pl->self_target[0]) {
    /* This hub restarted onto the step.  Its first link confirms it; the failback
     * undoes it if none comes, and then this is the old build, reading this. */
    bool linked = state->peer_count == 0;
    for (int i = 0; i < state->peer_count && !linked; i++)
      linked = peer_is_linked(state, &state->peers[i]);
    bool same = hub_update_version_cmp(HUB_VERSION, pl->self_target) == 0;
    if (same && !linked && now - pl->progressed < UPGRADE_CONFIRM_SECS) return;
    char want[64];
    snprintf(want, sizeof(want), "%s", pl->self_target);
    pl->self_target[0] = '\0';
    if (!same) {
      char note[192] = "", why[320];
      if (!hub_update_failback_note(note, sizeof(note))) snprintf(note, sizeof(note), "no reason left");
      snprintf(why, sizeof(why), "this hub is back on %s, not %s: %.180s", HUB_VERSION, want, note);
      plan_hold(state, why, true, "", "");
      return;
    }
    if (!pl->hold[0]) plan_close_step(state);
    else hub_config_write(state);
    return;
  }
  if (pl->hold[0]) {
    if (pl->progressed > 0 && now - pl->progressed > UPGRADE_PLAN_TTL) {
      char why[256];
      snprintf(why, sizeof(why), "stopped at step %d of %d: %.200s", pl->step + 1, plan_steps(pl),
               pl->hold);
      plan_stop(state, why);
      return;
    }
    if (pl->hold_uuid[0] && pl->hold_ver[0]) {
      const char *v = plan_node_version(state, pl->hold_uuid);
      if (v[0] && hub_update_version_cmp(v, pl->hold_ver) >= 0) plan_continue(state, false);
    }
    return;
  }
  if (pl->run_id[0]) {
    /* A step was in flight when this hub went down: its run table went with
     * the old process.  The freeze it set is still up — lift it — and run
     * the step again; nodes already on it answer that they are. */
    hub_log_warning("[UPGRADE] Step %d/%d (run %s) was cut off by a restart; "
                    "running it again\n", pl->step + 1, plan_steps(pl), pl->run_id);
    if (hub_config_frozen(state)) hub_opt_flag_set(state, OPT_CONFIG_FROZEN, false);
    pl->run_id[0] = '\0';
    if (++pl->reruns > UPGRADE_PLAN_RERUNS) {
      char why[128];
      snprintf(why, sizeof(why), "step %d/%d was cut off by a restart %d times", pl->step + 1,
               plan_steps(pl), pl->reruns);
      plan_hold(state, why, true, "", "");
      return;
    }
    pl->next_at = now + UPGRADE_PLAN_SETTLE;
    hub_config_write(state);
    return;
  }
  if (pl->next_at == 0) {
    /* just booted (onto a step, typically): let the mesh come back first */
    pl->next_at = now + UPGRADE_PLAN_SETTLE;
    return;
  }
  if (pl->progressed > 0 && now - pl->progressed > UPGRADE_PLAN_TTL) {
    plan_stop(state, "no progress for a day; start the upgrade again");
    return;
  }
  if (now < pl->next_at) return;
  if (hub_config_frozen(state) || state->rollup.active) return;
  /* Steps wait for the mesh, not a clock: a bot still relinking would otherwise
   * miss the next run's table. */
  int missing = 0;
  int mesh_wait = UPGRADE_PLAN_MESH_WAIT;
#ifdef IRC_TEST_HOOKS
  /* As for the driver silence: a sandbox cannot sit out the whole wait on each step. */
  const char *mesh_hook = getenv("IRCHUB_TEST_PLAN_MESH_WAIT");
  if (mesh_hook && atoi(mesh_hook) > 0) mesh_wait = atoi(mesh_hook);
#endif
  if (pl->mesh_until == 0) pl->mesh_until = now + mesh_wait;
  /* A step starts with every hub, as the plan did.  One still gone after the wait
   * ends the plan here; upgrade start carries on from this step later. */
  {
    char gone[320], why[512];
    int hm = 0;
    if (!plan_hubs_answered(state, &hm, gone, sizeof(gone))) return; /* the hubs are being asked */
    if (hm > 0) {
      if (now < pl->mesh_until) return;
      snprintf(why, sizeof(why), "step %d/%d needs every hub; %d missing: %s; upgrade start "
               "carries on", pl->step + 1, plan_steps(pl), hm, gone);
      plan_stop(state, why);
      return;
    }
  }
  if (!plan_mesh_ready(state, &missing)) {
    if (now < pl->mesh_until) return;
    hub_log_warning("[UPGRADE] %d node(s) still missing after %d s; step %d/%d starts without "
                    "them\n", missing, mesh_wait, pl->step + 1, plan_steps(pl));
  }
  char msg[640];
  if (!plan_start_step(state, NULL, "", msg, sizeof(msg))) {
    char why[192];
    snprintf(why, sizeof(why), "step %d/%d could not start: %.140s",
             pl->step + 1, plan_steps(pl),
             strncmp(msg, "ERROR: ", 7) == 0 ? msg + 7 : msg);
    plan_hold(state, why, true, "", "");
  }
}

/* Tell every hub to stop whatever upgrade it drives: an UPGRADE_FORGET
 * flagged "A" (abort), id|ts|A|issued.  `issued` is when the admin typed it:
 * a run or plan started after that is not the one meant. */
static int upgrade_cancel_flood(hub_state_t *state) {
  char id[64], fwd[128];
  generate_request_id(id, sizeof(id));
  op_forward_seen_check_and_add(state, id);
  time_t now = time(NULL);
  snprintf(state->upgrade_cancel_id, sizeof(state->upgrade_cancel_id), "%s", id);
  state->upgrade_cancel_issued = state->upgrade_cancel_seen = now;
  snprintf(fwd, sizeof(fwd), "%s|%lld|A|%lld", id, (long long)now, (long long)now);
  int told = 0;
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type == CLIENT_HUB && c->authenticated &&
        peer_send_urgent(state, c, CMD_UPGRADE_FORGET, fwd))
      told++;
  }
  return told;
}

/* "releases|bot_ver|hub_ver|sel": the path `upgrade start` would take, for
 * the console's confirmation card. */
static void upgrade_plan_preview(hub_state_t *state, const char *payload,
                                 reply_t *r) {
  if (!payload || payload[8] != '|') return;
  char bot[64] = "", hub[64] = "", sel[MAX_UPGRADE_SELECT * 80] = "";
  wire_field(payload, 1, bot, sizeof(bot));
  wire_field(payload, 2, hub, sizeof(hub));
  wire_tail(payload, 3, sel, sizeof(sel));
  if (!bot[0] || !hub_upgrade_plan_field_ok(bot) ||
      (hub[0] && !hub_upgrade_plan_field_ok(hub)))
    return;
  upgrade_plan_t *np = calloc(1, sizeof(*np));
  if (!np) return;
  char why[256];
  bool ok = plan_compute(state, bot, hub, "", sel, np, why, sizeof(why));
  /* What is known before anything is touched: who is who, and whether every step
   * has a build for every host history knows the shape of. */
  if (ok) {
    int nc = 0;
    upgrade_cand_t *cands = upgrade_candidates(state, &nc);
    for (int i = 0; cands && i < nc; i++) {
      const upgrade_cand_t *c = &cands[i];
      if (c->kind != 'b' && !hub[0]) continue;
      node_past_t p;
      node_past(state, c->uuid, &p);
      const char *online = c->kind == 'b' ? plan_node_version(state, c->uuid) : "x";
      reply_rec(r, "past");
      reply_kv(r, "name", c->name[0] ? c->name : c->uuid);
      char cl[2] = {node_class(&p), 0};
      reply_kv(r, "class", cl);
      reply_kvi(r, "restart", p.restart);
      reply_kvi(r, "stage_bin", p.stage_bin);
      reply_kvi(r, "stage_src", p.stage_src);
      if (p.code[0]) reply_kv(r, "code", p.code);
      if (!online[0]) {
        reply_kvb(r, "down", true);
        if (p.last[0]) reply_kv(r, "last", p.last);
      }
      char why2[192] = "";
      const char *cur = c->kind == 's' ? HUB_VERSION : plan_node_version(state, c->uuid);
      if (plan_node_blocked(c->kind, &p, cur, np, why2, sizeof(why2))) reply_kv(r, "blocked", why2);
    }
    free(cands);
  }
  char path[MAX_UPGRADE_STEPS * 65];
  reply_rec(r, "path");
  reply_kv(r, "product", "bot");
  if (np->bot_from[0]) reply_kv(r, "from", np->bot_from);
  plan_path_csv(&np->bot_path[0][0], np->bot_steps, path, sizeof(path));
  if (path[0]) reply_kv(r, "steps", path);
  if (!ok) reply_kv(r, "err", why);
  if (ok && hub[0]) {
    reply_rec(r, "path");
    reply_kv(r, "product", "hub");
    if (np->hub_from[0]) reply_kv(r, "from", np->hub_from);
    plan_path_csv(&np->hub_path[0][0], np->hub_steps, path, sizeof(path));
    if (path[0]) reply_kv(r, "steps", path);
  }
  free(np);
}

/* Production crontab lines: this hub's own, and each of its bots' orders. */
static void hub_cron_tick(hub_state_t *state) {
  hub_update_cron_set(hub_cron_wanted(state, 'h', state->hub_uuid));
  if (hub_update_cron_tick(state->executable_path)) state->tree_dirty = true;
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type != CLIENT_BOT || !c->authenticated || c->retiring || !c->bot_version[0]) continue;
    int want = hub_cron_wanted(state, 'b', c->id) ? 1 : 0;
    if (c->cron_sent == want + 1) continue;
    if (send_cmd_to_bot(state, c, CMD_CRON_SET, want ? "on" : "off")) c->cron_sent = want + 1;
  }
}

/* bot set cron / hub set cron: "<global|node>|on|off", with "bot" or "hub" first. */
static bool admin_cron_set(hub_state_t *state, hub_client_t *client, const char *payload) {
  char prod[8] = "", target[80] = "", val[8] = "";
  if (!wire_field(payload, 0, prod, sizeof(prod)) ||
      !wire_field(payload, 1, target, sizeof(target)) ||
      !wire_field(payload, 2, val, sizeof(val)) ||
      (strcmp(val, "on") && strcmp(val, "off")))
    return admin_err(state, client, "cron.usage", "cron takes a node, or global, and on or off",
                     "bot set cron <global|nick> <on|off>");
  bool is_hub = strcmp(prod, "hubcron") == 0;
  char kind = is_hub ? 'h' : 'b';
  bool on = strcmp(val, "on") == 0;
  const char *word = is_hub ? "hub set cron <global|#|uuid|name> <on|off>"
                            : "bot set cron <global|nick|uuid> <on|off>";
  reply_t r;
  if (strcasecmp(target, "global") == 0) {
    hub_gsetting_set(state, is_hub ? "hubcron" : "botcron", on ? 1 : 0);
    hub_cron_prune(state, kind);
    char line[HS_LINE_MAX];
    if (hub_gsetting_format(state, is_hub ? "hubcron" : "botcron", line, sizeof(line)) > 0)
      hub_broadcast_sync_to_peers(state, line, -1);
    reply_init(&r);
    reply_ok(&r, "cron.set");
    reply_kv(&r, "scope", is_hub ? "every hub" : "every bot");
    reply_kv(&r, "value", val);
    reply_kvi(&r, "peers", linked_peer_count(state));
    return send_reply(state, client, &r);
  }
  char uuid[64] = "", name[64] = "";
  /* A hub's list number, as hub set <#> key takes. */
  if (is_hub && target[0] && strspn(target, "0123456789") == strlen(target)) {
    int n = atoi(target);
    if (n >= 1 && n <= state->peer_count && state->peers[n - 1].uuid[0]) {
      snprintf(uuid, sizeof(uuid), "%s", state->peers[n - 1].uuid);
      snprintf(name, sizeof(name), "%s", state->peers[n - 1].friendly_name);
    }
  }
  if (!uuid[0]) {
    int nc = 0;
    upgrade_cand_t *cands = upgrade_candidates(state, &nc);
    char err[256] = "";
    const upgrade_cand_t *c = cands ? upgrade_resolve(cands, nc, target, err, sizeof(err)) : NULL;
    bool right = c && (is_hub ? c->kind != 'b' : c->kind == 'b');
    if (right) {
      snprintf(uuid, sizeof(uuid), "%s", c->uuid);
      snprintf(name, sizeof(name), "%s", c->name);
    }
    free(cands);
    if (!right)
      return admin_err(state, client, "cron.unknown_node",
                       is_hub ? "no such hub" : "no such bot", word);
  }
  char line[HS_LINE_MAX];
  if (!hub_cron_set_one(state, kind, uuid, on, line, sizeof(line)))
    return admin_err(state, client, "cron.full", "too many single-node cron settings",
                     is_hub ? "hub set cron global <on|off>" : "bot set cron global <on|off>");
  hub_broadcast_sync_to_peers(state, line, -1);
  reply_init(&r);
  reply_ok(&r, "cron.set");
  reply_kv(&r, "scope", name[0] ? name : uuid);
  reply_kv(&r, "uuid", uuid);
  reply_kv(&r, "value", val);
  reply_kvi(&r, "peers", linked_peer_count(state));
  return send_reply(state, client, &r);
}

static int upgrade_staged_count(const pending_upgrade_t *u) {
  int n = 0;
  for (int i = 0; i < u->node_count; i++) n += u->nodes[i].staged ? 1 : 0;
  return n;
}

/* The next bot to swap: staged (or with nothing to stage), and in class order. */
static upgrade_node_t *upgrade_next_bot(pending_upgrade_t *u) {
  static const char order[] = "fusp";
  for (const char *c = order; *c; c++) {
    for (int i = 0; i < u->node_count; i++) {
      upgrade_node_t *n = &u->nodes[i];
      if (n->state != UPG_NODE_READY || n->kind != 'b') continue;
      if (n->can_stage && !n->staged) continue;
      if ((n->cls ? n->cls : 'u') == *c) return n;
    }
  }
  return NULL;
}

static bool upgrade_same_build(const upgrade_node_t *a, const upgrade_node_t *b) {
  return a->kind == b->kind && !strcmp(a->variant, b->variant) && !strcmp(a->arch, b->arch) &&
         !strcmp(a->libc, b->libc);
}

/* No node of this build has come through yet: the next goes alone.  A problem host
 * always goes alone. */
static bool upgrade_build_unproven(const pending_upgrade_t *u, const upgrade_node_t *n) {
  if (n->cls == 'p') return true;
  for (int i = 0; i < u->node_count; i++) {
    const upgrade_node_t *o = &u->nodes[i];
    if (o != n && o->state == UPG_NODE_DONE && upgrade_same_build(o, n)) return false;
  }
  return true;
}

/* Who has left the stage, and is the release itself bad?  True when the run ended. */
static bool hub_upgrade_stage_watch(hub_state_t *state, time_t now) {
  pending_upgrade_t *u = &state->upgrade;
  int left = 0, touched = 0;
  for (int i = 0; i < u->node_count; i++) {
    upgrade_node_t *n = &u->nodes[i];
    if (!n->not_selected && n->state != UPG_NODE_UNABLE) touched++;
    if (n->left) {
      left++;
      touched++;
    }
    if (n->state != UPG_NODE_READY || !n->can_stage || n->staged) continue;
    int limit = n->is_src ? (n->build_limit ? n->build_limit : UPGRADE_BUILD_SECS) : n->stage_limit;
    bool silent = n->kind != 's' && now - n->stage_last > UPGRADE_STAGE_SILENCE;
    if (!silent && now - n->stage_sent <= limit) continue;
    n->state = UPG_NODE_UNABLE;
    n->left = true;
    left++;
    snprintf(n->stage_code, sizeof(n->stage_code), "%s", silent ? "silent" : "limit");
    if (silent)
      snprintf(n->reason, sizeof(n->reason), "stage: no word for %d s", UPGRADE_STAGE_SILENCE);
    else
      snprintf(n->reason, sizeof(n->reason), "stage: still %s at its %d s limit",
               n->stage_phase[0] ? n->stage_phase : "going", limit);
    hub_log_warning("[UPGRADE] %s left run %s: %s\n", hub_who(state, n->kind == 'b' ? 'b' : 'h', n->uuid), u->id,
                    n->reason);
  }
  if (left >= 2 && left * 100 > touched * UPGRADE_STOP_PERCENT) {
    char why[192];
    snprintf(why, sizeof(why), "%d of %d nodes could not stage it: something is wrong beyond one "
             "host, and nothing has changed", left, touched);
    hub_upgrade_abort(state, why);
    return true;
  }
  return false;
}

/* What failures mean.  One host failing leaves the run; the rest go on.  Two on one
 * build stop that build and undo it.  A quarter of the network stops everything, and
 * a peer hub failing stops the hubs.  A host with a bad history counts for nothing:
 * its failure says little about the build.  True when the run ended. */
static bool hub_upgrade_weigh_failures(hub_state_t *state) {
  pending_upgrade_t *u = &state->upgrade;
  int failed = 0, touched = 0;
  for (int i = 0; i < u->node_count; i++) {
    const upgrade_node_t *n = &u->nodes[i];
    if (n->not_selected) continue;
    if (n->state != UPG_NODE_UNABLE) touched++;
    if (n->state == UPG_NODE_FAILED && n->cls != 'p') failed++;
  }
  if (failed >= 2 && failed * 100 > touched * UPGRADE_STOP_PERCENT) {
    hub_upgrade_abort(state, "too many nodes failed: stopping everything");
    return true;
  }
  for (int i = 0; i < u->node_count; i++) {
    upgrade_node_t *n = &u->nodes[i];
    if (n->state != UPG_NODE_FAILED || n->counted) continue;
    n->counted = true;
    hub_log_warning("[UPGRADE] %s failed: %s\n", hub_who(state, n->kind == 'b' ? 'b' : 'h', n->uuid), n->reason);
    if (n->kind == 'h') {
      u->hubs_stopped = true;
      for (int k = 0; k < u->node_count; k++) {
        upgrade_node_t *o = &u->nodes[k];
        if (o->state != UPG_NODE_READY || o->kind == 'b') continue;
        o->state = UPG_NODE_UNABLE;
        snprintf(o->reason, sizeof(o->reason), "a peer hub failed: no more hubs move");
      }
      continue;
    }
    if (n->cls == 'p') continue;
    int same = 0;
    for (int k = 0; k < u->node_count; k++)
      if (u->nodes[k].state == UPG_NODE_FAILED && u->nodes[k].cls != 'p' &&
          upgrade_same_build(&u->nodes[k], n))
        same++;
    if (same < 2) continue;
    /* Stop this build: nothing more of it moves, and what moved comes back. */
    u->build_stopped = true;
    char why[128], msg[256];
    snprintf(why, sizeof(why), "%d nodes of the %s %s/%s build failed", same, n->variant, n->arch,
             n->libc);
    snprintf(msg, sizeof(msg), "%s|%s", u->id, why);
    hub_log_warning("[UPGRADE] %s: stopping that build\n", why);
    for (int k = 0; k < u->node_count; k++) {
      upgrade_node_t *o = &u->nodes[k];
      if (!upgrade_same_build(o, n)) continue;
      if (o->state == UPG_NODE_READY) {
        o->state = UPG_NODE_UNABLE;
        snprintf(o->reason, sizeof(o->reason), "%s", why);
      } else if (o->state == UPG_NODE_DONE || o->state == UPG_NODE_COMMITTED) {
        hub_client_t *c = o->via[0] ? NULL : upgrade_find_client(state, o->uuid, CLIENT_BOT);
        if (o->via[0]) {
          hub_client_t *peer = upgrade_find_peer(state, o->via);
          char relay[320];
          snprintf(relay, sizeof(relay), "%s|%s|%s", u->id, o->uuid, why);
          if (peer) peer_send_urgent(state, peer, CMD_UPGRADE_ABORT, relay);
        } else if (c) {
          send_cmd_to_bot(state, c, CMD_UPGRADE_ABORT, msg);
        }
        o->state = UPG_NODE_FAILED;
        o->counted = true;
        snprintf(o->reason, sizeof(o->reason), "rolled back: %.100s", why);
      }
    }
  }
  return false;
}

/* A note of "72%", "40% 18 of 45 files" or "~60% 120 of 200 crates", while a node fetches
 * or builds.  Anything else is no measure of how far it has got. */
static void stage_note_read(upgrade_node_t *n, const char *phase, const char *note) {
  n->stage_pct[0] = n->stage_detail[0] = '\0';
  if (strcmp(phase, "fetching") != 0 && strcmp(phase, "building") != 0) return;
  size_t at = note[0] == '~' ? 1 : 0, digits = 0;
  while (isdigit((unsigned char)note[at + digits]) && digits < 4) digits++;
  if (digits == 0 || digits > 3 || note[at + digits] != '%' || atoi(note + at) > 100) return;
  snprintf(n->stage_pct, sizeof(n->stage_pct), "%.*s", (int)(at + digits + 1), note);
  const char *rest = note + at + digits + 1;
  if (*rest == ' ') rest++;
  upgrade_clean(n->stage_detail, sizeof(n->stage_detail), rest);
}

/* CMD_UPGRADE_PROGRESS: id|uuid|phase|code|note */
static void hub_upgrade_note_progress(hub_state_t *state, const char *payload) {
  if (hub_rollup_note_progress(state, payload)) return;
  pending_upgrade_t *u = &state->upgrade;
  char id[64] = "", uuid[64] = "", phase[16] = "", code[16] = "", note[192] = "";
  if (!wire_field(payload, 0, id, sizeof(id)) || !wire_field(payload, 1, uuid, sizeof(uuid)) ||
      !wire_field(payload, 2, phase, sizeof(phase)))
    return;
  wire_field(payload, 3, code, sizeof(code));
  wire_field(payload, 4, note, sizeof(note));
  if (!u->active || strcmp(u->id, id) != 0) return;
  upgrade_node_t *n = upgrade_find_node(u, uuid);
  if (!n) return;
  if (strcmp(phase, "ready") == 0) {
    n->can_stage = u->phase == UPG_PREPARE; /* too late to stage: the old path */
    return;
  }
  n->stage_last = time(NULL);
  snprintf(n->stage_phase, sizeof(n->stage_phase), "%s", phase);
  stage_note_read(n, phase, note);
  if (strcmp(phase, "building") == 0 || strcmp(code, "src") == 0) n->is_src = true;
  if (n->state != UPG_NODE_READY) return;
  if (strcmp(phase, "staged") == 0) {
    n->staged = true;
    n->staged_at = time(NULL);
  } else if (strcmp(phase, "failed") == 0) {
    snprintf(n->stage_code, sizeof(n->stage_code), "%s", code);
    char why[sizeof(code) + 2 + sizeof(note)]; /* "<code>: <note>" whole */
    snprintf(why, sizeof(why), "%s: %s", code[0] ? code : "stage", note);
    /* A signature or hash that does not hold is the release's fault, not this host's. */
    if (strcmp(code, "sig") == 0 || strcmp(code, "hash") == 0) {
      char stop[256];
      snprintf(stop, sizeof(stop), "the release is bad: %.200s", why);
      n->state = UPG_NODE_UNABLE;
      upgrade_clean(n->reason, sizeof(n->reason), why);
      hub_upgrade_abort(state, stop);
      return;
    }
    n->state = UPG_NODE_UNABLE;
    n->left = true;
    upgrade_clean(n->reason, sizeof(n->reason), why);
    hub_log_warning("[UPGRADE] %s left run %s: %s\n", hub_who(state, n->kind == 'b' ? 'b' : 'h', uuid), id,
                    n->reason);
  }
}

/* A hub's STAGE: on to its own bots and peers, and itself if it is in the run. */
static void process_peer_upgrade_stage(hub_state_t *state, hub_client_t *peer, const char *payload) {
  char id[64] = "", key[96];
  wire_field(payload, 0, id, sizeof(id));
  if (!id[0]) return;
  snprintf(key, sizeof(key), "st:%.60s", id);
  if (op_forward_seen_check_and_add(state, key)) return;
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c == peer || !c->authenticated) continue;
    if (c->type == CLIENT_BOT) send_cmd_to_bot(state, c, CMD_UPGRADE_STAGE, id);
    else if (c->type == CLIENT_HUB) peer_send_urgent(state, c, CMD_UPGRADE_STAGE, id);
  }
  if (strcmp(state->follow_id, id) == 0 && state->follow_self_ready && state->follow_hub_target[0])
    hub_update_stage_start(state->executable_path, id, state->follow_hub_target,
                           state->follow_variant);
}

/* This hub's own stage: into the run it drives, or up to whoever does. */
static void hub_upgrade_stage_tick(hub_state_t *state) {
  char id[64], status[256], payload[400];
  if (!hub_update_stage_tick(id, sizeof(id), status, sizeof(status))) return;
  /* A build staged after another failed says so: the operator should know this
   * host could not take its first choice.  As ircbot. */
  if (strncmp(status, "staged|", 7) == 0 && strstr(status, "; the ") != NULL)
    hub_log_info("[UPGRADE] Stage of %s: %s\n", id, status);
  snprintf(payload, sizeof(payload), "%s|%s|%s", id, state->hub_uuid, status);
  bool following = strcmp(state->follow_id, id) == 0;
  hub_client_t *origin = following ? upgrade_find_peer(state, state->follow_origin) : NULL;
  if (origin) peer_send_urgent(state, origin, CMD_UPGRADE_PROGRESS, payload);
  else {
    if (following) hub_update_stage_unsaid(); /* driver's link down: keep it owed */
    hub_upgrade_note_progress(state, payload);
  }
}

/* The rolling plan, one step per maintenance tick. */
void hub_upgrade_tick(hub_state_t *state, time_t now) {
  /* Called once per event-loop pass.  The housekeeping below is second-granular
   * (a file probe, a walk of every bot, a roll-up settle), so it runs once a
   * second; the plan and the run's own steps still look on every pass. */
  static time_t last_sec = 0;
  bool new_sec = now != last_sec;
  last_sec = now;
  /* A hub with no peers to link to has nothing more to prove than being up. */
  if (new_sec && state->peer_count == 0) hub_update_failback_confirm();
  if (new_sec) hub_cron_tick(state);
  hub_upgrade_stage_tick(state);
  if (new_sec) hub_rollup_tick(state, now);
  hub_plan_tick(state, now);
  pending_upgrade_t *u = &state->upgrade;
  if (!u->active) return;

  if (u->phase == UPG_PREPARE) {
    bool timed_out = (now - u->phase_started > UPGRADE_PREPARE_TIMEOUT);
    if (!timed_out &&
        (upgrade_count(u, UPG_NODE_PENDING, 0) > 0 || upgrade_relays_owed(u) > 0 ||
         now - u->last_added < UPGRADE_PREPARE_SETTLE))
      return;
    for (int i = 0; i < u->node_count; i++) {
      if (u->nodes[i].state != UPG_NODE_PENDING) continue;
      u->nodes[i].state = UPG_NODE_UNABLE;
      snprintf(u->nodes[i].reason, sizeof(u->nodes[i].reason),
               "no answer to PREPARE");
    }
    int ready = upgrade_count(u, UPG_NODE_READY, 0);
    if (ready == 0) {
      upgrade_finish(state, UPG_DONE, "no node needed the upgrade");
      return;
    }
    /* Get the build ready everywhere first, while nothing has changed.  A node
     * that never said it can stage takes the old path at COMMIT. */
    int staging = 0;
    upgrade_apply_history(state);
    for (int i = 0; i < u->node_count; i++) {
      upgrade_node_t *n = &u->nodes[i];
      if (n->kind == 's' && n->state == UPG_NODE_READY) n->can_stage = true;
      if (n->state != UPG_NODE_READY || !n->can_stage) continue;
      n->stage_sent = n->stage_last = now;
      if (!n->stage_limit) n->stage_limit = UPGRADE_STAGE_GATE;
      if (n->kind == 's') {
        hub_update_stage_start(state->executable_path, u->id, u->hub_ver,
                               upgrade_node_variant(u, n));
      }
      staging++;
    }
    if (staging) {
      char key[96], frame[96];
      snprintf(key, sizeof(key), "st:%.60s", u->id);
      op_forward_seen_check_and_add(state, key);
      snprintf(frame, sizeof(frame), "%s", u->id);
      for (int i = 0; i < state->client_count; i++) {
        hub_client_t *c = state->clients[i];
        if (c->type == CLIENT_BOT && c->authenticated) send_cmd_to_bot(state, c, CMD_UPGRADE_STAGE, frame);
        else if (c->type == CLIENT_HUB && c->authenticated) peer_send_urgent(state, c, CMD_UPGRADE_STAGE, frame);
      }
      u->phase = UPG_STAGING;
      u->phase_started = now;
      upgrade_history_note(state);
      hub_log_info("[UPGRADE] Run %s staging on %d node(s)\n", u->id, staging);
      return;
    }
    u->phase = UPG_ROLLING;
    u->phase_started = now;
    u->rolling_at = now;
    upgrade_history_note(state);
    hub_log_info("[UPGRADE] Run %s rolling: %d node(s) ready\n", u->id, ready);
    return;
  }

  if (u->phase == UPG_STAGING || u->phase == UPG_ROLLING) {
    if (hub_upgrade_stage_watch(state, now)) return;
  }
  if (u->phase == UPG_STAGING) {
    /* A source build gets its time, but the rest of the run does not wait on it. */
    for (int i = 0; i < u->node_count; i++) {
      const upgrade_node_t *n = &u->nodes[i];
      if (n->state == UPG_NODE_READY && n->can_stage && !n->staged && !n->is_src) return;
    }
    u->phase = UPG_ROLLING;
    u->phase_started = now;
    u->rolling_at = now;
    upgrade_history_note(state);
    hub_log_info("[UPGRADE] Run %s rolling: %d node(s) ready, %d staged\n", u->id,
                 upgrade_count(u, UPG_NODE_READY, 0), upgrade_staged_count(u));
    return;
  }

  if (u->phase != UPG_ROLLING) return;

  /* A bot back on the target that never reports ready: it runs, and it came
   * back — done, with a note.  Only its channels' ops are unconfirmed. */
  for (int i = 0; i < u->node_count; i++) {
    upgrade_node_t *n = &u->nodes[i];
    if (n->state != UPG_NODE_COMMITTED || !n->back_at) continue;
    if (now - n->back_at <= UPGRADE_OPS_GRACE) continue;
    n->state = UPG_NODE_DONE;
    n->done_at = now;
    snprintf(n->reason, sizeof(n->reason), "back on target; no ready report");
    hub_log_info("[UPGRADE] %s: back %ld s without a ready report; done\n",
                 hub_who(state, 0, n->uuid), (long)(now - n->back_at));
  }
  /* A committed node that did not come back has failed.  A staged one had only a
   * swap to do; one that took the old path may still be fetching.  If it turns up
   * later on the target, the record says so.  Whether the run goes on is decided
   * below: one bad host must not roll back a healthy network. */
  for (int i = 0; i < u->node_count; i++) {
    upgrade_node_t *n = &u->nodes[i];
    if (n->state != UPG_NODE_COMMITTED) continue;
    /* Already seen back on the target: it came up, so only the ops grace
     * above applies — a bot back at 400 s must not fail at 420 s. */
    if (n->back_at) continue;
    int limit = n->staged ? UPGRADE_SWAP_BACK : UPGRADE_COMMIT_TIMEOUT;
    if (now - n->committed_at <= limit) continue;
    n->state = UPG_NODE_FAILED;
    n->done_at = now;
    snprintf(n->stage_code, sizeof(n->stage_code), "late");
    snprintf(n->reason, sizeof(n->reason), "did not return on %s in time",
             upgrade_node_target(u, n));
  }
  if (hub_upgrade_weigh_failures(state)) return;

  int in_flight = upgrade_count(u, UPG_NODE_COMMITTED, 0);
  int ready_bots = upgrade_count(u, UPG_NODE_READY, 'b');

  if (ready_bots > 0) {
    /* Wave size: never more than a quarter of the bots this run touches, and
     * never more than UPGRADE_BOT_WAVE_MAX, so the channels a botnet holds
     * keep a quorum of bots up throughout. */
    int touched = ready_bots + upgrade_count(u, UPG_NODE_COMMITTED, 'b') +
                  upgrade_count(u, UPG_NODE_DONE, 'b');
    int wave = touched / UPGRADE_BOT_WAVE_DIVISOR;
    if (wave < 1) wave = 1;
    if (wave > UPGRADE_BOT_WAVE_MAX) wave = UPGRADE_BOT_WAVE_MAX;
    /* A source build still staging holds no one else up, only the hubs after. */
    for (int i = 0; i < u->node_count && in_flight < wave; i++) {
      upgrade_node_t *n = upgrade_next_bot(u);
      if (!n) break;
      /* Each build's first node goes alone: a bad build costs one restart. */
      if (upgrade_build_unproven(u, n) && in_flight > 0) break;
      if (upgrade_commit_node(state, n)) in_flight++;
      if (upgrade_build_unproven(u, n)) break;
    }
    return;
  }

  /* Bots are settled.  Peer hubs go one at a time, and only once nothing is
   * mid-restart, so the mesh never drops below one reachable hub.
   *
   * Deepest first: a follower's run state (follow_id, its COMMIT routes) is
   * volatile, so a hub that restarts can no longer carry a COMMIT to the hubs
   * it routes for.  The latest READY is always from a hub no other pending
   * hub routes through (see upgrade_node_t.ready_seq).  This hub goes after
   * every peer hub: it restarts last and its run table goes with it. */
  if (in_flight > 0) return;
  upgrade_node_t *next = NULL;
  /* A hub still staging is waited for: order matters here, and the ring relies on
   * the deepest going first. */
  for (int i = 0; i < u->node_count; i++) {
    const upgrade_node_t *n = &u->nodes[i];
    if (n->state == UPG_NODE_READY && n->can_stage && !n->staged &&
        (n->kind == 'h' || n->kind == 's'))
      return;
  }
  for (int i = 0; i < u->node_count; i++) {
    upgrade_node_t *n = &u->nodes[i];
    if (n->state == UPG_NODE_READY && n->kind == 'h' &&
        (!next || n->ready_seq > next->ready_seq))
      next = n;
  }
  for (int i = 0; i < u->node_count && !next; i++) {
    upgrade_node_t *n = &u->nodes[i];
    if (n->state == UPG_NODE_READY && n->kind == 's') next = n;
  }
  if (next) {
    upgrade_commit_node(state, next);
    return;
  }

  int unable = 0;
  for (int i = 0; i < u->node_count; i++)
    if (u->nodes[i].state == UPG_NODE_UNABLE && !u->nodes[i].not_selected)
      unable++;
  char done_msg[192];
  int failed = upgrade_count(u, UPG_NODE_FAILED, 0);
  snprintf(done_msg, sizeof(done_msg),
           "%d node(s) now on the target, %d could not take it, %d failed",
           upgrade_count(u, UPG_NODE_DONE, 0), unable, failed);
  if (!failed && !u->build_stopped)
    snprintf(done_msg, sizeof(done_msg), "%d node(s) now on the target, %d could not take it",
             upgrade_count(u, UPG_NODE_DONE, 0), unable);
  upgrade_finish(state, failed || u->build_stopped ? UPG_PARTIAL : UPG_DONE, done_msg);
}

/* ---- Follower side: this hub as a node of another hub's run -------------
 * Symmetrical to the bot handlers in ircbot/hub_client.c, and reachable only
 * on an authenticated peer link.  A hub is a follower and a driver at the
 * same time — the mesh is flat — so the two halves are kept apart: `upgrade`
 * holds the run THIS hub drives, while the fields below are about a run
 * someone else drives. */

/* ---- Follower routing table (upgrade_route_t) --------------------------
 * A run reaches every hub in the mesh, whatever topology it is wired in: a
 * follower re-broadcasts PREPARE to its own peers and forwards their answers
 * back toward the driver.  For that to work in reverse, each hop remembers
 * which peer it heard a given node from; COMMIT and ABORT then walk the same
 * tree back down.  Suppression is by run id: a hub joins a run exactly once,
 * through the first peer that told it about the run, so a cycle in the peer
 * graph cannot make the fan-out loop. */

static void upgrade_routes_clear(hub_state_t *state) {
  memset(state->follow_routes, 0, sizeof(state->follow_routes));
  state->follow_route_count = 0;
}

/* Remember (or refresh) "frames for <uuid> go out through <via>". */
static void upgrade_route_note(hub_state_t *state, const char *uuid,
                               const char *via) {
  if (!uuid || !uuid[0] || !via || !via[0]) return;
  for (int i = 0; i < state->follow_route_count; i++) {
    if (strcmp(state->follow_routes[i].uuid, uuid) != 0) continue;
    snprintf(state->follow_routes[i].via, sizeof(state->follow_routes[i].via),
             "%s", via);
    return;
  }
  if (state->follow_route_count >= MAX_UPGRADE_ROUTES) {
    hub_log_warning("[UPGRADE] No room to route %s — it stays out of the run\n",
                    hub_who(state, 0, uuid));
    return;
  }
  upgrade_route_t *r = &state->follow_routes[state->follow_route_count++];
  snprintf(r->uuid, sizeof(r->uuid), "%s", uuid);
  snprintf(r->via, sizeof(r->via), "%s", via);
}

/* The next hop toward `uuid`, or NULL when this hub never saw it. */
static const char *upgrade_route_via(const hub_state_t *state,
                                     const char *uuid) {
  if (!uuid || !uuid[0]) return NULL;
  for (int i = 0; i < state->follow_route_count; i++)
    if (strcmp(state->follow_routes[i].uuid, uuid) == 0)
      return state->follow_routes[i].via;
  return NULL;
}

/* id|uuid|cur_ver|variant|arch|libc|ready|reason|kind */
static void hub_upgrade_answer_ready(hub_state_t *state, hub_client_t *peer,
                                     const char *id, bool ready,
                                     const char *reason, int relayed) {
  char arch[32], libc[16], clean_reason[192];
  hub_update_host_arch(arch, sizeof(arch));
  hub_update_host_libc(libc, sizeof(libc));
  upgrade_clean(clean_reason, sizeof(clean_reason), reason);

  /* The trailing "h" is the node KIND.  A bot's READY stops at the reason, so
   * an absent field still means "bot" and bot.h is untouched; a hub several
   * hops from the driver has no other way to say what it is, and the driver
   * has to know to route its COMMIT through the peer that forwarded this.
   * upgrade_clean() has already turned any '|' in the reason into '/', so the
   * field after it is unambiguous.  After the kind: how many local bots this
   * hub relayed the PREPARE to, so the driver waits for their answers. */
  char payload[640];
  snprintf(payload, sizeof(payload), "%s|%s|%s|%s|%s|%s|%d|%s|h|%d", id,
           state->hub_uuid, HUB_VERSION, hub_update_host_variant(), arch, libc,
           ready ? 1 : 0, clean_reason, relayed);
  peer_send_urgent(state, peer, CMD_UPGRADE_READY, payload);
  hub_log_info("[UPGRADE] %s upgrade %s%s%s\n", ready ? "Ready for" : "Cannot take",
          id, clean_reason[0] ? ": " : "", clean_reason);
}

/* id|uuid|status|version|detail */
/* Report a result upstream on behalf of `uuid` — this hub itself, or a local
 * bot the driver reaches through it.  `version` is the version to attribute
 * to that node ("" leaves it unknown). */
static void hub_upgrade_answer_result_uuid(hub_state_t *state,
                                           hub_client_t *peer, const char *id,
                                           const char *uuid, const char *status,
                                           const char *detail) {
  char clean_detail[192];
  upgrade_clean(clean_detail, sizeof(clean_detail), detail);
  char payload[640];
  snprintf(payload, sizeof(payload), "%s|%s|%s|%s|%s", id, uuid, status,
           HUB_VERSION, clean_detail);
  peer_send_urgent(state, peer, CMD_UPGRADE_RESULT, payload);
}

static void hub_upgrade_answer_result(hub_state_t *state, hub_client_t *peer,
                                      const char *id, const char *status,
                                      const char *detail) {
  hub_upgrade_answer_result_uuid(state, peer, id, state->hub_uuid, status,
                                 detail);
}

/* CMD_UPGRADE_PREPARE from a peer: a capability question.  Nothing is
 * downloaded and nothing on disk is touched until COMMIT. */
static void process_peer_upgrade_prepare(hub_state_t *state,
                                         hub_client_t *peer,
                                         const char *payload) {
  /* id|ver|variant|kind|min_from|base|hub_ver|hub_base — the bots' six
   * fields, then the hubs' own target (see hub_upgrade_start).  The base
   * slots are reserved and never read: every node reads its own compiled-in
   * root, the only tree its pinned key verifies. */
  char id[64] = "", ver[64] = "", variant[8] = "", kind[8] = "";
  char min_from[64] = "", hub_ver[64] = "";
  if (!wire_field(payload, 0, id, sizeof(id)) ||
      !wire_field(payload, 1, ver, sizeof(ver)) || !id[0] || !ver[0]) {
    hub_log_warning("[UPGRADE] Malformed UPGRADE_PREPARE from peer %s\n", peer->ip);
    return;
  }
  wire_field(payload, 2, variant, sizeof(variant));
  wire_field(payload, 3, kind, sizeof(kind));
  wire_field(payload, 4, min_from, sizeof(min_from));
  wire_field(payload, 6, hub_ver, sizeof(hub_ver));
  /* 9th field (2.4.3+): a selective run's resolved selection, uuid[=v],... */
  char sel[MAX_UPGRADE_SELECT * 72] = "";
  wire_tail(payload, 8, sel, sizeof(sel));
  for (const char *p = sel; *p; p++) {
    if (!isalnum((unsigned char)*p) && *p != '-' && *p != '=' && *p != ',') {
      hub_log_warning("[UPGRADE] Malformed selection in PREPARE from peer %s\n",
                      peer->ip);
      return;
    }
  }
  bool selective = sel[0] != '\0';
  /* Every field lands in this hub's config (the persisted roll-up plan) and
   * in a download path, so a peer's PREPARE is held to the same shape the
   * driver enforced on its admin: nothing that could split a line. */
  if (!hub_upgrade_plan_field_ok(id) || !hub_upgrade_plan_field_ok(ver) ||
      !hub_upgrade_plan_field_ok(variant) || !hub_upgrade_plan_field_ok(kind) ||
      !hub_upgrade_plan_field_ok(min_from) ||
      !hub_upgrade_plan_field_ok(hub_ver)) {
    hub_log_warning("[UPGRADE] Malformed UPGRADE_PREPARE from peer %s\n", peer->ip);
    return;
  }
  /* Loop suppression: a hub joins a run exactly ONCE, through the first peer
   * that told it about it.  Re-broadcasting means the same PREPARE arrives
   * again around every cycle in the peer graph; answering or relaying it a
   * second time would both duplicate the node and keep the frame circulating
   * forever.  Silence is the right answer — the driver already has ours.
   *
   * The id goes through the same seen-ring as OP_FORWARD, not a compare
   * against follow_id alone: follow_id holds ONE id and is cleared on abort,
   * refusal and expiry, so two runs in flight at once flip it back and forth
   * and a late copy after a clear is taken as new — either way the frames
   * circulate forever.  The driver seeds the ring with its own id at start,
   * so its PREPARE coming back around a cycle is dropped here too. */
  if (op_forward_seen_check_and_add(state, id)) {
    hub_log_debug("[UPGRADE] PREPARE %s already seen — not relaying it again\n", id);
    return;
  }
  /* Refuse to be a follower while driving a run of our own: two plans moving
   * the same mesh is exactly what the one-run-at-a-time rule prevents. */
  if (state->upgrade.active) {
    hub_upgrade_answer_ready(state, peer, id, false,
                             "already driving an upgrade of its own", 0);
    return;
  }

  /* Remember the plan whether or not this hub itself can take it: even a hub
   * that cannot upgrade must still relay the run to its own local bots and
   * carry their COMMITs, so `follow_*` is set unconditionally and
   * `follow_self_ready` records only whether the hub itself may commit. */
  char why[192] = "";
  bool ready = false;
  char self_variant[8] = "";
  bool self_picked =
      !selective || upgrade_sel_lookup(sel, state->hub_uuid, self_variant,
                                       sizeof(self_variant));
  if (!self_variant[0]) snprintf(self_variant, sizeof(self_variant), "%s", variant);
  if (!self_picked)
    snprintf(why, sizeof(why), "not selected");
  else if (hub_ver[0])
    ready = hub_update_can_take(hub_ver, self_variant, min_from, why,
                                sizeof(why));
  else
    snprintf(why, sizeof(why), "no hub target in this run");
  snprintf(state->follow_id, sizeof(state->follow_id), "%s", id);
  {
    char origin[64];
    snprintf(origin, sizeof(origin), "%s", upgrade_peer_uuid(state, peer));
    snprintf(state->follow_origin, sizeof(state->follow_origin), "%s", origin);
  }
  snprintf(state->follow_target, sizeof(state->follow_target), "%s", ver);
  snprintf(state->follow_variant, sizeof(state->follow_variant), "%s",
           self_variant[0] ? self_variant : hub_update_host_variant());
  snprintf(state->follow_hub_target, sizeof(state->follow_hub_target), "%s",
           hub_ver);
  snprintf(state->follow_bot_variant, sizeof(state->follow_bot_variant), "%s",
           variant);
  snprintf(state->follow_sel, sizeof(state->follow_sel), "%s", sel);
  state->follow_self_ready = ready;
  state->follow_prepared = time(NULL);
  upgrade_routes_clear(state);

  /* Record the driver's plan as this hub's roll-up plan too.  A bot that was
   * down while the run went through reconnects to whichever hub it likes, so
   * every hub has to know what the network is supposed to be running; the
   * replicated config freeze is what keeps any of them from acting on it
   * before the run is over (see hub_rollup_may_try).  Not for a selective
   * run: a few named nodes moving is no statement about the rest. */
  if (!selective) {
    pending_rollup_t *r = &state->rollup;
    r->have_plan = true;
    snprintf(r->target, sizeof(r->target), "%s", ver);
    snprintf(r->variant, sizeof(r->variant), "%s", variant);
    snprintf(r->kind, sizeof(r->kind), "%s", kind);
    snprintf(r->min_from, sizeof(r->min_from), "%s",
             min_from[0] ? min_from : "*");
    snprintf(r->hub_target, sizeof(r->hub_target), "%s", hub_ver);
    r->plan_set = time(NULL);
    state->rollup_try_count = 0;
    hub_config_write(state); /* the plan survives a restart (Task 13) */
  }

  /* Fan PREPARE out to this hub's own local bots.  Each answers READY to us
   * (its hub); we forward that up to the origin, which records it as a remote
   * node reached through this hub.  That is what makes one run reach a bot no
   * matter which hub it is homed on. */
  /* Bots get the six fields they read, not the hubs' on the end — and in a
   * selective run only the bots it names, each asked about its own build. */
  int relayed = 0;
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type != CLIENT_BOT || !c->authenticated) continue;
    char bot_variant[8] = "";
    if (selective &&
        !upgrade_sel_lookup(sel, c->id, bot_variant, sizeof(bot_variant)))
      continue;
    char bot_prepare[1024];
    snprintf(bot_prepare, sizeof(bot_prepare), "%s|%s|%s|%s|%s|", id, ver,
             bot_variant[0] ? bot_variant : variant, kind, min_from);
    if (send_cmd_to_bot(state, c, CMD_UPGRADE_PREPARE, bot_prepare)) relayed++;
  }
  if (relayed)
    hub_log_info("[UPGRADE] Relayed PREPARE %s to %d local bot(s)\n", id, relayed);

  /* ...and on to this hub's OWN peers, minus the one it came from.  This is
   * what carries a run past the driver's immediate neighbours: every hub the
   * mesh can reach joins the run, whatever shape the peer links are wired in
   * (a chain, a star, a partial mesh).  Their answers come back to us and we
   * forward them up, so the driver sees one flat node table.  Rebuilt from
   * the checked fields, so anything in a reserved slot goes no further. */
  char fwd[600 + sizeof(sel)];
  snprintf(fwd, sizeof(fwd), "%s|%s|%s|%s|%s||%s|%s%s", id, ver, variant, kind,
           min_from, hub_ver, sel[0] ? "|" : "", sel);
  int fanned = 0;
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type != CLIENT_HUB || !c->authenticated || c == peer) continue;
    if (peer_send_urgent(state, c, CMD_UPGRADE_PREPARE, fwd)) fanned++;
  }
  if (fanned)
    hub_log_info("[UPGRADE] Re-broadcast PREPARE %s to %d peer hub(s)\n", id, fanned);

  hub_upgrade_answer_ready(state, peer, id, ready, why, relayed);
  /* A frame an older driver drops: this hub can get a build ready before COMMIT. */
  if (ready) {
    char pr[160];
    snprintf(pr, sizeof(pr), "%s|%s|ready|", id, state->hub_uuid);
    peer_send_urgent(state, peer, CMD_UPGRADE_PROGRESS, pr);
  }
}

/* A COMMIT refused because the RELEASE is bad — tampered, corrupt, or the
 * wrong product — is still answered "fail" although nothing on this node
 * changed: every other node would hit the same artifact, and the run must
 * stop rather than retry it across the mesh in waves.  Any other refusal is
 * this node's own business and answered "skip". */
static bool upgrade_err_is_integrity(const char *err) {
  static const char *const marks[] = {
      "SHA-256 mismatch", "signature INVALID", "is not a irchub release",
      "is not a ircbot release", "untrusted artifact URL"};
  if (!err) return false;
  for (size_t i = 0; i < sizeof(marks) / sizeof(marks[0]); i++)
    if (strstr(err, marks[i])) return true;
  return false;
}

/* A frame this hub is only relaying: an answer from somewhere below it in the
 * fan-out tree, on its way to the driver.  Returns true when it was handled
 * as a relay (route remembered, frame forwarded), false when the frame
 * belongs to a run this hub drives itself and should be noted locally. */
static bool hub_upgrade_relay_upstream(hub_state_t *state, hub_client_t *from,
                                       int cmd, const char *payload) {
  char id[64] = "", uuid[64] = "";
  wire_field(payload, 0, id, sizeof(id));
  wire_field(payload, 1, uuid, sizeof(uuid));
  if (!state->follow_id[0] || !id[0] || strcmp(state->follow_id, id) != 0)
    return false;

  /* Taken by value: upgrade_peer_uuid() points into state->peers, and the
   * route table it would be copied into lives in the same object. */
  char from_uuid[64];
  snprintf(from_uuid, sizeof(from_uuid), "%s", upgrade_peer_uuid(state, from));
  /* A frame coming DOWN from the driver's direction is not an answer to
   * relay; nothing below us is reached through the hop we answer to. */
  if (from_uuid[0] && strcmp(from_uuid, state->follow_origin) == 0)
    return false;

  if (cmd == CMD_UPGRADE_READY) upgrade_route_note(state, uuid, from_uuid);

  hub_client_t *origin = upgrade_find_peer(state, state->follow_origin);
  if (!origin) {
    hub_log_debug("[UPGRADE] Driver of %s is gone — dropping a relayed answer for "
            "%s\n", id, hub_who(state, 0, uuid));
    return true;
  }
  peer_send_urgent(state, origin, (uint8_t)cmd, payload);
  return true;
}

/* CMD_UPGRADE_COMMIT from a peer: go.  Only an id we acknowledged at PREPARE,
 * and only while that acknowledgement is still fresh, may commit. */
static void process_peer_upgrade_commit(hub_state_t *state, hub_client_t *peer,
                                        const char *payload) {
  char id[64] = "", ver[64] = "", variant[8] = "", target_uuid[64] = "";
  if (!wire_field(payload, 0, id, sizeof(id)) ||
      !wire_field(payload, 1, ver, sizeof(ver)) || !id[0] || !ver[0]) {
    hub_log_warning("[UPGRADE] Malformed UPGRADE_COMMIT from peer %s\n", peer->ip);
    return;
  }
  wire_field(payload, 2, variant, sizeof(variant));
  wire_field(payload, 3, target_uuid, sizeof(target_uuid));
  bool for_self = !target_uuid[0] || strcmp(target_uuid, state->hub_uuid) == 0;
  /* Every refusal below touched nothing, so it is answered "skip" — the
   * node stays healthy where it is and leaves the run — and always under the
   * uuid of the node the driver addressed.  Answering a relayed bot's COMMIT
   * under this hub's own uuid is what turned a done hub into a failed one
   * and aborted run 83aac614. */
  const char *who = for_self ? state->hub_uuid : target_uuid;

  if (!state->follow_id[0] || strcmp(state->follow_id, id) != 0) {
    /* No run state: this hub restarted (or never saw the PREPARE).  If it
     * is itself the target and already on that build, the COMMIT's work is
     * done — say so rather than fail a node that succeeded. */
    bool there = for_self && hub_update_version_cmp(HUB_VERSION, ver) == 0 &&
                 (!variant[0] || strcmp(variant, hub_update_host_variant()) == 0);
    hub_upgrade_answer_result_uuid(state, peer, id, who, there ? "ok" : "skip",
                                   there ? "" : "this hub holds no such run "
                                                "(restarted since PREPARE?)");
    return;
  }
  /* The version must be one this run named: the bots' target for a frame
   * on its way to a bot, the hubs' own for this hub (checked again below). */
  if (strcmp(state->follow_target, ver) != 0 &&
      !(state->follow_hub_target[0] &&
        strcmp(state->follow_hub_target, ver) == 0)) {
    hub_upgrade_answer_result_uuid(state, peer, id, who, "skip",
                                   "commit version differs from prepare");
    return;
  }
  if (time(NULL) - state->follow_prepared > UPGRADE_PREPARE_TTL) {
    state->follow_id[0] = '\0';
    hub_upgrade_answer_result_uuid(state, peer, id, who, "skip",
                                   "prepare expired");
    return;
  }

  /* A 4th field names the node the driver is addressing.  It is one of three
   * things, in order: this hub, one of its local bots, or something further
   * out that this hub relayed an answer for at PREPARE time — in which case
   * the frame goes on, unchanged, along the route it learned. */
  if (!for_self) {
    hub_client_t *bot = upgrade_find_client(state, target_uuid, CLIENT_BOT);
    if (bot) {
      char relay[192];
      snprintf(relay, sizeof(relay), "%s|%s|%s", id, ver, variant);
      if (!send_cmd_to_bot(state, bot, CMD_UPGRADE_COMMIT, relay))
        hub_upgrade_answer_result_uuid(state, peer, id, target_uuid, "skip",
                                       "bot not reachable through this hub");
      return;
    }
    const char *via = upgrade_route_via(state, target_uuid);
    hub_client_t *next = via ? upgrade_find_peer(state, via) : NULL;
    if (!next || !peer_send_urgent(state, next, CMD_UPGRADE_COMMIT, payload))
      hub_upgrade_answer_result_uuid(state, peer, id, target_uuid, "skip",
                                     "no route to that node from this hub");
    return;
  }

  /* No target uuid: this hub is the node being committed. */
  if (!state->follow_self_ready) {
    hub_upgrade_answer_result(state, peer, id, "skip",
                              "this hub cannot take the upgrade");
    return;
  }
  if (strcmp(state->follow_hub_target, ver) != 0) {
    hub_upgrade_answer_result(state, peer, id, "skip",
                              "commit version differs from prepare");
    return;
  }

  const char *err = NULL;
  if (!hub_update_commit(state, id, ver,
                         variant[0] ? variant : state->follow_variant, &err)) {
    /* Nothing was changed on disk; stay on this build and say why. */
    hub_log_warning("[UPGRADE] Commit %s refused: %s\n", id,
            err ? err : "unknown error");
    hub_upgrade_answer_result(state, peer, id,
                              upgrade_err_is_integrity(err) ? "fail" : "skip",
                              err ? err : "failed");
    state->follow_id[0] = '\0';
  }
  /* On success hub_update_commit() does not return: the process is replaced
   * and hub_upgrade_report_pending() reports in after the restart. */
}

/* CMD_UPGRADE_ABORT from a peer: put the retained build back. */
static void process_peer_upgrade_abort(hub_state_t *state, hub_client_t *peer,
                                       const char *payload) {
  char id[64] = "", uuid[64] = "", reason[192] = "";
  wire_field(payload, 0, id, sizeof(id));
  wire_field(payload, 1, uuid, sizeof(uuid));
  wire_tail(payload, 2, reason, sizeof(reason));
  hub_log_info("[UPGRADE] Abort %s from %s%s%s: %s\n", id[0] ? id : "(no id)",
          hub_who_client(state, peer), uuid[0] ? " for " : "",
          uuid[0] ? hub_who(state, 'b', uuid) : "",
          reason[0] ? reason : "no reason given");

  /* A named node that is not this hub: one of its local bots (which gets the
   * plain id|reason frame), or something further out, which the route learned
   * at PREPARE time carries the frame on to unchanged.  Either way this hub's
   * own follower state belongs to its own node and is left alone. */
  if (uuid[0] && strcmp(uuid, state->hub_uuid) != 0) {
    hub_client_t *bot = upgrade_find_client(state, uuid, CLIENT_BOT);
    if (bot) {
      char relay[256];
      snprintf(relay, sizeof(relay), "%s|", id);
      upgrade_clean(relay + strlen(relay), sizeof(relay) - strlen(relay),
                    reason);
      send_cmd_to_bot(state, bot, CMD_UPGRADE_ABORT, relay);
      return;
    }
    const char *via = upgrade_route_via(state, uuid);
    hub_client_t *next = via ? upgrade_find_peer(state, via) : NULL;
    if (next) peer_send_urgent(state, next, CMD_UPGRADE_ABORT, payload);
    return;
  }

  /* Whether it names this hub or nobody, the run is over here: a staged build
   * must not stay behind. */
  hub_update_stage_clear();
  state->follow_id[0] = '\0';
  state->follow_prepared = 0;
  state->follow_self_ready = false;
  /* The routes stay until the next PREPARE: the driver's aborts for the nodes behind
   * this hub may still be on their way, and they travel by this table. */
  /* Only the run that installed the build we are running may take it back.  A hub
   * still staging never moved, and its <exe>.prev is the build from before an
   * earlier, completed run: going back to it would walk a healthy hub off the
   * version the rest of the mesh is on. */
  if (!id[0] || strcmp(id, state->upgrade_installed_id) != 0) {
    hub_upgrade_answer_result(state, peer, id[0] ? id : "-", "aborted", "this hub did not move");
    return;
  }
  if (!hub_update_rollback(state, reason[0] ? reason : "the upgrade was aborted"))
    hub_upgrade_answer_result(state, peer, id[0] ? id : "-", "aborted",
                              "nothing retained to roll back to");
  /* A successful rollback execs; the driver sees the old version reappear. */
}

/* Called once per authenticated peer link.  If this process is the product of
 * an upgrade another hub drove, the marker left behind by hub_update_commit()
 * says which run it belongs to; report whether we came up on the version that
 * run was aiming at.  The driver also infers success from the roster gossip,
 * so a lost RESULT costs nothing. */
void hub_upgrade_report_pending(hub_state_t *state, hub_client_t *peer) {
  /* A recent `upgrade abort` goes to every link that comes up: the hub it
   * was meant for may have been restarting onto a step when it was typed. */
  if (state->upgrade_cancel_id[0] &&
      time(NULL) - state->upgrade_cancel_seen < UPGRADE_CANCEL_HOLD) {
    char fwd[128];
    snprintf(fwd, sizeof(fwd), "%s|%lld|A|%lld", state->upgrade_cancel_id,
             (long long)time(NULL), (long long)state->upgrade_cancel_issued);
    peer_send_urgent(state, peer, CMD_UPGRADE_FORGET, fwd);
  }
  char id[64], want[64], want_variant[16];
  if (!hub_update_take_pending(id, sizeof(id), want, sizeof(want), want_variant,
                               sizeof(want_variant))) {
    /* Already reported: the same RESULT on this link too, for a while. */
    if (state->upgrade_installed_id[0] && state->upgrade_report_status[0] &&
        time(NULL) < state->upgrade_report_until)
      hub_upgrade_answer_result(state, peer, state->upgrade_installed_id,
                                state->upgrade_report_status, state->upgrade_report_detail);
    return;
  }
  snprintf(state->upgrade_installed_id, sizeof(state->upgrade_installed_id), "%s", id);
  bool ok = hub_update_version_cmp(HUB_VERSION, want) == 0 &&
            (!want_variant[0] ||
             strcmp(want_variant, hub_update_host_variant()) == 0);
  hub_log_warning("[UPGRADE] Restarted after %s: running %s/%s (wanted %s%s%s)\n",
                  id, HUB_VERSION, hub_update_host_variant(), want,
                  want_variant[0] ? "/" : "", want_variant);
  char detail[192];
  if (ok) hub_update_failback_confirm();
  else if (!hub_update_failback_note(detail, sizeof(detail)))
    snprintf(detail, sizeof(detail), "wanted %s%s%s", want,
             want_variant[0] ? "/" : "", want_variant);
  snprintf(state->upgrade_report_status, sizeof(state->upgrade_report_status), "%s",
           ok ? "ok" : "version-mismatch");
  snprintf(state->upgrade_report_detail, sizeof(state->upgrade_report_detail), "%s",
           ok ? "" : detail);
  state->upgrade_report_until = time(NULL) + UPGRADE_RESULT_RESEND;
  hub_upgrade_answer_result(state, peer, id, state->upgrade_report_status,
                            state->upgrade_report_detail);
}

/* CMD_ADMIN_UPGRADE_STATUS "": the run this hub drives (or drove last), the
 * roll-up plan it holds, and one node| record per node of the run:
 *   ok|upg.status[|id|phase|started|bot_ver|hub_ver|selective|summary]|frozen
 *   rollup|bot_ver|hub_ver|set
 *   node|kind|uuid|name|state|from|to|base|want|reason */
static void hub_upgrade_status(hub_state_t *state, reply_t *r) {
  pending_upgrade_t *u = &state->upgrade;
  reply_ok(r, "upg.status");
  if (u->id[0]) {
    reply_kv(r, "id", u->id);
    reply_kv(r, "phase", upgrade_phase_name(u->phase));
    reply_kvb(r, "active", u->active);
    reply_kvi(r, "started", (long long)u->started);
    reply_kv(r, "bot_ver", u->target_ver);
    if (u->hub_ver[0]) reply_kv(r, "hub_ver", u->hub_ver);
    reply_kvi(r, "selective", u->select_count);
    if (u->summary[0]) reply_kv(r, "summary", u->summary);
  }
  reply_kvb(r, "frozen", hub_config_frozen(state));
  if (state->uhist_count) reply_kvi(r, "keep", hub_uhist_keep(state));
  /* The roll-ups are outside history, so what each node's last one did is here. */
  for (int i = 0; i < state->rollup_try_count; i++) {
    const rollup_try_t *t = &state->rollup_tries[i];
    if (!t->note[0]) continue;
    reply_rec(r, "rolled");
    reply_kv(r, "uuid", t->uuid);
    reply_kv(r, "name", hub_who(state, 0, t->uuid));
    reply_kv(r, "step", t->step);
    reply_kvi(r, "tries", t->tries);
    reply_kvi(r, "when", (long long)t->last_try);
    reply_kv(r, "note", t->note);
  }
  /* The roll-up plan this hub holds, if any: what a bot that comes back is
   * walked up to, until an admin's "forget" drops it. */
  const pending_rollup_t *ru = &state->rollup;
  if (ru->have_plan) {
    reply_rec(r, "rollup");
    reply_kv(r, "bot_ver", ru->target);
    if (ru->hub_target[0]) reply_kv(r, "hub_ver", ru->hub_target);
    reply_kvi(r, "set", (long long)ru->plan_set);
    reply_kvi(r, "expires", (long long)(ru->plan_set + ROLLUP_PLAN_TTL));
  }
  /* A multi-step upgrade: the whole path, where it is, and — once it has
   * stopped — why (kept until this hub restarts). */
  const upgrade_plan_t *pl = &state->plan;
  /* Not this hub's to drive: what its driver last said, or why it stopped. */
  const upgrade_plan_t *sp = &state->splan;
  if (!pl->active && !sp->single && (sp->active || sp->summary[0]) && sp->started >= pl->started)
    pl = sp;
  if (pl->active || pl->summary[0]) {
    char path[MAX_UPGRADE_STEPS * 65];
    reply_rec(r, "plan");
    reply_kvb(r, "active", pl->active);
    if (pl->driver[0]) {
      reply_kv(r, "driver", pl->driver);
      if (strcmp(pl->driver, state->hub_uuid) != 0) {
        reply_kv(r, "driver_name", hub_who(state, 'h', pl->driver));
        reply_kvi(r, "heard", (long long)state->splan_seen);
      }
    }
    if (pl->hold[0]) reply_kv(r, "hold", pl->hold);
    reply_kvi(r, "step", pl->step + 1);
    reply_kvi(r, "steps", plan_steps(pl));
    reply_kv(r, "bot_final", pl->bot_target);
    if (pl->bot_from[0]) reply_kv(r, "bot_from", pl->bot_from);
    plan_path_csv(&pl->bot_path[0][0], pl->bot_steps, path, sizeof(path));
    if (path[0]) reply_kv(r, "bot_path", path);
    if (pl->hub_target[0]) {
      reply_kv(r, "hub_final", pl->hub_target);
      if (pl->hub_from[0]) reply_kv(r, "hub_from", pl->hub_from);
      plan_path_csv(&pl->hub_path[0][0], pl->hub_steps, path, sizeof(path));
      if (path[0]) reply_kv(r, "hub_path", path);
    }
    if (pl->active) {
      reply_kv(r, "state", pl->hold[0] ? "held" : pl->run_id[0] ? "running" : "waiting");
      if (!pl->run_id[0] && pl->next_at > 0) reply_kvi(r, "next", (long long)pl->next_at);
    }
    reply_kvi(r, "started", (long long)pl->started);
    if (pl->summary[0]) reply_kv(r, "summary", pl->summary);
  }
  for (int i = 0; u->id[0] && i < u->node_count; i++) {
    const upgrade_node_t *n = &u->nodes[i];
    reply_rec(r, "node");
    reply_kv(r, "kind", n->kind == 'b' ? "bot" : n->kind == 'h' ? "hub" : "self");
    reply_kv(r, "uuid", n->uuid);
    /* a bot node has no label of its own: its nick from the config */
    char nick[MAX_NICK] = "";
    if (!n->name[0] && n->kind == 'b') bot_nick_from_config(state, n->uuid, nick, sizeof(nick));
    if (n->name[0] || nick[0]) reply_kv(r, "name", n->name[0] ? n->name : nick);
    reply_kv(r, "state", n->not_selected ? "skipped" : upgrade_node_state_name(n->state));
    if (n->cur_version[0]) reply_kv(r, "from", n->cur_version);
    const char *to = n->kind == 'b' ? u->target_ver : u->hub_ver;
    if (to[0]) reply_kv(r, "to", to);
    if (n->variant[0]) reply_kv(r, "base", n->variant);
    /* the build it is being moved onto, when that is the other one */
    const char *want = upgrade_node_variant(u, n);
    if (want[0] && strcmp(want, n->variant) != 0) reply_kv(r, "want", want);
    if (n->reason[0]) reply_kv(r, "reason", n->reason);
    if (n->stage_code[0]) reply_kv(r, "code", n->stage_code);
    if (n->cls) {
      char cl[2] = {n->cls, 0};
      reply_kv(r, "class", cl);
    }
    /* Where it is in the run, and for how long. */
    time_t now = time(NULL);
    if (n->state == UPG_NODE_READY && n->can_stage && u->active) {
      reply_kv(r, "phase", n->staged ? "staged" : n->stage_phase[0] ? n->stage_phase : "staging");
      if (!n->staged && n->stage_pct[0]) {
        reply_kv(r, "pct", n->stage_pct);
        if (n->stage_detail[0]) reply_kv(r, "detail", n->stage_detail);
      }
      if (n->stage_sent)
        reply_kvi(r, "secs", (long long)((n->staged_at ? n->staged_at : now) - n->stage_sent));
    } else if (n->left) {
      reply_kv(r, "phase", "left");
    } else if (n->committed_at) {
      reply_kvi(r, "secs", (long long)((n->back_at ? n->back_at : n->done_at ? n->done_at : now) -
                                       n->committed_at));
    }
    /* idle: a hub a bots-only run never moves (it only relays the run to its
     * bots).  already: a node that declined because it already runs the
     * target build -- a no-op, not a failure. */
    if (n->kind != 'b' && !u->hub_ver[0] &&
        (n->not_selected || n->state == UPG_NODE_UNABLE))
      reply_kvb(r, "idle", true);
    else if (!n->not_selected && n->state == UPG_NODE_UNABLE && to[0] && n->cur_version[0] &&
             hub_update_version_cmp(n->cur_version, to) == 0 &&
             (!want[0] || strcmp(want, n->variant) == 0))
      reply_kvb(r, "already", true);
  }
  /* The kept runs, under the current one (view 4 and `upgrade status`). */
  hub_uhist_reply_runs(state, r);
}

/* CMD_ADMIN_UPGRADE_STATUS "releases[|bot_ver|hub_ver|sel]": everything the
 * admin console needs to offer choices instead of free text:
 *   ok|upg.releases
 *   rel|product|ver|date|bases           newest first, per product
 *   relerr|product|base|msg              a tree that could not be read
 *   node|kind|uuid|name|ver|base         the nodes a selective run can name
 *   path|product|from|steps|err          the path `upgrade start` would take
 * Manifests are signature-verified exactly as an upgrade would read them;
 * an unverifiable tree lists nothing. */
static void hub_upgrade_releases(hub_state_t *state, const char *payload,
                                 reply_t *r) {
  reply_ok(r, "upg.releases");
  static const char *variants[] = {"c", "rs"};
  for (int prod = 0; prod < 2; prod++) {
    const char *pname = prod == 0 ? "bot" : "hub";
    /* NULL = this hub's own root */
    const char *root = prod == 0 ? hub_update_bot_root() : NULL;
    hub_release_t merged[MAX_UPGRADE_RELEASES];
    char have[MAX_UPGRADE_RELEASES][8];
    int nm = 0;
    for (int v = 0; v < 2; v++) {
      hub_release_t rel[MAX_UPGRADE_RELEASES];
      const char *err = NULL;
      int n = hub_update_list_releases(root, variants[v], rel, MAX_UPGRADE_RELEASES, &err);
      if (n < 0) {
        reply_rec(r, "relerr");
        reply_kv(r, "product", pname);
        reply_kv(r, "base", variants[v]);
        reply_kv(r, "msg", err ? err : "unreadable");
        continue;
      }
      for (int k = 0; k < n; k++) {
        int at = -1;
        for (int m = 0; m < nm && at < 0; m++)
          if (hub_update_version_cmp(merged[m].version, rel[k].version) == 0) at = m;
        if (at < 0) {
          if (nm >= MAX_UPGRADE_RELEASES) continue;
          at = nm++;
          merged[at] = rel[k];
          have[at][0] = '\0';
        }
        size_t hl = strlen(have[at]);
        snprintf(have[at] + hl, sizeof(have[at]) - hl, "%s%s", hl ? "," : "",
                 variants[v]);
      }
    }
    /* Newest first across both trees. */
    for (int a = 1; a < nm; a++) {
      hub_release_t t = merged[a];
      char th[8];
      memcpy(th, have[a], sizeof(th));
      int b = a - 1;
      while (b >= 0 && hub_update_version_cmp(merged[b].version, t.version) < 0) {
        merged[b + 1] = merged[b];
        memcpy(have[b + 1], have[b], sizeof(th));
        b--;
      }
      merged[b + 1] = t;
      memcpy(have[b + 1], th, sizeof(th));
    }
    for (int m = 0; m < nm; m++) {
      reply_rec(r, "rel");
      reply_kv(r, "product", pname);
      reply_kv(r, "ver", merged[m].version);
      if (merged[m].date[0]) reply_kv(r, "date", merged[m].date);
      reply_kv(r, "bases", have[m]);
    }
  }

  /* The nodes a selective run could name, as this hub sees them now. */
  reply_rec(r, "node");
  reply_kv(r, "kind", "self");
  reply_kv(r, "uuid", state->hub_uuid);
  reply_kv(r, "name", hub_display_name(state));
  reply_kv(r, "ver", HUB_VERSION);
  reply_kv(r, "base", hub_update_host_variant());
  for (int i = 0; i < state->mesh_hub_count; i++) {
    const mesh_hub_t *m = &state->mesh_hubs[i];
    if (!m->uuid[0] || strcmp(m->uuid, state->hub_uuid) == 0) continue;
    reply_rec(r, "node");
    reply_kv(r, "kind", "hub");
    reply_kv(r, "uuid", m->uuid);
    if (m->name[0]) reply_kv(r, "name", m->name);
    if (m->version[0]) reply_kv(r, "ver", m->version);
    if (m->variant[0]) reply_kv(r, "base", m->variant);
  }
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type != CLIENT_BOT || !c->authenticated) continue;
    char nick[64] = "";
    hub_bot_entry(state, c->id, "n", nick, sizeof(nick));
    reply_rec(r, "node");
    reply_kv(r, "kind", "bot");
    reply_kv(r, "uuid", c->id);
    if (nick[0]) reply_kv(r, "name", nick);
    if (c->bot_version[0]) reply_kv(r, "ver", c->bot_version);
    if (c->bot_variant[0]) reply_kv(r, "base", c->bot_variant);
  }
  for (int i = 0; i < state->roster_count; i++) {
    const bot_roster_t *e = &state->roster[i];
    if (strcmp(e->hub_uuid, state->hub_uuid) == 0) continue;
    if (upgrade_find_client(state, e->bot_uuid, CLIENT_BOT)) continue;
    bool dup = false;
    for (int k = 0; k < i && !dup; k++)
      dup = strcmp(state->roster[k].bot_uuid, e->bot_uuid) == 0;
    if (dup) continue;
    reply_rec(r, "node");
    reply_kv(r, "kind", "bot");
    reply_kv(r, "uuid", e->bot_uuid);
    if (e->nick[0]) reply_kv(r, "name", e->nick);
    if (e->version[0]) reply_kv(r, "ver", e->version);
    if (e->variant[0]) reply_kv(r, "base", e->variant);
  }
  upgrade_plan_preview(state, payload, r);
}

/* A local bot's CMD_UPGRADE_READY/RESULT.  If this hub is following a run
 * another hub drives and the frame belongs to it, the bot is a node of that
 * run reached through us — forward the frame up to the driver unchanged so it
 * records the bot as a remote node.  Otherwise it belongs to a run this hub
 * drives itself (or none), and is noted locally. */
static void hub_upgrade_bot_report(hub_state_t *state, hub_client_t *client,
                                   int cmd, const char *payload) {
  char id[64] = "", uuid[64] = "";
  wire_field(payload, 0, id, sizeof(id));
  wire_field(payload, 1, uuid, sizeof(uuid));
  /* A bot reports for itself only: READY, PROGRESS and RESULT all carry the
   * sender's uuid in field 1, so anything else is refused before it is
   * forwarded or noted. */
  if (strcmp(uuid, client->id) != 0) {
    hub_log_warning("[UPGRADE] %s sent an upgrade report for another node: dropped\n",
                    hub_who_client(state, client));
    return;
  }
  if (state->follow_id[0] && id[0] && strcmp(state->follow_id, id) == 0) {
    hub_client_t *origin = upgrade_find_peer(state, state->follow_origin);
    if (origin) {
      peer_send_urgent(state, origin, (uint8_t)cmd, payload);
      return;
    }
    /* Driver gone: fall through and note it locally so nothing is lost. */
  }
  if (cmd == CMD_UPGRADE_READY) {
    hub_upgrade_note_ready(state, payload, NULL);
    return;
  }
  if (cmd == CMD_UPGRADE_PROGRESS) {
    hub_upgrade_note_progress(state, payload);
    return;
  }
  /* Once per link: a bot sends one RESULT after a restart, so one relay per
   * link bounds what it can make the mesh carry. */
  if (!client->result_relayed && hub_upgrade_result_relay(state, NULL, payload))
    client->result_relayed = true;
  hub_upgrade_note_result(state, payload);
}

/* ---- Sealed bot-to-bot relay (CMD_BOT_RELAY / CMD_BOT_RELAY_FWD) ------- */

/* The authenticated local bot with this uuid, or NULL. */
static hub_client_t *bot_relay_local_target(hub_state_t *state,
                                            const char *uuid) {
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type == CLIENT_BOT && c->authenticated && !c->superseded &&
        strcmp(c->id, uuid) == 0)
      return c;
  }
  return NULL;
}

/* Hand a sealed payload to a local bot as CMD_BOT_MSG "<sender>|<sealed frame>".
 * The sender is the uuid the originating hub authenticated, which is what the
 * bot binds the GCM AAD to. */
static bool bot_relay_deliver(hub_client_t *target, const char *sender_uuid,
                              const char *sealed) {
  char forwarded[MAX_BUFFER];
  int len = snprintf(forwarded, sizeof(forwarded), "%s|%s", sender_uuid,
                     sealed);
  if (len <= 0 || len + 5 > MAX_BUFFER) {
    hub_log_warning("[HUB] CMD_BOT_RELAY: forwarded payload too long\n");
    return false;
  }
  if (!send_cmd_to_bot(g_state, target, CMD_BOT_MSG, forwarded)) {
    hub_log_warning("[HUB] CMD_BOT_RELAY: write to %s failed\n", hub_who_client(g_state, target));
    return false;
  }
  hub_log_debug("[HUB] CMD_BOT_RELAY: forwarded to %s (%d bytes)\n",
          hub_who_client(g_state, target), len);
  return true;
}

/* Flood one relay to every authenticated peer except `exclude_fd`.  Returns
 * how many peers took it. */
static int bot_relay_forward(hub_state_t *state, const char *request_id,
                             long long origin_ts, const char *sender_uuid,
                             const char *target_uuid, const char *sealed,
                             int exclude_fd) {
  char *fwd = malloc(MAX_BUFFER);
  if (!fwd) return 0;
  int len = snprintf(fwd, MAX_BUFFER, "%s|%lld|%s|%s|%s", request_id,
                     origin_ts, sender_uuid, target_uuid, sealed);
  int sent = 0;
  if (len > 0 && len + 5 <= MAX_BUFFER) {
    for (int i = 0; i < state->client_count; i++) {
      hub_client_t *c = state->clients[i];
      if (c->type != CLIENT_HUB || !c->authenticated || c->fd == exclude_fd)
        continue;
      /* DELTA, not URGENT: a full lane drops the oldest relay, while a full
       * URGENT lane would take the peer link down with it. */
      queued_msg_t *m = queued_msg_new(CMD_BOT_RELAY_FWD, LANE_DELTA,
                                       (const unsigned char *)fwd, len);
      if (m && peer_enqueue(c, m)) sent++;
      peer_drain_writable(state, c);
    }
  } else {
    hub_log_warning("[HUB] CMD_BOT_RELAY: too long to forward to peers\n");
  }
  free(fwd);
  return sent;
}

/* A uuid a peer names in a forwarded relay: plain id characters only, so it
 * cannot smuggle a separator or a control byte into a bot frame or a log. */
static bool bot_relay_id_ok(const char *s) {
  if (!s || !s[0]) return false;
  for (; *s; s++)
    if (!isalnum((unsigned char)*s) && *s != '-' && *s != '_' && *s != '.')
      return false;
  return true;
}

/* CMD_BOT_RELAY_FWD from a peer: deliver it if the target is ours, else pass
 * it on.  Payload: id|origin_ts|sender_uuid|target_uuid|<sealed frame> */
static void process_peer_bot_relay(hub_state_t *state, hub_client_t *peer,
                                   const char *payload) {
  char id[64] = "", ts[24] = "", sender[64] = "", target[64] = "";
  if (!wire_field(payload, 0, id, sizeof(id)) ||
      !wire_field(payload, 1, ts, sizeof(ts)) ||
      !wire_field(payload, 2, sender, sizeof(sender)) ||
      !wire_field(payload, 3, target, sizeof(target)) ||
      !bot_relay_id_ok(id) || !bot_relay_id_ok(sender) ||
      !bot_relay_id_ok(target)) {
    hub_log_warning("[HUB] Invalid BOT_RELAY_FWD payload from peer %s\n", peer->ip);
    return;
  }
  /* The sealed blob is everything after the 4th '|'. */
  const char *sealed = payload;
  for (int n = 0; n < 4 && sealed; n++) {
    sealed = strchr(sealed, '|');
    if (sealed) sealed++;
  }
  /* Opaque to the hub (bots send "~B2 <b64>"): only require a non-empty
   * blob with no control bytes, so it cannot break a bot frame or a log. */
  bool blob_ok = sealed && *sealed;
  for (const unsigned char *b = (const unsigned char *)sealed; blob_ok && *b; b++)
    if (*b < 0x20 || *b == 0x7f) blob_ok = false;
  if (!blob_ok) {
    hub_log_warning("[HUB] BOT_RELAY_FWD without a sealed payload from peer %s\n",
            peer->ip);
    return;
  }
  long long origin_ts = atoll(ts);
  /* age only for a positive stamp: atoll saturates, and now - LLONG_MIN
   * overflows */
  long long age = origin_ts > 0 ? (long long)time(NULL) - origin_ts : 0;
  if (origin_ts <= 0 || age > BOT_RELAY_FWD_TTL || age < -BOT_RELAY_FWD_TTL) {
    hub_log_debug("[HUB] Dropping stale BOT_RELAY_FWD (id:%s, age=%llds)\n", id,
            age);
    return;
  }
  if (op_forward_seen_check_and_add(state, id)) return; /* around a cycle */

  hub_client_t *t = bot_relay_local_target(state, target);
  if (t) {
    hub_log_debug("[HUB] BOT_RELAY_FWD %s: %s -> local bot %s\n", id, sender, target);
    bot_relay_deliver(t, sender, sealed);
    return;
  }
  int sent = bot_relay_forward(state, id, origin_ts, sender, target, sealed,
                               peer->fd);
  hub_log_debug("[HUB] BOT_RELAY_FWD %s for %s passed on to %d peer(s)\n", id,
          target, sent);
}

/* ---- Activity (CMD_ACTIVITY / CMD_ACTIVITY_QUERY) ----------------------- */

/* A user uuid as the config stores it: 36 chars, hex and dashes. */
static bool activity_uuid_ok(const char *s) {
  if (!s || strlen(s) != 36) return false;
  for (int i = 0; i < 36; i++) {
    bool dash = (i == 8 || i == 13 || i == 18 || i == 23);
    if (dash ? s[i] != '-' : !isxdigit((unsigned char)s[i])) return false;
  }
  return true;
}

static hub_user_record_t *activity_user(hub_state_t *state, const char *uuid) {
  for (int i = 0; i < state->user_record_count; i++)
    if (strcmp(state->user_records[i].uuid, uuid) == 0)
      return &state->user_records[i];
  return NULL;
}

static hub_mask_record_t *activity_mask(hub_state_t *state, const char *uuid,
                                        const char *mask) {
  for (int i = 0; i < state->mask_record_count; i++)
    if (strcmp(state->mask_records[i].uuid, uuid) == 0 &&
        strcasecmp(state->mask_records[i].mask, mask) == 0)
      return &state->mask_records[i];
  return NULL;
}

/* Send CMD_ACTIVITY lines to every authenticated peer except exclude_fd. */
static void activity_flood(hub_state_t *state, const char *lines, int len,
                           int exclude_fd) {
  if (len <= 0) return;
  for (int i = 0; i < state->client_count; i++) {
    hub_client_t *c = state->clients[i];
    if (c->type != CLIENT_HUB || !c->authenticated || c->fd == exclude_fd)
      continue;
    queued_msg_t *m = queued_msg_new(CMD_ACTIVITY, LANE_DELTA,
                                     (const unsigned char *)lines, len);
    if (!m) continue;
    if (!peer_enqueue(c, m))
      hub_log_warning("[ACTIVITY] enqueue failed for peer %s\n", c->ip);
  }
}

/* A console login: stamp the admin's exact time; the first login in an
 * ACTIVITY_BUCKET is flooded to the peers.  Never a config change. */
static void hub_activity_stamp_user(hub_state_t *state, hub_user_record_t *u,
                                    time_t now) {
  if (!u || now <= u->last_seen) return;
  bool new_bucket = u->last_seen / ACTIVITY_BUCKET < now / ACTIVITY_BUCKET;
  u->last_seen = now;
  state->config_dirty = true;
  hub_log_debug("[ACTIVITY] %s last seen %lld%s\n", u->name, (long long)now,
                new_bucket ? " (first this hour: sent to peers)" : "");
  if (!new_bucket) return;
  char line[80];
  int len = snprintf(line, sizeof(line), "a|%s|%lld\n", u->uuid,
                     (long long)now);
  if (len > 0 && len < (int)sizeof(line))
    activity_flood(state, line, len, -1);
}

/* CMD_ACTIVITY from a bot (from = the bot) or a peer (from = the peer).
 * Every line is validated on its own; a bad or unknown one is dropped.
 * Lines that raised our value go on to the other peers. */
static void process_activity(hub_state_t *state, hub_client_t *from,
                             const char *payload) {
  char *fwd = malloc(MAX_BUFFER);
  char *buf = strdup(payload ? payload : "");
  if (!fwd || !buf) {
    free(fwd);
    free(buf);
    return;
  }
  int fwd_len = 0, raised = 0, lines = 0;
  long long now = (long long)time(NULL);
  char *save = NULL;
  for (char *line = strtok_r(buf, "\n", &save); line;
       line = strtok_r(NULL, "\n", &save)) {
    if (++lines > MAX_HUB_USER_RECORDS + MAX_HUB_USER_MASKS + MAX_BANS_TOTAL) break;
    /* a|uuid|ts or m|uuid|mask|ts.  The time is always the last field, so
     * a mask may hold a '|' of its own.  B|chan|mask|ts: a ban mask never
     * holds one (it is a field of the B| record). */
    char uuid[40] = "", mask[MAX_MASK_LEN] = "";
    char bchan[MAX_CHAN] = "", bmask[BAN_MASK_MAX + 1] = "";
    bool is_mask = line[0] == 'm', is_ban = line[0] == 'B';
    const char *last = strrchr(line, '|');
    size_t mask_len = 0;
    bool ok = is_ban ? line[1] == '|' && wire_field(line, 1, bchan, sizeof(bchan)) &&
                           bchan[0] && wire_field(line, 2, bmask, sizeof(bmask)) &&
                           bmask[0] && last == line + 2 + strlen(bchan) + 1 + strlen(bmask)
                     : (line[0] == 'a' || is_mask) && line[1] == '|' &&
                           wire_field(line, 1, uuid, sizeof(uuid)) && activity_uuid_ok(uuid);
    if (is_ban) {
      /* checked above */
    } else if (ok && is_mask) {
      const char *mstart = line + 2 + 36 + 1;
      ok = last > mstart && mstart[-1] == '|';
      mask_len = ok ? (size_t)(last - mstart) : 0;
      if (ok && mask_len < sizeof(mask)) {
        memcpy(mask, mstart, mask_len);
        mask[mask_len] = '\0';
      } else {
        ok = false;
      }
    } else if (ok) {
      ok = last == line + 2 + 36;
    }
    if (!ok) {
      hub_log_debug("[ACTIVITY] malformed line from %s\n", hub_who_client(state, from));
      continue;
    }
    char *end = NULL;
    long long ts = strtoll(last + 1, &end, 10);
    if (!end || *end != '\0' || ts <= 0 || ts > now + ACTIVITY_MAX_FUTURE) {
      hub_log_debug("[ACTIVITY] bad time from %s\n", hub_who_client(state, from));
      continue;
    }
    time_t *slot = NULL;
    if (is_ban) {
      slot = hub_ban_used_slot(state, bchan, bmask);
    } else if (is_mask) {
      hub_mask_record_t *m = activity_mask(state, uuid, mask);
      if (m) slot = &m->last_used;
    } else {
      hub_user_record_t *u = activity_user(state, uuid);
      if (u) slot = &u->last_seen;
    }
    if (!slot || (long long)*slot >= ts) continue; /* unknown or not newer */
    *slot = (time_t)ts;
    raised++;
    int w = is_ban    ? snprintf(fwd + fwd_len, (size_t)(MAX_BUFFER - fwd_len),
                                 "B|%s|%s|%lld\n", bchan, bmask, ts)
            : is_mask ? snprintf(fwd + fwd_len, (size_t)(MAX_BUFFER - fwd_len),
                                 "m|%s|%s|%lld\n", uuid, mask, ts)
                      : snprintf(fwd + fwd_len, (size_t)(MAX_BUFFER - fwd_len), "a|%s|%lld\n",
                                 uuid, ts);
    if (w > 0 && w < MAX_BUFFER - fwd_len - 5) fwd_len += w;
  }
  if (raised) {
    state->config_dirty = true;
    hub_log_debug("[ACTIVITY] %d record(s) raised by %s\n", raised, hub_who_client(state, from));
    activity_flood(state, fwd, fwd_len,
                   from->type == CLIENT_HUB ? from->fd : -1);
  }
  free(buf);
  free(fwd);
}

void hub_activity_send_bans(hub_state_t *state, hub_client_t *peer) {
  if (!peer || peer->type != CLIENT_HUB || !peer->authenticated) return;
  const int cap = MAX_BUFFER - 64;
  char *buf = malloc((size_t)cap);
  if (!buf) return;
  int len = 0, lines = 0;
  for (int i = 0; i <= state->global_entry_count; i++) {
    char line[MAX_CHAN + BAN_MASK_MAX + 32];
    int w = 0;
    if (i < state->global_entry_count) {
      const config_entry_t *e = &state->global_entries[i];
      char chan[MAX_CHAN], mask[BAN_MASK_MAX + 1];
      if (strcmp(e->key, "B") == 0 && e->last_used > 0 &&
          hub_global_value_active(e->value) && wire_field(e->value, 0, chan, sizeof(chan)) &&
          wire_field(e->value, 1, mask, sizeof(mask)))
        w = snprintf(line, sizeof(line), "B|%s|%s|%lld\n", chan, mask,
                     (long long)e->last_used);
      if (w < 0 || w >= (int)sizeof(line)) w = 0;
    }
    if (len > 0 && (i == state->global_entry_count || len + w > cap)) {
      queued_msg_t *m = queued_msg_new(CMD_ACTIVITY, LANE_BULK, (const unsigned char *)buf, len);
      if (!m || !peer_enqueue(peer, m)) {
        hub_log_warning("[ACTIVITY] ban last-use enqueue failed for peer %s\n", peer->ip);
        break;
      }
      len = 0;
    }
    if (w > 0) {
      memcpy(buf + len, line, (size_t)w);
      len += w;
      lines++;
    }
  }
  if (lines) hub_log_debug("[ACTIVITY] %d ban last-use line(s) sent to %s\n", lines,
                           hub_who_client(state, peer));
  free(buf);
}

/* Queue one CMD_ACTIVITY_REPLY chunk to a bot. */
static void activity_reply_send(hub_client_t *bot, const char *frame, int len) {
  queued_msg_t *m = queued_msg_new(CMD_ACTIVITY_REPLY, LANE_DELTA,
                                   (const unsigned char *)frame, len);
  if (!m) return;
  if (!peer_enqueue(bot, m))
    hub_log_warning("[ACTIVITY] reply enqueue failed for %s\n", hub_who_client(g_state, bot));
}

/* CMD_ACTIVITY_QUERY from a bot: <req_id>|users or <req_id>|masks|<uuid|*>.
 * Answers every known time (records at 0 are left out), chunked. */
static void process_activity_query(hub_state_t *state, hub_client_t *bot,
                                   const char *payload) {
  char req[ACTIVITY_REQ_ID_MAX + 1] = "", kind[8] = "", who[40] = "";
  if (!wire_field(payload, 0, req, sizeof(req)) || !bot_relay_id_ok(req) ||
      !wire_field(payload, 1, kind, sizeof(kind))) {
    hub_log_warning("[ACTIVITY] invalid query from %s\n", hub_who_client(state, bot));
    return;
  }
  bool masks = strcmp(kind, "masks") == 0;
  if (!masks && strcmp(kind, "users") != 0) {
    hub_log_warning("[ACTIVITY] unknown query kind from %s\n", hub_who_client(state, bot));
    return;
  }
  if (masks && (!wire_field(payload, 2, who, sizeof(who)) ||
                (strcmp(who, "*") != 0 && !activity_uuid_ok(who)))) {
    hub_log_warning("[ACTIVITY] invalid masks query from %s\n", hub_who_client(state, bot));
    return;
  }
  bool all = !masks || strcmp(who, "*") == 0;

  /* Frame budget: header + the longest line must always fit. */
  const int cap = MAX_BUFFER - 64;
  char *frame = malloc((size_t)cap);
  if (!frame) return;
  int hdr = snprintf(frame, (size_t)cap, "%s|1\n", req);
  int len = hdr;
  for (int pass = 0; pass < (masks ? 2 : 1); pass++) {
    int n = pass == 0 ? state->user_record_count : state->mask_record_count;
    for (int i = 0; i < n; i++) {
      char line[MAX_MASK_LEN + 96];
      int w = 0;
      if (pass == 0) {
        const hub_user_record_t *u = &state->user_records[i];
        if (u->last_seen <= 0 || (!all && strcmp(u->uuid, who) != 0)) continue;
        w = snprintf(line, sizeof(line), "a|%s|%lld\n", u->uuid,
                     (long long)u->last_seen);
      } else {
        const hub_mask_record_t *m = &state->mask_records[i];
        if (m->last_used <= 0 || (!all && strcmp(m->uuid, who) != 0)) continue;
        w = snprintf(line, sizeof(line), "m|%s|%s|%lld\n", m->uuid, m->mask,
                     (long long)m->last_used);
      }
      if (w <= 0 || w >= (int)sizeof(line)) continue;
      if (len + w > cap) {
        activity_reply_send(bot, frame, len);
        len = hdr;
      }
      memcpy(frame + len, line, (size_t)w);
      len += w;
    }
  }
  /* Last chunk: more=0. */
  frame[hdr - 2] = '0';
  activity_reply_send(bot, frame, len);
  free(frame);
}

static void process_bot_command(hub_state_t *state, hub_client_t *client,
                                int cmd, char *payload) {
  switch (cmd) {
  case CMD_PING:
    if (!HIDEPINGPONG)
      hub_log_debug("[HUB] %s PING\n", hub_who_client(state, client));
    break;

  case CMD_BOT_PRESENCE:
    process_bot_presence(state, client, payload);
    break;

  case CMD_SERVER_REPORT:
    hub_pool_server_report(state, client, payload);
    break;

  case CMD_BOT_IRC_LINK:
    if (hub_pool_irc_link(state, client, payload)) {
      hub_roster_mark_dirty(state, true);
      hub_presence_event(state);
    }
    break;

  case CMD_BOT_CHAN_STATE:
    if (hub_bot_chan_state(state, client, payload)) {
      hub_roster_mark_dirty(state, true);
      hub_presence_event(state);
    } else if (!hub_chan_state_ok(payload)) {
      hub_log_debug("[HUB] Malformed channel state from %s dropped\n", hub_who_client(state, client));
    }
    break;

  case CMD_BOT_TREE_PULL:
    /* Phase 5: the bot's tree diverged from a delta — send it the whole one. */
    hub_tree_pull(state, client);
    break;

  case CMD_ACTIVITY:
    process_activity(state, client, payload);
    break;

  case CMD_ACTIVITY_QUERY:
    process_activity_query(state, client, payload);
    break;

  case CMD_UPGRADE_READY:
    hub_upgrade_bot_report(state, client, CMD_UPGRADE_READY, payload);
    break;

  case CMD_UPGRADE_RESULT:
    hub_upgrade_bot_report(state, client, CMD_UPGRADE_RESULT, payload);
    break;

  case CMD_UPGRADE_PROGRESS:
    hub_upgrade_bot_report(state, client, CMD_UPGRADE_PROGRESS, payload);
    break;

  case CMD_CONFIG_PUSH: {
    process_bot_config_push(state, client, payload);
  } break;

  case CMD_CONFIG_PULL:
    /* A delta did not apply, or the keepalive's c| did not match what the bot
     * holds: a full push.  A burst collapses into the one queued frame. */
    hub_log_debug("[HUB] Config PULL request from %s\n", hub_who_client(state, client));
    g_hub_stats.cfg_pull++;
    send_config_to_bot(state, client, true);
    break;

  case CMD_BOT_DELTA: {
    /* Payload: key|value|ts
     * Update one entry for this bot and forward a single DELTA to each peer
     * with Lamport seq and coalesce key — replaces the old full-config push
     * for single-field changes (hostmask, nick, etc.).
     * Wire format forwarded to peers: b|<bot_uuid>|<key>|<value>|<ts>
     * with two trailing fields |<origin_hub_uuid>|<lamport_seq> for the
     * seen-set. We compose that into the payload for CMD_PEER_SYNC DELTA. */
    char key[32], val[1024];
    long long ts = 0; /* "key|val" with no stamp means now */
    client->cfg_sent_valid = false; /* as for CMD_CONFIG_PUSH */
    if (sscanf(payload, "%31[^|]|%1023[^|]|%lld", key, val, &ts) < 2) {
      hub_log_warning("[HUB] Invalid CMD_BOT_DELTA from %s — ignoring\n",
                      hub_who_client(state, client));
      break;
    }
    if (ts == 0) ts = (long long)time(NULL);

    /* Change 3 — opt 'h' (OPT_HUB_ONLY_MUTATIONS): the delta path bypasses the
     * reject-list that process_bot_config_push enforces, letting a compromised
     * bot mutate hub-authoritative records (a/o/m/c/p) that hub_storage routes
     * to global storage.  Apply the same guard here so the flag is binding on
     * every bot-write path. */
    if ((strchr(state->opt_flags, OPT_HUB_ONLY_MUTATIONS) != NULL) &&
        (strcmp(key, "a") == 0 || strcmp(key, "o") == 0 ||
         strcmp(key, "m") == 0 || strcmp(key, "c") == 0 ||
         strcmp(key, "p") == 0)) {
      hub_log_warning("[HUB] opt 'h' active: REJECTED bot delta '%s' from %s "
              "(hub-authoritative)\n", key, hub_who_client(state, client));
      break;
    }

    /* Task 6 — opt 'F' (OPT_CONFIG_FROZEN): while an upgrade run is open the
     * store does not move, or a node that restarts mid-roll comes back
     * against a config its neighbours have not seen.  The bot's nick and
     * hostmask still move (see process_bot_config_push). */
    if (hub_config_frozen(state) && strcmp(key, "n") != 0 && strcmp(key, "h") != 0) {
      hub_log_warning("[UPGRADE] config frozen: REJECTED bot delta '%s' from %s\n",
              key, hub_who_client(state, client));
      break;
    }

    /* Change 3b's per-bot key whitelist + value caps are enforced centrally in
     * hub_storage_update_entry (the single choke point shared by this delta
     * path, process_bot_config_push, process_peer_sync, and config load), so a
     * rejected key/value simply returns "not accepted" below. */

    hub_log_debug("[HUB] BOT_DELTA from %s: key=%s val=%.40s ts=%lld\n",
            hub_who_client(state, client), key, val, ts);

    bool accepted = hub_storage_update_entry(state, client->id, key,
                                             val, "", "", (time_t)ts);
    if (!accepted) break;

    state->config_dirty = true;

    /* Build the delta line forwarded to peers.
     * Format: b|<bot_uuid>|<key>|<value>|<ts>   — the existing process_peer_sync
     * wire format, compatible with strrchr-based timestamp parsing.
     * The Lamport seq lives in the queued_msg_t coalesce metadata ONLY; it must
     * NOT be embedded in the payload content because process_peer_sync uses
     * strrchr (last pipe = timestamp) and extra trailing fields corrupt the
     * stored value. */
    uint64_t seq = hub_next_lamport_seq(state);
    char delta_line[MAX_BUFFER];
    int dlen = snprintf(delta_line, sizeof(delta_line),
                        "b|%s|%s|%s|%lld\n",
                        client->id, key, val, ts);
    if (dlen <= 0 || dlen >= (int)sizeof(delta_line)) break;

    /* Forward as a single DELTA message to every peer hub.
     * The coalesce key and Lamport seq on the queued_msg_t handle dedup. */
    char coalesce[160];
    snprintf(coalesce, sizeof(coalesce), "%s|%s|%s",
             state->hub_uuid, client->id, key);

    sync_send_to_peers(state, delta_line, -1, false, LANE_DELTA, coalesce, seq);

    /* The local bots learn the new hostmask / nick from the next coalesced
     * push (within BOT_CONFIG_PUSH_COALESCE), not one full push per delta:
     * a reconnect burst made that O(deltas x bots) frames of the same state. */
    broadcast_full_config_to_all_bots(state);
    break;
  }

  case CMD_OP_REQUEST: {
    // Payload format: target_uuid|channel
    char target_uuid[64];
    char channel[MAX_CHAN];

    if (sscanf(payload, "%63[^|]|%64s", target_uuid, channel) != 2) {
      hub_log_warning("[HUB] Invalid OP_REQUEST payload from %s\n", hub_who_client(state, client));
      break;
    }

    hub_log_info("[HUB] OP_REQUEST from %s for target %s in %s\n", hub_who_client(state, client),
            hub_who(state, 'b', target_uuid), channel);

    // Find target bot's client connection
    hub_client_t *target = NULL;
    for (int i = 0; i < state->client_count; i++) {
      if (state->clients[i]->type == CLIENT_BOT &&
          state->clients[i]->authenticated &&
          strcmp(state->clients[i]->id, target_uuid) == 0) {
        target = state->clients[i];
        break;
      }
    }

    if (!target) {
      // Target bot not connected locally - check for peer hubs
      hub_log_info("[HUB] Target %s not connected locally\n", hub_who(state, 'b', target_uuid));

      // Count connected peer hubs
      int peer_count = 0;
      for (int i = 0; i < state->client_count; i++) {
        if (state->clients[i]->type == CLIENT_HUB &&
            state->clients[i]->authenticated) {
          peer_count++;
        }
      }

      if (peer_count > 0) {
        // Resolve requester's hostmask here (home hub always has it)
        char req_hostmask[MAX_MASK_LEN] = "";
        for (int i = 0; i < state->bot_count; i++) {
          if (strcmp(state->bots[i].uuid, client->id) == 0) {
            for (int j = 0; j < state->bots[i].entry_count; j++) {
              if (strcmp(state->bots[i].entries[j].key, "h") == 0) {
                snprintf(req_hostmask, sizeof(req_hostmask), "%.*s",
                         (int)(sizeof(req_hostmask) - 1),
                         state->bots[i].entries[j].value);
                break;
              }
            }
            break;
          }
        }
        if (req_hostmask[0] == '\0') {
          hub_log_warning("[HUB] No hostmask for requester %s — cannot forward OP_REQUEST\n",
                  hub_who_client(state, client));
          peer_count = 0; // fall through to OP_FAILED
        }

        char request_id[64];
        generate_request_id(request_id, sizeof(request_id));

        if (peer_count > 0 &&
            add_pending_op_request(state, request_id, client->id, target_uuid,
                                    channel, client->fd) >= 0) {
          /* Stamp origin_ts and mark this request_id as seen on the originating
           * hub so any loop-back copy arriving from other hubs is dropped. */
          time_t op_origin_ts = time(NULL);
          op_forward_seen_check_and_add(state, request_id);
          forward_op_request_to_peers(state, request_id, client->id,
                                       target_uuid, channel, req_hostmask, -1, op_origin_ts,
                                       false);
          hub_log_info("[HUB] Forwarded OP_REQUEST (id:%s) to %d peer hub(s)\n",
                  request_id, peer_count);
        } else {
          hub_log_warning("[HUB] Failed to add pending OP request - table full\n");
          // Fall through to send OP_FAILED
          peer_count = 0;
        }
      }

      if (peer_count == 0) {
        // No peers available or table full - send OP_FAILED
        if (!send_cmd_to_bot(state, client, CMD_OP_FAILED, "Target bot not connected"))
          hub_log_warning("[HUB] Failed to send OP_FAILED response to %s\n",
                  hub_who_client(state, client));
      }
      break;
    }

    // Look up requesting bot's hostmask from storage
    char requester_hostmask[MAX_MASK_LEN] = "";
    for (int i = 0; i < state->bot_count; i++) {
      if (strcmp(state->bots[i].uuid, client->id) == 0) {
        for (int j = 0; j < state->bots[i].entry_count; j++) {
          if (strcmp(state->bots[i].entries[j].key, "h") == 0) {
            snprintf(requester_hostmask, sizeof(requester_hostmask), "%.*s",
                     (int)(sizeof(requester_hostmask) - 1),
                     state->bots[i].entries[j].value);
            break;
          }
        }
        break;
      }
    }

    if (requester_hostmask[0] == '\0') {
      hub_log_warning("[HUB] No hostmask stored for requesting %s\n",
                      hub_who_client(state, client));
      if (!send_cmd_to_bot(state, client, CMD_OP_FAILED, "Hostmask not yet stored"))
        hub_log_warning("[HUB] Failed to send OP_FAILED to %s\n", hub_who_client(state, client));
      break;
    }

    // Forward CMD_OP_GRANT to target bot
    // Payload: requester_hostmask|channel
    char grant_payload[512];
    snprintf(grant_payload, sizeof(grant_payload), "%s|%s", requester_hostmask,
             channel);

    if (send_cmd_to_bot(state, target, CMD_OP_GRANT, grant_payload))
      hub_log_info("[HUB] Forwarded OP_GRANT to %s: grant ops to %s in %s\n",
              hub_who(state, 'b', target_uuid), requester_hostmask, channel);
  } break;

  case CMD_CHAN_REQUEST:
    process_chan_request(state, client, payload);
    break;

  case CMD_USER_CHAN_REQUEST:
    process_user_chan_request(state, client, payload);
    break;

  case CMD_CHAN_REPLY:
    process_chan_reply(state, client, payload);
    break;

  case CMD_CHAN_PROBE_ACK:
    process_chan_probe_ack(state, client, payload);
    break;

  case CMD_CHAN_DONE:
    process_chan_done(state, client, payload);
    break;

  case CMD_CHAN_WHO:
    process_chan_who(state, client, payload);
    break;

  case CMD_CHAN_EVENT:
    hub_chan_event_receive(state, client, payload);
    break;

  case CMD_BOT_RELAY: {
    /* Payload: target_uuid|<sealed frame> — forward to target bot. The hub
     * KNOWS the sender's identity from the authenticated session
     * (client->id == sender bot's UUID). It prepends that UUID to the
     * forwarded CMD_BOT_MSG payload so the receiver can verify the
     * sender's GCM AAD binding. */
    char target_uuid[64];
    char *pipe = strchr(payload, '|');
    if (!pipe) {
      hub_log_warning("[HUB] Invalid CMD_BOT_RELAY payload from %s\n",
                      hub_who_client(state, client));
      break;
    }
    size_t uuid_len = (size_t)(pipe - payload);
    if (uuid_len == 0 || uuid_len >= sizeof(target_uuid)) {
      hub_log_warning("[HUB] CMD_BOT_RELAY bad UUID len from %s\n", hub_who_client(state, client));
      break;
    }
    memcpy(target_uuid, payload, uuid_len);
    target_uuid[uuid_len] = '\0';

    time_t rnow = time(NULL);
    if (client->relay_window != rnow) {
      client->relay_window = rnow;
      client->relay_count = 0;
    }
    if (++client->relay_count > BOT_RELAY_PER_SEC) {
      if (client->relay_count == BOT_RELAY_PER_SEC + 1)
        hub_log_warning("[HUB] CMD_BOT_RELAY: %s sends over %d a second — dropping the rest\n",
                        hub_who_client(state, client), BOT_RELAY_PER_SEC);
      break;
    }

    hub_log_debug("[HUB] CMD_BOT_RELAY from %s to %s\n", hub_who_client(state, client),
                  hub_who(state, 'b', target_uuid));

    hub_client_t *target = bot_relay_local_target(state, target_uuid);
    if (target) {
      bot_relay_deliver(target, client->id, pipe + 1);
      break;
    }
    /* Not one of ours: the target may be homed on any hub in the mesh, as
     * many hops out as the peer links go.  Flood it under a fresh id — but
     * only for a bot the config knows, so a bot cannot make the whole mesh
     * carry frames for uuids nobody will ever deliver. */
    bool known = false;
    for (int i = 0; i < state->bot_count && !known; i++)
      known = state->bots[i].is_active &&
              strcmp(state->bots[i].uuid, target_uuid) == 0;
    if (!known) {
      hub_log_warning("[HUB] CMD_BOT_RELAY: target %s is not a known bot\n",
              hub_who(state, 'b', target_uuid));
      break;
    }
    char request_id[64];
    generate_request_id(request_id, sizeof(request_id));
    op_forward_seen_check_and_add(state, request_id);
    int sent = bot_relay_forward(state, request_id, (long long)time(NULL),
                                 client->id, target_uuid, pipe + 1, -1);
    if (sent == 0)
      hub_log_warning("[HUB] CMD_BOT_RELAY: target %s not connected and no peer "
              "to forward to\n", hub_who(state, 'b', target_uuid));
    else
      hub_log_debug("[HUB] CMD_BOT_RELAY: %s not local — forwarded (id:%s) to "
              "%d peer(s)\n", hub_who(state, 'b', target_uuid), request_id, sent);
  } break;
  }
}

// NEW FUNCTION: Send hub's stored config back to bot
/* SHA-256 of a bot config, leaving out the pd| line: it is stamped with the
 * time it was built, and bots do not read it, so it alone never makes a push
 * worth sending.  Returns false if the digest could not be taken. */
static bool bot_config_hash(const char *payload, size_t len,
                            unsigned char out[32]) {
  const char *pd = NULL;
  if (len >= 3 && strncmp(payload, "pd|", 3) == 0) pd = payload;
  else {
    const char *hit = strstr(payload, "\npd|");
    if (hit) pd = hit + 1;
  }
  const char *after = NULL;
  if (pd) {
    const char *nl = strchr(pd, '\n');
    after = nl ? nl + 1 : payload + len;
  }
  EVP_MD_CTX *ctx = EVP_MD_CTX_new();
  unsigned int olen = 0;
  bool ok = ctx && EVP_DigestInit_ex(ctx, EVP_sha256(), NULL) == 1 &&
            EVP_DigestUpdate(ctx, payload, pd ? (size_t)(pd - payload) : len) == 1 &&
            (!pd || EVP_DigestUpdate(ctx, after,
                                     (size_t)(payload + len - after)) == 1) &&
            EVP_DigestFinal_ex(ctx, out, &olen) == 1 && olen == 32;
  EVP_MD_CTX_free(ctx);
  return ok;
}

static bool bot_takes_cfg_deltas(const hub_client_t *c) {
  return c->bot_version[0] && hub_update_version_cmp(c->bot_version, CFG_DELTA_MIN_BOT) >= 0;
}

static void cfg_hex(const unsigned char h[32], char out[CFGD_HASH_HEX + 1]) {
  static const char hx[] = "0123456789abcdef";
  for (int i = 0; i < 32; i++) {
    out[2 * i] = hx[h[i] >> 4];
    out[2 * i + 1] = hx[h[i] & 15];
  }
  out[CFGD_HASH_HEX] = '\0';
}

/* Queue this bot its config: a delta of the text it holds (S, cfg_base) when
 * it takes them, else the full text.  force=false (a broadcast) skips the
 * push when the bot was already sent this exact config and that push was not
 * lost; force=true always sends, and sends it full (the bot's first config, a
 * PULL, `bot resync`).  Plan §4.3a: the one queued frame always has base S; a
 * newer push replaces it (same coalesce key) with delta(S -> newer), and S
 * moves only when a frame is written (cfg_frame_written). */
static void send_config_to_bot(hub_state_t *state, hub_client_t *client,
                               bool force) {
  /* The first config of a link waits for the bot's version (CFG_FIRST_HOLD):
   * released by its presence or by hub_flush_bot_config. */
  if (!client->cfg_hold_done) {
    if (!client->bot_version[0]) {
      if (!client->cfg_hold_at) {
        client->cfg_hold_at = time(NULL);
        g_cfg_holds++;
      }
      return;
    }
    client->cfg_hold_done = true;
    client->cfg_hold_at = 0;
  }
  /* Change 5: heap the generation buffer — a full config can exceed MAX_BUFFER
   * at scale and is too large for the stack.  MAX_CONFIG_PAYLOAD is a hard
   * upper bound (see hub.h), so hub_generate_bot_payload never truncates. */
  char *payload = malloc(MAX_CONFIG_PAYLOAD);
  if (!payload) {
    hub_log_error("[HUB] send_config_to_bot: OOM for %s\n", hub_who_client(state, client));
    return;
  }

  // Use the new payload generator that combines Global + Bot-specific
  // and omits "b|uuid|" prefix for correct bot parsing
  hub_generate_bot_payload(state, client->id,
                           hub_bot_version_takes_pool(client->bot_version),
                           payload, MAX_CONFIG_PAYLOAD);

  int len = (int)strlen(payload);
  if (len == 0) {
    hub_log_warning("[HUB] No config to send to %s\n", hub_who_client(state, client));
    free(payload);
    return;
  }

  unsigned char hash[32];
  bool hashed = bot_config_hash(payload, (size_t)len, hash);
  if (!force && hashed && client->cfg_sent_valid &&
      memcmp(hash, client->cfg_sent_hash, sizeof(hash)) == 0) {
    g_hub_stats.cfg_same++;
    secure_wipe(payload, (size_t)len);
    free(payload);
    return;
  }

  /* The text the bot holds once this frame is written (cfg_next). */
  char *next = malloc((size_t)len);
  if (next) memcpy(next, payload, (size_t)len);

  /* A delta against S when the bot takes them and S is known. */
  char *delta = NULL;
  long dlen = -1;
  if (!force && next && client->cfg_base && bot_takes_cfg_deltas(client)) {
    unsigned char nh[32];
    unsigned int olen = 0;
    if (EVP_Digest(payload, (size_t)len, nh, &olen, EVP_sha256(), NULL) == 1 && olen == 32) {
      char bhex[CFGD_HASH_HEX + 1], nhex[CFGD_HASH_HEX + 1];
      cfg_hex(client->cfg_base_hash, bhex);
      cfg_hex(nh, nhex);
      size_t cap = (size_t)len * CFG_DELTA_MAX_PCT / 100 + CFGD_HEADER_LEN;
      delta = malloc(cap);
      if (delta)
        dlen = cfgd_diff(client->cfg_base, client->cfg_base_len, payload, (size_t)len, bhex,
                         nhex, delta, cap);
    }
  }

  hub_log_debug("[HUB-SYNC] Queueing config to %s (%d bytes%s)\n", hub_who_client(state, client),
                len, dlen > 0 ? ", as a delta" : "");

  /* Bot config push goes through the bot-client's BULK lane.  Coalesce on a
   * per-bot key so a burst of broadcast_full_config_to_all_bots calls
   * collapses to one frame per bot per drain cycle — full or delta, the
   * newer replaces the queued one whole (queued_msg_replace_payload). */
  char coalesce[160];
  snprintf(coalesce, sizeof(coalesce), "%s|cfg_data|%s",
           state->hub_uuid, client->id);

  queued_msg_t *m =
      dlen > 0 ? queued_msg_new(CMD_CONFIG_DELTA, LANE_BULK, (const unsigned char *)delta, (int)dlen)
               : queued_msg_new(CMD_CONFIG_DATA, LANE_BULK, (const unsigned char *)payload, len);
  secure_wipe(payload, (size_t)len);
  free(payload);
  if (delta) {
    secure_wipe(delta, dlen > 0 ? (size_t)dlen : 0);
    free(delta);
  }
  client->cfg_sent_valid = false;
  if (!m || !next) {
    /* Nothing queued, or no text to move S to: owe it rather than leave it. */
    if (m) queued_msg_free(m);
    if (next) {
      secure_wipe(next, (size_t)len);
      free(next);
    }
    client->cfg_owed = true;
    g_cfg_owed = true;
    return;
  }
  m->cfg_frame = true;
  queued_msg_set_coalesce(m, state->hub_uuid,
                          hub_next_lamport_seq(state), coalesce);
  /* The queued frame's result: replaces any earlier queued one's. */
  if (client->cfg_next) {
    secure_wipe(client->cfg_next, client->cfg_next_len);
    free(client->cfg_next);
  }
  client->cfg_next = next;
  client->cfg_next_len = (size_t)len;
  client->cfg_queued = true;
  client->cfg_owed = false;
  bool is_delta = dlen > 0;
  if (!peer_enqueue(client, m)) {
    /* peer_enqueue freed m; the frame never queued. */
    secure_wipe(client->cfg_next, client->cfg_next_len);
    free(client->cfg_next);
    client->cfg_next = NULL;
    client->cfg_next_len = 0;
    client->cfg_queued = false;
    g_hub_stats.cfg_lost++;
    return;
  }
  if (is_delta) {
    g_hub_stats.cfg_delta++;
    g_hub_stats.cfg_delta_bytes += (uint64_t)dlen;
    g_hub_stats.cfg_delta_of += (uint64_t)len;
  } else {
    g_hub_stats.cfg_full++;
    g_hub_stats.cfg_full_bytes += (uint64_t)len;
  }
  if (hashed) {
    memcpy(client->cfg_sent_hash, hash, sizeof(hash));
    client->cfg_sent_valid = true;
  }
}

bool hub_handle_client_data(hub_state_t *state, hub_client_t *client) {
  // Process at most 8 packets per call so the event loop stays fair across
  // connections — prevents one backlogged peer from starving bot auth.
  int packets_this_call = 0;
  while (client->recv_len - client->recv_off >= 4 && packets_this_call < 8) {
    packets_this_call++;
    uint32_t net_len;
    memcpy(&net_len, client->recv_buf + client->recv_off, 4);
    int packet_len = (int)ntohl(net_len);

    // ADDED: Enhanced bounds checking. D2: bound against the client's actual
    // buffer capacity (recv_cap), which is the small PREAUTH_BUF_SIZE until the
    // handshake completes. This turns the pre-auth buffer into a clean hard
    // limit — an oversized pre-auth frame is rejected here rather than hanging
    // until the recv loop fills and trips the overflow path.
    if (packet_len < 0 || packet_len > (client->recv_cap - 4)) {
      hub_log_warning("[HUB] Invalid packet length %d from %s (cap %d)\n", packet_len,
              client->ip, client->recv_cap);
      hub_disconnect_client(state, client);
      return false;
    }

    if (client->recv_len - client->recv_off < (4 + packet_len)) {
      return true; // Need more data
    }

    unsigned char *data = client->recv_buf + client->recv_off + 4;

    // ========================================================================
    // SSH CONSOLE (docs/console.md): plaintext op || payload from the console
    // thread, which authenticated the admin before this connection existed.
    // ========================================================================
    if (client->internal) {
      if (packet_len < 1) {
        hub_disconnect_client(state, client);
        return false;
      }
      uint8_t op = data[0];
      int plen = packet_len - 1;
      char *payload = malloc((size_t)plen + 1);
      if (!payload) {
        hub_disconnect_client(state, client);
        return false;
      }
      memcpy(payload, data + 1, (size_t)plen);
      payload[plen] = '\0';
      if (op == CMD_CONSOLE) {
        bool ok = hub_console_frame(state, client, op, payload, plen);
        secure_wipe(payload, (size_t)plen + 1);
        free(payload);
        if (!ok) {
          hub_disconnect_client(state, client);
          return false;
        }
      } else {
        /* Both return false only after they closed this client. */
        bool ok = console_admin_op(op)
                      ? handle_admin_command(state, client, op, payload, plen)
                      : send_response(state, client,
                                      "err|admin.not_allowed|msg=not an admin command");
        secure_wipe(payload, (size_t)plen + 1);
        free(payload);
        if (!ok) return false;
      }
      goto packet_consumed;
    }

    // ========================================================================
    // AUTHENTICATION PHASE
    // ========================================================================
    if (!client->authenticated) {
      // Detect packet type: Bot UUID (plaintext, 36 chars, hex+hyphens)
      // or mid-handshake bot packet (64-byte sig or eph_pub response)
      bool looks_like_uuid = false;
      if (packet_len >= 36 && packet_len <= 36) {
        looks_like_uuid = true;
        for (int i = 0; i < packet_len && looks_like_uuid; i++) {
          char c = (char)data[i];
          if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') ||
                (c >= 'A' && c <= 'F') || c == '-')) {
            looks_like_uuid = false;
          }
        }
      }

      // Route to bot auth handler (UUID or mid-handshake)
      if (looks_like_uuid || client->bot_auth_state != BOT_AUTH_IDLE) {
        if (!handle_bot_authentication(state, client, data, packet_len)) {
          hub_disconnect_client(state, client);
          return false;
        }
        goto packet_consumed;
      }

      // Sealed-box decrypt for HUB peer auth
      // Packet layout: eph_pub(32) || IV(GCM_IV_LEN) || ct(N) || tag(GCM_TAG_LEN)
      if (packet_len >= 32 + GCM_IV_LEN + GCM_TAG_LEN && packet_len <= MAX_BUFFER) {
        static const unsigned char PEER_INFO[]  = "irchub-peer-session-v1";

        unsigned char plain[MAX_BUFFER];
        unsigned char session_key[32];

        int pl = hub_seal_open(state, data, packet_len,
                               PEER_INFO, sizeof(PEER_INFO) - 1,
                               plain, sizeof(plain) - 1, session_key);

        if (pl > 0) {
          memcpy(client->session_key, session_key, 32);
          secure_wipe(session_key, 32);
          plain[pl] = 0;
          char *payload = (char *)plain;

          // v3 HUB Peer Authentication (Ed25519 signature, no password).  Any
          // other handshake (HUBv2 and older included) is refused below.
          if (strncmp(payload, "HUBv3|", 6) == 0) {
            /* Format: "HUBv3|<uuid>|<port>|<name>|<bind_ip>|<ts>|<sig_b64>" */
            char peer_uuid[64] = "", peer_name[64] = "", peer_bind_ip[64] = "";
            char ts_str[32] = "", sig_b64[128] = "";
            int claimed_port = 0;

            /* Parse pipe-separated fields without sscanf-quirks. */
            char work[MAX_BUFFER];
            snprintf(work, sizeof(work), "%s", payload + 6);
            char *sp_v2;
            char *t_uuid    = strtok_r(work,  "|", &sp_v2);
            char *t_port    = strtok_r(NULL,  "|", &sp_v2);
            char *t_name    = strtok_r(NULL,  "|", &sp_v2);
            char *t_bind    = strtok_r(NULL,  "|", &sp_v2);
            char *t_ts      = strtok_r(NULL,  "|", &sp_v2);
            char *t_sig     = strtok_r(NULL,  "|", &sp_v2);
            if (!t_uuid || !t_port || !t_name || !t_bind || !t_ts || !t_sig) {
              hub_log_warning("[HUB] v3 peer auth: malformed payload from %s\n",
                      client->ip);
              secure_wipe(plain, sizeof(plain));
              hub_disconnect_client(state, client);
              return false;
            }
            snprintf(peer_uuid,    sizeof(peer_uuid),    "%s", t_uuid);
            snprintf(peer_name,    sizeof(peer_name),    "%s", t_name);
            snprintf(peer_bind_ip, sizeof(peer_bind_ip), "%s", t_bind);
            snprintf(ts_str,       sizeof(ts_str),       "%s", t_ts);
            snprintf(sig_b64,      sizeof(sig_b64),      "%s", t_sig);
            claimed_port = atoi(t_port);

            /* Locate peer entry by UUID; require stored pubkey. */
            int peer_idx = -1;
            for (int p = 0; p < state->peer_count; p++) {
              if (state->peers[p].uuid[0] &&
                  strcmp(state->peers[p].uuid, peer_uuid) == 0) {
                peer_idx = p;
                break;
              }
            }
            if (peer_idx < 0 || !state->peers[peer_idx].has_pubkey) {
              hub_log_warning("[HUB] v3 peer auth: no pubkey on file for %s "
                      "(from %s) — add the peer with its 88-char pubkey.\n",
                      hub_who(state, 'h', peer_uuid), client->ip);
              record_failed_auth(state, client->ip);
              secure_wipe(plain, sizeof(plain));
              hub_disconnect_client(state, client);
              return false;
            }

            /* Reconstruct the transcript the sender committed to and verify. */
            char transcript[512];
            int tlen = snprintf(transcript, sizeof(transcript),
                                "irchub-peer-auth-v3|%s|%s|%d|%s|%s",
                                peer_uuid, ts_str, claimed_port,
                                peer_name, peer_bind_ip);
            if (tlen < 0 || tlen >= (int)sizeof(transcript)) {
              hub_log_error("[HUB] v3 peer auth: transcript overflow\n");
              secure_wipe(plain, sizeof(plain));
              hub_disconnect_client(state, client);
              return false;
            }

            int sig_len = 0;
            unsigned char *sig = base64_decode(sig_b64, &sig_len);
            if (!sig || sig_len != ED25519_SIG_LEN) {
              hub_log_warning("[HUB] v3 peer auth: bad signature length %d\n", sig_len);
              if (sig) { secure_wipe(sig, (size_t)sig_len); free(sig); }
              record_failed_auth(state, client->ip);
              secure_wipe(plain, sizeof(plain));
              hub_disconnect_client(state, client);
              return false;
            }

            bool sig_ok = hub_crypto_ed25519_verify(
                state->peers[peer_idx].ed_pub,
                (unsigned char *)transcript, (size_t)tlen, sig);
            secure_wipe(sig, (size_t)sig_len);
            free(sig);

            if (!sig_ok) {
              hub_log_warning("[HUB] v3 peer auth: signature verify FAILED for %s "
                      "(from %s)\n", hub_who(state, 'h', peer_uuid), client->ip);
              record_failed_auth(state, client->ip);
              secure_wipe(plain, sizeof(plain));
              hub_disconnect_client(state, client);
              return false;
            }

            /* Freshness window (±60 s). */
            time_t client_ts = (time_t)strtoll(ts_str, NULL, 10);
            time_t now_v2 = time(NULL);
            /* a negative stamp is as stale as it gets; for one >= 0 the
             * difference cannot overflow */
            long long skew = client_ts < 0 ? LLONG_MAX : (long long)(now_v2 - client_ts);
            if (llabs(skew) > 60) {
              hub_log_warning("[HUB] v3 peer auth: timestamp skew %llds (max 60) for %s\n",
                      skew, hub_who(state, 'h', peer_uuid));
              record_failed_auth(state, client->ip);
              secure_wipe(plain, sizeof(plain));
              hub_disconnect_client(state, client);
              return false;
            }
            /* Review 7b: the sealed box opens with the hello's ephemeral key
             * (its first 32 bytes); seen inside the window, it is replayed. */
            if (hello_replayed(state, data)) {
              hub_log_warning("[HUB] v3 peer auth: replayed hello for %s from %s — refused\n",
                              hub_who(state, 'h', peer_uuid), client->ip);
              secure_wipe(plain, sizeof(plain));
              hub_disconnect_client(state, client);
              return false;
            }
            if (!peer_link_tie(state, peer_idx, client)) {
              secure_wipe(plain, sizeof(plain));
              hub_disconnect_client(state, client);
              return false;
            }

            /* Accept. */
            client->type = CLIENT_HUB;
            client->authenticated = true;
            hub_known_ip_note(state, client->ip);
            /* D2: grow buffers — peers exchange bulk anti-entropy sync. */
            if (!hub_client_promote_buffers(client)) {
              hub_log_error("[HUB] Buffer promotion OOM for peer %s — "
                      "disconnecting\n", client->ip);
              hub_disconnect_client(state, client);
              return false;
            }
            state->peers[peer_idx].connected = true;
            state->peers[peer_idx].fd = client->fd;
            snprintf(state->peers[peer_idx].remote_ip,
                     sizeof(state->peers[peer_idx].remote_ip), "%s", client->ip);
            if (!state->peers[peer_idx].friendly_name[0] &&
                hub_name_valid(peer_name)) {
              snprintf(state->peers[peer_idx].friendly_name,
                       sizeof(state->peers[peer_idx].friendly_name),
                       "%s", peer_name);
            }
            snprintf(client->id, sizeof(client->id), "%s",
                     state->peers[peer_idx].friendly_name[0] ?
                     state->peers[peer_idx].friendly_name :
                     (hub_name_valid(peer_name) ? peer_name : "HUB-PEER"));
            client->id[sizeof(client->id) - 1] = 0;

            hub_log_info("[HUB] v3 Peer authenticated by Ed25519 signature: %s (%s)\n",
                    peer_name[0] ? peer_name : client->ip, hub_who(state, 'h', peer_uuid));

            /* If this process is the product of an upgrade this peer drove,
             * close that run out now that there is a peer to tell. */
            hub_upgrade_report_pending(state, client);
            hub_uhist_send_digest(state, client);
            hub_plan_send_digest(state, client);

            client->peer_heard = true; /* its signed hello was the first frame */
            hub_link_offer(state, client, peer_uuid);
            hub_p2_link_up(state, client);
            hub_roster_send_to_peer(state, client);

            /* Initial full state sync to the newly authenticated peer. */
            {
              char *init_sync = malloc(MAX_SYNC_PAYLOAD);
              if (init_sync) {
                hub_generate_sync_packet(state, init_sync, MAX_SYNC_PAYLOAD);
                hub_peer_enqueue_sync(state, client, CMD_PEER_SYNC, LANE_BULK, init_sync, NULL, 0);
                free(init_sync);
              }
              hub_activity_send_bans(state, client);
            }
          }
          else {
            secure_wipe(plain, sizeof(plain));
            hub_disconnect_client(state, client);
            return false;
          }

          secure_wipe(plain, sizeof(plain));
        } else {
          secure_wipe(session_key, 32);
          secure_wipe(plain, sizeof(plain));
          // Sealed-box failed — fall through to bot auth
          if (!handle_bot_authentication(state, client, data, packet_len)) {
            hub_disconnect_client(state, client);
            return false;
          }
        }
      } else {
        // Short packet — must be bot UUID or mid-handshake
        if (!handle_bot_authentication(state, client, data, packet_len)) {
          hub_disconnect_client(state, client);
          return false;
        }
      }
    }
    // ========================================================================
    // AUTHENTICATED - AES-GCM ENCRYPTED PACKETS
    // ========================================================================
    else {
      if (packet_len > GCM_TAG_LEN) {
        /* Change 5: an authenticated peer frame (full CMD_PEER_SYNC) can be
         * far larger than MAX_BUFFER — recv_cap was promoted to
         * MAX_SYNC_PAYLOAD for it — so the plaintext must be heap-sized to the
         * frame, not a 16 KB stack buffer.  A stack MAX_BUFFER here both
         * truncated large peer syncs (records past 16 KB were lost) and risked
         * a stack overwrite.  Bot/admin frames stay small; the alloc is sized
         * to this frame and freed on every path. */
        unsigned char tag[GCM_TAG_LEN];
        unsigned char *plain = malloc((size_t)packet_len + 1);
        if (!plain) {
          hub_log_error("[HUB] OOM decrypting frame from %s\n", client->ip);
          hub_disconnect_client(state, client);
          return false;
        }

        memcpy(tag, data + packet_len - GCM_TAG_LEN, GCM_TAG_LEN);

        /* Review 6: on a sequenced link the frame must be the next one. */
        unsigned char aad[HUB_LINK_AAD_LEN];
        bool seq = client->link_rx_seq;
        if (seq) link_aad(client->link_dir_rx, client->link_rx_ctr, aad);
        int pl = aes_gcm_decrypt_aad(data, packet_len - GCM_TAG_LEN, seq ? aad : NULL,
                                     seq ? HUB_LINK_AAD_LEN : 0, client->session_key,
                                     plain, tag);

        if (pl <= 0) {
          hub_log_warning("[HUB] GCM tag verification failed from authenticated client %s%s\n",
                  client->ip, seq ? " (replayed, reordered or forged frame)" : "");
        } else if (seq) {
          client->link_rx_ctr++;
        }

        if (pl > 0 && client->type == CLIENT_HUB && !client->peer_heard) {
          /* A dialled link: the far end answered, so it is alive and holds
           * our session key.  Only now does the link count as up. */
          client->peer_heard = true;
          hub_p2_link_up(state, client);
        }

        if (pl > 0) {
          unsigned char cmd = plain[0];
          g_hub_stats.rx_frames[cmd]++;
          g_hub_stats.rx_bytes[cmd] += (uint64_t)packet_len + 4;

          if (cmd == CMD_PING) {
            time_t now = time(NULL);
            if (now - client->last_pong_sent >= 5) {
              if (!send_pong(state, client)) {
                secure_wipe(plain, (size_t)packet_len + 1);
                free(plain);
                return false;
              }
              client->last_pong_sent = now;
            }
          } else {
            /* Every sender frames [cmd][len:4][payload], so a shorter frame
             * is malformed: plain + 5 would sit past the only NUL, and the
             * parsers below would read off the end of this allocation. */
            if (pl < 5) {
              hub_log_warning("[HUB] Short frame (%d bytes, cmd 0x%02x) from %s "
                              "— disconnecting\n", pl, cmd, client->ip);
              secure_wipe(plain, (size_t)packet_len + 1);
              free(plain);
              hub_disconnect_client(state, client);
              return false;
            }
            plain[pl] = 0;
            char *payload_ptr = (char *)plain + 5;

            if (cmd == CMD_LINK_SEQ &&
                (client->type == CLIENT_BOT || client->type == CLIENT_HUB)) {
              link_seq_recv(state, client, payload_ptr);
            } else if (client->type == CLIENT_ADMIN) {
              if (!handle_admin_command(state, client, cmd, payload_ptr,
                                        pl >= 5 ? pl - 5 : 0)) {
                secure_wipe(plain, (size_t)packet_len + 1);
                free(plain);
                return false;
              }
            } else if (client->type == CLIENT_BOT && client->retiring) {
              /* Deleted: only its CMD_BOT_RETIRE_ACK counts, then it goes. */
              if (cmd == CMD_BOT_RETIRE_ACK) {
                retire_ack_apply(state, client, payload_ptr);
                secure_wipe(plain, (size_t)packet_len + 1);
                free(plain);
                hub_disconnect_client(state, client);
                return false;
              }
            } else if (client->type == CLIENT_BOT) {
              process_bot_command(state, client, cmd, payload_ptr);
              if (client->refused) { /* below MESH_MIN_VERSION */
                secure_wipe(plain, (size_t)packet_len + 1);
                free(plain);
                hub_disconnect_client(state, client);
                return false;
              }
            } else if (client->type == CLIENT_HUB) {
              if (cmd == CMD_PEER_SYNC || cmd == CMD_PEER_BCAST) {
                /* Not read until this peer's version is known current:
                 * hub_peer_sync_release asks for it again then. */
                if (peer_version_level(state, client) == 2)
                  process_peer_sync(state, payload_ptr, client->fd,
                                    cmd == CMD_PEER_BCAST);
                else
                  client->sync_held = true;
              } else if (cmd == CMD_SERVER_REPORT) {
                hub_pool_peer_report(state, client, payload_ptr);
              } else if (cmd == CMD_MESH_STATE) {
                process_mesh_state(state, client, payload_ptr);
              } else if (cmd == CMD_PRESENCE2) {
                hub_p2_rx(state, client, payload_ptr);
              } else if (cmd == CMD_BOT_ROSTER) {
                process_bot_roster(state, client, payload_ptr);
                if (client->refused) { /* a peer below MESH_MIN_VERSION */
                  secure_wipe(plain, (size_t)packet_len + 1);
                  free(plain);
                  hub_disconnect_client(state, client);
                  return false;
                }
                hub_peer_sync_release(state, client);
              } else if (cmd == CMD_OP_FORWARD_REQUEST) {
                process_forward_op_request(state, client, payload_ptr);
              } else if (cmd == CMD_OP_FORWARD_GRANT) {
                process_forward_op_grant(state, client, payload_ptr);
              } else if (cmd == CMD_OP_FORWARD_FAILED) {
                process_forward_op_failed(state, client, payload_ptr);
              } else if (cmd == CMD_UPGRADE_HISTORY) {
                hub_uhist_process(state, client, payload_ptr);
              } else if (cmd == CMD_UPGRADE_PLAN) {
                hub_plan_process(state, client, payload_ptr);
              } else if (cmd == CMD_UPGRADE_FORGET) {
                process_peer_upgrade_forget(state, client, payload_ptr);
              } else if (cmd == CMD_CFG_RESYNC) {
                process_peer_cfg_resync(state, client, payload_ptr);
              } else if (cmd == CMD_BOT_MOVE) {
                process_peer_bot_move(state, client, payload_ptr);
              } else if (cmd == CMD_SYNC_DIGEST) {
                process_sync_digest(state, client, payload_ptr);
              } else if (cmd == CMD_HUB_ROLLCALL) {
                process_hub_rollcall(state, client, payload_ptr);
              } else if (cmd == CMD_HUB_ROLLCALL_ACK) {
                process_hub_rollcall_ack(state, client, payload_ptr);
              } else if (cmd == CMD_BOT_RELAY_FWD) {
                process_peer_bot_relay(state, client, payload_ptr);
              } else if (cmd == CMD_ACTIVITY) {
                process_activity(state, client, payload_ptr);
              } else if (cmd == CMD_CHAN_FWD_REQUEST) {
                process_forward_chan_request(state, client, payload_ptr);
              } else if (cmd == CMD_CHAN_FWD_REPLY) {
                process_forward_chan_reply(state, client, payload_ptr);
              } else if (cmd == CMD_CHAN_ELECT_FWD) {
                process_chan_elect_fwd(state, client, payload_ptr);
              } else if (cmd == CMD_CHAN_ELECT_ACK) {
                process_chan_elect_ack(state, client, payload_ptr);
              } else if (cmd == CMD_CHAN_ELECT_DO) {
                process_chan_elect_do(state, client, payload_ptr);
              } else if (cmd == CMD_CHAN_ELECT_DONE) {
                process_chan_elect_done(state, client, payload_ptr);
              } else if (cmd == CMD_CHAN_ELECT_END) {
                process_chan_elect_end(state, client, payload_ptr);
              } else if (cmd == CMD_CHAN_WHO) {
                process_chan_who(state, client, payload_ptr);
              } else if (cmd == CMD_UPGRADE_PREPARE) {
                process_peer_upgrade_prepare(state, client, payload_ptr);
              } else if (cmd == CMD_UPGRADE_COMMIT) {
                process_peer_upgrade_commit(state, client, payload_ptr);
              } else if (cmd == CMD_UPGRADE_ABORT) {
                process_peer_upgrade_abort(state, client, payload_ptr);
              } else if (cmd == CMD_UPGRADE_READY) {
                /* A peer answering a run WE drive — for itself, or forwarded
                 * on behalf of a node in its own subtree (registered as a
                 * remote node reached through this peer).  If instead we are
                 * only a hop on someone else's run, pass it further up. */
                if (!hub_upgrade_relay_upstream(state, client,
                                                CMD_UPGRADE_READY, payload_ptr))
                  hub_upgrade_note_ready(state, payload_ptr, client);
              } else if (cmd == CMD_UPGRADE_RESULT) {
                if (!hub_upgrade_relay_upstream(state, client,
                                                CMD_UPGRADE_RESULT,
                                                payload_ptr)) {
                  hub_upgrade_result_relay(state, client, payload_ptr);
                  hub_upgrade_note_result(state, payload_ptr);
                }
              } else if (cmd == CMD_UPGRADE_PROGRESS) {
                if (!hub_upgrade_relay_upstream(state, client, CMD_UPGRADE_PROGRESS, payload_ptr))
                  hub_upgrade_note_progress(state, payload_ptr);
              } else if (cmd == CMD_UPGRADE_STAGE) {
                process_peer_upgrade_stage(state, client, payload_ptr);
              } else if (cmd == CMD_PEER_REKEY_BOT) {
                /* v3: per-bot independent keys.  Peer-forwarded bot rekey
                 * is rejected because it would carry a private key. */
                hub_log_warning("[HUB] Rejected CMD_PEER_REKEY_BOT from peer %s: "
                        "per-bot independent keys; rekey is bot-local.\n",
                        client->ip);
              } else if (cmd == CMD_SYNC_REQUEST) {
                /* Peer is asking us for our full state immediately.
                 * Send our full sync packet to just this requesting peer. */
                hub_log_debug("[MESH] Sync request from peer %s — sending full state\n",
                        client->ip);
                char *reply_sync = malloc(MAX_SYNC_PAYLOAD);
                if (reply_sync) {
                  hub_generate_sync_packet(state, reply_sync, MAX_SYNC_PAYLOAD);
                  hub_peer_enqueue_sync(state, client, CMD_PEER_SYNC, LANE_BULK, reply_sync,
                                    NULL, 0);
                  free(reply_sync);
                }
              } else if (cmd == CMD_UPDATE_PUBKEY) {
                /* v3: independent per-hub keypairs.  A peer must NEVER
                 * push its private key to us.  Refuse and log. */
                hub_log_warning("[HUB] Rejected CMD_UPDATE_PUBKEY from peer %s: "
                        "per-hub independent keys; private keys do not "
                        "cross hub boundaries.\n", client->ip);
              }
            }
          }
        } else {
          hub_log_warning("[HUB] GCM decrypt failed from %s\n", client->ip);
          secure_wipe(plain, (size_t)packet_len + 1);
          free(plain);
          hub_disconnect_client(state, client);
          return false;
        }

        secure_wipe(plain, (size_t)packet_len + 1);
        free(plain);
      } else {
        /* Too short to hold a GCM tag: never a frame we sent, so the stream
         * is not ours (or is out of step) -- drop, as on a bad tag. */
        hub_log_warning("[HUB] Frame too short from authenticated client %s "
                        "(len=%d) — dropping\n", client->ip, packet_len);
        hub_disconnect_client(state, client);
        return false;
      }
    }

    packet_consumed:;
    /* Step past the frame; the reader compacts the buffer only when it is
     * full (a memmove per frame made a backlog quadratic). */
    client->recv_off += 4 + packet_len;
    if (client->recv_off >= client->recv_len) client->recv_off = client->recv_len = 0;
  }

  return true;
}

/* ==========================================================================
 * SSH console hooks (hub_console_core.c).  Snapshots of state the console
 * shows, built from the same helpers the bots' tree and the admin console's upgrade
 * status always used.  Main thread only.
 * ========================================================================== */
int hub_console_tree_rows(hub_state_t *state, char *buf, int max_len) {
  return hub_build_tree(state, buf, max_len);
}

/* A refused SSH login (FAIL frame): counted in the SSH-only table (D26), so an
 * admin's mistyped keys never block a bot or peer on the same address. */
void hub_console_ssh_failed(hub_state_t *state, const char *ip) {
  if (state->trust_loopback &&
      (strcmp(ip, "127.0.0.1") == 0 || strcmp(ip, "::1") == 0)) return;
  int blk = 0;
  hub_ssh_table_failed(state->ssh_ips, &state->ssh_ip_count, &state->conn_cfg, ip,
                       time(NULL), &blk);
  if (blk > 0)
    hub_log_warning("[AUTH_BLOCK] SSH from %s blocked for %d seconds (too many refused "
                    "logins)\n", ip, blk);
}

/* The connection from `ip` just sniffed as SSH: the console scope of the ACL
 * (D27), then the SSH block and connect window.  False = close it. */
bool hub_console_ssh_admit(hub_state_t *state, const char *ip) {
  if (!hub_ip_acl_permits_console(state, ip)) {
    hub_log_warning("[ACCESS_CONTROL] SSH from %s refused (console scope of the "
                    "allow/deny lists)\n", ip);
    return false;
  }
  if (state->trust_loopback &&
      (strcmp(ip, "127.0.0.1") == 0 || strcmp(ip, "::1") == 0)) return true;
  int blk = 0;
  if (hub_ssh_table_connect(state->ssh_ips, &state->ssh_ip_count, &state->conn_cfg, ip,
                            time(NULL), &blk))
    return true;
  if (blk > 0)
    hub_log_warning("[RATE_LIMIT] SSH from %s connecting too fast; blocked for %d "
                    "seconds\n", ip, blk);
  else
    hub_log_info("[RATE_LIMIT] SSH from %s refused (blocked)\n", ip);
  return false;
}

void hub_console_note_login(hub_state_t *state, const char *name, const char *ip) {
  if (!(state->trust_loopback && (strcmp(ip, "127.0.0.1") == 0 || strcmp(ip, "::1") == 0)))
    hub_ssh_table_success(state->ssh_ips, &state->ssh_ip_count, ip, time(NULL));
  for (int i = 0; i < state->user_record_count; i++) {
    hub_user_record_t *u = &state->user_records[i];
    if (u->type == 'a' && u->is_active && strcmp(u->name, name) == 0) {
      /* Activity, not a config change: no peer sync, no bot push. */
      hub_activity_stamp_user(state, u, time(NULL));
      return;
    }
  }
}

/* docs/console.md §3.3 "status": one line, fields in a fixed order.  `tree`
 * is the current hub_build_tree output: hubs are its H rows (this hub, its
 * peers and the hubs beyond them), bots online are the distinct B rows, and
 * the mesh is split when any hub row is offline. */
void hub_console_status_line(hub_state_t *state, const char *tree, char *out,
                             size_t out_size) {
  int hubs_up = 0, hubs_total = 0;
  int bots_total = 0;
  for (int i = 0; i < state->bot_count; i++)
    if (state->bots[i].is_active) bots_total++;
  int bots_on = 0;
  bool split = false;
  char seen[MAX_BOTS][40];
  int nseen = 0;
  for (const char *line = tree; line && *line;) {
    const char *nl = strchr(line, '\n');
    size_t ll = nl ? (size_t)(nl - line) : strlen(line);
    char row[TREE_ROW_MAX + 1];
    if (ll < sizeof(row)) {
      memcpy(row, line, ll);
      row[ll] = '\0';
      char f[9][TREE_ROW_MAX];
      int nf = 0;
      char *save = NULL;
      for (char *t = strtok_r(row, "|", &save); t && nf < 9;
           t = strtok_r(NULL, "|", &save))
        snprintf(f[nf++], sizeof(f[0]), "%s", t);
      if (nf >= 5 && strcmp(f[0], "H") == 0) {
        hubs_total++;
        if (strcmp(f[4], "0") == 0) split = true;
        else hubs_up++;
      }
      if (nf >= 4 && strcmp(f[0], "B") == 0) {
        bool dup = false;
        for (int k = 0; k < nseen && !dup; k++) dup = strcmp(seen[k], f[3]) == 0;
        if (!dup && nseen < MAX_BOTS) {
          snprintf(seen[nseen++], sizeof(seen[0]), "%.39s", f[3]);
          bots_on++;
        }
      }
    }
    line = nl ? nl + 1 : NULL;
  }
  char upg[32] = "-";
  const pending_upgrade_t *u = &state->upgrade;
  if (u->active) {
    int done = 0, total = 0;
    for (int i = 0; i < u->node_count; i++) {
      if (u->nodes[i].not_selected) continue;
      total++;
      if (u->nodes[i].state == UPG_NODE_DONE) done++;
    }
    snprintf(upg, sizeof(upg), "%d/%d", done, total);
  }
  snprintf(out, out_size,
           "name=%s|hubs=%d/%d|bots=%d/%d|upg=%s|frozen=%d|rollup=%d|split=%d|"
           "loglevel=%d|consolelevel=%d",
           state->hub_friendly_name[0] ? state->hub_friendly_name : "hub",
           hubs_up, hubs_total, bots_on, bots_total, upg,
           hub_config_frozen(state) ? 1 : 0, state->rollup.active ? 1 : 0,
           split ? 1 : 0, state->log_level, state->console_log_level);
}

/* docs/console.md §3.3 "upg": <id>|<phase>|<done>/<total>|<failed>, or ""
 * when this hub has not driven a run. */
void hub_console_upg_line(hub_state_t *state, char *out, size_t out_size) {
  const pending_upgrade_t *u = &state->upgrade;
  out[0] = '\0';
  if (!u->id[0]) return;
  int done = 0, total = 0, failed = 0;
  for (int i = 0; i < u->node_count; i++) {
    if (u->nodes[i].not_selected) continue;
    total++;
    if (u->nodes[i].state == UPG_NODE_DONE) done++;
    if (u->nodes[i].state == UPG_NODE_FAILED) failed++;
  }
  snprintf(out, out_size, "%s|%s|%d/%d|%d", u->id, upgrade_phase_name(u->phase),
           done, total, failed);
}
