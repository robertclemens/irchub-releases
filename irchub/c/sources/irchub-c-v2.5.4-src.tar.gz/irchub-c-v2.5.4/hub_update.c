/* hub_update.c — the hub's own signed self-update, for the network upgrade.
 *
 * This is the hub-side twin of ircbot/utils.c's updater, and it exists for one
 * reason: a network upgrade that can move every bot but not the hubs leaves
 * the mesh permanently mixed.  The orchestration in hub_logic.c already treats
 * peer hubs and this hub as nodes of a run; what lives here is what a node
 * needs to actually *be* upgraded — fetch a signed manifest, pick the artifact
 * that fits this host, install it atomically and keep the old one so the run
 * can be rolled back.
 *
 * Trust model, identical to the bot's: the manifest is verified against the
 * pinned Ed25519 key in HUB_UPDATE_PUBKEY_B64 before a single field in it is
 * read, and each artifact against the SHA-256 the signed manifest gives.  An
 * empty pinned key disables updates entirely (fail-closed), and a hub built
 * without libcurl reports the feature unavailable rather than falling back to
 * anything.
 */
#include <ctype.h>
#include <strings.h>
#include <errno.h>
#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <sys/utsname.h>
#include "elf_needs.h"
#include <sys/wait.h>
#include <signal.h>
#include <time.h>

#include "hub.h"

/* Close every descriptor above stderr before this process exec()s into the
 * upgrade script or the retained build.  None of the hub's sockets are
 * close-on-exec, so without this the replacement inherits the old listening
 * socket — and its own bind() on the same port fails ("Bind failed"), leaving
 * a hub that installed the new build but never comes back — plus every peer
 * and bot connection, which would stay open, half-alive, under the new
 * process.  (The Rust hub gets this for free: std opens sockets CLOEXEC.)
 * Nothing is logged after this point; the log file's fd is closed too. */
static void hub_update_close_fds_for_exec(void) {
  fflush(NULL); /* every stdio stream, the log included */
  long max = sysconf(_SC_OPEN_MAX);
  if (max < 0 || max > 65536) max = 65536;
  for (int fd = 3; fd < (int)max; fd++) close(fd);
}

#ifdef HAVE_CURL
#include <curl/curl.h>
#endif
#include <dirent.h> /* cron_work_rm: used with or without curl */

/* ---- Host capability probe (answered in CMD_UPGRADE_READY) --------------
 * Both answers describe the RUNNING binary, not the machine in the abstract:
 * a hub reports what it can be replaced with.  The arch comes from uname(2)
 * so it matches the manifest's `uname -m` spelling; the libc is decided at
 * compile time because the binary is already linked against one and musl
 * publishes no runtime identifier. */
void hub_update_host_arch(char *out, size_t out_size) {
  if (!out || out_size == 0) return;
  struct utsname u;
  if (uname(&u) == 0 && u.machine[0]) {
    size_t n = strnlen(u.machine, out_size - 1);
    memcpy(out, u.machine, n);
    out[n] = '\0';
  } else {
    snprintf(out, out_size, "unknown");
  }
}

/* The host's C library, at run time (2.5.4, docs/plans/2026-11-20_artifact_choice_plan.md
 * §3): on Linux "gnu" when a glibc program loader is present — whatever libc
 * this build itself uses, so a static (musl) build on Ubuntu can still take a
 * gnu artifact — else "musl"; elsewhere the OS name in lower case (freebsd,
 * netbsd, openbsd, darwin), which no Linux row ever matches. */
void hub_update_host_libc(char *out, size_t out_size) {
  if (!out || out_size == 0) return;
#if defined(__linux__)
  static const char *const loaders[] = {"/lib64/ld-linux-x86-64.so.2", "/lib/ld-linux-x86-64.so.2",
                                        "/lib/ld-linux-aarch64.so.1", "/lib/ld-linux-armhf.so.3",
                                        "/lib/ld-linux.so.2"};
  for (size_t i = 0; i < sizeof(loaders) / sizeof(loaders[0]); i++)
    if (access(loaders[i], F_OK) == 0) {
      snprintf(out, out_size, "gnu");
      return;
    }
  snprintf(out, out_size, "musl");
#else
  struct utsname u;
  size_t w = 0;
  if (uname(&u) == 0)
    for (const char *c = u.sysname; *c && w + 1 < out_size; c++)
      if (isalnum((unsigned char)*c)) out[w++] = (char)tolower((unsigned char)*c);
  out[w] = '\0';
  if (!w) snprintf(out, out_size, "unknown");
#endif
}

static int run_bounded(const char *const argv[], int timeout_s, char *out, size_t out_size);

/* The host's glibc version (the highest GLIBC_x.y its libc.so.6 defines,
 * read from that file's version table — elf_needs.c), or NULL when there is
 * none; asked once.  The same in a static and a glibc build, and in the Rust
 * trees.  A pre-filter only: the new build's -selftest decides. */
static const char *host_glibc(void) {
  static bool asked;
  static char ver[32];
  if (!asked) {
    asked = true;
    if (!en_glibc(ver, sizeof(ver))) ver[0] = '\0';
  }
  return ver[0] ? ver : NULL;
}

const char *hub_update_host_variant(void) { return HUB_UPDATE_VARIANT; }

/* ---- Version comparison -------------------------------------------------
 * glibc strverscmp, carried here rather than linked so a hub on musl or an
 * older libc compares versions the same way every other node does. */
static int hub_strverscmp(const char *s1, const char *s2) {
  const unsigned char *p1 = (const unsigned char *)s1;
  const unsigned char *p2 = (const unsigned char *)s2;
  unsigned char c1, c2;

  while ((c1 = *p1++) == (c2 = *p2++)) {
    if (c1 == '\0') return 0;
  }
  p1--;
  p2--;

  if (isdigit(c1) && isdigit(c2)) {
    int state = 0;
    while (1) {
      if (state == 0) {
        if (c1 > c2)
          state = 1;
        else if (c1 < c2)
          state = -1;
      }
      c1 = isdigit(*p1) ? *p1++ : 0;
      c2 = isdigit(*p2) ? *p2++ : 0;
      if (!c1 && !c2) break;
      if (c1 == 0 && c2 != 0) return -1;
      if (c1 != 0 && c2 == 0) return 1;
    }
    return state;
  }
  return (int)p1[0] - (int)p2[0];
}

/* Release manifests spell versions with a leading 'v' ("v2.3.0") while
 * HUB_VERSION does not ("2.4.0").  Compare them on the numeric part alone:
 * hub_strverscmp("v0.0.1", "2.4.0") would otherwise compare 'v' against '2' and
 * report a downgrade as an upgrade, which is exactly what the downgrade guard
 * exists to stop.  Mirrors updater_version_cmp in ircbot/utils.c. */
static const char *version_strip_v(const char *v) {
  if (!v) return "";
  return (*v == 'v' || *v == 'V') ? v + 1 : v;
}

int hub_update_version_cmp(const char *a, const char *b) {
  return hub_strverscmp(version_strip_v(a), version_strip_v(b));
}

#ifdef HAVE_CURL /* only the curl-based updater compares for equality */
static bool version_eq(const char *a, const char *b) {
  return strcasecmp(version_strip_v(a), version_strip_v(b)) == 0;
}
#endif

/* ---- Upgrade hand-off marker -------------------------------------------
 * exec() throws away everything the old process knew, so the upgrade id and
 * the version we were aiming at are left in a file for the new binary to
 * find.  It is read exactly once, by the peer-upgrade reporting path after
 * the restart, and removed there. */
bool hub_upgrade_marker_write(const char *upgrade_id, const char *target_ver,
                              const char *variant) {
  if (!upgrade_id || !target_ver || !variant) return false;
  int fd = open(HUB_UPGRADE_MARKER_FILE,
                O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0600);
  if (fd < 0) return false;
  char line[256];
  /* id|version|variant.  The variant is what makes a C<->Rust switch at the
   * same version checkable: without it the old build, restored by the
   * script's watchdog, would read the marker and report "ok". */
  int n = snprintf(line, sizeof(line), "%s|%s|%s\n", upgrade_id, target_ver,
                   variant);
  bool ok = (n > 0 && n < (int)sizeof(line) && write(fd, line, (size_t)n) == n);
  if (close(fd) != 0) ok = false;
  if (!ok) remove(HUB_UPGRADE_MARKER_FILE);
  return ok;
}

/* Read and consume the marker.  False for every ordinary start. */
bool hub_update_take_pending(char *id_out, size_t id_size, char *ver_out,
                             size_t ver_size, char *variant_out,
                             size_t variant_size) {
  if (!id_out || !ver_out || !variant_out || id_size == 0 || ver_size == 0 ||
      variant_size == 0)
    return false;
  id_out[0] = ver_out[0] = variant_out[0] = '\0';

  FILE *f = fopen(HUB_UPGRADE_MARKER_FILE, "r");
  if (!f) return false;
  char line[256] = "";
  bool got = (fgets(line, sizeof(line), f) != NULL);
  fclose(f);
  /* Consumed whatever it said: a marker we cannot parse must not be retried
   * on every reconnect for the rest of this process's life. */
  remove(HUB_UPGRADE_MARKER_FILE);
  if (!got) return false;

  /* A two-field marker (an older build wrote it) has no variant: "". */
  char id[64] = "", ver[64] = "", variant[16] = "";
  if (sscanf(line, "%63[^|\r\n]|%63[^|\r\n]|%15[^|\r\n]", id, ver,
             variant) < 2)
    return false;
  if (!id[0] || !ver[0]) return false;
  snprintf(id_out, id_size, "%s", id);
  snprintf(ver_out, ver_size, "%s", ver);
  snprintf(variant_out, variant_size, "%s", variant);
  return true;
}

/* ---- Failback ----------------------------------------------------------
 * A node must recover by itself: its admin may have no shell on the host.  One
 * script decides, called from two places: the upgrade script's background loop
 * every 10 s, and a temporary crontab line every minute, which outlives a reboot
 * or a killed loop.  It holds no secrets, and removes itself and the line once
 * the new build confirms or the old one is back.  The body is the same text in
 * all four trees: ircbot, ircbot.rs, irchub, irchub.rs. */
#define FAILBACK_FILE ".upgrade.failback"
#define FAILBACK_STATE ".upgrade.state"
#define FAILBACK_CONFIRM ".upgrade.confirmed"
#define CRON_HELPER ".cron.helper"

static const char *const FAILBACK_BODY[] = {
  "umask 077\n",
  "PATH=\"${PATH:-}:/usr/bin:/bin\"; export PATH\n",
  "cd \"$D\" 2>/dev/null || exit 1\n",
  "STATE=.upgrade.state; CONF=.upgrade.confirmed; SELF=${SELF:-.upgrade.failback}\n",
  "FAILF=.upgrade.failback\n",
  "LOCK=.upgrade.lock; TRIES=.upgrade.tries; PREV=\"$EXE.prev\"\n",
  "FAILTAG=\"# $PRODUCT:failback:$D:\"; PRODTAG=\"# $PRODUCT:production:$D:\"\n",
  "# A hardened daemon is not dumpable, so its /proc/<pid>/exe cannot be read: the\n",
  "# pid file and the process name say whether it is ours.\n",
  "COMM=$(basename \"$EXE\" | cut -c1-15)\n",
  "HLOCK=\"${HOME:-$D}/.irc-cron.lock\"\n",
  "HELD=\"\"\n",
  "\n",
  "take_lock() {\n",
  "  i=0; e=0\n",
  "  while :; do\n",
  "    if ( set -C; echo $$ >\"$1\" ) 2>/dev/null; then HELD=\"$HELD $1\"; return 0; fi\n",
  "    h=$(cat \"$1\" 2>/dev/null)\n",
  "    # Empty: its holder may be between create and write; look once more first.\n",
  "    if [ -z \"$h\" ] && [ \"$e\" = 0 ]; then e=1; sleep 1; continue; fi\n",
  "    e=0\n",
  "    if [ -n \"$h\" ] && kill -0 \"$h\" 2>/dev/null; then\n",
  "      i=$((i + 1)); [ \"$i\" -ge \"$2\" ] && return 1\n",
  "      sleep 1\n",
  "    elif ( set -C; echo $$ >\"$1.take\" ) 2>/dev/null; then\n",
  "      # Only the holder of $1.take clears a stale $1, and only while it still\n",
  "      # names the dead holder it saw: two waiters can never both take over.\n",
  "      [ \"$(cat \"$1\" 2>/dev/null)\" = \"$h\" ] && rm -f \"$1\"\n",
  "      rm -f \"$1.take\"\n",
  "    else\n",
  "      t=$(cat \"$1.take\" 2>/dev/null)\n",
  "      [ -n \"$t\" ] && ! kill -0 \"$t\" 2>/dev/null && rm -f \"$1.take\"\n",
  "      i=$((i + 1)); [ \"$i\" -ge \"$2\" ] && return 1\n",
  "      sleep 1\n",
  "    fi\n",
  "  done\n",
  "}\n",
  "drop_locks() { for l in $HELD; do rm -f \"$l\"; done; HELD=\"\"; }\n",
  "trap drop_locks EXIT\n",
  "\n",
  "clean() { printf '%s' \"$1\" | tr -d '|\\r\\n' | cut -c1-160; }\n",
  "set_state() { # phase pid note\n",
  "  printf '%s|%s|%s|%s|%s\\n' \"$ID\" \"$1\" \"$(date +%s)\" \"$2\" \"$(clean \"$3\")\" >\"$STATE.tmp\" &&\n",
  "    mv -f \"$STATE.tmp\" \"$STATE\"\n",
  "}\n",
  "read_state() {\n",
  "  rid=\"\"; phase=\"\"; since=0; spid=\"\"; note=\"\"\n",
  "  [ -f \"$STATE\" ] || return 1\n",
  "  IFS='|' read -r rid phase since spid note <\"$STATE\" || return 1\n",
  "  [ \"$rid\" = \"$ID\" ]\n",
  "}\n",
  "pid_now() { [ -f \"$PIDF\" ] && tr -dc 0-9 <\"$PIDF\"; }\n",
  "alive() {\n",
  "  p=$(pid_now)\n",
  "  [ -n \"$p\" ] && kill -0 \"$p\" 2>/dev/null && [ \"$(cat \"/proc/$p/comm\" 2>/dev/null)\" = \"$COMM\" ]\n",
  "}\n",
  "start_exe() { \"$EXE\" </dev/null >/dev/null 2>&1 & }\n",
  "\n",
  "# Read, change, write, read back, compare.  Only an answer that says there is\n",
  "# no crontab counts as empty: any other read error writes nothing, so a bad read\n",
  "# can never wipe an admin's jobs.  Only a line holding this tag changes, along with\n",
  "# tagged lines whose directory is gone; every other line stays as it was.\n",
  "cron_read() { # file\n",
  "  if ! crontab -l >\"$1\" 2>\"$1.err\"; then\n",
  "    grep -Eqi 'no crontab|no such file|does not exist' \"$1.err\" || return 1\n",
  "    : >\"$1\"\n",
  "  fi\n",
  "}\n",
  "cron_sweep() { # in out\n",
  "  sed -nE 's/.*# (ircbot|irchub):(production|failback):(\\/[^:]*):$/\\3/p' \"$1\" |\n",
  "    while read -r dd; do [ -d \"$dd\" ] || printf ':%s:\\n' \"$dd\"; done >\"$2.dead\"\n",
  "  if [ -s \"$2.dead\" ]; then grep -vF -f \"$2.dead\" \"$1\" >\"$2\"; else cp \"$1\" \"$2\"; fi\n",
  "}\n",
  "cron_edit() { # add|remove|orphan tag line\n",
  "  command -v crontab >/dev/null 2>&1 || return 3\n",
  "  take_lock \"$HLOCK\" 15 || return 5  # busy: the binary runs it again soon\n",
  "  T=\".upgrade.cron.$$\"; rc=1; n=0\n",
  "  # orphan: remove, but only while no upgrade script is here.  Looked at under\n",
  "  # the lock, so an upgrade that is starting keeps its line.\n",
  "  if [ \"$1\" = orphan ]; then\n",
  "    [ -e \"$FAILF\" ] && n=3 && rc=0\n",
  "    set -- remove \"$2\"\n",
  "  fi\n",
  "  while [ \"$n\" -lt 3 ]; do\n",
  "    n=$((n + 1))\n",
  "    cron_read \"$T.cur\" || break\n",
  "    if [ \"$1\" = remove ] && ! grep -qF \"$2\" \"$T.cur\"; then rc=0; break; fi\n",
  "    if [ \"$1\" = add ] && grep -qF \"$2\" \"$T.cur\"; then rc=0; break; fi\n",
  "    cron_sweep \"$T.cur\" \"$T.swept\"\n",
  "    grep -vF \"$2\" \"$T.swept\" >\"$T.rest\"\n",
  "    cp \"$T.rest\" \"$T.new\"\n",
  "    [ \"$1\" = add ] && printf '%s\\n' \"$3\" >>\"$T.new\"\n",
  "    crontab \"$T.new\" >/dev/null 2>&1 || { sleep 1; continue; }\n",
  "    crontab -l >\"$T.chk\" 2>/dev/null\n",
  "    grep -vF \"$2\" \"$T.chk\" | grep -v '^# \\(DO NOT EDIT\\|(\\)' >\"$T.a\"\n",
  "    grep -v '^# \\(DO NOT EDIT\\|(\\)' \"$T.rest\" >\"$T.b\"\n",
  "    if cmp -s \"$T.a\" \"$T.b\"; then\n",
  "      if [ \"$1\" = add ]; then grep -qF \"$2\" \"$T.chk\" && { rc=0; break; }\n",
  "      else grep -qF \"$2\" \"$T.chk\" || { rc=0; break; }; fi\n",
  "    fi\n",
  "    sleep 1\n",
  "  done\n",
  "  rm -f \"$T\".*\n",
  "  rm -f \"$HLOCK\"; HELD=$(printf '%s' \"$HELD\" | sed \"s| $HLOCK||\")\n",
  "  return \"$rc\"\n",
  "}\n",
  "# An upgrade's line whose script is gone: a \"done\" that found the crontab lock\n",
  "# busy left it behind.  A helper that finds the lock busy here exits 5 (busy),\n",
  "# and the binary runs it again in 10-30 s.\n",
  "orphan_or_busy() {\n",
  "  [ -e \"$FAILF\" ] && return 0\n",
  "  command -v crontab >/dev/null 2>&1 || return 0\n",
  "  T=\".upgrade.cron.$$\"\n",
  "  cron_read \"$T.fo\" || { rm -f \"$T\".*; return 0; }\n",
  "  grep -qF \"$FAILTAG\" \"$T.fo\"; f=$?\n",
  "  rm -f \"$T\".*\n",
  "  [ \"$f\" = 0 ] || return 0\n",
  "  cron_edit orphan \"$FAILTAG\"\n",
  "  [ $? = 5 ] && { rm -f \"$SELF\"; exit 5; }\n",
  "  return 0\n",
  "}\n",
  "fail_line() {\n",
  "  printf \"* * * * * [ -x '%s/%s' ] && '%s/%s' tick >/dev/null 2>&1 %s\\n\" \\\n",
  "    \"$D\" \"$SELF\" \"$D\" \"$SELF\" \"$FAILTAG\"\n",
  "}\n",
  "prod_line() {\n",
  "  printf \"*/5 * * * * touch '%s/.cron.seen'; [ -x '%s' ] && '%s' >/dev/null 2>&1 %s\\n\" \\\n",
  "    \"$D\" \"$EXE\" \"$EXE\" \"$PRODTAG\"\n",
  "}\n",
  "# What this instance's production line is: 0 ours, 10 a hand-written line runs\n",
  "# this binary, 11 none, 3 no crontab tool, 1 it cannot be read.\n",
  "cron_status() {\n",
  "  command -v crontab >/dev/null 2>&1 || return 3\n",
  "  T=\".upgrade.cron.$$\"\n",
  "  cron_read \"$T.st\" || { rm -f \"$T\".*; return 1; }\n",
  "  rc=11\n",
  "  if grep -qF \"$PRODTAG\" \"$T.st\"; then rc=0\n",
  "  elif grep -vE '^[[:space:]]*#' \"$T.st\" | grep -qF \"$EXE\"; then rc=10\n",
  "  fi\n",
  "  rm -f \"$T\".*\n",
  "  return \"$rc\"\n",
  "}\n",
  "safe_path() { case \"$D\" in *[!A-Za-z0-9._/-]*) return 1 ;; esac; }\n",
  "\n",
  "# keep = leave the state file, for the build that has to report it\n",
  "finish() {\n",
  "  cron_edit remove \"$FAILTAG\"\n",
  "  [ \"${1:-}\" = keep ] || rm -f \"$STATE\"\n",
  "  rm -f \"$CONF\" \"$TRIES\" \"$SELF\" \"./$SCRIPT\"\n",
  "  drop_locks\n",
  "  exit 1\n",
  "}\n",
  "\n",
  "restore() { # reason\n",
  "  read_state\n",
  "  [ -n \"$spid\" ] && [ \"$spid\" != \"$PPID\" ] && [ \"$spid\" != \"$$\" ] && kill \"$spid\" 2>/dev/null\n",
  "  if alive; then\n",
  "    p=$(pid_now); kill \"$p\" 2>/dev/null\n",
  "    i=0\n",
  "    while kill -0 \"$p\" 2>/dev/null && [ \"$i\" -lt 5 ]; do sleep 1; i=$((i + 1)); done\n",
  "    kill -9 \"$p\" 2>/dev/null\n",
  "  fi\n",
  "  if [ ! -f \"$PREV\" ]; then\n",
  "    [ -x \"$EXE\" ] && ! alive && start_exe\n",
  "    set_state failback-gave-up \"\" \"$1; no previous build retained\"\n",
  "    return\n",
  "  fi\n",
  "  mv -f \"$EXE\" \"$EXE.failed\" 2>/dev/null\n",
  "  if ! mv -f \"$PREV\" \"$EXE\"; then\n",
  "    mv -f \"$EXE.failed\" \"$EXE\" 2>/dev/null\n",
  "    set_state failback-gave-up \"\" \"$1; could not restore the previous build\"\n",
  "    return\n",
  "  fi\n",
  "  [ -f \"$CFG.prev\" ] && cp -f \"$CFG.prev\" \"$CFG\"\n",
  "  rm -f \"$PIDF\"\n",
  "  set_state restored \"\" \"$1\"\n",
  "  start_exe\n",
  "}\n",
  "\n",
  "tick() {\n",
  "  # Another upgrade's state: it is about to replace this script, so leave it be.\n",
  "  read_state || { [ -n \"$rid\" ] && exit 1; finish; }\n",
  "  now=$(date +%s); age=$((now - since))\n",
  "  if [ \"$now\" -ge \"$HARD\" ]; then\n",
  "    case \"$phase\" in\n",
  "      restored|failback-gave-up) ;;\n",
  "      *) set_state failback-gave-up \"\" \"the upgrade never finished\" ;;\n",
  "    esac\n",
  "    finish keep\n",
  "  fi\n",
  "  case \"$phase\" in\n",
  "    installing)\n",
  "      if ! kill -0 \"$spid\" 2>/dev/null; then restore \"the install was interrupted\"\n",
  "      elif [ \"$age\" -ge \"$INSTALL_LIMIT\" ]; then restore \"the install took over $INSTALL_LIMIT s\"\n",
  "      fi ;;\n",
  "    started)\n",
  "      if [ -f \"$CONF\" ] && [ \"$(cat \"$CONF\" 2>/dev/null)\" = \"$ID\" ] && alive; then finish\n",
  "      elif ! alive; then\n",
  "        [ \"$age\" -ge \"$WATCH\" ] && restore \"the new build did not stay up\"\n",
  "      elif [ \"$age\" -ge \"$CONFIRM_LIMIT\" ]; then restore \"$NOTE within $CONFIRM_LIMIT s\"\n",
  "      fi ;;\n",
  "    restored)\n",
  "      alive && finish keep\n",
  "      t=$(cat \"$TRIES\" 2>/dev/null); t=$((${t:-0} + 1)); echo \"$t\" >\"$TRIES\"\n",
  "      if [ \"$t\" -ge 5 ]; then\n",
  "        set_state failback-gave-up \"\" \"$note; the previous build will not start\"\n",
  "        finish keep\n",
  "      fi\n",
  "      start_exe ;;\n",
  "    failback-gave-up) finish keep ;;\n",
  "    *) finish ;;\n",
  "  esac\n",
  "  return 0\n",
  "}\n",
  "\n",
  "# The cron-* arguments are a one-shot helper's: it runs once and removes itself.\n",
  "case \"${1:-tick}\" in\n",
  "  install)\n",
  "    safe_path || exit 3\n",
  "    cron_edit add \"$FAILTAG\" \"$(fail_line)\"; exit $? ;;\n",
  "  phase) take_lock \"$LOCK\" 20 && set_state \"$2\" \"$3\" \"\" ;;\n",
  "  restore) take_lock \"$LOCK\" 20 && restore \"$2\" ;;\n",
  "  done) take_lock \"$LOCK\" 20; finish ;;\n",
  "  # A loop names its upgrade: a loop that outlived it stops here, touching nothing.\n",
  "  tick) [ -n \"${2:-}\" ] && [ \"$2\" != \"$ID\" ] && exit 1\n",
  "    take_lock \"$LOCK\" 2 || exit 0; tick ;;\n",
  "  cron-status) orphan_or_busy; cron_status; rc=$?; rm -f \"$SELF\"; exit \"$rc\" ;;\n",
  "  cron-on)\n",
  "    orphan_or_busy\n",
  "    cron_status; rc=$?\n",
  "    if [ \"$rc\" = 11 ]; then\n",
  "      if safe_path; then\n",
  "        touch .cron.seen\n",
  "        cron_edit add \"$PRODTAG\" \"$(prod_line)\" && cron_status; rc=$?\n",
  "      else\n",
  "        rc=4\n",
  "      fi\n",
  "    fi\n",
  "    rm -f \"$SELF\"; exit \"$rc\" ;;\n",
  "  cron-off)\n",
  "    orphan_or_busy\n",
  "    rc=0\n",
  "    cron_edit remove \"$PRODTAG\" || rc=$?\n",
  "    if [ \"$rc\" = 0 ]; then rm -f .cron.seen; cron_status; rc=$?; fi\n",
  "    rm -f \"$SELF\"; exit \"$rc\" ;;\n",
  "esac\n",
  "exit 0\n"
};

/* A value for the script's header: single-quoted, so nothing in a path expands */
static void failback_quoted(FILE *f, const char *name, const char *value) {
  fprintf(f, "%s='", name);
  for (const char *p = value; *p; p++) {
    if (*p == '\'') fputs("'\\''", f);
    else fputc(*p, f);
  }
  fputs("'\n", f);
}

/* The script, for one upgrade (FAILBACK_FILE) or one crontab change (CRON_HELPER). */
static bool failback_write(const char *path, const char *exe, const char *id, bool is_bin,
                           const char *cfg, const char *pidf, const char *script,
                           const char *note, const char *self) {
  char dir[PATH_MAX];
  snprintf(dir, sizeof(dir), "%s", exe);
  char *slash = strrchr(dir, '/');
  if (!slash) return false;
  *slash = '\0';
  int fd = open(path, O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0700);
  FILE *f = fd >= 0 ? fdopen(fd, "w") : NULL;
  if (!f) {
    if (fd >= 0) close(fd);
    return false;
  }
  int install = is_bin ? UPGRADE_INSTALL_SECS : UPGRADE_BUILD_SECS;
  fputs("#!/bin/sh\n", f);
  fputs("# Written by irchub: removes itself.  See its README.\n", f);
  failback_quoted(f, "PRODUCT", "irchub");
  failback_quoted(f, "SELF", self);
  failback_quoted(f, "D", dir);
  failback_quoted(f, "EXE", exe);
  failback_quoted(f, "ID", id);
  failback_quoted(f, "CFG", cfg);
  failback_quoted(f, "PIDF", pidf);
  failback_quoted(f, "SCRIPT", script);
  failback_quoted(f, "NOTE", note);
  fprintf(f, "INSTALL_LIMIT=%d\nCONFIRM_LIMIT=%d\nWATCH=%d\nHARD=%lld\n", install,
          UPGRADE_CONFIRM_SECS, UPGRADE_WATCH_SECS,
          (long long)time(NULL) + install + UPGRADE_CONFIRM_SECS + UPGRADE_FAILBACK_EXPIRY);
  for (size_t i = 0; i < sizeof(FAILBACK_BODY) / sizeof(FAILBACK_BODY[0]); i++)
    fputs(FAILBACK_BODY[i], f);
  (void)fchmod(fileno(f), 0700);
  if (fclose(f) != 0) {
    remove(path);
    return false;
  }
  return true;
}

/* Run the script with one argument; its exit status, -1 if it could not run. */
static int failback_run(const char *arg) {
  pid_t pid = fork();
  if (pid < 0) return -1;
  if (pid == 0) {
    for (int fd = 3; fd < 1024; fd++) close(fd);
    execl("./" FAILBACK_FILE, "./" FAILBACK_FILE, arg, (char *)NULL);
    _exit(127);
  }
  int st = 0;
  if (waitpid(pid, &st, 0) != pid || !WIFEXITED(st)) return -1;
  return WEXITSTATUS(st);
}

/* Takes the upgrade back out of cron and off the disk. */
static void failback_clear(void) {
  if (access(FAILBACK_FILE, X_OK) == 0) (void)failback_run("done");
  remove(FAILBACK_STATE);
  remove(FAILBACK_CONFIRM);
}

/* The new build is up and has proved it can do its job. */
void hub_update_failback_confirm(void) {
  char line[256];
  FILE *f = fopen(FAILBACK_STATE, "r");
  if (!f) return;
  bool got = fgets(line, sizeof(line), f) != NULL;
  fclose(f);
  if (!got) return;
  char *phase = strchr(line, '|');
  if (!phase) return;
  *phase++ = '\0';
  if (strncmp(phase, "started|", 8) != 0) return;
  char tmp[64];
  snprintf(tmp, sizeof(tmp), "%s.tmp", FAILBACK_CONFIRM);
  f = fopen(tmp, "w");
  if (!f) return;
  fprintf(f, "%s\n", line);
  if (fclose(f) == 0) (void)rename(tmp, FAILBACK_CONFIRM);
}

/* Why this build is running instead of the one asked for: the note the script
 * wrote when it restored it.  Taken once. */
bool hub_update_failback_note(char *out, size_t out_size) {
  char line[256];
  out[0] = '\0';
  FILE *f = fopen(FAILBACK_STATE, "r");
  if (!f) return false;
  bool got = fgets(line, sizeof(line), f) != NULL;
  fclose(f);
  if (!got) return false;
  line[strcspn(line, "\r\n")] = '\0';
  char *phase = strchr(line, '|');
  if (!phase) return false;
  phase++;
  if (strncmp(phase, "restored|", 9) != 0 &&
      strncmp(phase, "failback-gave-up|", 17) != 0)
    return false;
  char *note = strrchr(phase, '|');
  if (!note || !note[1]) return false;
  snprintf(out, out_size, "%s", note + 1);
  remove(FAILBACK_STATE);
  return true;
}

/* ---- Production crontab line --------------------------------------------
 * An instance's keepalive line, tagged "# <product>:production:<dir>:".  Off
 * unless a hub says otherwise, and only ever this one tagged line: everything
 * else in the crontab is read and left alone.  The script runs as a child, so a
 * slow crontab never holds up the event loop. */
static pid_t g_cron_pid = 0;
static time_t g_cron_started = 0, g_cron_next = 0, g_cron_stat = 0;
static int g_cron_wanted = -1;  /* -1 no hub has said, 0 off, 1 on */
static char g_cron_status[CRON_STATUS_MAX + 1] = ""; /* the presence/tree field cap */
static bool g_cron_ours = false;

static const char *cron_helper_run_arg(const char *exe, const char **fail) {
  *fail = NULL;
  if (g_cron_wanted == 1 && access(HUB_PASS_FILE, F_OK) != 0) {
    *fail = "no .irchub.pass";
    return NULL;
  }
  if (!failback_write(CRON_HELPER, exe, "", true, HUB_CONFIG_FILE, HUB_PID_FILE, HUB_UPGRADE_SCRIPT, "",
                      CRON_HELPER)) {
    *fail = "cannot write here";
    return NULL;
  }
  return g_cron_wanted == 1 ? "cron-on" : g_cron_wanted == 0 ? "cron-off" : "cron-status";
}

static void cron_note(int rc, time_t now) {
  char next[sizeof(g_cron_status)];
  g_cron_ours = rc == 0;
  if (rc == 0) snprintf(next, sizeof(next), "yes");
  else if (rc == 10) snprintf(next, sizeof(next), "manual");
  else if (rc == 11 || (rc == 3 && g_cron_wanted != 1)) snprintf(next, sizeof(next), "no");
  else if (rc == 3) snprintf(next, sizeof(next), "failed:no crontab tool");
  else if (rc == 4) snprintf(next, sizeof(next), "failed:unsafe path");
  else if (rc == CRON_RC_BUSY) snprintf(next, sizeof(next), "busy");
  else snprintf(next, sizeof(next), "failed:cannot read crontab");
  snprintf(g_cron_status, sizeof(g_cron_status), "%s", next);
  /* Ours: look at the stamp in this same pass, so a host whose cron is dead
   * stays "silent" instead of reading "yes" for a minute after every check. */
  g_cron_stat = g_cron_ours ? 0 : now;
  /* Another node held the lock: soon, not in an hour, and never later than an
   * order that arrived meanwhile has already asked for. */
  if (rc == CRON_RC_BUSY) {
    time_t at = now + CRON_BUSY_RETRY_MIN +
                (time_t)(((unsigned long)getpid() * 2654435761UL + (unsigned long)now) %
                         CRON_BUSY_RETRY_SPAN);
    if (at < g_cron_next) g_cron_next = at;
  }
}

/* The helper's work files are .upgrade.cron.<its pid>.*: a helper that was
 * killed could not remove them, and they hold a copy of the crontab. */
static void cron_work_rm(pid_t pid) {
  char pre[48];
  int n = snprintf(pre, sizeof(pre), ".upgrade.cron.%ld.", (long)pid);
  if (n <= 0 || n >= (int)sizeof(pre)) return;
  DIR *d = opendir(".");
  if (!d) return;
  struct dirent *e;
  while ((e = readdir(d)) != NULL)
    if (strncmp(e->d_name, pre, (size_t)n) == 0) (void)unlink(e->d_name);
  closedir(d);
}

/* Kill the helper and whatever it started (a hung crontab, a sleep): it leads
 * a process group of its own. */
static void cron_helper_kill(pid_t pid) {
  if (kill(-pid, SIGKILL) != 0) kill(pid, SIGKILL);
}

/* What hub_update_cron_tick last found: yes, silent, manual, no, busy or failed:<why>. */
const char *hub_update_cron_status(void) { return g_cron_status; }

/* When the next look at the line is due (0 = at once). */
time_t hub_update_cron_next(void) { return g_cron_next; }

/* A hub's order. */
void hub_update_cron_set(bool on) {
  int want = on ? 1 : 0;
  if (want != g_cron_wanted) g_cron_next = 0;
  g_cron_wanted = want;
}

/* True when the status changed, so the hub should hear it. */
bool hub_update_cron_tick(const char *exe) {
  time_t now = time(NULL);
  char before[sizeof(g_cron_status)];
  snprintf(before, sizeof(before), "%s", g_cron_status);
  if (g_cron_pid > 0) {
    int st = 0;
    pid_t r = waitpid(g_cron_pid, &st, WNOHANG);
    if (r == 0) {
      if (now - g_cron_started > CRON_HELPER_TIMEOUT) cron_helper_kill(g_cron_pid);
      return false;
    }
    cron_work_rm(g_cron_pid);
    g_cron_pid = 0;
    remove(CRON_HELPER);
    cron_note(r > 0 && WIFEXITED(st) ? WEXITSTATUS(st) : 1, now);
  }
  if (now >= g_cron_next && exe && exe[0]) {
    const char *fail = NULL;
    const char *arg = cron_helper_run_arg(exe, &fail);
    if (!arg) {
      snprintf(g_cron_status, sizeof(g_cron_status), "failed:%s", fail);
      g_cron_next = now + CRON_CHECK_SECS;
    } else {
      pid_t pid = fork();
      if (pid == 0) {
        (void)setpgid(0, 0);
        for (int fd = 3; fd < 1024; fd++) close(fd);
        execl("./" CRON_HELPER, "./" CRON_HELPER, arg, (char *)NULL);
        _exit(127);
      }
      if (pid > 0) {
        (void)setpgid(pid, pid);
        g_cron_pid = pid;
        g_cron_started = now;
      } else {
        remove(CRON_HELPER);
        snprintf(g_cron_status, sizeof(g_cron_status), "failed:cannot start the helper");
      }
      /* Set before it finishes: an order that arrives meanwhile clears this, and
       * must not be overwritten when this child ends. */
      g_cron_next = now + CRON_CHECK_SECS;
    }
  }
  /* The line stamps .cron.seen each time it runs: no stamp, no cron daemon. */
  if (g_cron_ours && now - g_cron_stat >= 60) {
    struct stat cs;
    g_cron_stat = now;
    bool quiet = stat(".cron.seen", &cs) != 0 || now - cs.st_mtime > CRON_SILENT_SECS;
    snprintf(g_cron_status, sizeof(g_cron_status), "%s", quiet ? "silent" : "yes");
  }
  return strcmp(before, g_cron_status) != 0;
}

/* A keepalive line can fire while an upgrade installs, when no daemon holds the
 * pid lock.  Starting the old build then would make the new one refuse to start,
 * so a start waits that out.  A stale file past its limits stops nothing. */
bool hub_update_install_in_progress(void) {
  char line[256];
  FILE *f = fopen(FAILBACK_STATE, "r");
  if (!f) return false;
  bool got = fgets(line, sizeof(line), f) != NULL;
  fclose(f);
  if (!got) return false;
  char *phase = strchr(line, '|');
  if (!phase || strncmp(phase + 1, "installing|", 11) != 0) return false;
  long long since = 0, pid = 0;
  if (sscanf(phase + 12, "%lld|%lld", &since, &pid) != 2 || pid <= 0) return false;
  if (time(NULL) - since > UPGRADE_BUILD_SECS + 60) return false;
  return kill((pid_t)pid, 0) == 0;
}


/* ---- Rollback -----------------------------------------------------------
 * Put back the binary and config an upgrade retained, then restart onto them.
 * Used for CMD_UPGRADE_ABORT: by the time it arrives the new build is already
 * the running process, so undoing it means another exec. */
bool hub_update_rollback(hub_state_t *state, const char *reason) {
  if (!state || !state->executable_path[0]) return false;
  char prev_exe[PATH_MAX + 8], prev_cfg[PATH_MAX];
  if (snprintf(prev_exe, sizeof(prev_exe), "%s%s", state->executable_path,
               HUB_UPGRADE_PREV_SUFFIX) >= (int)sizeof(prev_exe) ||
      snprintf(prev_cfg, sizeof(prev_cfg), "%s%s", HUB_CONFIG_FILE,
               HUB_UPGRADE_PREV_SUFFIX) >= (int)sizeof(prev_cfg))
    return false;
  if (access(prev_exe, X_OK) != 0) {
    hub_log_error("[UPGRADE] Rollback requested (%s) but no retained binary\n",
            reason ? reason : "no reason given");
    return false;
  }

  hub_log_warning("[UPGRADE] Rolling back to the retained build: %s\n",
          reason ? reason : "the upgrade was aborted");
  /* Config first: if the restart races us, the old binary must not come up
   * against a config only the newer build understands. */
  bool cfg_restored = false;
  if (access(prev_cfg, R_OK) == 0) {
    cfg_restored = (rename(prev_cfg, HUB_CONFIG_FILE) == 0);
    if (!cfg_restored)
      hub_log_error("[UPGRADE] Could not restore %s; keeping the current one\n",
              prev_cfg);
  }
  if (rename(prev_exe, state->executable_path) != 0) {
    hub_log_error("[UPGRADE] Could not restore %s\n", prev_exe);
    return false;
  }
  remove(HUB_UPGRADE_MARKER_FILE);
  failback_clear();

  /* Not over a restored config: it is the retained build's own file, and
   * this build would write it in its format (2.5.0+: a PBKDF2 count older
   * builds cannot read).  What changed since comes back from the peers. */
  if (!cfg_restored) hub_config_write(state);
  if (state->pid_fd >= 0) close(state->pid_fd);
  remove(HUB_PID_FILE);
  sleep(1);
  hub_update_close_fds_for_exec();
  execl(state->executable_path, state->executable_path, (char *)NULL);
  exit(1); /* exec of the restored build failed; the log is already closed */
}

#ifdef HAVE_CURL

/* ---- Fetch --------------------------------------------------------------
 * Same libcurl usage as the bot's updater, including the two settings that
 * matter: peer and host verification stay on, always. */
typedef struct {
  char *buffer;
  size_t size;
} hub_http_response_t;

/* curl 7.85 replaced the bitmask protocol options with string ones and marked
 * the old pair deprecated; Rocky 8's 7.61 has only the bitmask.  Pick at
 * compile time so both build warning-free.  HTTP/1.1 only: a static build
 * links Alpine's libcurl with HTTP/2 and HTTP/3 compiled in, and pinning the
 * version keeps that code (nghttp2/nghttp3) unreachable — the Rust updater's
 * ureq speaks HTTP/1.1 alone.  No Accept-Encoding is ever set, so brotli /
 * zstd / gzip decoding never runs either; IDN only runs for a non-ASCII host,
 * which validate_url never lets through. */
#if LIBCURL_VERSION_NUM >= 0x075500
#define UPDATER_SET_PROTOCOLS(h)                                               \
  do {                                                                         \
    curl_easy_setopt((h), CURLOPT_PROTOCOLS_STR, "https,file");                \
    curl_easy_setopt((h), CURLOPT_REDIR_PROTOCOLS_STR, "https");               \
    curl_easy_setopt((h), CURLOPT_HTTP_VERSION, (long)CURL_HTTP_VERSION_1_1);  \
  } while (0)
#else
#define UPDATER_SET_PROTOCOLS(h)                                               \
  do {                                                                         \
    curl_easy_setopt((h), CURLOPT_PROTOCOLS, CURLPROTO_HTTPS | CURLPROTO_FILE);\
    curl_easy_setopt((h), CURLOPT_REDIR_PROTOCOLS, CURLPROTO_HTTPS);           \
    curl_easy_setopt((h), CURLOPT_HTTP_VERSION, (long)CURL_HTTP_VERSION_1_1);  \
  } while (0)
#endif

static size_t write_callback(void *contents, size_t size, size_t nmemb,
                             void *userp) {
  size_t realsize = size * nmemb;
  hub_http_response_t *mem = (hub_http_response_t *)userp;
  /* Bound the reply: a manifest is a few KB, and an unbounded realloc loop on
   * a hostile or broken server is a memory-exhaustion hole. */
  if (mem->size + realsize + 1 > HUB_UPDATE_MAX_MANIFEST) return 0;

  char *ptr = realloc(mem->buffer, mem->size + realsize + 1);
  if (!ptr) return 0;
  mem->buffer = ptr;
  memcpy(&mem->buffer[mem->size], contents, realsize);
  mem->size += realsize;
  mem->buffer[mem->size] = '\0';
  return realsize;
}

/* An archive download, counted: CURLOPT_MAXFILESIZE_LARGE only sees a
 * declared Content-Length on older curl (Rocky 8). */
typedef struct {
  FILE *fp;
  curl_off_t n;
} capped_file_t;

static size_t write_file_callback(void *ptr, size_t size, size_t nmemb, void *userp) {
  capped_file_t *cf = (capped_file_t *)userp;
  size_t real = size * nmemb;
  if (cf->n + (curl_off_t)real > (curl_off_t)HUB_UPDATE_MAX_ARCHIVE) return 0;
  cf->n += (curl_off_t)real;
  return fwrite(ptr, 1, real, cf->fp);
}

/* A statically linked release binary carries the CA-bundle path of the distro
 * it was built on (Alpine: /etc/ssl/certs/ca-certificates.crt), which RHEL /
 * Rocky / Fedora do not have — every https fetch would then fail closed.  If
 * that compiled-in bundle is missing here, point curl at the first readable
 * bundle this host does have.  A distro-built (dynamic) libcurl's default is
 * right for its own host and is left alone.  Peer verification stays on
 * either way; this only chooses which trust store it uses. */
static void hub_update_set_ca(CURL *h) {
#if LIBCURL_VERSION_NUM >= 0x074600 /* 7.70: curl_version_info()->cainfo */
  static const char *const bundles[] = {
      "/etc/ssl/certs/ca-certificates.crt",               /* Debian/Ubuntu/Alpine */
      "/etc/pki/tls/certs/ca-bundle.crt",                 /* RHEL/Rocky/Fedora    */
      "/etc/pki/ca-trust/extracted/pem/tls-ca-bundle.pem", /* RHEL (extracted)     */
      "/etc/ssl/ca-bundle.pem",                           /* openSUSE             */
      "/etc/ssl/cert.pem",                                /* Alpine/BSD           */
  };
  const curl_version_info_data *vi = curl_version_info(CURLVERSION_NOW);
  if (vi && vi->age >= CURLVERSION_SEVENTH && vi->cainfo &&
      access(vi->cainfo, R_OK) == 0)
    return;
  for (size_t i = 0; i < sizeof(bundles) / sizeof(bundles[0]); i++) {
    if (access(bundles[i], R_OK) == 0) {
      curl_easy_setopt(h, CURLOPT_CAINFO, bundles[i]);
      return;
    }
  }
#else
  (void)h;
#endif
}

/* Manifest reads made from the event loop (a PREPARE answer, the admin console
 * release list) run on a short budget: the hub serves nothing while curl
 * blocks, and a peer link that misses its pings is a worse outcome than a
 * node answering "unable: manifest fetch failed".  0 = the full budget, for
 * COMMIT, which is about to restart the process anyway. */
static long g_fetch_quick = 0;

static void curl_common(CURL *h, const char *url) {
  curl_easy_setopt(h, CURLOPT_URL, url);
  curl_easy_setopt(h, CURLOPT_USERAGENT, "irchub-updater/1.0");
  curl_easy_setopt(h, CURLOPT_FOLLOWLOCATION, 1L);
  curl_easy_setopt(h, CURLOPT_SSL_VERIFYPEER, 1L);
  curl_easy_setopt(h, CURLOPT_SSL_VERIFYHOST, 2L);
  curl_easy_setopt(h, CURLOPT_CONNECTTIMEOUT, g_fetch_quick ? 5L : 30L);
  curl_easy_setopt(h, CURLOPT_TIMEOUT,
                   g_fetch_quick ? g_fetch_quick : HUB_UPDATE_FETCH_TIMEOUT);
  /* Fail-closed transport: a 404 page is not a manifest.  Without
   * FAILONERROR curl reports CURLE_OK for a 4xx/5xx and hands the error body
   * to the caller, so a missing release tree arrives as a signature failure
   * rather than a clean "not found".  The protocol allow-list keeps a
   * redirect from walking the updater onto any other scheme curl was built
   * with. */
  curl_easy_setopt(h, CURLOPT_FAILONERROR, 1L);
  UPDATER_SET_PROTOCOLS(h);
  hub_update_set_ca(h);
}

static bool fetch_url(const char *url, hub_http_response_t *response) {
  CURL *h = curl_easy_init();
  if (!h) return false;
  response->buffer = malloc(1);
  response->size = 0;
  if (!response->buffer) {
    curl_easy_cleanup(h);
    return false;
  }
  response->buffer[0] = '\0';
  curl_common(h, url);
  curl_easy_setopt(h, CURLOPT_WRITEFUNCTION, write_callback);
  curl_easy_setopt(h, CURLOPT_WRITEDATA, (void *)response);
  CURLcode res = curl_easy_perform(h);
  curl_easy_cleanup(h);
  return res == CURLE_OK;
}

/* A stage reports how far it has got in the note of its status line: "72%" while it
 * fetches, "40% 18 of 45 files" while make runs, "~60% 120 of 200 crates" while cargo
 * runs, whose crates differ too much in size for more than an estimate. */
static void stage_say(const char *phase, const char *code, const char *note);
static bool g_stage_fetching = false;     /* in the stage child, during its download */
static const char *g_stage_build = NULL;  /* in the stage child, during its build */

static int stage_fetch_tick(void *data, curl_off_t total, curl_off_t now, curl_off_t ut,
                            curl_off_t un) {
  (void)data;
  (void)ut;
  (void)un;
  static int last = -1;
  static time_t said = 0;
  time_t t = time(NULL);
  if (total <= 0 || t - said < 2) return 0;
  int pct = (int)(now * 100 / total);
  if (pct == last) return 0;
  last = pct;
  said = t;
  char note[16];
  snprintf(note, sizeof(note), "%d%%", pct);
  stage_say("fetching", "", note);
  return 0;
}

static bool download_file(const char *url, const char *outfile) {
  CURL *h = curl_easy_init();
  if (!h) return false;
  /* 0600 from the start: no world-readable window on a file we are about to
   * unpack and run. */
  int fd = open(outfile, O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0600);
  FILE *fp = (fd >= 0) ? fdopen(fd, "wb") : NULL;
  if (!fp) {
    if (fd >= 0) close(fd);
    curl_easy_cleanup(h);
    return false;
  }
  curl_common(h, url);
  capped_file_t cf = {fp, 0};
  curl_easy_setopt(h, CURLOPT_WRITEFUNCTION, write_file_callback);
  curl_easy_setopt(h, CURLOPT_WRITEDATA, &cf);
  curl_easy_setopt(h, CURLOPT_MAXFILESIZE_LARGE,
                   (curl_off_t)HUB_UPDATE_MAX_ARCHIVE);
  if (g_stage_fetching) {
    curl_easy_setopt(h, CURLOPT_XFERINFOFUNCTION, stage_fetch_tick);
    curl_easy_setopt(h, CURLOPT_NOPROGRESS, 0L);
  }
  CURLcode res = curl_easy_perform(h);
  curl_easy_cleanup(h);
  bool ok = (fclose(fp) == 0) && res == CURLE_OK;
  if (!ok) remove(outfile);
  return ok;
}

static bool verify_sha256(const char *filepath, const char *expected_hash) {
  unsigned char hash[EVP_MAX_MD_SIZE];
  unsigned int hash_len = 0;
  EVP_MD_CTX *ctx = EVP_MD_CTX_new();
  if (!ctx) return false;
  if (EVP_DigestInit_ex(ctx, EVP_sha256(), NULL) != 1) {
    EVP_MD_CTX_free(ctx);
    return false;
  }
  FILE *f = fopen(filepath, "rb");
  if (!f) {
    EVP_MD_CTX_free(ctx);
    return false;
  }
  unsigned char buf[4096];
  size_t n;
  bool ok = true;
  while ((n = fread(buf, 1, sizeof(buf), f)) > 0) {
    if (EVP_DigestUpdate(ctx, buf, n) != 1) {
      ok = false;
      break;
    }
  }
  if (ferror(f)) ok = false;
  fclose(f);
  if (ok) ok = (EVP_DigestFinal_ex(ctx, hash, &hash_len) == 1);
  EVP_MD_CTX_free(ctx);
  if (!ok || hash_len != 32) return false;

  char hex[65];
  for (unsigned i = 0; i < hash_len; i++)
    snprintf(hex + i * 2, 3, "%02x", hash[i]);
  return strcasecmp(hex, expected_hash) == 0;
}

/* ---- URL and filename gates --------------------------------------------
 * Test hook, compiled in only with -DIRC_TEST_HOOKS (the testnet's builds;
 * never a release or a plain `make`): a non-empty IRCHUB_UPDATE_BASE
 * overrides the compiled release root so the sandbox can read a local
 * irchub-releases tree over file://, validate_url accepts URLs under it, and
 * IRCHUB_UPDATE_PUBKEY / IRCHUB_BOT_RELEASE_BASE are read alongside it.  A
 * production binary has no code that reads any of them: its roots and key
 * are the compiled-in ones, so nobody who can set the daemon's environment
 * can point it at their own signed releases. */
#ifdef IRC_TEST_HOOKS
static const char *hub_update_env_base(void) {
  const char *b = getenv("IRCHUB_UPDATE_BASE");
  return (b && b[0]) ? b : NULL;
}
#else
static const char *hub_update_env_base(void) { return NULL; }
#endif

/* The hub release root: the operator's env override, else the compiled-in
 * root.  `root`, when given, is a tree the caller names explicitly (the bots'
 * ircbot-releases root, for the roll-up and the release list). */
static const char *effective_root(const char *root) {
  if (root && root[0]) return root;
  const char *e = hub_update_env_base();
  return e ? e : HUB_UPDATE_BASE;
}

/* The bots' release root, for reading their manifest (roll-up stepping and
 * the console's release list).  IRCHUB_BOT_RELEASE_BASE repoints it, but only
 * alongside IRCHUB_UPDATE_BASE — the same sandbox gate as the test key — so
 * a production hub always reads the compiled-in tree. */
const char *hub_update_bot_root(void) {
#ifdef IRC_TEST_HOOKS
  const char *b = getenv("IRCHUB_BOT_RELEASE_BASE");
  if (hub_update_env_base() && b && b[0]) return b;
#endif
  return HUB_BOT_RELEASE_BASE;
}

/* An https:// URL whose host is exactly github.com, githubusercontent.com or
 * a subdomain of it (raw. for manifests; downloads redirect to objects.).
 * "Contains github.com" let https://evil.example/github.com through; userinfo
 * (github.com@evil.example) is refused outright. */
static bool url_host_trusted(const char *url) {
  if (strncmp(url, "https://", 8) != 0) return false;
  const char *h = url + 8;
  size_t n = strcspn(h, "/:?#@");
  if (h[n] == '@') return false;
  static const char gh[] = "github.com", ghu[] = "githubusercontent.com";
  if (n == sizeof(gh) - 1 && strncasecmp(h, gh, n) == 0) return true;
  if (n == sizeof(ghu) - 1 && strncasecmp(h, ghu, n) == 0) return true;
  return n > sizeof(ghu) && h[n - sizeof(ghu)] == '.' &&
         strncasecmp(h + n - (sizeof(ghu) - 1), ghu, sizeof(ghu) - 1) == 0;
}

static bool validate_url(const char *url) {
  if (!url) return false;
  /* Reject shell metacharacters regardless of source. */
  if (strpbrk(url, ";|&`$")) return false;
  const char *ebase = hub_update_env_base();
  if (ebase && strncmp(url, ebase, strlen(ebase)) == 0) return true;
  return url_host_trusted(url);
}

/* Keep [A-Za-z0-9._-]; the result must end in ".tar.gz". */
static bool sanitize_filename(const char *input, char *out, size_t out_size) {
  if (!input || !out || out_size == 0) return false;
  size_t o = 0;
  for (const char *p = input; *p && o + 1 < out_size; p++) {
    if (isalnum((unsigned char)*p) || *p == '.' || *p == '_' || *p == '-')
      out[o++] = *p;
  }
  out[o] = '\0';
  size_t len = strlen(out);
  return len >= 8 && strcmp(out + len - 7, ".tar.gz") == 0;
}

/* ---- Manifest ----------------------------------------------------------- */

/* Fetch releases.txt and its detached signature and verify one against the
 * other before any field in the manifest is trusted. */
static char *fetch_verified_manifest(const char *base, const char **err) {
  *err = NULL;

  /* Pinned key.  Only a test-hooks build (see hub_update_env_base) takes a
   * throwaway key from IRCHUB_UPDATE_PUBKEY, and only alongside
   * IRCHUB_UPDATE_BASE. */
  const char *pubkey_b64 = HUB_UPDATE_PUBKEY_B64;
#ifdef IRC_TEST_HOOKS
  if (hub_update_env_base()) {
    const char *ep = getenv("IRCHUB_UPDATE_PUBKEY");
    if (ep && ep[0]) pubkey_b64 = ep;
  }
#endif
  if (pubkey_b64[0] == '\0') {
    *err = "hub updater disabled (no signing key configured)";
    return NULL;
  }

  int publen = 0;
  unsigned char *pub = base64_decode(pubkey_b64, &publen);
  if (!pub || publen != 32) {
    free(pub);
    *err = "configured update public key is malformed";
    return NULL;
  }

  char man_url[1024], sig_url[1024];
  if (snprintf(man_url, sizeof(man_url), "%s/releases.txt", base) >=
          (int)sizeof(man_url) ||
      snprintf(sig_url, sizeof(sig_url), "%s/releases.sig", base) >=
          (int)sizeof(sig_url)) {
    free(pub);
    *err = "release base URL too long";
    return NULL;
  }

  hub_http_response_t man = {NULL, 0};
  if (!fetch_url(man_url, &man)) {
    free(pub);
    free(man.buffer);
    *err = "failed to download release manifest";
    return NULL;
  }

  hub_http_response_t sig = {NULL, 0};
  if (!fetch_url(sig_url, &sig)) {
    free(pub);
    free(man.buffer);
    free(sig.buffer);
    *err = "failed to download release signature";
    return NULL;
  }

  int siglen = 0;
  unsigned char *sigbytes = base64_decode(sig.buffer, &siglen);
  bool ok = (sigbytes && siglen == 64 &&
             hub_crypto_ed25519_verify(pub, (const unsigned char *)man.buffer,
                                       man.size, sigbytes));
  free(pub);
  free(sigbytes);
  free(sig.buffer);

  if (!ok) {
    free(man.buffer);
    *err = "release manifest signature INVALID — possible tampering";
    return NULL;
  }
  return man.buffer; /* verified manifest; caller frees */
}

/* One artifact row.  Columns 1-5 are the format ircbot's original updater
 * parses; 6-9 were appended for the network upgrade and are absent from older
 * manifests, which is why they default to a source build that fits anything. */
typedef struct {
  char version[64];
  char url[512];
  char hash[128];
  char deps[256];
  char kind[8];      /* bin | src        */
  char arch[32];     /* x86_64 | any     */
  char libc[16];     /* gnu | musl | any */
  char min_from[64]; /* oldest version this may upgrade FROM; '*' = any */
  char cpu[256];     /* CPU features it needs, "-" = none (column 10)   */
  unsigned long long size; /* archive + unpacked bytes (column 11), 0 = unknown */
  char libc_min[16]; /* a gnu row's minimum glibc (column 12), "-" = none */
  char needs[512];   /* a gnu row's libraries + versions (column 13), "-" = none */
} hub_manifest_row_t;

/* Candidates manifest_candidates() keeps per version: gnu, static, src, with
 * room for a manifest that lists more than one of a kind. */
#define MANIFEST_CANDIDATES_MAX 8

/* The variant whose tree manifest_select() is reading, for its reasons. */
static const char *g_select_variant = NULL;

/* Is CPU feature `f` present, per /proc/cpuinfo ("flags" on x86_64,
 * "Features" on aarch64; "neon" is that file's "asimd")?  A host whose
 * cpuinfo cannot be read is not refused here: the staged -selftest and the
 * upgrade script's watchdog still stand between it and a build it cannot
 * run.  Mirrors ircbot/utils.c. */
static bool host_cpu_has(const char *f) {
  static char flags[8192];
  static bool loaded = false;
  if (!loaded) {
    loaded = true;
    FILE *fp = fopen("/proc/cpuinfo", "r");
    if (fp) {
      char line[8192];
      while (fgets(line, sizeof(line), fp)) {
        if (strncmp(line, "flags", 5) != 0 && strncmp(line, "Features", 8) != 0)
          continue;
        const char *colon = strchr(line, ':');
        if (!colon) continue;
        snprintf(flags, sizeof(flags), " %s", colon + 1);
        flags[strcspn(flags, "\r\n")] = '\0';
        size_t fl = strlen(flags);
        if (fl + 1 < sizeof(flags)) {
          flags[fl] = ' ';
          flags[fl + 1] = '\0';
        }
        break;
      }
      fclose(fp);
    }
  }
  if (!flags[0]) return true;
  if (strcmp(f, "neon") == 0) f = "asimd";
  char needle[80];
  snprintf(needle, sizeof(needle), " %s ", f);
  return strstr(flags, needle) != NULL;
}

/* The first CPU feature a row's column 10 names that this host lacks, or
 * NULL.  Entries are comma-separated; "arch:feature" applies only on that
 * arch. */
static const char *row_cpu_missing(const hub_manifest_row_t *r) {
  static char miss[64];
  if (!r->cpu[0] || strcmp(r->cpu, "-") == 0) return NULL;
  char arch[32];
  hub_update_host_arch(arch, sizeof(arch));
  char work[256];
  snprintf(work, sizeof(work), "%s", r->cpu);
  char *save = NULL;
  for (char *e = strtok_r(work, ",", &save); e; e = strtok_r(NULL, ",", &save)) {
    const char *feat = e;
    char *colon = strchr(e, ':');
    if (colon) {
      *colon = '\0';
      if (strcasecmp(e, arch) != 0) continue;
      feat = colon + 1;
    }
    if (!feat[0] || host_cpu_has(feat)) continue;
    snprintf(miss, sizeof(miss), "%s", feat);
    return miss;
  }
  return NULL;
}

/* `why` (may be NULL) says what does not fit.  A binary row with libc "any"
 * is a static Linux build: only Linux hosts (gnu / musl) take it.  A gnu row
 * whose libc_min is newer than this host's known glibc is skipped without a
 * download; an unknown glibc (a static build asking) leaves it to -selftest. */
static bool row_fits_host(const hub_manifest_row_t *r, char *why, size_t why_size) {
  char arch[32], libc[16];
  hub_update_host_arch(arch, sizeof(arch));
  hub_update_host_libc(libc, sizeof(libc));
  if (why && why_size) why[0] = '\0';
  if (strcmp(r->arch, "any") != 0 && strcasecmp(r->arch, arch) != 0) {
    if (why) snprintf(why, why_size, "no artifact for this host arch/libc");
    return false;
  }
  bool linux_host = strcmp(libc, "gnu") == 0 || strcmp(libc, "musl") == 0;
  bool bin = strcasecmp(r->kind, "bin") == 0;
  if (strcmp(r->libc, "any") == 0 ? (bin && !linux_host) : strcasecmp(r->libc, libc) != 0) {
    if (why) snprintf(why, why_size, "no artifact for this host arch/libc");
    return false;
  }
  const char *g = host_glibc();
  if (bin && strcasecmp(r->libc, "gnu") == 0 && g && r->libc_min[0] && strcmp(r->libc_min, "-") != 0 &&
      hub_update_version_cmp(g, r->libc_min) < 0) {
    if (why) snprintf(why, why_size, "this host's glibc %s is older than the gnu build's %s", g, r->libc_min);
    return false;
  }
  /* Column 13: every library the gnu build needs, with the versions it
   * requires, present here — read from the host's own files, nothing
   * downloaded (plan §4a). */
  char miss[320];
  if (bin && strcmp(r->libc, "any") != 0 && !en_check(r->needs, miss, sizeof(miss))) {
    if (why) snprintf(why, why_size, "the gnu build needs %s", miss);
    return false;
  }
  return true;
}

/* A candidate's rank: the host's own libc's build first (gnu: distro-patched
 * shared libraries), then the static Linux build, then source. */
static int row_rank(const hub_manifest_row_t *r) {
  if (strcasecmp(r->kind, "bin") != 0) return 2;
  return strcmp(r->libc, "any") == 0 ? 1 : 0;
}

/* What a candidate is called in logs: gnu, static or src. */
static const char *row_label(const hub_manifest_row_t *r) {
  int k = row_rank(r);
  return k == 0 ? "gnu" : k == 1 ? "static" : "src";
}

/* Every artifact for `version` this host can take, best first (row_rank: the
 * host's own libc's build, the static build, source; manifest order within a
 * rank) into rows[0..max).  `manifest` is consumed (strtok_r), and `reason`
 * explains an empty result.  The caller tries them in turn: the first whose
 * download, hash and -selftest pass is installed (plan §2).
 *
 * Build dependencies are NOT checked here as the bot's updater does: the hub
 * has no dependency prober, and a source build that cannot compile fails in
 * the stage or the upgrade script, which restores the retained binary — see
 * write_upgrade_script. */
static int manifest_candidates(char *manifest, const char *version, hub_manifest_row_t *rows,
                               int max, char *reason, size_t reason_size) {
  int n = 0;
  snprintf(reason, reason_size, "requested version is not in the manifest");
  char *saveptr = NULL;
  for (char *line = strtok_r(manifest, "\n", &saveptr); line;
       line = strtok_r(NULL, "\n", &saveptr)) {
    if (line[0] == '#' || line[0] == '\0') continue;
    hub_manifest_row_t row;
    memset(&row, 0, sizeof(row));
    char date[64];
    snprintf(row.kind, sizeof(row.kind), "src");
    snprintf(row.arch, sizeof(row.arch), "any");
    snprintf(row.libc, sizeof(row.libc), "any");
    snprintf(row.min_from, sizeof(row.min_from), "*");
    snprintf(row.cpu, sizeof(row.cpu), "-");
    snprintf(row.libc_min, sizeof(row.libc_min), "-");
    snprintf(row.needs, sizeof(row.needs), "-");
    int f = sscanf(line, "%63s %63s %511s %127s %255s %7s %31s %15s %63s %255s %llu %15s %511s",
                   row.version, date, row.url, row.hash, row.deps, row.kind,
                   row.arch, row.libc, row.min_from, row.cpu, &row.size, row.libc_min, row.needs);
    if (f < 5) continue;
    if (!version_eq(row.version, version)) continue;
    if (!validate_url(row.url)) {
      snprintf(reason, reason_size, "untrusted artifact URL in manifest");
      continue;
    }
    char nofit[400];
    if (!row_fits_host(&row, nofit, sizeof(nofit))) {
      snprintf(reason, reason_size, "%s", nofit);
      continue;
    }
    const char *lacks = row_cpu_missing(&row);
    if (lacks) {
      snprintf(reason, reason_size, "this CPU lacks %s, which the %s build needs",
               lacks, g_select_variant ? g_select_variant : hub_update_host_variant());
      continue;
    }
    if (strcmp(row.min_from, "*") != 0 &&
        hub_update_version_cmp(HUB_VERSION, row.min_from) < 0) {
      snprintf(reason, reason_size,
               "running version is below the artifact's min_from %s",
               row.min_from);
      continue;
    }
    if (n >= max) continue;
    /* Insert after every row of the same or a better rank (stable). */
    int at = n;
    while (at > 0 && row_rank(&rows[at - 1]) > row_rank(&row)) {
      rows[at] = rows[at - 1];
      at--;
    }
    rows[at] = row;
    n++;
  }
  if (n) reason[0] = '\0';
  return n;
}

/* The best candidate alone (the checks that only need to know one fits). */
static bool manifest_select(char *manifest, const char *version,
                            hub_manifest_row_t *out, char *reason,
                            size_t reason_size) {
  hub_manifest_row_t rows[MANIFEST_CANDIDATES_MAX];
  int n = manifest_candidates(manifest, version, rows, MANIFEST_CANDIDATES_MAX, reason, reason_size);
  if (n > 0) *out = rows[0];
  return n > 0;
}

/* The checks that need no network: version order, variant, min_from and the
 * unattended-restart password file.  Same version is only "already running"
 * when the variant matches too — a different variant is a switch between
 * the C and Rust builds, which is exactly what an admin's "name=rs" asks. */
static bool can_take_local(const char *target_ver, const char *want_variant,
                           const char *min_from, char *reason,
                           size_t reason_size) {
  if (!target_ver || !target_ver[0]) {
    snprintf(reason, reason_size, "no target version");
    return false;
  }
  int cmp = hub_update_version_cmp(target_ver, HUB_VERSION);
  bool same_variant = strcmp(want_variant, hub_update_host_variant()) == 0;
  if (cmp == 0 && same_variant) {
    snprintf(reason, reason_size, "already running the target version");
    return false;
  }
  if (cmp < 0) {
    snprintf(reason, reason_size, "target is older than the running version");
    return false;
  }
  if (min_from && min_from[0] && strcmp(min_from, "*") != 0 &&
      hub_update_version_cmp(HUB_VERSION, min_from) < 0) {
    snprintf(reason, reason_size,
             "running version is below the target's min_from");
    return false;
  }
  /* An unattended restart needs the machine-bound password file; without it
   * the new binary would stop at a password prompt with nobody to answer. */
  if (access(HUB_PASS_FILE, R_OK) != 0) {
    snprintf(reason, reason_size,
             "no " HUB_PASS_FILE "; cannot restart unattended");
    return false;
  }
  return true;
}

/* <root>/<variant> for a hub release tree, or false when it does not fit or
 * carries anything that could split a URL or a shell word. */
static bool release_tree(const char *variant, char *out, size_t out_size) {
  const char *root = effective_root(NULL);
  if (strlen(root) >= 512 || strpbrk(root, ";|&`$ \t\r\n")) return false;
  if (!variant || !variant[0] || strlen(variant) > 7 ||
      strpbrk(variant, "/;|&`$ \t\r\n"))
    return false;
  return snprintf(out, out_size, "%s/%s", root, variant) < (int)out_size;
}

/* Is `target` a version this hub could move to?  Answered at PREPARE time,
 * and it answers everything COMMIT will need short of the download itself:
 * the signed manifest for the wanted variant must verify and list an
 * artifact that fits this host.  A node that says "ready" here and then
 * cannot fetch its artifact at COMMIT is what turns a routine run into an
 * abort, so the question is asked in full up front.  `min_from` is what the
 * driving hub sent; an empty or "*" value means the manifest decides. */
/* ---- Preflight (PREPARE) -----------------------------------------------
 * Can this host take the build at all?  Asked before anything changes, so a
 * full disk or a read-only directory is an "unable" with a reason an admin
 * can act on, not a failed restart.  Each reason starts with a fixed code
 * word (disk:, dir:, exe:, exec:, tool:, net:).  Only a probe file is
 * written, and it is gone again before this returns.  The instance dir is the
 * cwd: instance_dir_enter() put us there. */
#ifndef ST_NOEXEC
#define ST_NOEXEC 8 /* Linux: glibc hides it without _GNU_SOURCE */
#endif

static bool preflight_tool(const char *name) {
  const char *path = getenv("PATH");
  char work[1024], full[1100];
  snprintf(work, sizeof(work), "%s", path && path[0] ? path : "/usr/bin:/bin");
  char *save = NULL;
  for (char *d = strtok_r(work, ":", &save); d; d = strtok_r(NULL, ":", &save)) {
    snprintf(full, sizeof(full), "%s/%s", d, name);
    if (access(full, X_OK) == 0) return true;
  }
  return false;
}

static bool preflight_dir_probe(char *reason, size_t reason_size, const char *dir) {
  const char *probe = ".upgrade.probe", *moved = ".upgrade.probe2";
  int fd = open(probe, O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0600);
  bool ok = fd >= 0 && write(fd, "x", 1) == 1 && fsync(fd) == 0;
  int err = errno;
  if (fd >= 0) close(fd);
  if (ok && rename(probe, moved) != 0) {
    ok = false;
    err = errno;
  }
  (void)unlink(probe);
  (void)unlink(moved);
  if (!ok)
    snprintf(reason, reason_size, "dir: cannot write %.160s: %s", dir, strerror(err));
  return ok;
}

/* The binary must be ours, and not immutable: a hard link fails on that where
 * a rename could not be tried without moving it.  A filesystem with no hard
 * links at all still passes: it is a different errno. */
static bool preflight_exe(const char *exe, char *reason, size_t reason_size) {
  struct stat st;
  if (stat(exe, &st) != 0) {
    snprintf(reason, reason_size, "exe: cannot read %.160s: %s", exe, strerror(errno));
    return false;
  }
  if (st.st_uid != geteuid()) {
    snprintf(reason, reason_size, "exe: cannot replace %.160s: owned by another user", exe);
    return false;
  }
  const char *probe = ".upgrade.probe3";
  (void)unlink(probe);
  int rc = link(exe, probe);
  int err = errno;
  (void)unlink(probe);
  if (rc != 0 && (err == EPERM || err == EACCES)) {
    snprintf(reason, reason_size, "exe: cannot replace %.160s: %s", exe, strerror(err));
    return false;
  }
  return true;
}

/* Everything the swap will write, plus a margin.  A manifest row without the
 * size column gets a fixed allowance; a source build always gets one on top,
 * for its objects. */
static bool preflight_space(const char *dir, const char *exe, const char *cfg,
                            unsigned long long size,
                            bool is_bin, const char *variant, char *reason,
                            size_t reason_size) {
  struct statvfs sv;
  if (statvfs(".", &sv) != 0) return true; /* unknown: the stage will tell */
  if (sv.f_flag & ST_NOEXEC) {
    snprintf(reason, reason_size, "exec: %.160s is mounted noexec", dir);
    return false;
  }
  if (sv.f_files > 0 && sv.f_favail < UPGRADE_MIN_INODES) {
    snprintf(reason, reason_size, "disk: no free inodes in %.160s", dir);
    return false;
  }
  unsigned long long need = size;
  if (!need) need = is_bin ? UPGRADE_SPACE_BIN_DEFAULT : 0;
  if (!is_bin)
    need += strcmp(variant, "rs") == 0 ? UPGRADE_SPACE_BUILD_RS : UPGRADE_SPACE_BUILD_C;
  struct stat st;
  if (stat(cfg, &st) == 0 && st.st_size > 0) need += (unsigned long long)st.st_size;
  if (stat(exe, &st) == 0 && st.st_size > 0) need += (unsigned long long)st.st_size;
  need += UPGRADE_SPACE_MARGIN;
  unsigned long long have = (unsigned long long)sv.f_bavail * sv.f_frsize;
  if (have < need) {
    snprintf(reason, reason_size, "disk: needs %llu MB in %.160s, has %llu MB",
             need / (1024 * 1024) + 1, dir, have / (1024 * 1024));
    return false;
  }
  return true;
}

/* HEAD on the artifact.  A server that does not do HEAD says nothing either
 * way, so it passes and the download decides. */
static bool preflight_artifact(const char *url, char *reason, size_t reason_size) {
  CURL *h = curl_easy_init();
  if (!h) return true;
  g_fetch_quick = HUB_UPDATE_QUICK_TIMEOUT;
  curl_common(h, url);
  g_fetch_quick = 0;
  /* curl_common fails a 4xx at once; the code is still there to read below. */
  curl_easy_setopt(h, CURLOPT_NOBODY, 1L);
  CURLcode res = curl_easy_perform(h);
  long code = 0;
  curl_easy_getinfo(h, CURLINFO_RESPONSE_CODE, &code);
  curl_easy_cleanup(h);
  const char *slash = strrchr(url, '/');
  const char *name = slash ? slash + 1 : url;
  if (code >= 400) {
    if (code == 405 || code == 501) return true;
    snprintf(reason, reason_size, "net: %ld from %.120s", code, name);
    return false;
  }
  if (res != CURLE_OK) {
    snprintf(reason, reason_size, "net: cannot reach %.120s: %s", name, curl_easy_strerror(res));
    return false;
  }
  return true;
}

static bool preflight_host(const char *exe, const char *cfg, const char *url,
                           unsigned long long size, const char *kind,
                           const char *variant, char *reason, size_t reason_size) {
  char dir[512];
  if (!getcwd(dir, sizeof(dir))) snprintf(dir, sizeof(dir), ".");
  bool is_bin = strcasecmp(kind, "bin") == 0;
  if (!preflight_space(dir, exe, cfg, size, is_bin, variant, reason, reason_size)) return false;
  if (!preflight_dir_probe(reason, reason_size, dir)) return false;
  if (!preflight_exe(exe, reason, reason_size)) return false;
  if (access("/bin/bash", X_OK) != 0) {
    snprintf(reason, reason_size, "tool: /bin/bash not found");
    return false;
  }
  if (!preflight_tool("tar")) {
    snprintf(reason, reason_size, "tool: tar not found");
    return false;
  }
  return preflight_artifact(url, reason, reason_size);
}

bool hub_update_can_take(const char *target_ver, const char *variant,
                         const char *min_from, char *reason,
                         size_t reason_size) {
  if (reason && reason_size) reason[0] = '\0';
  const char *want_variant =
      (variant && variant[0]) ? variant : hub_update_host_variant();
  if (!can_take_local(target_ver, want_variant, min_from, reason, reason_size))
    return false;

  char tree[600];
  if (!release_tree(want_variant, tree, sizeof(tree))) {
    snprintf(reason, reason_size, "rejected malformed manifest base or variant");
    return false;
  }
  const char *verr = NULL;
  g_fetch_quick = HUB_UPDATE_QUICK_TIMEOUT;
  char *manifest = fetch_verified_manifest(tree, &verr);
  g_fetch_quick = 0;
  if (!manifest) {
    snprintf(reason, reason_size, "%s", verr ? verr : "manifest fetch failed");
    return false;
  }
  hub_manifest_row_t row;
  memset(&row, 0, sizeof(row));
  g_select_variant = want_variant;
  bool picked = manifest_select(manifest, target_ver, &row, reason, reason_size);
  free(manifest);
  if (!picked) {
    /* Can't run this build here — would the other one?  Say so, never
     * switch: which build a node runs is the admin's call. */
    const char *other = strcmp(want_variant, "c") == 0 ? "rs" : "c";
    char otree[600], why_other[320];
    if (strncmp(reason, "this CPU lacks ", 15) == 0 &&
        release_tree(other, otree, sizeof(otree))) {
      g_fetch_quick = HUB_UPDATE_QUICK_TIMEOUT;
      char *om = fetch_verified_manifest(otree, &verr);
      g_fetch_quick = 0;
      if (om) {
        hub_manifest_row_t orow;
        memset(&orow, 0, sizeof(orow));
        g_select_variant = other;
        bool fits = manifest_select(om, target_ver, &orow, why_other,
                                    sizeof(why_other));
        free(om);
        if (fits) {
          size_t rl = strlen(reason);
          snprintf(reason + rl, reason_size - rl,
                   " — the %s build fits: select this node with =%s", other,
                   other);
        }
      }
    }
    g_select_variant = NULL;
    return false;
  }
  g_select_variant = NULL;
  if (strncmp(strrchr(row.url, '/') ? strrchr(row.url, '/') + 1 : row.url,
              "irchub-", 7) != 0) {
    snprintf(reason, reason_size, "manifest artifact is not a irchub release");
    return false;
  }
  char exe[PATH_MAX];
  ssize_t el = readlink("/proc/self/exe", exe, sizeof(exe) - 1);
  if (el <= 0) return true; /* unknown: the commit's own check will say */
  exe[el] = '\0';
  return preflight_host(exe, HUB_CONFIG_FILE, row.url, row.size, row.kind,
                        want_variant, reason, reason_size);
}

/* List the distinct versions a release tree offers, newest first — what
 * the admin console shows so an admin picks a version instead of typing one.  The
 * manifest is signature-verified like any other read of it; an unverifiable
 * one lists nothing. */
int hub_update_list_releases(const char *root, const char *variant,
                             hub_release_t *out, int max, const char **err) {
  *err = NULL;
  char tree[600];
  if (!root || !root[0]) root = effective_root(NULL);
  if (strlen(root) >= 512 ||
      strpbrk(root, ";|&`$ \t\r\n") || !variant || !variant[0] ||
      strlen(variant) > 7 || strpbrk(variant, "/;|&`$ \t\r\n") ||
      snprintf(tree, sizeof(tree), "%s/%s", root, variant) >= (int)sizeof(tree)) {
    *err = "malformed release base";
    return -1;
  }
  g_fetch_quick = HUB_UPDATE_QUICK_TIMEOUT;
  char *manifest = fetch_verified_manifest(tree, err);
  g_fetch_quick = 0;
  if (!manifest) return -1;

  int n = 0;
  char *saveptr = NULL;
  for (char *line = strtok_r(manifest, "\n", &saveptr); line;
       line = strtok_r(NULL, "\n", &saveptr)) {
    if (line[0] == '#' || line[0] == '\0') continue;
    char version[64] = "", date[16] = "";
    if (sscanf(line, "%63s %15s", version, date) != 2) continue;
    if (strpbrk(version, "|;&`$")) continue;
    bool dup = false;
    for (int i = 0; i < n && !dup; i++)
      dup = hub_update_version_cmp(out[i].version, version) == 0;
    if (dup) continue;
    if (n >= max) {
      /* Full: keep the newest `max` — replace the oldest if this is newer. */
      int oldest = 0;
      for (int i = 1; i < n; i++)
        if (hub_update_version_cmp(out[i].version, out[oldest].version) < 0)
          oldest = i;
      if (hub_update_version_cmp(version, out[oldest].version) <= 0) continue;
      snprintf(out[oldest].version, sizeof(out[oldest].version), "%s", version);
      snprintf(out[oldest].date, sizeof(out[oldest].date), "%s", date);
      continue;
    }
    snprintf(out[n].version, sizeof(out[n].version), "%s", version);
    snprintf(out[n].date, sizeof(out[n].date), "%s", date);
    n++;
  }
  free(manifest);
  /* Newest first (insertion sort: n is tiny). */
  for (int i = 1; i < n; i++) {
    hub_release_t t = out[i];
    int j = i - 1;
    while (j >= 0 && hub_update_version_cmp(out[j].version, t.version) < 0) {
      out[j + 1] = out[j];
      j--;
    }
    out[j + 1] = t;
  }
  return n;
}

/* ---- Install ----------------------------------------------------------- */

/* Byte-copy with an explicit mode.  Used for the config snapshot, where the
 * original must stay in place (the binary is renamed instead). */
static bool copy_file(const char *src, const char *dst, mode_t mode) {
  int in = open(src, O_RDONLY | O_CLOEXEC);
  if (in < 0) return false;
  int out = open(dst, O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, mode);
  if (out < 0) {
    close(in);
    return false;
  }
  char buf[8192];
  bool ok = true;
  ssize_t n;
  while ((n = read(in, buf, sizeof(buf))) > 0) {
    ssize_t off = 0;
    while (off < n) {
      ssize_t w = write(out, buf + off, (size_t)(n - off));
      if (w <= 0) {
        ok = false;
        break;
      }
      off += w;
    }
    if (!ok) break;
  }
  if (n < 0) ok = false;
  if (ok && fsync(out) != 0) ok = false;
  close(in);
  if (close(out) != 0) ok = false;
  if (!ok) remove(dst);
  return ok;
}

/* ---- Staging -------------------------------------------------------------
 * Get the new build ready and proven while the old one keeps running.  A child
 * does the work under STAGE_DIR and writes one status line after each phase; the
 * event loop reads it and tells the hub.  COMMIT then only swaps a file.  Nothing
 * here touches <exe>, and everything here is gone again if no COMMIT comes. */
#define STAGE_DIR ".upgrade.stage"

/* The process group of the command run_bounded runs now: in the stage child,
 * the build (make or cargo and every compiler under it).  stage_term takes it
 * down when the stage is stopped. */
static volatile sig_atomic_t g_build_pgid = 0;


static pid_t g_stage_pid = 0;
static char g_stage_id[64] = "", g_stage_ver[64] = "";
static char g_stage_phase[16] = "", g_stage_code[16] = "", g_stage_note[192] = "";
static time_t g_stage_started = 0, g_stage_said = 0, g_stage_done = 0;
static bool g_stage_ready = false;

#define STAGE_ASIDE STAGE_DIR ".old."

/* Remove `dir` without waiting for it: a grandchild runs the rm, so init reaps
 * it and the event loop does not sit through a cargo target/ tree.  If that
 * cannot start, the old bounded wait. */
static void stage_rm_detached(const char *dir) {
  pid_t c = fork();
  if (c == 0) {
    pid_t g = fork();
    if (g == 0) {
      long maxfd = sysconf(_SC_OPEN_MAX);
      if (maxfd < 0 || maxfd > 65536) maxfd = 65536;
      for (int fd = 3; fd < maxfd; fd++) close(fd);
      execl("/bin/rm", "rm", "-rf", dir, (char *)NULL);
      _exit(127);
    }
    _exit(g > 0 ? 0 : 1);
  }
  int st = 0;
  if (c > 0 && waitpid(c, &st, 0) == c && WIFEXITED(st) && WEXITSTATUS(st) == 0) return;
  const char *rm[] = {"/bin/rm", "-rf", dir, NULL};
  run_bounded(rm, 30, NULL, 0);
}

/* The stage directory goes at once: renamed aside (so a new stage can start in
 * a clean one straight away, and nothing still writing lands in it), then
 * removed in the background. */
static void stage_rm(void) {
  if (access(STAGE_DIR, F_OK) != 0) return;
  static unsigned n = 0;
  char aside[96];
  snprintf(aside, sizeof(aside), STAGE_ASIDE "%ld.%u", (long)getpid(), ++n);
  if (rename(STAGE_DIR, aside) == 0) {
    stage_rm_detached(aside);
    return;
  }
  const char *rm[] = {"/bin/rm", "-rf", STAGE_DIR, NULL};
  run_bounded(rm, 30, NULL, 0);
}

/* In the child: one line, atomically, for the parent to read. */
static void stage_say(const char *phase, const char *code, const char *note) {
  char clean[192];
  snprintf(clean, sizeof(clean), "%s", note ? note : "");
  for (char *c = clean; *c; c++)
    if (*c == '|' || *c == '\r' || *c == '\n') *c = ' ';
  FILE *f = fopen(STAGE_DIR "/status.tmp", "w");
  if (!f) return;
  fprintf(f, "%s|%s|%s\n", phase, code ? code : "", clean);
  if (fclose(f) == 0) (void)rename(STAGE_DIR "/status.tmp", STAGE_DIR "/status");
}

/* Files make has compiled so far: a top-level .c with its object in place. */
static void stage_count_c(const char *dir, int *total, int *done) {
  static const char *const where[] = {"", "build/", "build/obj/", "obj/"};
  DIR *d = opendir(dir);
  if (!d) return;
  struct dirent *e;
  while ((e = readdir(d)) != NULL) {
    size_t n = strlen(e->d_name);
    if (n < 3 || n > 200 || strcmp(e->d_name + n - 2, ".c") != 0) continue;
    (*total)++;
    for (size_t i = 0; i < sizeof(where) / sizeof(where[0]); i++) {
      char obj[512];
      snprintf(obj, sizeof(obj), "%s/%s%.*s.o", dir, where[i], (int)(n - 2), e->d_name);
      if (access(obj, F_OK) == 0) {
        (*done)++;
        break;
      }
    }
  }
  closedir(d);
}

/* Crates cargo has got to, against the packages its lock file names. */
static void stage_count_crates(const char *dir, int *total, int *done) {
  char path[512], line[64];
  snprintf(path, sizeof(path), "%s/Cargo.lock", dir);
  FILE *f = fopen(path, "r");
  if (!f) return;
  while (fgets(line, sizeof(line), f))
    if (strncmp(line, "[[package]]", 11) == 0) (*total)++;
  fclose(f);
  snprintf(path, sizeof(path), "%s/target/release/.fingerprint", dir);
  DIR *d = opendir(path);
  if (!d) return;
  struct dirent *e;
  while ((e = readdir(d)) != NULL)
    if (e->d_name[0] != '.') (*done)++;
  closedir(d);
}

/* From run_bounded's loop: at most one look every 5 s, and a word only on a change. */
static void stage_build_tick(void) {
  static time_t said = 0;
  static char last[64] = "";
  if (!g_stage_build) return;
  time_t t = time(NULL);
  if (t - said < 5) return;
  said = t;
  char path[512], note[64];
  int total = 0, done = 0;
  snprintf(path, sizeof(path), "%s/Cargo.toml", g_stage_build);
  bool crates = access(path, R_OK) == 0;
  if (crates) stage_count_crates(g_stage_build, &total, &done);
  else stage_count_c(g_stage_build, &total, &done);
  if (total <= 0) return;
  if (done > total) done = total;
  int pct = done * 100 / total;
  if (pct > 99) pct = 99;
  snprintf(note, sizeof(note), "%s%d%% %d of %d %s", crates ? "~" : "", pct, done, total,
           crates ? "crates" : "files");
  if (strcmp(note, last) == 0) return;
  snprintf(last, sizeof(last), "%s", note);
  stage_say("building", "src", note);
}

static void stage_fail(const char *code, const char *note) {
  stage_say("failed", code, note);
  _exit(1);
}

/* The whole job, in the child. */
/* One candidate, in the stage child: fetch, verify, unpack, build (source),
 * -selftest, and keep it as STAGE_DIR/new.  False with *code / why on any
 * failure, after removing what it laid down, so the next candidate starts
 * clean. */
static bool stage_one(const hub_manifest_row_t *row, const char **code, char *why, size_t why_size) {
  bool is_bin = strcasecmp(row->kind, "bin") == 0;
  const char *archive = STAGE_DIR "/archive.tar.gz";
  const char *bdir = STAGE_DIR "/build";
  const char *rmb[] = {"/bin/rm", "-rf", bdir, archive, NULL};
  run_bounded(rmb, 60, NULL, 0);
#define STAGE_NO(c, ...)                         \
  do {                                           \
    *code = (c);                                 \
    snprintf(why, why_size, __VA_ARGS__);        \
    run_bounded(rmb, 60, NULL, 0);               \
    return false;                                \
  } while (0)
  g_stage_fetching = true;
  bool fetched = download_file(row->url, archive);
  g_stage_fetching = false;
  if (!fetched) STAGE_NO("net", "artifact download failed");
  stage_say("verifying", is_bin ? "bin" : "src", "");
  if (!verify_sha256(archive, row->hash)) STAGE_NO("hash", "artifact SHA-256 mismatch");
  if (mkdir(bdir, 0700) != 0) STAGE_NO("dir", "could not make the build directory");
  char out[256] = "";
  const char *tar[] = {"/bin/tar", "-xzf", archive, "--strip-components=1", "-C", bdir, NULL};
  if (access("/bin/tar", X_OK) != 0) tar[0] = "/usr/bin/tar";
  if (run_bounded(tar, 120, out, sizeof(out)) != 0)
    STAGE_NO("archive", "could not unpack the artifact");
  char bin[256];
  snprintf(bin, sizeof(bin), "%s/irchub", bdir);
  if (!is_bin) {
    stage_say("building", "src", "");
    g_stage_build = bdir;
    char cargo[256];
    snprintf(cargo, sizeof(cargo), "%s/Cargo.toml", bdir);
    int rc;
    if (access(cargo, R_OK) == 0) {
      const char *cb[] = {"cargo", "build", "--release", "--manifest-path", cargo, NULL};
      rc = run_bounded(cb, UPGRADE_BUILD_SECS - 60, out, sizeof(out));
      snprintf(bin, sizeof(bin), "%s/target/release/irchub", bdir);
    } else {
      const char *mk[] = {"make", "-C", bdir, NULL};
      rc = run_bounded(mk, UPGRADE_BUILD_SECS - 60, out, sizeof(out));
      snprintf(bin, sizeof(bin), "%s/bin/irchub", bdir);
      if (access(bin, F_OK) != 0) snprintf(bin, sizeof(bin), "%s/irchub", bdir);
    }
    g_stage_build = NULL;
    if (rc < 0) STAGE_NO("build", "the build ran past its limit");
    if (rc != 0 || access(bin, F_OK) != 0) STAGE_NO("build", "the build failed: %.200s", out);
  }
  if (access(bin, F_OK) != 0) STAGE_NO("archive", "the artifact holds no irchub binary");
  (void)chmod(bin, 0700);
  stage_say("testing", is_bin ? "bin" : "src", "");
  const char *st[] = {bin, "-selftest", NULL};
  int rc = run_bounded(st, UPGRADE_SELFTEST_SECS, out, sizeof(out));
  if (rc != 0)
    STAGE_NO("selftest", "new build failed its selftest: %.200s",
             out[0] ? out : (rc < 0 ? "timed out" : "it exited with an error"));
  if (rename(bin, STAGE_DIR "/new") != 0) STAGE_NO("dir", "could not keep the staged build");
#undef STAGE_NO
  run_bounded(rmb, 60, NULL, 0);
  return true;
}

/* The whole job, in the child: every candidate in turn (gnu, static, src —
 * plan docs/plans/2026-11-20_artifact_choice_plan.md §2) until one builds
 * and passes its -selftest here. */
static void stage_child(const char *ver, const char *variant, const char *exe) {
  (void)exe;
  char why[320] = "";
  /* A run names no variant unless the admin chose one: this host's own, as at PREPARE. */
  if (!variant || !variant[0]) variant = hub_update_host_variant();
  stage_say("fetching", "", "");
  char tree[600];
  if (!release_tree(variant, tree, sizeof(tree))) stage_fail("net", "rejected malformed manifest base or variant");
  const char *verr = NULL;
  char *manifest = fetch_verified_manifest(tree, &verr);
  if (!manifest) {
    const char *t = verr ? verr : "manifest fetch failed";
    stage_fail(strstr(t, "signature") ? "sig" : "net", t);
  }
  hub_manifest_row_t rows[MANIFEST_CANDIDATES_MAX];
  g_select_variant = variant;
  int n = manifest_candidates(manifest, ver, rows, MANIFEST_CANDIDATES_MAX, why, sizeof(why));
  free(manifest);
  if (n <= 0) stage_fail("build", why[0] ? why : "no usable artifact");
  const char *code = "build";
  /* What failed before the build that is staged: the "staged" note carries
   * it ("static; the gnu build: <why>"), since the "trying" notes in between
   * can be overwritten before the daemon reads them.  As ircbot. */
  char fell[192] = "";
  for (int i = 0; i < n; i++) {
    if (stage_one(&rows[i], &code, why, sizeof(why))) {
      char note[sizeof(fell) + 8];
      snprintf(note, sizeof(note), "%s%s", row_label(&rows[i]), fell);
      stage_say("staged", strcasecmp(rows[i].kind, "bin") == 0 ? "bin" : "src", note);
      _exit(0);
    }
    if (i + 1 < n) {
      char note[400];
      snprintf(note, sizeof(note), "the %s build: %.300s; trying the %s build", row_label(&rows[i]),
               why, row_label(&rows[i + 1]));
      stage_say("fetching", "", note);
      size_t used = strlen(fell);
      if (used + 1 < sizeof(fell))
        snprintf(fell + used, sizeof(fell) - used, "; the %s build: %.120s", row_label(&rows[i]), why);
    }
  }
  stage_fail(code, why);
}

/* The stage child's SIGTERM (a stop, or the daemon's death): the build's group
 * goes first, then the child.  Only async-signal-safe calls. */
static void stage_term(int sig) {
  (void)sig;
  pid_t g = (pid_t)g_build_pgid;
  if (g > 0) kill(-g, SIGKILL);
  _exit(1);
}

/* Stop a stage child and its build: SIGTERM lets it take the build down with
 * it (stage_term); what is still there after a second is killed outright. */
static void stage_stop(pid_t pid) {
  if (kill(-pid, SIGTERM) != 0) kill(pid, SIGTERM);
  for (int i = 0; i < 20; i++) {
    if (waitpid(pid, NULL, WNOHANG) != 0) return;
    struct timespec t = {0, 50 * 1000 * 1000};
    nanosleep(&t, NULL);
  }
  if (kill(-pid, SIGKILL) != 0) kill(pid, SIGKILL);
  (void)waitpid(pid, NULL, 0);
}

/* A hub's STAGE.  Starting again for the same build is a no-op, so a repeat costs
 * nothing. */
void hub_update_stage_start(const char *exe, const char *id, const char *ver, const char *variant) {
  if (g_stage_id[0] && strcmp(g_stage_id, id) == 0 && (g_stage_pid > 0 || g_stage_ready)) return;
  hub_update_stage_clear();
  stage_rm();
  snprintf(g_stage_id, sizeof(g_stage_id), "%s", id);
  snprintf(g_stage_ver, sizeof(g_stage_ver), "%s", ver);
  snprintf(g_stage_phase, sizeof(g_stage_phase), "fetching");
  g_stage_code[0] = g_stage_note[0] = '\0';
  g_stage_started = time(NULL);
  g_stage_said = 0;
  if (mkdir(STAGE_DIR, 0700) != 0) {
    snprintf(g_stage_phase, sizeof(g_stage_phase), "failed");
    snprintf(g_stage_code, sizeof(g_stage_code), "dir");
    snprintf(g_stage_note, sizeof(g_stage_note), "could not make %s", STAGE_DIR);
    return;
  }
  pid_t parent = getpid();
  pid_t pid = fork();
  if (pid == 0) {
    /* A group of its own, and its own SIGTERM: the daemon's handler only sets
     * a flag nothing here reads, so without this the death signal and a stop
     * would be swallowed and the build would run on. */
    (void)setpgid(0, 0);
    signal(SIGTERM, stage_term);
    signal(SIGINT, stage_term);
    long maxfd = sysconf(_SC_OPEN_MAX);
    if (maxfd < 0 || maxfd > 65536) maxfd = 65536;
    for (int fd = 3; fd < maxfd; fd++) close(fd);
    /* It goes when the daemon goes: a stage belongs to one process. */
    (void)prctl(PR_SET_PDEATHSIG, SIGTERM);
    if (getppid() != parent) _exit(1); /* the daemon went before prctl */
    /* A fresh process for the stage: none of the daemon's memory (keys, the
     * config password), threads or library locks come along.  The running
     * build, not whatever is on disk at exe now; the group, the death signal,
     * the closed fds and the working directory carry over the exec. */
    const char *v = variant ? variant : "";
    const char *a0 = exe && exe[0] ? exe : "irchub";
    execl("/proc/self/exe", a0, "-stage", ver, v, (char *)NULL);
    if (exe && exe[0]) execl(exe, a0, "-stage", ver, v, (char *)NULL);
    stage_say("failed", "exec", "could not start the stage");
    _exit(1);
  }
  if (pid < 0) {
    snprintf(g_stage_phase, sizeof(g_stage_phase), "failed");
    snprintf(g_stage_code, sizeof(g_stage_code), "fork");
    snprintf(g_stage_note, sizeof(g_stage_note), "could not start the stage");
    return;
  }
  (void)setpgid(pid, pid);
  g_stage_pid = pid;
}

void hub_update_stage_clear(void) {
  if (g_stage_pid > 0) {
    stage_stop(g_stage_pid);
    g_stage_pid = 0;
  }
  if (g_stage_id[0]) stage_rm();
  g_stage_id[0] = g_stage_phase[0] = '\0';
  g_stage_ready = false;
}

/* True when the hub should hear: "phase|code|note" in out, with the run's id. */
bool hub_update_stage_tick(char *id, size_t id_size, char *out, size_t out_size) {
  if (!g_stage_id[0]) return false;
  time_t now = time(NULL);
  bool changed = false;
  if (g_stage_pid > 0) {
    /* Reap first: once the child is gone its status file is final, so a
     * stage that says "staged" and exits between the two is not lost. */
    int st = 0;
    pid_t r = waitpid(g_stage_pid, &st, WNOHANG);
    char line[256];
    FILE *f = fopen(STAGE_DIR "/status", "r");
    if (f) {
      if (fgets(line, sizeof(line), f)) {
        line[strcspn(line, "\r\n")] = '\0';
        char *c1 = strchr(line, '|');
        char *c2 = c1 ? strchr(c1 + 1, '|') : NULL;
        if (c1 && c2) {
          *c1 = *c2 = '\0';
          if (strcmp(g_stage_phase, line) != 0) changed = true;
          snprintf(g_stage_phase, sizeof(g_stage_phase), "%.15s", line);
          snprintf(g_stage_code, sizeof(g_stage_code), "%.15s", c1 + 1);
          snprintf(g_stage_note, sizeof(g_stage_note), "%.191s", c2 + 1);
        }
      }
      fclose(f);
    }
    if (r != 0) {
      g_stage_pid = 0;
      if (strcmp(g_stage_phase, "staged") == 0 && access(STAGE_DIR "/new", X_OK) == 0) {
        g_stage_ready = true;
        g_stage_done = now;
      } else if (strcmp(g_stage_phase, "failed") != 0) {
        snprintf(g_stage_phase, sizeof(g_stage_phase), "failed");
        snprintf(g_stage_code, sizeof(g_stage_code), "stopped");
        snprintf(g_stage_note, sizeof(g_stage_note), "the stage stopped before it finished");
      }
      changed = true;
    } else if (now - g_stage_started > UPGRADE_BUILD_SECS) {
      stage_stop(g_stage_pid);
      g_stage_pid = 0;
      snprintf(g_stage_phase, sizeof(g_stage_phase), "failed");
      snprintf(g_stage_code, sizeof(g_stage_code), "limit");
      snprintf(g_stage_note, sizeof(g_stage_note), "the stage ran past its limit");
      changed = true;
    }
  }
  /* A failed stage holds nothing worth keeping, and the run may not come back to say so. */
  if (changed && g_stage_pid <= 0 && strcmp(g_stage_phase, "failed") == 0) stage_rm();
  if (g_stage_ready && now - g_stage_done > UPGRADE_STAGE_KEEP) {
    hub_update_stage_clear();
    return false;
  }
  /* A beat while it works: silence is how the driver tells a stage has died. */
  if (!changed && (g_stage_pid <= 0 || now - g_stage_said < UPGRADE_STAGE_BEAT)) {
    if (g_stage_said) return false;
  }
  g_stage_said = now;
  snprintf(id, id_size, "%s", g_stage_id);
  snprintf(out, out_size, "%s|%s|%s", g_stage_phase, g_stage_code, g_stage_note);
  return true;
}

/* -stage <ver> <variant>: the stage body in a process of its own, exec'd by
 * hub_update_stage_start's child.  It runs in the instance directory the
 * daemon left it in, before any config, password or pid lock is touched, and
 * only into the empty stage directory that daemon has just made: a hand-run
 * -stage, or one beside a live stage, is refused. */
int hub_update_stage_main(const char *ver, const char *variant) {
  struct stat sb;
  if (!ver || !ver[0] || strlen(ver) >= sizeof(g_stage_ver) || !variant ||
      lstat(STAGE_DIR, &sb) != 0 || !S_ISDIR(sb.st_mode) || sb.st_uid != getuid() ||
      access(STAGE_DIR "/status", F_OK) == 0) {
    fprintf(stderr, "-stage is the updater's own: a daemon runs it for its stage\n");
    return 1;
  }
  signal(SIGTERM, stage_term);
  signal(SIGINT, stage_term);
  stage_child(ver, variant, NULL);
  return 1; /* stage_child ends in _exit */
}

/* The last report could not be sent (no hub link, or the driver's peer link is
 * down): say the current state again on the next tick. */
void hub_update_stage_unsaid(void) { g_stage_said = 0; }

/* A stage belongs to one process: whatever a dead one left is rubbish. */
void hub_update_stage_boot_clean(void) {
  stage_rm();
  /* and what an earlier process had set aside but not finished removing */
  DIR *d = opendir(".");
  if (!d) return;
  struct dirent *e;
  while ((e = readdir(d)) != NULL)
    if (strncmp(e->d_name, STAGE_ASIDE, sizeof(STAGE_ASIDE) - 1) == 0) stage_rm_detached(e->d_name);
  closedir(d);
}

/* The staged build for this run, ready to swap in. */
static bool stage_ready_for(const char *id, const char *ver) {
  return g_stage_ready && strcmp(g_stage_id, id) == 0 && strcmp(g_stage_ver, ver) == 0 &&
         access(STAGE_DIR "/new", X_OK) == 0;
}

/* Write the upgrade script.  `kind` decides the middle of it: a prebuilt
 * binary is unpacked and moved into place, a source tarball is compiled
 * first.  Either way the previous binary stays at <exe>.prev — the driving
 * hub, not the script, decides whether to keep it. */
/* Run argv[0] with argv, stdout+stderr captured into `out` (first line
 * kept), killed after `timeout_s`.  Returns its exit status, or -1 when it
 * could not run or timed out.  No shell: every argument is passed as-is.
 * Mirrors ircbot/utils.c. */
static int run_bounded(const char *const argv[], int timeout_s, char *out,
                       size_t out_size) {
  if (out && out_size) out[0] = '\0';
  int pipefd[2];
  if (pipe(pipefd) != 0) return -1;
  pid_t pid = fork();
  if (pid < 0) {
    close(pipefd[0]);
    close(pipefd[1]);
    return -1;
  }
  if (pid == 0) {
    (void)setpgid(0, 0); /* its own group: a timeout kills what it started too */
    dup2(pipefd[1], STDOUT_FILENO);
    dup2(pipefd[1], STDERR_FILENO);
    int devnull = open("/dev/null", O_RDONLY);
    if (devnull >= 0) dup2(devnull, STDIN_FILENO);
    /* Nothing of this process leaks into the child: not the listener, not a
     * peer link, not the PID lock. */
    long maxfd = sysconf(_SC_OPEN_MAX);
    if (maxfd < 0 || maxfd > 65536) maxfd = 65536;
    for (int fd = 3; fd < maxfd; fd++) close(fd);
    /* execv() takes char *const[] for historical reasons only: POSIX never
     * writes through it, so the union passes the const array unchanged. */
    union { const char *const *ro; char *const *rw; } av = { .ro = argv };
    /* A bare name (make, cargo) is looked up on PATH, as the Rust port's Command does;
     * a path runs as given. */
    if (strchr(argv[0], '/')) execv(argv[0], av.rw);
    else execvp(argv[0], av.rw);
    _exit(127);
  }
  (void)setpgid(pid, pid);
  g_build_pgid = (sig_atomic_t)pid;
  close(pipefd[1]);
  fcntl(pipefd[0], F_SETFL, fcntl(pipefd[0], F_GETFL) | O_NONBLOCK);
  size_t got = 0;
  int status = 0;
  bool done = false;
  /* Short sleeps first: most commands (an rm, a tar of a small archive) end in
   * a few ms, and this can run on the event loop.  Then 100 ms steps. */
  long nap_ms = 1;
  for (long waited_ms = 0; waited_ms < (long)timeout_s * 1000; waited_ms += nap_ms,
            nap_ms = nap_ms < 100 ? (nap_ms * 2 > 100 ? 100 : nap_ms * 2) : 100) {
    char buf[256];
    ssize_t n;
    while ((n = read(pipefd[0], buf, sizeof(buf))) > 0) {
      if (out && got + 1 < out_size) {
        size_t take = (size_t)n < out_size - 1 - got ? (size_t)n : out_size - 1 - got;
        memcpy(out + got, buf, take);
        got += take;
        out[got] = '\0';
      }
    }
    stage_build_tick();
    if (waitpid(pid, &status, WNOHANG) == pid) {
      done = true;
      break;
    }
    struct timespec tick = {0, nap_ms * 1000 * 1000};
    nanosleep(&tick, NULL);
  }
  if (!done) {
    if (kill(-pid, SIGKILL) != 0) kill(pid, SIGKILL);
    waitpid(pid, &status, 0);
  }
  g_build_pgid = 0;
  close(pipefd[0]);
  if (out) out[strcspn(out, "\r\n")] = '\0';
  if (!done) return -1;
  return WIFEXITED(status) ? WEXITSTATUS(status) : -1;
}

/* Unpack `archive` into a scratch directory and run the binary in it with
 * -selftest, from this directory (so it reads this config and pass file).
 * Nothing live is touched either way; the scratch directory is removed. */
static bool staged_selftest(const char *archive, char *err, size_t err_size) {
  static const char *dir = "./irchub_selftest_tmp";
  const char *rm[] = {"/bin/rm", "-rf", dir, NULL};
  run_bounded(rm, 30, NULL, 0);
  if (mkdir(dir, 0700) != 0) {
    snprintf(err, err_size, "could not stage the new build for its selftest");
    return false;
  }
  char out[256];
  const char *tar[] = {"/bin/tar", "-xzf", archive, "--strip-components=1",
                       "-C", dir, NULL};
  if (access("/bin/tar", X_OK) != 0) tar[0] = "/usr/bin/tar";
  if (run_bounded(tar, 60, out, sizeof(out)) != 0) {
    run_bounded(rm, 30, NULL, 0);
    snprintf(err, err_size, "could not unpack the new build for its selftest");
    return false;
  }
  char bin[64];
  snprintf(bin, sizeof(bin), "%s/irchub", dir);
  const char *st[] = {bin, "-selftest", NULL};
  int rc = run_bounded(st, UPGRADE_SELFTEST_SECS, out, sizeof(out));
  run_bounded(rm, 30, NULL, 0);
  if (rc != 0) {
    if (out[0])
      snprintf(err, err_size, "new build failed its selftest: %.160s", out);
    else if (rc < 0)
      snprintf(err, err_size, "new build failed its selftest: timed out after %d s",
               UPGRADE_SELFTEST_SECS);
    else
      snprintf(err, err_size, "new build failed its selftest: exited with %d", rc);
    return false;
  }
  return true;
}

/* Lay the script down and put it in cron, before anything changes.  A host with
 * no usable cron still has the upgrade script's own loop: it loses only the
 * reboot cover, and says so. */
static bool failback_stage(const char *exe, const char *id, bool is_bin,
                           const char *cfg, const char *pidf, const char *script,
                           const char *note) {
  FILE *f;
  /* The state first: a tick that finds none takes the script away again, and
   * the previous upgrade's loop may still tick.  Its script, finding this
   * upgrade's state, leaves it be.  exec keeps this pid, so it already names
   * the upgrade script. */
  remove(FAILBACK_CONFIRM);
  f = fopen(FAILBACK_STATE ".tmp", "w");
  if (!f) return false;
  fprintf(f, "%s|installing|%lld|%d|\n", id, (long long)time(NULL), (int)getpid());
  if (fclose(f) != 0 || rename(FAILBACK_STATE ".tmp", FAILBACK_STATE) != 0) {
    remove(FAILBACK_STATE ".tmp");
    return false;
  }
  /* Then the script, whole or not at all: a tick never runs a half-written one. */
  if (!failback_write(FAILBACK_FILE ".tmp", exe, id, is_bin, cfg, pidf, script, note,
                      FAILBACK_FILE) ||
      rename(FAILBACK_FILE ".tmp", FAILBACK_FILE) != 0) {
    remove(FAILBACK_FILE ".tmp");
    remove(FAILBACK_STATE);
    return false;
  }
  return true;
}

/* The script removes itself only while the file is still its own: a later
 * upgrade may already have written its script there, and the hub is about to
 * exec it (nightly 2026-11-06: the earlier script, still waiting on its loop,
 * deleted the next one and that exec failed).  OLD_PID tells them apart: the
 * earlier script is alive while the next is written, so the pids differ. */
#define SELF_RM "grep -qx \"OLD_PID=$OLD_PID\" ./" HUB_UPGRADE_SCRIPT \
                " 2>/dev/null && rm -f ./" HUB_UPGRADE_SCRIPT

static bool write_upgrade_script(const hub_state_t *state, const char *kind,
                                 const char *archive, bool selftest) {
  /* 0700 at creation: no umask-dependent window on a script we are about to
   * exec. */
  /* Written beside and renamed over: a reader never sees half a script. */
  int fd = open(HUB_UPGRADE_SCRIPT ".tmp", O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC,
                0700);
  FILE *f = (fd >= 0) ? fdopen(fd, "w") : NULL;
  if (!f) {
    if (fd >= 0) close(fd);
    return false;
  }
  const char *exe = state->executable_path;
  bool is_bin = (strcasecmp(kind, "bin") == 0);
  bool is_staged = (strcasecmp(kind, "staged") == 0);

  fprintf(f, "#!/bin/bash\n");
  fprintf(f, "set -u\n");
  fprintf(f, "OLD_PID=%d\n", getpid());
  /* The hub execs this script, so OLD_PID is usually the script itself;
   * waiting on it would only burn 30 s of every restart. */
  fprintf(f, "for i in $(seq 1 30); do\n");
  fprintf(f, "  [ \"$OLD_PID\" = \"$$\" ] && break\n");
  fprintf(f, "  kill -0 $OLD_PID 2>/dev/null || break\n");
  fprintf(f, "  sleep 1\n");
  fprintf(f, "done\n");
  fprintf(f, "UPGRADE_DIR=\"./hub_build_tmp\"\n");
  fprintf(f, "rm -rf \"$UPGRADE_DIR\"\n");
  fprintf(f, "mkdir \"$UPGRADE_DIR\" || exit 1\n");
  /* One rollback path for every failure below: put <exe>.prev back and run
   * it, so a hub that cannot upgrade still comes back on the old build. */
  fprintf(f, "rollback() {\n");
  fprintf(f, "  echo \"[UPGRADE] FAILED: $1 — restoring previous build\"\n");
  fprintf(f, "  ./" FAILBACK_FILE " restore \"$1\"\n");
  fprintf(f, "  rm -rf \"$UPGRADE_DIR\" \"%s\"\n", archive);
  fprintf(f, "  wait\n");
  fprintf(f, "  %s\n", SELF_RM);
  fprintf(f, "  exit 0\n");
  fprintf(f, "}\n");
  /* The failback's loop runs through every phase, so a hung build or a new
   * build that never confirms is undone even with no cron on this host. */
  fprintf(f, "./" FAILBACK_FILE " phase installing $$\n");
  /* The loop names this upgrade, so it stops once a later one owns the script. */
  fprintf(f, "FB_ID=$(cut -d'|' -f1 <\"" FAILBACK_STATE "\" 2>/dev/null)\n");
  fprintf(f, "( while ./" FAILBACK_FILE " tick \"$FB_ID\"; do sleep 10; done ) </dev/null >/dev/null 2>&1 &\n");
  if (!is_staged)
  fprintf(f,
          "tar -xzf \"%s\" --strip-components=1 -C \"$UPGRADE_DIR\" "
          "2>/dev/null || rollback \"could not extract artifact\"\n",
          archive);

  if (is_staged) {
    /* Fetched, built and selftested while the old build ran: only the swap is left. */
    fprintf(f, "NEW_BIN=\"" STAGE_DIR "/new\"\n");
    fprintf(f, "[ -x \"$NEW_BIN\" ] || rollback \"the staged build is gone\"\n");
  } else if (is_bin) {
    /* Prebuilt: the tarball holds the binary itself, no toolchain needed.
     * No "run it once" probe — irchub has no --version flag and starting a
     * second instance would fight the one we are replacing for the pid lock.
     * The driving hub is the health monitor: it waits for this node to
     * reappear on the target version and aborts if it never does. */
    fprintf(f, "NEW_BIN=\"$UPGRADE_DIR/irchub\"\n");
    fprintf(f, "chmod 700 \"$NEW_BIN\" 2>/dev/null\n");
    fprintf(f, "[ -x \"$NEW_BIN\" ] || rollback \"artifact binary is not executable\"\n");
  } else {
    fprintf(f, "cd \"$UPGRADE_DIR\" || rollback \"build directory vanished\"\n");
    fprintf(f, "if [ -f Cargo.toml ]; then\n");
    fprintf(f, "  cargo build --release >build.log 2>&1\n");
    fprintf(f, "  BUILT=target/release/irchub\n");
    fprintf(f, "else\n");
    fprintf(f, "  make clean >/dev/null 2>&1\n");
    fprintf(f, "  make >make.log 2>&1\n");
    fprintf(f, "  BUILT=bin/irchub\n");
    fprintf(f, "  [ -f \"$BUILT\" ] || BUILT=irchub\n");
    fprintf(f, "fi\n");
    fprintf(f, "cd ..\n");
    fprintf(f, "NEW_BIN=\"$UPGRADE_DIR/$BUILT\"\n");
    fprintf(f, "[ -f \"$NEW_BIN\" ] || rollback \"build failed (see $UPGRADE_DIR)\"\n");
    /* A prebuilt binary was selftested before the swap; a source build can
     * only be checked here, once it exists. */
    if (selftest)
      fprintf(f, "\"$NEW_BIN\" -selftest >/dev/null 2>&1 || rollback \"new build failed its selftest\"\n");
  }

  /* Atomic same-directory rename into place; <exe> was already renamed to
   * <exe>.prev, which we keep for the run's rollback window. */
  fprintf(f, "mv -f \"$NEW_BIN\" \"%s\" || rollback \"could not install new binary\"\n", exe);
  fprintf(f, "chmod 700 \"%s\"\n", exe);
  fprintf(f, "rm -f \"%s\"\n", HUB_PID_FILE);
  fprintf(f, "rm -rf \"$UPGRADE_DIR\" \"%s\" 2>/dev/null\n", archive);
  /* From here the failback decides.  The marker stays either way, so a restored
   * build reports why on its first link. */
  fprintf(f, "rm -rf " STAGE_DIR " 2>/dev/null\n");
  fprintf(f, "./" FAILBACK_FILE " phase started $$\n");
  fprintf(f, "\"%s\" </dev/null >/dev/null 2>&1\n", exe);
  fprintf(f, "wait\n");
  fprintf(f, "%s\n", SELF_RM);
  fprintf(f, "exit 0\n");

  (void)fchmod(fileno(f), 0700);
  if (fclose(f) != 0 || rename(HUB_UPGRADE_SCRIPT ".tmp", HUB_UPGRADE_SCRIPT) != 0) {
    remove(HUB_UPGRADE_SCRIPT ".tmp");
    return false;
  }
  return true;
}

/* Run the upgrade this hub was committed to.  Returns false with *err set
 * when nothing was touched (the caller answers CMD_UPGRADE_RESULT fail and
 * stays on the current build); on success it does not return — the process is
 * replaced and reports in after the restart. */
bool hub_update_commit(hub_state_t *state, const char *upgrade_id,
                       const char *target_ver, const char *variant,
                       const char **err) {
  *err = NULL;
  if (!state || !upgrade_id || !target_ver) {
    *err = "malformed upgrade command";
    return false;
  }
  if (!state->executable_path[0]) {
    *err = "this hub does not know its own executable path";
    return false;
  }

  const char *want_variant =
      (variant && variant[0]) ? variant : hub_update_host_variant();
  if (strpbrk(want_variant, "/;|&`$ \t\r\n") || strlen(want_variant) > 7) {
    *err = "rejected malformed variant";
    return false;
  }
  static char why[320];
  if (!can_take_local(target_ver, want_variant, NULL, why, sizeof(why))) {
    *err = why[0] ? why : "cannot take this version";
    return false;
  }
  /* The driving hub names the release tree ROOT; the variant picks the
   * subtree.  That is what lets one run leave each node on its own kind of
   * build — and lets an admin move a hub from the C build to the Rust one. */
  const char *root = effective_root(NULL);
  if (strlen(root) >= 512 || strpbrk(root, ";|&`$ \t\r\n")) {
    *err = "rejected malformed manifest base";
    return false;
  }
  char tree[600];
  if (snprintf(tree, sizeof(tree), "%s/%s", root, want_variant) >=
      (int)sizeof(tree)) {
    *err = "manifest base too long";
    return false;
  }

  hub_log_info("[UPGRADE] Commit %s: %s -> %s (variant %s)\n", upgrade_id,
          HUB_VERSION, target_ver, want_variant);

  hub_manifest_row_t row;
  memset(&row, 0, sizeof(row));
  char archive[256] = "";
  bool staged = stage_ready_for(upgrade_id, target_ver);
  if (staged) {
    snprintf(row.kind, sizeof(row.kind), "staged");
    hub_log_info("[UPGRADE] Using the build staged for %s\n", target_ver);
  } else {
  hub_update_stage_clear();
  const char *verr = NULL;
  char *manifest = fetch_verified_manifest(tree, &verr);
  if (!manifest) {
    *err = verr ? verr : "manifest fetch failed";
    return false;
  }

  static char pick_why[320];
  hub_manifest_row_t cands[MANIFEST_CANDIDATES_MAX];
  g_select_variant = want_variant;
  int nc = manifest_candidates(manifest, target_ver, cands, MANIFEST_CANDIDATES_MAX, pick_why,
                               sizeof(pick_why));
  g_select_variant = NULL;
  free(manifest);
  if (nc <= 0) {
    *err = pick_why[0] ? pick_why : "no usable artifact";
    return false;
  }
  /* A target older than MESH_MIN_VERSION would be refused by every peer and bot. */
  if (hub_update_version_cmp(target_ver, MESH_MIN_VERSION) < 0) {
    *err = "target predates " MESH_MIN_VERSION ", the oldest the mesh links with";
    return false;
  }

  /* Every candidate in turn, best first (gnu, static, src: plan
   * docs/plans/2026-11-20_artifact_choice_plan.md §2): the first whose
   * download, hash and -selftest pass is the one.  A source build is checked
   * by the script. */
  static char last_err[400];
  bool have = false;
  for (int ci = 0; ci < nc && !have; ci++) {
    row = cands[ci];
    const char *slash = strrchr(row.url, '/');
    if (!sanitize_filename(slash ? slash + 1 : "irchub.tar.gz", archive,
                           sizeof(archive))) {
      *err = "artifact filename in manifest is not acceptable";
      return false;
    }
    /* Every release artifact is named "<product>-…tar.gz" (see the releases
     * repo README).  A base override that names the OTHER product's tree would
     * otherwise hand this daemon the wrong binary and install it over itself —
     * fail closed here instead, where nothing has been downloaded yet. */
    if (strncmp(archive, "irchub-", 7) != 0) {
      *err = "manifest artifact is not a irchub release";
      return false;
    }
    hub_log_info("[UPGRADE] Fetching the %s artifact %s\n", row_label(&row), archive);
    const char *no = NULL;
    static char st_err[320];
    if (!download_file(row.url, archive)) {
      no = "artifact download failed";
    } else if (!verify_sha256(archive, row.hash)) {
      no = "artifact SHA-256 mismatch";
    } else if (strcasecmp(row.kind, "bin") == 0) {
      /* Run the NEW binary's -selftest before anything is swapped: CPU,
       * libraries and this very config, checked by the build that would have
       * to run on them. */
      if (!staged_selftest(archive, st_err, sizeof(st_err))) no = st_err;
      else hub_log_info("[UPGRADE] Staged %s (%s) passed its selftest\n", target_ver, row_label(&row));
    }
    if (!no) {
      have = true;
      break;
    }
    remove(archive);
    snprintf(last_err, sizeof(last_err), "the %s build: %s", row_label(&row), no);
    if (ci + 1 < nc)
      hub_log_warning("[UPGRADE] %s; trying the %s build\n", last_err, row_label(&cands[ci + 1]));
  }
  if (!have) {
    *err = last_err;
    return false;
  }
  }

  /* End the previous upgrade's failback before laying down anything of this
   * one.  Its loop may be inside finish(), which edits cron for a second or
   * more before removing the state, the script and upgrade.sh: whatever this
   * upgrade had written by then would go with them (nightly 2026-11-06).
   * "done" waits on the lock a tick holds, so that tick is over when it returns. */
  failback_clear();

  /* Flush the live config, then snapshot the pair we may have to restore.
   * Both are copied: <exe> stays in place until the new one is renamed over it,
   * so there is never a moment with no binary there. */
  unsigned long saves = hub_config_saves();
  hub_config_write(state);
  if (hub_config_saves() == saves) {
    if (archive[0]) remove(archive);
    *err = "could not save the config before the swap";
    return false;
  }
  char prev_cfg[PATH_MAX];
  char prev_exe[PATH_MAX + 8];
  if (snprintf(prev_cfg, sizeof(prev_cfg), "%s%s", HUB_CONFIG_FILE,
               HUB_UPGRADE_PREV_SUFFIX) >= (int)sizeof(prev_cfg) ||
      snprintf(prev_exe, sizeof(prev_exe), "%s%s", state->executable_path,
               HUB_UPGRADE_PREV_SUFFIX) >= (int)sizeof(prev_exe)) {
    remove(archive);
    *err = "path too long for rollback snapshot";
    return false;
  }
  if (!copy_file(HUB_CONFIG_FILE, prev_cfg, 0600)) {
    remove(archive);
    *err = "could not snapshot config for rollback";
    return false;
  }
  char prev_tmp[PATH_MAX + 16];
  snprintf(prev_tmp, sizeof(prev_tmp), "%s.tmp", prev_exe);
  if (!copy_file(state->executable_path, prev_tmp, 0700) ||
      rename(prev_tmp, prev_exe) != 0) {
    remove(prev_tmp);
    remove(prev_cfg);
    remove(archive);
    *err = "could not retain previous binary";
    return false;
  }
  /* From here a failure is the script's to handle: it restores <exe>.prev and
   * restarts the old build rather than leaving this hub with no binary. */
  if (!hub_upgrade_marker_write(upgrade_id, target_ver, want_variant) ||
      !write_upgrade_script(state, row.kind, archive, true) ||
      !failback_stage(state->executable_path, upgrade_id,
                      strcasecmp(row.kind, "src") != 0, HUB_CONFIG_FILE,
                      HUB_PID_FILE, HUB_UPGRADE_SCRIPT, "no peer link")) {
    failback_clear();
    remove(HUB_UPGRADE_MARKER_FILE);
    remove(prev_exe);
    remove(prev_cfg);
    remove(archive);
    *err = "could not stage the upgrade script";
    return false;
  }

  int cron = failback_run("install");
  if (cron != 0)
    hub_log_warning("[UPGRADE] No cron failback on this host (%d): it will not "
                    "survive a reboot during this upgrade\n", cron);
  hub_log_info("[UPGRADE] Installing %s and restarting\n", target_ver);
  if (state->pid_fd >= 0) close(state->pid_fd);
  sleep(1);
  hub_update_close_fds_for_exec();
  execl("./" HUB_UPGRADE_SCRIPT, "./" HUB_UPGRADE_SCRIPT, (char *)NULL);
  /* exec failed: <exe> was never moved.  The sockets are already gone, so
   * exiting is all that is left. */
  hub_log_info("[UPGRADE] Could not run " HUB_UPGRADE_SCRIPT ": %s\n", strerror(errno));
  failback_clear();
  remove(prev_exe);
  remove(HUB_UPGRADE_MARKER_FILE);
  exit(1);
}

/* ---- Multi-version stepping (upgrade plan, Task 7) ---------------------
 * A manifest row may declare a min_from_version: the oldest release it is
 * willing to be installed over.  A node further back than that cannot jump
 * straight to the target, so the run walks it there one release at a time.
 * This reads the manifest for ANOTHER node — a bot on its own release tree,
 * or a peer hub — so the host arch/libc filter is deliberately not applied:
 * the node itself picks the artifact when it commits.  Returns the highest
 * version `cur_ver` may take right now on the way to `target_ver`. */
/* Does this release have something this host can install: a build for its arch and
 * libc, or source?  An unreadable manifest says nothing either way, so it passes. */
bool hub_update_has_build(const char *root, const char *variant, const char *ver, const char *arch,
                          const char *libc) {
  char base[512], tree[600];
  snprintf(base, sizeof(base), "%s", root && root[0] ? root : effective_root(NULL));
  if (snprintf(tree, sizeof(tree), "%s/%s", base, variant) >= (int)sizeof(tree)) return true;
  const char *verr = NULL;
  g_fetch_quick = HUB_UPDATE_QUICK_TIMEOUT;
  char *manifest = fetch_verified_manifest(tree, &verr);
  g_fetch_quick = 0;
  if (!manifest) return true;
  bool found = false;
  char *save = NULL;
  for (char *line = strtok_r(manifest, "\n", &save); line && !found;
       line = strtok_r(NULL, "\n", &save)) {
    char v[64], date[64], url[512], hash[128], deps[256], kind[8] = "src", a[32] = "any",
                                                          l[16] = "any";
    if (line[0] == '#' || sscanf(line, "%63s %63s %511s %127s %255s %7s %31s %15s", v, date, url,
                                 hash, deps, kind, a, l) < 5)
      continue;
    if (!version_eq(v, ver)) continue;
    if ((!strcmp(a, "any") || !strcmp(a, arch)) && (!strcmp(l, "any") || !strcmp(l, libc))) found = true;
  }
  free(manifest);
  return found;
}

bool hub_update_next_step(const char *root, const char *variant,
                          const char *cur_ver, const char *target_ver,
                          char *out, size_t out_size, char *reason,
                          size_t reason_size) {
  if (out && out_size) out[0] = '\0';
  if (reason && reason_size) reason[0] = '\0';
  if (!cur_ver || !target_ver || !target_ver[0]) {
    snprintf(reason, reason_size, "no target version");
    return false;
  }

  char tree[600];
  root = effective_root(root);
  const char *var = (variant && variant[0]) ? variant : hub_update_host_variant();
  if (snprintf(tree, sizeof(tree), "%s/%s", root, var) >= (int)sizeof(tree)) {
    snprintf(reason, reason_size, "release base URL too long");
    return false;
  }

  const char *verr = NULL;
  char *manifest = fetch_verified_manifest(tree, &verr);
  if (!manifest) {
    snprintf(reason, reason_size, "%s", verr ? verr : "manifest fetch failed");
    return false;
  }

  char best[64] = "";
  char *saveptr = NULL;
  for (char *line = strtok_r(manifest, "\n", &saveptr); line;
       line = strtok_r(NULL, "\n", &saveptr)) {
    if (line[0] == '#' || line[0] == '\0') continue;
    char version[64] = "", date[64], url[512], hash[128], deps[256];
    char kind[8] = "src", arch[32] = "any", libc[16] = "any";
    char min_from[64] = "*";
    int n = sscanf(line, "%63s %63s %511s %127s %255s %7s %31s %15s %63s",
                   version, date, url, hash, deps, kind, arch, libc, min_from);
    if (n < 5 || !version[0]) continue;
    /* Strictly forward, and never past where the run is going. */
    if (hub_update_version_cmp(version, cur_ver) <= 0) continue;
    if (hub_update_version_cmp(version, target_ver) > 0) continue;
    /* Reachable from where the node is now. */
    if (strcmp(min_from, "*") != 0 &&
        hub_update_version_cmp(cur_ver, min_from) < 0)
      continue;
    if (!best[0] || hub_update_version_cmp(version, best) > 0)
      snprintf(best, sizeof(best), "%s", version);
  }
  free(manifest);

  if (!best[0]) {
    snprintf(reason, reason_size,
             "no release in the manifest can be installed over %s", cur_ver);
    return false;
  }
  snprintf(out, out_size, "%s", best);
  return true;
}

/* irchub -checkupdate [variant]: fetch the irchub release manifest and its
 * signature exactly as a hub self-upgrade does — <root>/<variant>, the
 * compiled-in root and pinned key unless IRCHUB_UPDATE_BASE says otherwise —
 * verify one against the other, and report.  Nothing past the manifest is
 * downloaded and nothing is installed, so an operator (or the testnet) can
 * prove a host reaches and trusts the real release channel — TLS, CA store,
 * pinned key — without upgrading anything.  0 = verified. */
int hub_update_check_cli(const char *variant) {
  const char *want = (variant && variant[0]) ? variant : hub_update_host_variant();
  if (strpbrk(want, "/;|&`$ \t\r\n") || strlen(want) > 7) {
    printf("checkupdate: FAIL malformed variant\n");
    return 1;
  }
  char tree[600];
  if (snprintf(tree, sizeof(tree), "%s/%s", effective_root(NULL), want) >=
      (int)sizeof(tree)) {
    printf("checkupdate: FAIL release base URL too long\n");
    return 1;
  }
  const char *verr = NULL;
  char *manifest = fetch_verified_manifest(tree, &verr);
  if (!manifest) {
    printf("checkupdate: FAIL %s (%s)\n", verr ? verr : "manifest fetch failed",
           tree);
    return 1;
  }
  int rows = 0;
  char newest[64] = "";
  char *saveptr = NULL;
  for (char *line = strtok_r(manifest, "\n", &saveptr); line;
       line = strtok_r(NULL, "\n", &saveptr)) {
    char version[64];
    if (line[0] == '#' || sscanf(line, "%63s", version) != 1) continue;
    rows++;
    if (!newest[0] || hub_update_version_cmp(version, newest) > 0)
      snprintf(newest, sizeof(newest), "%s", version);
  }
  free(manifest);
  printf("checkupdate: OK %s manifest verified: %d release row(s), newest %s, "
         "running %s\n",
         want, rows, newest[0] ? newest : "-", HUB_VERSION);
  return 0;
}

#else /* !HAVE_CURL */

int hub_update_check_cli(const char *variant) {
  (void)variant;
  printf("checkupdate: FAIL hub built without curl support\n");
  return 1;
}

const char *hub_update_bot_root(void) { return HUB_BOT_RELEASE_BASE; }

bool hub_update_has_build(const char *root, const char *variant, const char *ver, const char *arch,
                          const char *libc) {
  (void)root; (void)variant; (void)ver; (void)arch; (void)libc;
  return true;
}

bool hub_update_next_step(const char *root, const char *variant,
                          const char *cur_ver, const char *target_ver,
                          char *out, size_t out_size, char *reason,
                          size_t reason_size) {
  (void)root;
  (void)variant;
  (void)cur_ver;
  (void)target_ver;
  if (out && out_size) out[0] = '\0';
  if (reason && reason_size)
    snprintf(reason, reason_size, "hub built without curl support");
  return false;
}

int hub_update_list_releases(const char *root, const char *variant,
                             hub_release_t *out, int max, const char **err) {
  (void)root;
  (void)variant;
  (void)out;
  (void)max;
  *err = "hub built without curl support";
  return -1;
}

bool hub_update_can_take(const char *target_ver, const char *variant,
                         const char *min_from, char *reason,
                         size_t reason_size) {
  (void)target_ver;
  (void)variant;
  (void)min_from;
  if (reason && reason_size)
    snprintf(reason, reason_size, "hub built without curl support");
  return false;
}

void hub_update_stage_start(const char *exe, const char *id, const char *ver, const char *variant) {
  (void)exe; (void)id; (void)ver; (void)variant;
}
void hub_update_stage_clear(void) {}
void hub_update_stage_unsaid(void) {}
int hub_update_stage_main(const char *ver, const char *variant) {
  (void)ver; (void)variant;
  return 1;
}
void hub_update_stage_boot_clean(void) {}
bool hub_update_stage_tick(char *id, size_t id_size, char *out, size_t out_size) {
  (void)id; (void)id_size; (void)out; (void)out_size;
  return false;
}

bool hub_update_commit(hub_state_t *state, const char *upgrade_id,
                       const char *target_ver, const char *variant,
                       const char **err) {
  (void)state;
  (void)upgrade_id;
  (void)target_ver;
  (void)variant;
  *err = "hub built without curl support";
  return false;
}

#endif /* HAVE_CURL */
