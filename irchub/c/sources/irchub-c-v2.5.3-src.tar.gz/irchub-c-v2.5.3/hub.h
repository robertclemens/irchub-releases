#ifndef HUB_H
#define HUB_H

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>   /* PATH_MAX for hub_state_t.executable_path */
#include <netinet/in.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/ssl.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

/* A non-blocking call with nothing to do.  POSIX lets EAGAIN and EWOULDBLOCK
 * differ; where they are one value (Linux) testing both trips -Wlogical-op. */
#if EAGAIN == EWOULDBLOCK
#define IO_WOULD_BLOCK(e) ((e) == EAGAIN)
#else
#define IO_WOULD_BLOCK(e) ((e) == EAGAIN || (e) == EWOULDBLOCK)
#endif

/* FD_ISSET for a descriptor already known to be >= 0.  musl does the macro's
 * index math in unsigned long, which -Wsign-conversion reports at every call;
 * the one conversion is spelled out here. */
static inline bool fd_isset(int fd, const fd_set *set) {
  return FD_ISSET((unsigned)fd, set) != 0;
}

#define HUB_CONFIG_FILE ".irchub.cnf"
#define MAX_CLIENTS 100
#define MAX_BOTS 100
#define MAX_PEERS 10
#define MAX_OPT_FLAGS 32

/* Network option flag letters (synced via the 'opt|' record).
 * Each option is a single [a-zA-Z0-9] character; the active set lives in
 * hub_state_t.opt_flags and replicates to bots in CMD_CONFIG_DATA / sync. */
#define OPT_HUB_ONLY_MUTATIONS 'h'
/* Set for the duration of a network upgrade window: config mutations (admin
 * commands + bot deltas) are refused until every node reports success and the
 * verification pass completes, or the run aborts.  Task 6 (upgrade freeze). */
#define OPT_CONFIG_FROZEN 'F'
#define MAX_CHAN 65
#define MAX_NICK 32
#define MAX_KEY 31
#define MAX_MASK_LEN 256
#define MAX_PASS 128
#define MAX_BUFFER 16384
#define SALT_SIZE 16 // FIXED: Increased from 8 to 16 bytes (128 bits)
#define GCM_IV_LEN 12
#define GCM_TAG_LEN 16
#define MAX_PENDING_OP_REQUESTS 500
/* PBKDF2-HMAC-SHA256 rounds for the .irchub.cnf and .irchub.pass keys
 * (OWASP's 2023 figure).  2.5.0 moved both files here from 100k; every
 * release since carries min_from 2.5.0 or later, so only this count is read. */
#define PBKDF2_ITERATIONS 600000
/* A bot that knows admin flags and oper channel bindings (uf| / uc|) says
 * "v|3" at the head of its full CMD_CONFIG_PUSH (docs/passwordless.md §3.4);
 * a push whose v| is below that is refused (record-only pushes carry no v|
 * and are taken).  Mirrored in ircbot/bot.h
 * (BOT_PROTO_VERSION). */
#define BOT_PROTO_USER_FLAGS 3
/* The oldest bot or hub this hub links with (2.5.1 plan D1 / D4): a bot's
 * CMD_BOT_PRESENCE or a direct peer's roster header below it drops the link
 * with a "upgrade it by hand" line.  2.5.2 raised it to 2.5.1: every node
 * reads only PBKDF2 600k files, reports K|, and has dropped .pass.prev. */
#define MESH_MIN_VERSION "2.5.1"
#define KEY_FP_LEN 19              /* "ab12:cd34:ef56:7890" */
#define HUB_PID_FILE ".irchub.pid"
#define HUB_PASS_FILE ".irchub.pass"
#define HUB_CONFIG_PURGE_DAYS_KEY "purge_days"
#define HUB_LOG_FILE ".irchub.log"
#define HUB_LOG_FILE_SIZE (10 * 1024 * 1024)  // 10MB default; log_size| overrides
/* CMD_ADMIN_SET_LOG_SIZE / log_size| bounds (ircbot's L| takes the same). */
#define HUB_LOG_SIZE_MIN 1024
#define HUB_LOG_SIZE_MAX (1024 * 1024 * 1024)

// Curve25519 key constants
#define ED25519_KEY_LEN    32
#define X25519_KEY_LEN     32
#define ED25519_SIG_LEN    64
#define COMBINED_KEY_LEN   64
#define COMBINED_KEY_B64   88

// Log levels
#define LOG_NONE    0
#define LOG_ERROR   1
#define LOG_WARNING 2
#define LOG_INFO    3
#define LOG_DEBUG   4

/* The log FILE is off by default: a production hub writes nothing to disk
 * until log_level| (or the console's "loglevel file") turns it on.  The
 * in-memory ring the SSH consoles read has its own level. */
#define HUB_DEFAULT_LOG_LEVEL         LOG_NONE
#define HUB_DEFAULT_CONSOLE_LOG_LEVEL LOG_DEBUG

// Rate Limiting Settings
#define MAX_IP_RATE_LIMITS 500
#define MAX_CONNECTIONS_PER_IP 5
#define MAX_FAILED_AUTH_ATTEMPTS 3
#define FAILED_AUTH_BLOCK_DURATION 300  // 5 minutes
#define FAILED_AUTH_RESET_TIME 3600     // 1 hour

/* D1 — churn-based (connect/close flood) throttle. Concurrency + failed-auth
 * limits don't catch a rapid connect/close flood; this sliding window does.
 * More than CHURN_MAX_CONNS new connections from one IP within
 * CHURN_WINDOW_SEC seconds triggers a CHURN_BLOCK_SEC temporary block. */
#define CHURN_WINDOW_SEC 10
#define CHURN_MAX_CONNS  30
#define CHURN_BLOCK_SEC  30

/* 13b — connections not yet authenticated (MaxStartups-style random early
 * drop, `hub set conn startups S:R:F`).  Below S of them every new one is
 * taken; from S, a new one from an unknown address is refused with
 * probability R%, rising linearly to 100% at F.  A known address — a
 * configured peer, a bot in the roster, a bot or peer that authenticated
 * here within KNOWN_IP_MEMORY, a recent console login — skips the gate, and
 * so does the rate-limit table being full of live entries, which refuses
 * an unknown address instead of letting it through untracked. */
#define STARTUPS_DEF_START 20
#define STARTUPS_DEF_RATE  30
#define STARTUPS_DEF_FULL  50
#define MAX_KNOWN_IPS      256
#define KNOWN_IP_MEMORY    86400
#define STARTUP_LOG_EVERY  60     /* one refusal warning per this, with a count */
/* PURGE loop suppression.  A purge is flooded to every peer and forwarded on,
 * so on a big mesh each hub sees many copies, some of them minutes late when
 * peer queues back up.  An id is random and never reused, so it is remembered
 * long and in quantity: with 5 ids for 60 s, a late copy or one pushed out by
 * newer purges was taken as new, re-applied and re-flooded, and a 10-hub
 * mesh kept a dozen purges circulating for good.  An id-less purge (a hub
 * that predates the id) can only be told apart by time, so it keeps the short
 * window — a longer one would swallow a second, deliberate purge now. */
/* The full config push to bots is coalesced: however many updates land in a
 * burst (a mass reconnect sends two per bot, and each reaches every hub), the
 * bots get one push per this many seconds, carrying the latest state. */
#define BOT_CONFIG_PUSH_COALESCE 1
#define MAX_RECENT_PURGES 64
#define PURGE_DEDUP_WINDOW 3600          // seconds an id'd purge is remembered
#define PURGE_ID_HEX 16                  // PURGE|<cutoff>|<id>: 8 random bytes, hex
#define PURGE_FLOOR_HOLD 600             // s a purge refuses re-creating older tombstones

// OP_FORWARD_REQUEST deduplication — prevents packet storms
#define OP_FORWARD_TTL_SECONDS 60        // Drop forwarded OP requests older than 60s
#define MAX_SEEN_FORWARD_IDS   256       // LRU ring of recently-seen OP forward request IDs
/* The longest key the ring is given: the plan keys ("pb:<driver>:<step>",
 * "pc:<started>:<at>") are built in 96-byte buffers.  A key cut to fit would
 * make two different steps look like one. */
#define SEEN_FORWARD_ID_MAX    96

/* Keepalive traffic (CMD_PING and the PONG it draws) is pure noise in the hub
 * log: with every bot and peer exchanging one a minute it buries the lines
 * that matter.  true = never log it; false = log it like any other frame.
 * Only the logging is suppressed -- the keepalives themselves still run.
 * Mirrors HIDEPINGPONG in ircbot/bot.h. */
#define HIDEPINGPONG true

/* This hub's version, reported in the bots tree beside each hub node and the
 * one every upgrade comparison is made against.  Keep in step with VERSION in
 * the Makefile; -D-overridable so a release build can stamp its own version
 * without editing the tree (mirrors BOT_VERSION in ircbot/bot.h). */
#ifndef HUB_VERSION
#define HUB_VERSION "2.5.3"
#endif

/* Signed-release channel for the hub (irchub-releases).  Same Ed25519 key as
 * ircbot's BOT_UPDATE_PUBKEY_B64: one key signs both repos.  All of these are
 * -D-overridable.  A run never names a base: every node reads its own root,
 * the only one its pinned key can verify, so a different release site means
 * a different build.  Only a -DIRC_TEST_HOOKS build (the testnet's) reads the
 * IRCHUB_UPDATE_BASE / _PUBKEY / IRCHUB_BOT_RELEASE_BASE env overrides; see
 * hub_update.c.
 * An empty pubkey DISABLES hub updates (fail-closed).
 *
 * HUB_UPDATE_BASE is the tree ROOT; one variant subdirectory below it holds
 * that build's manifest.  Keeping the root separate is what lets a
 * hub-orchestrated upgrade flip a hub between the C and Rust builds, exactly
 * as it does for a bot: hub_update_commit() appends the variant it was told
 * to install.  Mirrors BOT_UPDATE_BASE in ircbot/bot.h. */
#ifndef HUB_UPDATE_BASE
#define HUB_UPDATE_BASE                                                        \
  "https://raw.githubusercontent.com/robertclemens/irchub-releases/main/"      \
  "irchub"
#endif
/* The variant THIS build is.  The Rust hub answers "rs". */
/* The bots' release tree ROOT (ircbot-releases), for the admin console release
 * list and for walking a bot up via the roll-up.  Mirrors BOT_UPDATE_BASE in
 * ircbot/bot.h; a run's own bot base, when an admin names one, wins. */
#ifndef HUB_BOT_RELEASE_BASE
#define HUB_BOT_RELEASE_BASE                                                   \
  "https://raw.githubusercontent.com/robertclemens/ircbot-releases/main/"      \
  "ircbot"
#endif
#ifndef HUB_UPDATE_VARIANT
#define HUB_UPDATE_VARIANT "c"
#endif
#ifndef HUB_UPDATE_URL
#define HUB_UPDATE_URL HUB_UPDATE_BASE "/" HUB_UPDATE_VARIANT "/releases.txt"
#endif
/* Detached Ed25519 signature over releases.txt (raw 64-byte sig, base64). */
#ifndef HUB_UPDATE_SIG_URL
#define HUB_UPDATE_SIG_URL HUB_UPDATE_BASE "/" HUB_UPDATE_VARIANT "/releases.sig"
#endif
#ifndef HUB_UPDATE_PUBKEY_B64
#define HUB_UPDATE_PUBKEY_B64 "qkXMh/F8TC+cnKuIwrP5TJIynfrLBD+MDUwvkyh9lBU="
#endif
/* Hand-off note written just before a hub-driven upgrade execs the new binary:
 * the restarted process has no memory of the run that replaced it, so it reads
 * the upgrade id from here and answers CMD_UPGRADE_RESULT. */
#define HUB_UPGRADE_MARKER_FILE ".irchub.upgrade"
/* Retained previous binary/config, kept (not deleted) after an upgrade so
 * CMD_UPGRADE_ABORT can put this hub back. */
#define HUB_UPGRADE_PREV_SUFFIX ".prev"
/* The upgrade script's startup watchdog: how long the new build's daemon has
 * to be up and alive before the script keeps it (see write_upgrade_script). */
#define UPGRADE_WATCH_SECS 20
/* The generated installer, written 0700 and exec'd once the old process has
 * let go of its pid lock. */
#define HUB_UPGRADE_SCRIPT "hub_upgrade.sh"
/* Ceilings on what the updater will pull down.  A manifest is a few KB and an
 * unbounded realloc loop against a hostile or broken server is a
 * memory-exhaustion hole; the archive cap is enforced by libcurl itself. */
#define HUB_UPDATE_MAX_MANIFEST (1024 * 1024)
#define HUB_UPDATE_MAX_ARCHIVE (256L * 1024 * 1024)
#define HUB_UPDATE_FETCH_TIMEOUT 300L
/* Per-transfer budget for manifest reads made from the event loop (PREPARE
 * answers, the admin console release list): the hub serves nothing meanwhile. */
#define HUB_UPDATE_QUICK_TIMEOUT 8L
/* The failback's limits, in seconds (see FAILBACK_BODY).  A source build's limit
 * and the confirm window are the reliability plan's agreed values. */
#define UPGRADE_INSTALL_SECS    120
#define UPGRADE_BUILD_SECS      1800
#define UPGRADE_CONFIRM_SECS    300
#define UPGRADE_FAILBACK_EXPIRY 1800
#define UPGRADE_STAGE_BEAT   20    /* a node says it is staging this often */
#define UPGRADE_STAGE_SILENCE 90   /* a node silent this long has left the run */
#define UPGRADE_STAGE_GATE   180   /* a prebuilt's stage limit */
#define UPGRADE_CLASS_RECORDS 5    /* how far back a node's history is read */
#define UPGRADE_SLOW_RESTART 120   /* slower than this usually: a slow host */
#define UPGRADE_STAGE_FLOOR  60    /* the least a known prebuilt stage gets */
#define UPGRADE_BUILD_FLOOR  300   /* the least a known source build gets */
#define UPGRADE_STOP_PERCENT 25    /* more than this share failing stops everything */
#define UPGRADE_SWAP_BACK    90    /* a staged node must be back by now */
#define UPGRADE_STAGE_KEEP   900   /* a stage no COMMIT came for is removed */
#define CRON_STATUS_MAX     31   /* yes, silent, manual, no, busy, failed:<why> */
#define CRON_HELPER_TIMEOUT 60   /* a crontab edit that takes longer is killed */
#define CRON_CHECK_SECS     3600 /* how often a node looks at its line */
#define CRON_SILENT_SECS    900  /* no stamp for this long: no cron daemon */
/* Every node of one account edits its one crontab under one lock: a helper that
 * cannot get it exits CRON_RC_BUSY and is run again this soon, spread by pid so
 * a queue of nodes does not meet again at the same second. */
#define CRON_RC_BUSY        5
#define CRON_BUSY_RETRY_MIN 10
#define CRON_BUSY_RETRY_SPAN 21  /* 10..30 s */
/* What preflight asks of the disk, in bytes.  A build's own needs come from the
 * manifest's size column; these cover what it cannot say. */
#define UPGRADE_SPACE_MARGIN      (16ULL * 1024 * 1024)
#define UPGRADE_SPACE_BIN_DEFAULT (64ULL * 1024 * 1024)   /* no size column     */
#define UPGRADE_SPACE_BUILD_C     (256ULL * 1024 * 1024)  /* objects, make      */
#define UPGRADE_SPACE_BUILD_RS    (1536ULL * 1024 * 1024) /* cargo's target dir */
#define UPGRADE_MIN_INODES        64

// Timeout Settings
#define PING_INTERVAL 60
#define CLIENT_TIMEOUT 180
#define CONNECT_TIMEOUT 5

/* D4 — pre-authentication handshake timeout. An accepted connection that has
 * not authenticated within this window is dropped, freeing its MAX_CLIENTS
 * slot far sooner than CLIENT_TIMEOUT (180s). Outbound CLIENT_HUB peers are
 * exempt (they are trusted, operator-configured endpoints). */
#define PREAUTH_TIMEOUT_SEC 10

/* D2 — two-tier client buffers. Unauthenticated clients get a small buffer
 * (enough for the handshake); it is grown to MAX_BUFFER on successful auth.
 * This keeps the unauthenticated footprint ~8KB instead of ~33KB. */
#define PREAUTH_BUF_SIZE 4096
#define PEER_RECONNECT_INTERVAL 120

// Protocol Commands
#define CMD_PING 0x01
#define CMD_CONFIG_PUSH 0x02
#define CMD_CONFIG_PULL 0x03
#define CMD_CONFIG_DATA 0x04
#define CMD_UPDATE_PUBKEY 0x05
#define CMD_PEER_SYNC 0x06
#define CMD_MESH_STATE 0x07
#define CMD_SYNC_REQUEST 0x08  // Hub -> Hub: request peer to immediately send its full sync
/* 0x09 was CMD_INVITE_REQUEST (a bot asking every bot to invite a nick, flooded
 * as invite| sync lines); removed in 2.5.3, the channel-request election does
 * invites.  Never reuse the value. */

#define CMD_ADMIN_AUTH 0x10
#define CMD_ADMIN_LIST_FULL 0x11
/* 0x12 / 0x16 / 0x17 (ADD / GET_PENDING / APPROVE) are retired with bot
 * pending/approve/authorize: bot add is the only way in.  Never reuse. */
#define CMD_ADMIN_ADD 0x12 // RETIRED
#define CMD_ADMIN_DEL 0x13
#define CMD_ADMIN_REGEN_KEYS 0x14
#define CMD_ADMIN_LIST_SUMMARY 0x15
#define CMD_ADMIN_GET_PENDING 0x16 // RETIRED
#define CMD_ADMIN_APPROVE 0x17 // RETIRED
#define CMD_ADMIN_ADD_PEER 0x18
#define CMD_ADMIN_LIST_PEERS 0x19
#define CMD_ADMIN_DEL_PEER 0x1A
#define CMD_ADMIN_GET_PUBKEY 0x1B
/* 0x1C / 0x1D (SET/GET_PRIVKEY) are retired with hub_admin: the hub key never
 * leaves the hub, a backup is a copy of .irchub.cnf.  Never reuse the values. */
#define CMD_ADMIN_SET_PRIVKEY 0x1C // RETIRED
#define CMD_ADMIN_GET_PRIVKEY 0x1D // RETIRED
#define CMD_ADMIN_SET_PUBKEY 0x1E
#define CMD_ADMIN_SYNC_MESH 0x1F
#define CMD_ADMIN_CREATE_BOT 0x32     // 50 decimal
#define CMD_ADMIN_REKEY_BOT 0x20      // Generate new bot keypair
#define CMD_ADMIN_DISCONNECT_BOT 0x21 // Force disconnect bot
#define CMD_ADMIN_BOT_STATUS 0x22     // Get bot connection info
#define CMD_BOT_KEY_UPDATE 0x40       // Hub -> Bot: New private key update

// Global Config Management Commands
#define CMD_ADMIN_LIST_CHANNELS 0x23  // List all channels
#define CMD_ADMIN_ADD_CHANNEL 0x24    // Add channel
#define CMD_ADMIN_DEL_CHANNEL 0x25    // Remove channel
#define CMD_ADMIN_LIST_MASKS 0x26     // List admin masks
#define CMD_ADMIN_ADD_MASK 0x27       // Add admin mask
#define CMD_ADMIN_DEL_MASK 0x2B       // Remove admin mask
#define CMD_ADMIN_LIST_OPERS 0x2C     // List oper masks
#define CMD_ADMIN_ADD_OPER 0x2D       // Add oper mask
#define CMD_ADMIN_DEL_OPER 0x2E       // Remove oper mask
/* 0x2F (SET_ADMIN_PASS) and 0x30 (SET_BOT_PASS) are retired — passwordless.
 * Kept as names so the hub can answer "retired"; never reuse the values. */
#define CMD_ADMIN_SET_ADMIN_PASS 0x2F // RETIRED
#define CMD_ADMIN_SET_BOT_PASS 0x30   // RETIRED
#define CMD_ADMIN_OP_USER 0x31        // Op a user in a channel

// Bot-to-Bot Op Commands (via Hub)
#define CMD_OP_REQUEST 0x28 // Bot -> Hub: Request ops from another bot
#define CMD_OP_GRANT 0x29   // Hub -> Bot: Grant ops to requesting bot
#define CMD_OP_FAILED 0x2A  // Hub -> Bot: Op request failed
#define CMD_OP_FORWARD_REQUEST 0x33 // Hub -> Hub: Forward OP request to peer
#define CMD_OP_FORWARD_GRANT 0x34   // Hub -> Hub: Forward grant response back
#define CMD_OP_FORWARD_FAILED 0x35  // Hub -> Hub: Forward failure back
#define CMD_PEER_REKEY_BOT 0x42     // Hub -> Hub: Forward bot rekey to peer
#define CMD_BOT_RELAY 0x50  // Bot -> Hub: relay encrypted bot command to target bot by UUID
#define CMD_BOT_MSG   0x51  // Hub -> Bot: relayed encrypted bot command payload

// Tombstone Purge Commands
#define CMD_ADMIN_PURGE_TOMBSTONES 0x36 // Purge tombstoned entries (payload: days or "immediate")
#define CMD_ADMIN_SET_PURGE_DAYS 0x41   // Configure automatic purge (payload: days, 0=disabled)

// Bind IP and IP Access Control Commands
#define CMD_ADMIN_SET_BIND_IP 0x37
#define CMD_ADMIN_LIST_ALLOWLIST 0x38
#define CMD_ADMIN_ADD_ALLOWLIST 0x39
#define CMD_ADMIN_DEL_ALLOWLIST 0x3A
#define CMD_ADMIN_LIST_DENYLIST 0x3B
#define CMD_ADMIN_ADD_DENYLIST 0x3C
#define CMD_ADMIN_DEL_DENYLIST 0x3D
#define CMD_ADMIN_SET_HUB_NAME 0x3E
#define CMD_ADMIN_SET_BIND_PORT 0x3F
#define CMD_ADMIN_SET_LOG_LEVEL 0x43    // Set log level (payload: level 0-4)
#define CMD_ADMIN_SET_LOG_SIZE  0x44    // Set log size limit (payload: size in bytes)
#define CMD_BOT_DELTA           0x45    // Bot -> Hub: single-key change (mesh.md Phase 4)

// Named Admin/Oper/Usermask Commands (v2)
#define CMD_ADMIN_ADD_ADMIN      0x46   // Create admin record + first mask (payload: name|pass|mask)
#define CMD_ADMIN_DEL_ADMIN      0x47   // Soft-delete admin + all its m| lines (payload: name)
#define CMD_ADMIN_ADD_OPER_RECORD 0x48  // Create oper record + first mask (payload: name|pass|mask)
#define CMD_ADMIN_DEL_OPER_RECORD 0x49  // Soft-delete oper + all its m| lines (payload: name)
#define CMD_ADMIN_ADD_USERMASK   0x4A   // Add mask to admin or oper by name (payload: name|mask)
#define CMD_ADMIN_DEL_USERMASK   0x4B   // Soft-delete one mask for named user (payload: name|mask)
#define CMD_ADMIN_SET_USERPASS   0x4C   // RETIRED (passwordless); never reuse
#define CMD_ADMIN_MATCH          0x4D   // Query all records for user or * (payload: name or *)
#define CMD_ADMIN_LIST_ADMINS    0x4E   // List all admin records
#define CMD_ADMIN_LIST_OPERS_V2  0x4F   // List all oper records
#define CMD_ADMIN_SET_PEER_PUBKEY 0x52  // Set/replace pubkey on existing peer (payload: UUID:PUBKEY_B64)
#define CMD_ADMIN_SET_OPT_FLAGS   0x53  // Set network opt flag string (payload: <letters>)
#define CMD_ADMIN_GET_OPT_FLAGS   0x54  // Get current network opt flag string
#define CMD_ADMIN_SET_USERKEY     0x55  // Replace a user's public key (payload: name|pubkey_b64)

/* ---- Bot presence (the 'bots' tree) --------------------------------------
 * Deliberately OUTSIDE the config store.  Version / IRC server / uptime are
 * volatile runtime facts: parking them in the LWW config would persist them to
 * disk, replicate them with tombstones, drag them through the purge policy and
 * leave a dead hub's bots reading "online, uptime 40d" forever.  They also do
 * not belong in the per-bot ingest whitelist {t,n,h,pub,seen,d,hl} -- that bound
 * is what makes the payload ceilings above provable, and it stays untouched.
 *
 * So presence rides its own gossip: every hub reports the bots currently
 * connected to IT, peers hold that in memory only, and an entry nobody has
 * refreshed within BOT_ROSTER_TTL is simply dropped.  Nothing to tombstone,
 * nothing to purge, and a hub that dies ages out of the tree on its own.
 * Identity (nick, last-seen) still comes from the persisted config -- read
 * only -- so disconnected bots can still be listed with a real timestamp. */
#define CMD_BOT_PRESENCE 0x56  // Bot -> Hub: version|server|started|variant (volatile)
#define CMD_BOT_ROSTER   0x57  // Hub <-> Hub: presence gossip (volatile)
#define CMD_BOT_TREE     0x58  // Hub -> Bot: rendered tree rows (volatile)

/* ---- Channel-access requests (unban / invite / key) ----------------------
 * A bot locked out of a managed channel (474 banned, 473 invite-only, 475 bad
 * key) asks the mesh to let it back in.  Routed exactly like CMD_OP_REQUEST:
 * stamp a request id, broadcast the action to local bots, forward to peers
 * under the same id (dropped on the second sighting via the shared
 * seen_forwards ring), and route any reply back down the fd the request
 * arrived on.  Only `key` produces a reply.
 *
 * The requesting bot supplies only `kind|channel`.  The hub fills in the
 * requester's nick and hostmask from its own `n`/`h` records for that
 * authenticated UUID, so a bot can neither request an unban for a mask that
 * is not its own nor have a third party invited.  Mirrors ircbot/bot.h. */
#define CMD_CHAN_REQUEST 0x59 // Bot -> Hub: kind|channel
#define CMD_CHAN_ACTION  0x5A // Hub -> Bot: id|kind|chan|uuid|nick|hostmask
#define CMD_CHAN_REPLY   0x5B // Bot <-> Hub: id|kind|chan|status|data
#define CMD_CHAN_FWD_REQUEST 0x5C // Hub -> Hub: forward the action
#define CMD_CHAN_FWD_REPLY   0x5D // Hub -> Hub: route a reply home

/* ---- Channel-request election (docs/plans/2026-10-07_chan_election_plan.md)
 * One bot acts, not every bot that could.  The hub asks its own bots whether
 * they can (PROBE -> PROBE_ACK, answered at once from the bot's own state),
 * hands the action to ONE ready bot picked at random (DO -> DONE), and moves
 * on to the next ready bot when that one fails.  With nobody ready here the
 * origin floods the question to the mesh (ELECT_FWD), each hub probes its own
 * bots and answers ELECT_ACK back along the path, and the origin hands it to
 * one hub with a ready bot (ELECT_DO -> ELECT_DONE, along the same path).
 * A bot that has not answered when CHAN_ELECT_PROBE_WAIT runs out counts as
 * a no ("no answer"): every bot the mesh admits answers probes, so it is
 * never sent a blind old-style CMD_OP_GRANT / CMD_CHAN_ACTION (that skipped
 * +bitch).  Mirrors ircbot/bot.h and irchub.rs consts.rs.
 *   PROBE      hub->bot  eid|kind|channel
 *   PROBE_ACK  bot->hub  eid|1| or eid|0|reason
 *   DO         hub->bot  eid|kind|channel|requester|nick|hostmask
 *   DONE       bot->hub  eid|ok|detail or eid|fail|detail
 *   ELECT_FWD  hub->hub  eid|origin_hub|kind|channel|requester|nick|hostmask|origin_ts
 *   ELECT_ACK  hub->hub  eid|hub_uuid|hub_name|asked|ready|0 (the last field
 *              is a reserved slot, always 0 and never read)
 *   ELECT_DO   hub->hub  eid|hub_uuid|elect
 *   ELECT_DONE hub->hub  eid|hub_uuid|hub_name|bot_uuid|bot_nick|status|detail
 * kind = op / invite / unban / key / mode / kick / ban; requester = a bot
 * uuid, or ADMIN.  kick: nick = the target, hostmask = the reason (may be
 * empty).  ban: hostmask = the mask, nick empty on the hubs and "*" in DO
 * (the bot's DO parser needs a field there). */
#define CMD_CHAN_PROBE       0x6D
#define CMD_CHAN_PROBE_ACK   0x6E
#define CMD_CHAN_DO          0x6F
#define CMD_CHAN_DONE        0x70
#define CMD_CHAN_ELECT_FWD   0x71
#define CMD_CHAN_ELECT_ACK   0x72
#define CMD_CHAN_ELECT_DO    0x73
#define CMD_CHAN_ELECT_DONE  0x74
#define CMD_ADMIN_INVITE_USER 0x75 // Admin: invite a user (nick|#chan)

/* ---- Modes, settings, bans, flood protection (docs/modes.md, 2.4.5) ------
 * Mirrors ircbot/bot.h and irchub.rs/ircbot.rs consts.rs.
 *   CMD_ADMIN_CHAN_MODE  console->hub  #chan (view) | #chan|<modes>|<arg>... | #chan|-
 *   CMD_ADMIN_CHAN_SET   console->hub  <#chan|default> | <#chan|default>|<tok>|<tok>...
 *   CMD_ADMIN_BAN        console->hub  list|<#c|*|""> | add|<#c|*>|<mask>|<min|perm>|<sticky 0/1>|<reason>
 *                                      | del|<#c|*>|<mask>
 *   CMD_ADMIN_NET_SET    console->hub  "" | flood|<cmd|msg|ctcp>|<N:S|off|default> | ignoretime|<min|default> | sendq|<B:I|default>
 *   CMD_ADMIN_SET_SSH    console->hub  "" | <name>|<value|default> | conn|<name>|<value>
 *   CMD_CHAN_EVENT       bot->hub      #chan|<action>|<target>|<detail>   (D42)
 * CMD_CHAN_EVENT: action is deop reop kick ban unban moderevert limit
 * floodtrip ignore; target (nick or mask) <= CHAN_EVENT_TARGET_MAX bytes,
 * detail <= CHAN_EVENT_DETAIL_MAX, no control characters.  The hub checks the
 * bounds, rate-limits per bot connection (CHAN_EVENT_MAX_PER_WINDOW per
 * CHAN_EVENT_WINDOW seconds, the rest dropped) and writes one info line to
 * its log ring, "chan #c <action> <target> by <botname>: <detail>".  Hub
 * local: never stored, never forwarded to peers or other bots. */
#define CMD_ADMIN_CHAN_MODE 0x76
#define CMD_ADMIN_CHAN_SET  0x77
#define CMD_ADMIN_BAN       0x78
#define CMD_ADMIN_NET_SET   0x79
#define CMD_ADMIN_SET_SSH   0x7A
#define CMD_CHAN_EVENT      0x7B
/* Admin flags / oper channel bindings from the console (user_flags plan §4.1):
 *   CMD_ADMIN_USER_ACCESS console->hub  flags|<name>|<+x-y|letters>
 *                                       chan|add|<name>|<#chan|*>
 *                                       chan|del|<name>|<#chan|*>
 * Answers user.flags / user.chan.  Internal (console only), never on the
 * network; the number is reserved in ircbot/bot.h. */
#define CMD_ADMIN_USER_ACCESS 0x7C
/* A person's channel request from a bot (user_flags plan §5):
 *   CMD_USER_CHAN_REQUEST bot->hub  rid|kind|#chan|user_uuid|nick|nick!user@host
 *   CMD_USER_CHAN_RESULT  hub->bot  rid|ok|detail  or  rid|fail|detail
 * kind = op / invite / unban.  The bot sends it when it cannot act itself;
 * the hub re-checks the user's rights (admin +c, or oper bound to the
 * channel) and runs the channel-request election with the person as the
 * target.  Mirrored in ircbot/bot.h. */
#define CMD_USER_CHAN_REQUEST 0x7D
#define CMD_USER_CHAN_RESULT  0x7E
/* Revoked bots (docs/plans/2026-10-17_bot_revoke_plan.md).  A deleted bot's
 * uuid and key stay on a permanent revoke list; when it connects it is told
 * to wipe its config and exit:
 *   CMD_BOT_RETIRE       hub->bot  empty; in session a sealed frame, in the
 *                                  handshake the 1-byte sealed ACK is 0x7F
 *   CMD_BOT_RETIRE_ACK   bot->hub  "1" config wiped, "0" wipe failed
 *   CMD_ADMIN_LIST_REVOKED console->hub  bot revoked
 * Mirrored in ircbot/bot.h. */
#define CMD_BOT_RETIRE        0x7F
#define CMD_BOT_RETIRE_ACK    0x80
#define CMD_ADMIN_LIST_REVOKED 0x81
/* hub del's preview (docs/plans/2026-10-18_hub_del_refs_plan.md): console ->
 * hub "<uuid|name>"; the reply names the hubs that link to it and the bots
 * whose hl| list holds it. */
#define CMD_ADMIN_PEER_REFS    0x82
/* Review 6: link framing with a sequence (bot<->hub and hub<->hub).  After a
 * link authenticates each side sends "offer"; the side that sees the other's
 * offer answers "go", and every frame it seals after its go carries
 * HUB_LINK_AAD_LEN bytes of AAD: "LNK1" || direction || 64-bit counter (big
 * endian, from 0, not sent).  The counter makes a replayed or reordered
 * frame fail its tag, the direction byte a reflected one (H hub->bot, B
 * bot->hub; between hubs L from the lower uuid, G from the greater).  A
 * 2.5.1 node ignores the offer and the link keeps the old framing; one that
 * says it is HUB_LINK_SEQ_VERSION or newer without having offered is dropped
 * (a stripped offer).  2.5.3 drops the old framing. */
#define CMD_LINK_SEQ           0x83
/* channel kick (2.5.3): console -> hub "nick|#chan|reason"; one elected bot
 * kicks (CMD_CHAN_PROBE kind "kick", the reason riding the hostmask slot). */
#define CMD_ADMIN_KICK_USER    0x84
/* Hub<->hub: "R|<body>" one upgrade history record, "D|keep|id:rev:started,..."
 * what the sender holds.  See hub_uhist.c. */
#define CMD_UPGRADE_HISTORY    0x87
#define CMD_UPGRADE_STAGE      0x88  /* Hub -> all: id, get the build ready while the old one runs */
#define CMD_UPGRADE_PROGRESS   0x89  /* node -> Hub: id|uuid|phase|code|note */
#define CMD_UPGRADE_PLAN       0x8A  /* Hub <-> Hub: P|plan, D|started|rev, B|started|rev|ts, C|started|ts */
#define CMD_CRON_SET           0x8B  /* Hub -> Bot: on|off, its production crontab line */

/* ---- Hub roll call (the upgrade gates) ----------------------------------
 * An upgrade starts, and each step of a multi-step plan starts, only with every
 * hub present.  The gossip that says which hubs are linked is second-hand and,
 * with damped event gossip, up to 30 s old: a hub that has just died can still
 * look linked (nightly 2026-11-06, test_95 "hub5 down").  So the gate asks the
 * hubs themselves.  The asking hub floods ROLLCALL to its peers; each hub passes
 * it on (once: the shared seen_forwards ring), remembers the link it arrived on,
 * and answers ROLLCALL_ACK back down that link; a relay routes every ACK of that
 * roll call the same way.  A hub that has not answered within ROLLCALL_WAIT is
 * missing.  An unanswered ACK can only make the gate refuse, never pass it.
 *   ROLLCALL      hub->hub  rid|origin_uuid|origin_ts
 *   ROLLCALL_ACK  hub->hub  rid|hub_uuid
 * Hub <-> hub only.  A hub that can answer says so with a k|rollcall line in
 * its roster gossip (older hubs skip a line they do not know).  While any hub
 * known here has not said so, the gate keeps to the gossip it used before: an
 * older hub neither answers nor passes the probe on, and refusing every start
 * would leave the mesh unable to upgrade it. */
#define CMD_HUB_ROLLCALL       0x8C
#define CMD_HUB_ROLLCALL_ACK   0x8D
/* Presence v2 (docs/plans/2026-11-14_presence_v2_plan.md, phase 1): one
 * versioned record per hub.  Hub <-> Hub only, text payload, one frame each:
 *   S|origin|epoch|seq|ttl|caps|links|bots   record (ttl 0 = this peer only)
 *   G|origin:epoch:seq,...  W|...            digest (W asks for a G back)
 *   R|origin                                 pull: answer S ttl 0
 * Unknown tags are ignored (later phases add D/H).  hub_presence2.c. */
#define CMD_PRESENCE2          0x8E
/* Phase 5 (presence v2 K): the bots tree is pushed to bots as row deltas, not
 * the whole tree, with the new tree's hash in each; a bot whose hash mismatches
 * pulls the whole tree.  The 300 s whole-tree refresh stays. */
#define CMD_BOT_TREE_DELTA     0x8F  /* Hub -> Bot: <seq>|<fnv64> + +/- row ops */
#define CMD_BOT_TREE_PULL      0x90  /* Bot -> Hub: send me the whole tree      */
#define ROLLCALL_WAIT          3   /* seconds the asking hub waits for the answers */
#define ROLLCALL_TTL           30  /* a relayed roll call older than this is dropped */
#define ROLLCALL_KEEP          10  /* seconds a relay routes the answers back */
#define MAX_ROLLCALLS          16  /* in flight here, asked or relayed */
#define ROLLCALL_ID_LEN        33  /* 16 random bytes in hex + NUL */
#define HUB_LINK_AAD_LEN 13
#define HUB_LINK_SEQ_VERSION "2.5.2"
/* Review 7: ephemeral keys of the HUBv3 hellos accepted in the last
 * HELLO_SEEN_SECS (the hello's freshness window); a repeat is a replay. */
#define HELLO_SEEN_MAX  128
#define HELLO_SEEN_SECS 60
#define MAX_REVOKED           1024 /* revoke list ceiling; oldest dropped past it */
#define RETIRE_GRACE_SEC      10   /* s an online bot gets to answer CMD_BOT_RETIRE */
#define USER_CHAN_RID_MAX     32   /* rid bytes, [A-Za-z0-9-]              */
#define USER_CHAN_REQ_WINDOW  60   /* s, per bot connection                */
#define USER_CHAN_REQ_MAX     20   /* requests per window, the rest dropped */
#define CHAN_EVENT_TARGET_MAX     120
#define CHAN_EVENT_DETAIL_MAX     160
#define CHAN_EVENT_WINDOW         60
#define CHAN_EVENT_MAX_PER_WINDOW 30
/* kind = "mode" (2.4.5, docs/modes.md §3.1): apply the stored modes of a
 * channel once.  The DO payload carries nothing extra; the elected bot reads
 * the stored C| modes + c| key (it has them in its config) and sends the MODE
 * line(s) that move the live modes there.  DONE ok|detail, or fail|reason; a
 * `channel op` to a nick that is not authorised on a +bitch channel answers
 * fail|bitch, which the origin turns into channel.not_authorised. */
#define CHAN_ELECT_PROBE_WAIT 3   /* s: local bots' answers (whole seconds: >= 2 s) */
#define CHAN_ELECT_MESH_WAIT  5   /* s: other hubs' answers (their probe wait + 2) */
#define CHAN_ELECT_DO_WAIT    5   /* s: one bot's DONE                      */
#define CHAN_ELECT_HUB_WAIT   12  /* s: one hub's ELECT_DONE (it may retry)  */
#define CHAN_ELECT_TTL        40  /* s: hard end of any election            */
/* An origin whose mesh view is still settling holds its mesh ask (CE_HOLD):
 * up to CHAN_ELECT_SETTLE s after start while configured peers are still
 * dialing, or while a peer linked less than that ago has not yet named its
 * version (sync_held).  At most CHAN_ELECT_HOLD_MAX s, once per election;
 * HOLD_MAX + PROBE + MESH + DO + HUB_WAIT stays within CHAN_ELECT_TTL. */
#define CHAN_ELECT_SETTLE     10
#define CHAN_ELECT_HOLD_MAX   10
#define MAX_CHAN_ELECTIONS    16
#define CHAN_ELECT_REASON_MAX 48

/* --- Network-wide upgrade coordination (console-initiated rolling upgrade).
 * Fan PREPARE out to bots + peer hubs, collect READY/UNABLE acks routed home by
 * origin_fd (like CMD_OP_*), then COMMIT node-by-node and await RESULT.  Mirror
 * in ircbot/bot.h, irchub.rs/consts.rs, ircbot.rs/consts.rs and
 * docs/ARCHITECTURE.md.  Payloads are '|'-delimited text. */
#define CMD_UPGRADE_PREPARE      0x5E // Hub -> Bot/Hub: id|ver|variant|kind|min_from|base
#define CMD_UPGRADE_READY        0x5F // Bot/Hub -> Hub: id|uuid|cur|variant|arch|libc|ok|reason
#define CMD_UPGRADE_COMMIT       0x60 // Hub -> node: id|ver|variant
#define CMD_UPGRADE_RESULT       0x61 // node -> Hub: id|uuid|status|new_ver|detail
#define CMD_UPGRADE_ABORT        0x62 // Hub -> all: id|reason
#define CMD_ADMIN_UPGRADE_NET    0x63 // console -> Hub: ver|variant|kind|min_from|base
#define CMD_ADMIN_UPGRADE_STATUS 0x64 // console -> Hub: ""=poll, "abort"=stop+roll back

/* Sealed bot-to-bot relay across hubs.  CMD_BOT_RELAY names its target by
 * uuid only; when that bot is not connected here the hub stamps the frame
 * with a request id and floods it to its peers, each of which delivers it
 * (as CMD_BOT_MSG) if the target is one of its own bots and otherwise passes
 * it on minus the link it came in on.  The id goes through the shared
 * seen_forwards ring, so a cycle in the peer graph cannot keep it moving,
 * and a frame older than BOT_RELAY_FWD_TTL is dropped.  The sender uuid is
 * the one the ORIGIN hub authenticated; the target bot still checks the
 * sealed payload against that sender's key (AAD binding), so a peer cannot
 * forge a command.  Hub <-> hub only: bots never see this opcode.
 * Payload: id|origin_ts|sender_uuid|target_uuid|cipher:tag */
#define CMD_BOT_RELAY_FWD 0x65
#define BOT_RELAY_FWD_TTL 30 /* seconds a forwarded relay stays deliverable */
/* CMD_BOT_RELAY a local bot may send per second; the rest are dropped.  Each
 * one not for a local bot goes to every peer, so one bot could fill them. */
#define BOT_RELAY_PER_SEC 20
/* A client with output queued that takes no byte of it for this long is
 * dropped: a bot or peer that stopped reading only looks connected. */
#define WRITE_STALL_TIMEOUT 60
/* A full DELTA/BULK lane's drop warning: one line per client this often. */
#define QUEUE_DROP_LOG_EVERY 60
/* A bot whose new session replaces a live one more often than this in an
 * hour is warned about: two processes with one key, or a stolen key. */
#define BOT_REPLACE_WARN_PER_HOUR 3

/* Drop the roll-up plan mesh-wide.  Every hub that followed a run keeps that
 * run's plan in its own .irchub.cnf (a hub-local `rollup|` line) and walks any
 * bot that comes back behind it up to the target; an admin's
 * CMD_ADMIN_UPGRADE_STATUS "forget" drops it on the hub it is logged into and
 * floods this frame so every other hub drops its copy too.  Loop-suppressed
 * by the seen_forwards ring like CMD_BOT_RELAY_FWD, refused while the config
 * freeze (a run in flight) is up.  Hub <-> hub only.
 * Payload: id|origin_ts */
#define CMD_UPGRADE_FORGET 0x66
#define UPGRADE_FORGET_TTL 60 /* seconds a forwarded forget stays valid */

/* A config broadcast: the payload of CMD_PEER_SYNC, sent by a hub to EVERY
 * peer it is linked to (minus the one it forwards for).  What it adds is that
 * fact, which the receiver may rely on when it forwards what it accepted: a
 * peer the sender is linked to right now already has the frame first hand,
 * so the forwarder skips it (hub_broadcast_sync_to_peers' split horizon).  On
 * a full mesh that turns one copy of every accepted update from every hub
 * into none.  Point-to-point syncs (the reply to CMD_SYNC_REQUEST, the sync a
 * new link opens with) stay CMD_PEER_SYNC: a forwarder must reach everyone
 * with those.  Sent only to a peer whose roster gossip carries l| lines, i.e.
 * one that knows this opcode; an older peer gets CMD_PEER_SYNC as before. */
#define CMD_PEER_BCAST 0x67
/* After a peer link drops, ask the remaining peers for a full sync this many
 * seconds later: a forwarder may have skipped us on the strength of that
 * link in the moment before the drop reached its gossip. */
#define SYNC_RESYNC_AFTER_LINK_LOSS 5

/* Admin -> Hub: this hub's traffic counters since it started (read-only,
 * empty payload).  Reply lines, zero rows left out:
 *   stats|up=<s>
 *   cfg|sent=<n>|same=<n>|lost=<n>        full config pushes to bots
 *   sync|frames=<n>|noop=<n>|records=<n>|applied=<n>   PEER_SYNC/BCAST in
 *   op|0x<cc>|rx=<frames>/<bytes>|tx=<frames>/<bytes>
 * "same" = a push skipped because that bot was already sent the identical
 * config; "lost" = a queued push dropped on overflow (that bot is re-sent the
 * next one in full).  rx counts every authenticated frame this hub decrypted,
 * tx every frame it sent from its outbound queues (the ping/pong keepalive and
 * direct admin/bot replies are not queued and not counted). */
#define CMD_ADMIN_STATS 0x68

/* ---- Activity (last seen / last used) -----------------------------------
 * An admin/oper's last_seen and a usermask's last_used are max-merged values
 * OUTSIDE the LWW config: they only ever rise, a rise is never a config
 * change (no record forward, no bot push), and every hub converges on the
 * latest time any node saw.  A node reports a record only on its first use
 * within an ACTIVITY_BUCKET (a clock hour), with that use's exact time; later
 * uses in the same bucket stay local.  A hub that receives CMD_ACTIVITY keeps
 * max(stored, ts) and forwards to its other peers only the lines that raised
 * its value, so a flood dies out without a seen-set.  PEER_SYNC / CONFIG_PUSH
 * max-merge the same fields as a repair path (anti-entropy).
 * A ban's last use (a bot saw an unauthorised member match a listed,
 * non-sticky ban) cannot ride its B| line, whose last field before the stamp
 * is the op: it lives beside the record (config_entry_t.last_used), is saved
 * as a bu| line in the cnf, and a hub repairs a peer by sending all of them
 * as CMD_ACTIVITY right after the link's initial sync (hub_activity_send_bans).
 * Mirrors ircbot/bot.h, irchub.rs + ircbot.rs consts.rs.
 *
 *   CMD_ACTIVITY        bot -> hub, hub <-> hub.  Lines:
 *                         a|<user_uuid>|<ts>          (admin or oper)
 *                         m|<user_uuid>|<mask>|<ts>
 *                         B|<#chan|*>|<mask>|<ts>     (a listed ban's last use)
 *   CMD_ACTIVITY_QUERY  bot -> hub: <req_id>|users   or
 *                                   <req_id>|masks|<user_uuid or *>
 *                       ("masks" answers that user's a| line too)
 *   CMD_ACTIVITY_REPLY  hub -> bot: first line <req_id>|<more>, then a|/m|
 *                       lines; chunked under MAX_BUFFER, more=0 on the last. */
#define CMD_ACTIVITY       0x69
#define CMD_ACTIVITY_QUERY 0x6A
#define CMD_ACTIVITY_REPLY 0x6B
#define ACTIVITY_BUCKET    3600 /* report the first use per this many seconds */
/* A reported time this far ahead of our clock is refused: activity only
 * rises, so one bogus future stamp would stick for good. */
#define ACTIVITY_MAX_FUTURE 300
#define ACTIVITY_REQ_ID_MAX 32

/* ---- SSH admin console (docs/console.md) --------------------------------
 * The hub's only admin interface: an SSH server on the hub's own port, run on
 * a console thread (hub_console.c) that never touches hub_state_t.  Each
 * logged-in console reaches the core over its own socketpair, as an admin
 * connection that is already authenticated (hub_client_t.internal): plaintext
 * frames len(4, big-endian) || op(1) || payload.  CMD_CONSOLE is the one
 * opcode that exists only there -- console -> core "sub|<topics>" /
 * "get|tree" / "get|log", core -> console "<topic>|<data>" events.  It
 * never appears on the network; a bot or peer sending it is ignored like any
 * other opcode it has no business sending.  Mirrors irchub.rs consts.rs. */
#define CMD_CONSOLE        0x6C
#define CONSOLE_REPLY      0x00  /* core -> console: reply to the request   */
#define CONSOLE_MAX_PREAUTH   8     /* SSH connections not yet logged in    */
#define CONSOLE_MAX_PREAUTH_CAP 64  /* ceiling `hub set ssh preauth` accepts */
#define CONSOLE_MAX_SESSIONS  8     /* open consoles                        */
#define CONSOLE_LOGIN_GRACE   20    /* connect -> running shell, seconds    */
#define CONSOLE_IDLE_TIMEOUT  1800  /* seconds without a keystroke          */
#define CONSOLE_MAX_AUTH_TRIES 3    /* refused keys before the drop         */
/* The first bytes of an accepted connection decide console vs. bot/peer.  A
 * sender that has not produced 4 bytes within this window is treated as the
 * bot/peer protocol (whose own pre-auth timeout then applies). */
#define CONSOLE_SNIFF_MS      2000
/* Core-side queue towards one console.  A reply that does not fit closes the
 * console (fail-secure); an event or log line that does not fit is dropped
 * and counted ("drop|<n>"). */
#define CONSOLE_CORE_OUTQ_MAX (1024 * 1024)
/* In-memory ring of recent log lines the log view and "log on" replay. */
#define CONSOLE_LOG_RING      1024
#define CONSOLE_LOG_LINE_MAX  512
/* Coalescing of pushed events. */
#define CONSOLE_NAME_MAX      64

#define MAX_PENDING_CHAN_REQUESTS 200
#define CHAN_REQUEST_TIMEOUT 45   // Reap a pending request with no reply

/* ---- Network upgrade run (CMD_UPGRADE_*, CMD_ADMIN_UPGRADE_NET) ----------
 * One run at a time per hub: the whole point is that exactly one plan drives
 * the mesh while the config is frozen. */
/* A run spans the whole mesh, not one hub's clients: every registered bot
 * (the config holds at most MAX_BOTS mesh-wide), every hub the mesh can know
 * (MAX_MESH_HUBS remote plus MAX_PEERS direct), plus this hub.  Sized to
 * MAX_CLIENTS + 1 it left 10 bots out of an 11-hub, 100-bot network. */
#define MAX_UPGRADE_NODES (MAX_BOTS + MAX_MESH_HUBS + MAX_PEERS + 1)
/* Downstream routes a follower remembers for a run it is only relaying: one
 * per node it forwarded an answer for.  See upgrade_route_t. */
#define MAX_UPGRADE_ROUTES MAX_UPGRADE_NODES
#define UPGRADE_PREPARE_TIMEOUT 45  /* stop waiting for READY acks          */
/* PREPARE also stays open this long after the node table last grew: a hub
 * several hops out is unknown to the driver until its first READY arrives. */
#define UPGRADE_PREPARE_SETTLE 3
#define UPGRADE_COMMIT_TIMEOUT 420  /* a node must be back, upgraded, by now */
/* Bots go in waves so a channel never loses every bot at once, and peer hubs
 * go one at a time so the mesh never fully drops. */
#define UPGRADE_BOT_WAVE_MAX 4
#define UPGRADE_BOT_WAVE_DIVISOR 4  /* never commit more than 1/N of the bots */
/* How long a CMD_UPGRADE_PREPARE this hub acknowledged stays commitable.  A
 * driver that stalls mid-roll has to ask again rather than commit against a
 * stale plan.  Mirrors UPGRADE_PREPARE_TTL in ircbot/bot.h. */
#define UPGRADE_PREPARE_TTL 900
/* A selective run (CMD_ADMIN_UPGRADE_NET's 8th field) names at most this many
 * nodes; an empty selection is the whole network. */
#define MAX_UPGRADE_SELECT 16
/* Releases listed by the admin console "releases" query, per product. */
#define MAX_UPGRADE_RELEASES 24
/* A bot back on the target that never sends its ready report is taken as
 * done after this long (it runs; its channels are its own business). */
#define UPGRADE_OPS_GRACE 240
/* The staged new binary's -selftest must finish within this many seconds. */
#define UPGRADE_SELFTEST_SECS 15

/* ---- Offline roll-up (upgrade plan, Task 7) ----------------------------
 * A node that was down, or homed elsewhere, when a run went through comes
 * back on the old build.  The hub brings it up to the last completed run's
 * target by itself, ONE node at a time and WITHOUT freezing the config: a
 * single late bot is not a reason to hold the whole network's config still.
 * Bounded on purpose — a node that keeps failing must not be re-committed on
 * every reconnect. */
#define ROLLUP_MAX_TRIES   3    /* per node, per hub lifetime               */
#define ROLLUP_COOLDOWN    900  /* seconds between attempts on one node     */
#define ROLLUP_SETTLE      20   /* seconds after a node appears before we try */
#define ROLLUP_STAGE_WAIT 3    /* READY, then this long to say it can stage */
#define ROLLUP_TIMEOUT     300  /* give up on one attempt after this        */
#define UPGRADE_RESULT_RELAY_MAX 640 /* longest UPGRADE_RESULT passed between hubs */
#define MAX_ROLLUP_TRIES   64   /* nodes remembered in the attempt ledger   */
/* A plan only exists while somebody is owed it: it is dropped as soon as every
 * registered bot and every known hub is on the target, and after this long
 * regardless -- a bot down for a day is likely coming back, one down for
 * months is not, and its admin can still run an upgrade by hand. */
#define ROLLUP_PLAN_TTL    (7 * 86400)

/* ---- Upgrade history (hub_uhist.c) --------------------------------------
 * The last runs, one uhist| line each, replicated hub to hub.  UHIST_NODE_MAX
 * holds a node with every string field fully %XX-escaped; the 6144 holds the
 * header the same way (the selection is the only long field). */
#define MAX_UPGRADE_HISTORY 20
#define UHIST_DEFAULT_KEEP  10
#define UHIST_NODE_FIELDS   14
#define UHIST_HEADER_FIELDS 20
#define UHIST_NODE_MAX      1280
#define UHIST_LINE_MAX ((size_t)6144 + (size_t)MAX_UPGRADE_NODES * UHIST_NODE_MAX)
/* D|keep| plus id:rev:started for every record. */
#define UHIST_DIGEST_MAX (32 + MAX_UPGRADE_HISTORY * (64 + 20 + 20 + 3))
#define UHIST_MIN_PREFIX    4   /* upgrade history <run>: shortest id prefix */

/* ---- Multi-step upgrades (2.5.1) ---------------------------------------
 * A target a node cannot jump to directly (it sits below the release's
 * min_from) is reached through the intermediate releases the manifests name.
 * The hub an admin starts the upgrade on plans the whole path up front and
 * drives it as a sequence of ordinary runs, one per step, every node
 * finishing a step before any starts the next.  The plan is persisted in
 * this hub's own .irchub.cnf (an `uplan|` line) because the hub restarts
 * onto each step itself. */
#define MAX_UPGRADE_STEPS    16    /* longer paths are refused at start     */
#define UPGRADE_PLAN_SETTLE  60    /* seconds between steps, and after boot */
#define UPGRADE_PLAN_TTL     86400 /* a plan with no progress for this long is dropped */
#define UPGRADE_PLAN_MESH_WAIT 300 /* how long a next step waits for the mesh to relink */
#define UPGRADE_PLAN_RERUNS  3     /* a step cut off this often goes on hold */
#define MAX_PLAN_LEFT        12    /* nodes one plan remembers leaving behind; then it holds again */
/* One plan line at its caps: paths, selection, and the short fields around them. */
#define HUB_PLAN_LINE_MAX    (MAX_UPGRADE_STEPS * 65 * 2 + MAX_UPGRADE_SELECT * 80 + MAX_PLAN_LEFT * 37 + 1536)
#define UPGRADE_PLAN_BEAT    60    /* the driver says it is alive this often */
#define UPGRADE_DRIVER_SILENCE 900 /* then another hub takes the plan over */
/* An `upgrade abort` is re-sent to every peer link that comes up for this
 * long, so a planner restarting onto a step when it was typed still gets it. */
#define UPGRADE_CANCEL_HOLD  600

typedef struct {
  bool   active;
  char   bot_target[64];      /* the final targets the admin asked for     */
  char   hub_target[64];      /* "" = hubs are not moved                   */
  char   variant[8];
  char   kind[8];
  char   sel[MAX_UPGRADE_SELECT * 80]; /* the admin's selection, as typed  */
  char   bot_from[64];        /* the oldest bot / hub when it was planned  */
  char   hub_from[64];
  char   bot_path[MAX_UPGRADE_STEPS][64];
  int    bot_steps;
  char   hub_path[MAX_UPGRADE_STEPS][64];
  int    hub_steps;
  int    step;                /* 0-based: the step running, or next        */
  char   run_id[64];          /* the run driving `step`; "" = none yet     */
  time_t started;
  time_t progressed;          /* last step started or finished            */
  time_t next_at;             /* volatile: when the next step may start    */
  time_t mesh_until;          /* volatile: stop waiting for the mesh then  */
  char   summary[192];        /* why it ended (kept after it stops)        */
  /* Who drives it, and how many times it has changed: every hub keeps a copy
   * (hub_state_t.splan), and the highest (started, rev) is the truth. */
  char   driver[64];
  char   driver_name[64];    /* its name when it published, for logs   */
  long long rev;
  bool   single;              /* one plain run, published but with no steps */
  int    reruns;              /* a step cut off by restarts, and run again  */
  char   self_target[64];     /* this hub's own swap is waiting to be seen  */
  char   last_run[64];        /* the step that closed: who to wait for      */
  /* A plan on hold: the network sits at its last closed step, and says why. */
  char   hold[192];
  bool   hold_rerun;          /* resuming runs this step again, else the next */
  char   hold_uuid[64];       /* it resumes itself once this node ... */
  char   hold_ver[64];        /* ... runs this */
  char   left[MAX_PLAN_LEFT * 37 + 1]; /* comma list: upgrade continue left these behind */
} upgrade_plan_t;

/* A stored run: the line as it came, plus what the merge compares. */
typedef struct {
  char *body;
  char id[64];
  long long rev;
  time_t started;
} uhist_rec_t;

/* A run parsed for reading or amending; never kept in the store. */
typedef struct {
  char kind[2];       /* b, h, s = the driver                             */
  char state[16];
  char uuid[64];
  char name[64];
  char from[64];
  char to[64];
  char base[8];
  char want[8];
  char arch[32];
  char libc[16];
  long long committed, back, done;
  char reason[128];
  /* Newer readers only; an older one stops at reason. */
  char code[16];     /* why it did not make it: disk, net, selftest, ... */
  char build[8];     /* bin or src */
  long long stage_s; /* how long getting it ready took */
} uhist_node_t;

typedef struct {
  char id[64];
  long long rev;
  char driver_uuid[64];
  char driver_name[64];
  char by[64];
  long long started, rolling_at, ended;
  char result[16];
  char bot_ver[64];
  char hub_ver[64];
  char variant[8];
  char kind[8];
  char min_from[64];
  long long plan_id;
  int step, steps;
  char sel[MAX_UPGRADE_SELECT * 72];
  char summary[192];
  uhist_node_t *nodes; /* heap; hub_uhist_view_free */
  int node_count;
} uhist_view_t;

typedef struct {
  char request_id[64];
  char requester_uuid[64];  // Bot that is locked out
  char kind[8];             // "unban" | "invite" | "key"
  char channel[MAX_CHAN];
  int origin_fd;            // Peer fd the request came from, -1 if local bot
  uint64_t origin_serial;   // ...and that link's conn_serial
  time_t timestamp;
  bool active;
} pending_chan_request_t;


#define MESH_ANTI_ENTROPY_INTERVAL 300
#define MAX_BOT_ENTRIES 64

#define MAX_HUB_USER_RECORDS 40   // max combined admin + oper records
/* The admin floor (hub_admin_floor_restore): +a removals stamped within
 * this many seconds of the newest one are one race and are all undone; the
 * ring of remembered 'a' flag drops. */
#define ADMIN_FLOOR_WINDOW   60
#define ADMIN_DROP_LOG       16
#define MAX_HUB_USER_MASKS   200  // max total usermask records across all users
/* Admin flags and oper channel bindings (user_flags plan §3.1).  The letters
 * in their canonical order: a full, b bots, c channels, h hub, o opers,
 * u upgrades.  Mirrored in ircbot/bot.h. */
#define USER_FLAG_LETTERS    "abchou"
#define USER_FLAGS_MAX       6
#define MAX_HUB_USER_FLAGS   MAX_HUB_USER_RECORDS  /* one uf| per user record */
#define MAX_HUB_CHAN_BINDS   400  /* uc| records, live and tombstones */
/* The stamp hub_access_migrate writes: older than any real record. */
#define USER_ACCESS_MIGRATE_TS 1

/* ==========================================================================
 * Bulk-payload ceilings (Change 5) — hard upper bounds on generated config /
 * sync payloads, derived entirely from the record-count macros above so they
 * auto-track whatever an operator sets.  These bound the *allocation cap*, not
 * the bytes actually sent (payloads carry only real records at real sizes).
 *
 * These are true hard bounds because ingest is bounded: per-bot state is
 * restricted to the whitelist {t,n,h,pub,seen,d,hl} with per-key value caps in
 * hub_storage_update_entry, so a bot has at most BOT_SYNC_FIELDS entries whose
 * lines never approach value[1024].  Keep this shared contract identical with
 * ircbot/bot.h (MAX_CONFIG_PAYLOAD).
 * ========================================================================== */
#define BOT_SYNC_FIELDS   8      /* {t,n,h,pub,seen,d,hl} = 7, +slack; hl has its own HK_LINE_MAX */
#define GLOBAK_LINE_MAX   1088   /* config_entry_t: key[32]+value[1024]+ts+seps */
#define BOT_FIELD_LINE    320    /* per-bot line: capped value (<=MAX_MASK_LEN) */
#define USER_LINE_MAX     384    /* a|/o|: uuid+name+COMBINED_KEY_B64+stamps */
#define MASK_LINE_MAX     352    /* m|: uuid+MAX_MASK_LEN */
#define BLINE_MAX         448    /* b|<mask>|<uuid>|<pubkey>|<ts> trusted-bot line */
#define PEER_LINE_MAX     256    /* peer|/opt| sync lines */
#define UF_LINE_MAX       96     /* uf|<uuid>|<flags>|<ts> */
#define UC_LINE_MAX       160    /* uc|<uuid>|<chan>|add/del|<ts> */
#define RV_LINE_MAX       256    /* rv|uuid|pub|pub_ts|nick|wiped|del_ts */
#define HS_LINE_MAX       96     /* hs|<name>|<value>|<ts> */
#define MAX_CRON_RECS     128    /* single-node cron settings: hs|cr.<b|h>.<uuid> */
#define HUB_GSETTINGS_MAX 8      /* hs| settings the registry may hold */
/* hl|<addr>/<fp>,...: the hubs a bot dials, pushed by the bot, stored as its
 * per-bot entry "hl" (never sent to bots).  <fp> = hex of SHA-256(the hub's
 * Ed25519 key)[0..8].  Mirrors ircbot's bot.h. */
#define HL_ADDR_MAX       80
#define HL_FP_LEN         16
#define HL_ENTRIES_MAX    10     /* ircbot MAX_SERVERS */
#define HL_VALUE_MAX      (HL_ENTRIES_MAX * (HL_ADDR_MAX + 1 + HL_FP_LEN + 1))
#define HK_LINE_MAX       (HL_VALUE_MAX + 64)  /* b|<uuid>|hl|<value>|<ts> */
/* What rv| and hs| add to a bulk payload at their caps. */
#define REVOKE_RECORDS_MAX \
  ( MAX_REVOKED * RV_LINE_MAX + (HUB_GSETTINGS_MAX + MAX_CRON_RECS) * HS_LINE_MAX )
/* What uf| and uc| add to a bulk payload at their caps. */
#define USER_ACCESS_RECORDS_MAX \
  ( MAX_HUB_USER_FLAGS * UF_LINE_MAX + MAX_HUB_CHAN_BINDS * UC_LINE_MAX )
#define PAYLOAD_SLACK     8192

/* ---- Modes / settings / bans records (docs/modes.md §2, 2.4.5) ----------
 * C|<#chan>|<modes>|<settings>|<op>|<ts>   channel settings (console only)
 * D|<modes>|<settings>|<ts>                network defaults (console only)
 * B|<#chan|*>|<mask>|<expires>|<flags>|<setter>|<reason>|<op>|<ts>   one ban
 * They live in global_entries[] beside c|, under the same LWW store.  Every
 * field is capped at the single ingest point (hub_storage_put_record), and the
 * bulk ceilings below grow by exactly these counts x line sizes, so they stay
 * hard bounds.  Mirrored in ircbot/bot.h.  MAX_BANS_TOTAL counts live bans
 * AND tombstones. */
#define MAX_CHANNELS        MAX_BOT_ENTRIES /* c| and C| records each      */
#define C_MODES_MAX         64    /* modes field, e.g. "+stnkl 20"          */
#define C_SETTINGS_MAX      512   /* C| settings field                      */
#define D_SETTINGS_MAX      512   /* D| settings field                      */
#define BAN_MASK_MAX        120
#define BAN_REASON_MAX      120
#define BAN_SETTER_MAX      64    /* admin name or bot uuid, with the NUL   */
#define MAX_BANS_PER_CHAN   100
#define MAX_GLOBAL_BANS     100   /* bans whose channel is "*"              */
#define MAX_BANS_TOTAL      (MAX_CHANNELS * MAX_BANS_PER_CHAN + MAX_GLOBAL_BANS)
/* One serialized line each: tag + every field at its cap + op + 20-digit
 * stamp + separators + newline, rounded up. */
#define C_LINE_MAX          704
#define D_LINE_MAX          640
#define B_LINE_MAX          448
/* K|<#chan>|<key>|<modes>|<ts>: what the bots saw on IRC (learned key, M_K /
 * M_I bits).  Never existence: kept only while the channel's c| is add, one
 * per channel, dropped with it (docs/plans/2026-10-20_learned_state_purge_plan.md). */
#define K_LINE_MAX          (2 + MAX_CHAN + MAX_KEY + 32)
#define K_MODES_MASK        (64 | 128)   /* M_K | M_I */
/* bu|<#chan|*>|<mask>|<last_used>: a ban's last use, cnf only (activity). */
#define BU_LINE_MAX         (MAX_CHAN + BAN_MASK_MAX + 32)
/* global_entries[]: the old c/m/o rows (MAX_BOT_ENTRIES), then C, D, B. */
#define MAX_GLOBAL_ENTRIES \
  ( MAX_BOT_ENTRIES + MAX_CHANNELS + 1 + MAX_BANS_TOTAL )
#define GLOBAL_IDX_SLOTS    ( 2 * MAX_GLOBAL_ENTRIES )  /* open addressing, load <= 0.5 */
/* Live bans of one channel: rep = index + 1 of a B entry that names it. */
typedef struct { int rep; int live; } global_ban_slot_t;
#define BOT_BANS_PER_CHAN   10    /* live bans one bot may hold per channel  */
#define TOMB_MIN_AGE_OFF    (7 * 86400L) /* tombstone age kept when purge is off */
#define BAN_BOT_SLACK       60    /* s a bot-written ban may exceed bantime */
#define BANTIME_DEFAULT_MIN 120   /* built-in bantime (minutes)             */
#define BAN_SWEEP_INTERVAL  60    /* s between expiry sweeps                */
/* What C|, D|, B| and K| add to a bulk payload at their caps. */
#define MODES_RECORDS_MAX \
  ( MAX_CHANNELS * C_LINE_MAX + D_LINE_MAX + MAX_BANS_TOTAL * B_LINE_MAX + \
    MAX_CHANNELS * K_LINE_MAX )

/* Bot config payload (hub_generate_bot_payload): globals + users + masks +
 * this bot's own fields + one b| line per other bot. */
#define MAX_CONFIG_PAYLOAD \
  ( MAX_BOT_ENTRIES      * GLOBAK_LINE_MAX + \
    MAX_HUB_USER_RECORDS * USER_LINE_MAX   + \
    MAX_HUB_USER_MASKS   * MASK_LINE_MAX   + \
    USER_ACCESS_RECORDS_MAX                + \
    BOT_SYNC_FIELDS      * BOT_FIELD_LINE  + \
    MAX_BOTS             * BLINE_MAX       + \
    MODES_RECORDS_MAX                          + \
    PAYLOAD_SLACK )

/* Hub<->hub full-state sync (hub_generate_sync_packet): globals + users +
 * masks + every bot's fields + peer/opt lines. */
#define MAX_SYNC_PAYLOAD \
  ( MAX_BOT_ENTRIES      * GLOBAK_LINE_MAX + \
    MAX_HUB_USER_RECORDS * USER_LINE_MAX   + \
    MAX_HUB_USER_MASKS   * MASK_LINE_MAX   + \
    USER_ACCESS_RECORDS_MAX                + \
    MAX_BOTS * BOT_SYNC_FIELDS * BOT_FIELD_LINE + \
    MAX_BOTS             * HK_LINE_MAX     + \
    MAX_PEERS            * PEER_LINE_MAX   + \
    MODES_RECORDS_MAX                          + \
    REVOKE_RECORDS_MAX                         + \
    PAYLOAD_SLACK )

/* hub_config_write() buffer: every serialized section at its bound, with the
 * per-bot term scaled by the bots actually present.  A config that does not
 * fit is NOT written (the old file is kept) — never a truncated one.
 * ircbot-testnet's tools/c/hub_tool.h derives HUB_TOOL_MAX_CONFIG from this at
 * MAX_BOTS. */
/* The persisted roll-up plan (see pending_rollup_t): rollup| + target,
 * variant, kind, min_from, hub_target, plan_set and two empty base slots. */
#define ROLLUP_LINE_MAX 1536
/* The persisted multi-step plan (see upgrade_plan_t): uplan| + the fixed
 * fields, both paths (MAX_UPGRADE_STEPS versions each) and the selection. */
#define PLAN_LINE_MAX \
  ( (size_t)512 + (size_t)2 * MAX_UPGRADE_STEPS * 65 + \
    (size_t)MAX_UPGRADE_SELECT * 80 )
#define HUB_CONFIG_FIXED_MAX \
  ( (size_t)8192 + (size_t)ROLLUP_LINE_MAX + (size_t)PLAN_LINE_MAX + \
    (size_t)MAX_UPGRADE_HISTORY * UHIST_LINE_MAX + \
    (size_t)MAX_BOT_ENTRIES      * GLOBAK_LINE_MAX + \
    (size_t)MAX_HUB_USER_RECORDS * USER_LINE_MAX   + \
    (size_t)MAX_HUB_USER_MASKS   * MASK_LINE_MAX   + \
    (size_t)USER_ACCESS_RECORDS_MAX                + \
    (size_t)MODES_RECORDS_MAX                      + \
    (size_t)REVOKE_RECORDS_MAX                     + \
    (size_t)MAX_BANS_TOTAL       * BU_LINE_MAX     + \
    (size_t)2 * MAX_IP_ACL_ENTRIES * IP_ACK_LINE_MAX + \
    (size_t)MAX_PEERS            * 512 )
#define HUB_CONFIG_PER_BOT_MAX ((size_t)MAX_BOT_ENTRIES * 1100)

/* Largest bulk lane payload — buffers on the config/sync paths size to this. */
#define MAX_BULK_PAYLOAD \
  ((MAX_CONFIG_PAYLOAD) > (MAX_SYNC_PAYLOAD) ? (MAX_CONFIG_PAYLOAD) \
                                             : (MAX_SYNC_PAYLOAD))

/* ==========================================================================
 * Bot-presence gossip sizing (the 'bots' tree).  Same macro-derived discipline
 * as the ceilings above: every bound below follows from MAX_BOTS / MAX_PEERS,
 * so raising either retracks the buffers automatically.  None of this touches
 * the config store — see the CMD_BOT_PRESENCE block near the opcodes.
 * ========================================================================== */
#define BOT_PRESENCE_INTERVAL 60   /* how often a hub gossips its own bots   */
#define BOT_TREE_REFRESH      300  /* whole-tree re-push to pre-delta bots    */
/* Bots from this version apply CMD_BOT_TREE_DELTA and check the tree hash a
 * keepalive PING carries ("t|<fnv64hex>"); older ones get whole trees. */
#define TREE_DELTA_MIN_BOT    "2.5.3"
/* Change pushes are coalesced: news from the mesh (peer gossip, links, TTL
 * expiry) reaches bots at most once per BOT_TREE_COALESCE — it is already up
 * to a gossip interval old — while a change to this hub's own bots goes out
 * within BOT_TREE_COALESCE_LOCAL.  A quiet mesh pushes at once (leading edge);
 * the flag is held until the push, so the latest tree always lands. */
#define BOT_TREE_COALESCE       30
#define BOT_TREE_COALESCE_LOCAL 2
/* A bot's CMD_BOT_TREE_PULLs are served at most once per this many seconds;
 * one inside the gap is held and served when it ends (hub_tree_pull). */
#define TREE_PULL_MIN_GAP       2
#define BOT_ROSTER_TTL        240  /* entry nobody refreshed since -> dropped */
#define ROSTER_VERSION_MAX    15   /* "2.3.0", with room to grow             */
#define ROSTER_VARIANT_MAX    7    /* code base: "c" / "rs"                  */
/* The longest CMD_BOT_PRESENCE payload read: version|server|started|variant|
 * cron|link_ord at their caps (a 64-bit number is at most 20 digits), plus
 * room for fields a newer bot adds.  Anything longer is cut, and then the
 * link-order counter (last) is not trusted: it reads 0. */
#define BOT_PRESENCE_MAX \
  (ROSTER_VERSION_MAX + ROSTER_SERVER_MAX + 20 + ROSTER_VARIANT_MAX + CRON_STATUS_MAX + 20 + 5 + 64)
#define ROSTER_SERVER_MAX     63   /* host:port of the bot's IRC link        */
#define ROSTER_IP_MAX         45   /* INET6_ADDRSTRLEN - 1                   */
#define ROSTER_FRAME_BUDGET   8192 /* chunk gossip well under MAX_BUFFER     */
#define TREE_ROW_MAX          256  /* one tree row at its field caps         */
/* One entry per (reporting hub, bot).  A hub only ever reports bots connected
 * to itself, so the mesh-wide worst case is every hub carrying MAX_BOTS. */
#define MAX_BOT_ROSTER        ((MAX_PEERS + 1) * MAX_BOTS)
/* Hubs the tree can know mesh-wide, direct peers or not.  Each hub's roster
 * gossip is relayed hop by hop (see CMD_BOT_ROSTER), so a chain or a star
 * still draws every hub; this bounds the per-origin relay bookkeeping. */
#define MAX_MESH_HUBS         64
/* Hops a relayed roster frame may still travel when its origin sends it. */
#define ROSTER_RELAY_HOPS     16
/* Hub rows are hung no deeper than this; the bots render up to depth 32. */
#define MAX_TREE_DEPTH        30
/* A forwarder trusts a sender's reported links (for the sync split horizon)
 * only while the report is this fresh: past one missed gossip round it
 * forwards to everyone, as a hub that never reported links is. */
#define SYNC_SPLIT_HORIZON_FRESH (2 * BOT_PRESENCE_INTERVAL + 10)
/* Presence events (a bot linked or left, a peer link came up or went down) gossip at
 * once; a burst is damped: each event gossip within PRESENCE_FLAP_WINDOW of the last
 * doubles the hold before the next (1, 2, 4 ... PRESENCE_HOLD_MAX s), and a quiet
 * window resets it.  Events inside a hold coalesce into one round.  A link that comes
 * up gossips again PRESENCE_LINK_REGOSSIP later: the first round can be lost to the
 * duplicate-link race (both ends dial, one link closes). */
#define PRESENCE_FLAP_WINDOW   30
#define PRESENCE_HOLD_MAX      30
#define PRESENCE_LINK_REGOSSIP 3
/* Tree rows: every hub node, every bot beneath one, plus the disconnected
 * tail (bounded by the bots the config knows about). */
#define MAX_TREE_ROWS         (MAX_MESH_HUBS + MAX_PEERS + 1 + MAX_BOT_ROSTER + MAX_BOTS)
/* Open-addressed uuid set for one tree (hub_build_tree's "each bot once", the
 * delta builder's row keys): a power of two at least twice MAX_TREE_ROWS. */
#define TREE_USET_SLOTS       4096
_Static_assert(TREE_USET_SLOTS >= 2 * MAX_TREE_ROWS &&
                   (TREE_USET_SLOTS & (TREE_USET_SLOTS - 1)) == 0,
               "tree uuid set: a power of two, at most half full");
#define MAX_TREE_PAYLOAD      ((MAX_TREE_ROWS) * TREE_ROW_MAX + PAYLOAD_SLACK)

/* ==========================================================================
 * Mesh transport tuning (see docs/mesh.md)
 * ========================================================================== */
#define LANE_COUNT                3
#define MAX_QUEUE_PER_LANE        256          /* per peer/client, per lane */
/* Must hold one full bulk payload plus concurrent small-lane traffic (deltas,
 * op grants) on a connection — a multiple of the bulk ceiling.  Enforced cap,
 * not a reservation, so a large value costs nothing until actually queued. */
#define MAX_QUEUED_BYTES_PER_PEER (3 * (MAX_BULK_PAYLOAD))

/* Change 5 guard: a single bulk payload must fit within a connection's queue
 * byte budget, else a full config/sync could never be enqueued.  Compile-time
 * so a future macro change that breaks the relationship fails the build rather
 * than silently dropping payloads at runtime. */
_Static_assert(UHIST_LINE_MAX + 16 <= MAX_SYNC_PAYLOAD,
               "one upgrade history record must fit a peer frame");
_Static_assert(MAX_QUEUED_BYTES_PER_PEER >= MAX_BULK_PAYLOAD,
               "per-peer queue budget must hold at least one bulk payload");
#define BULK_SOFT_BUDGET_BPS      (32 * 1024)
#define DELTA_HARD_BUDGET_BPS     (64 * 1024)

/* Lane indices (lower = higher priority). LANE_URGENT must be 0 so the drain
 * loop can rely on numeric ordering. */
typedef enum {
  LANE_URGENT = 0,   /* CMD_OP_REQUEST/GRANT/FAILED, CMD_OP_FORWARD_*  */
  LANE_DELTA  = 1,   /* small per-key deltas (b|uuid|h|...), global add/del */
  LANE_BULK   = 2,   /* CMD_PEER_SYNC, CMD_MESH_STATE, CMD_CONFIG_DATA  */
} lane_t;

typedef struct {
  char key[32];
  char value[1024];
  time_t timestamp;
  time_t last_used;   /* B| only: last ban match, max-merged outside LWW */
} config_entry_t;

/* K| (hub_storage.c hub_learned_*): one per managed channel. */
typedef struct {
  char   chan[MAX_CHAN];
  char   key[MAX_KEY];
  int    modes;          /* K_MODES_MASK bits */
  time_t ts;
} hub_chan_learned_t;

typedef struct {
  char   uuid[37];
  char   name[64];
  /* Per-user Curve25519 combined pubkey (Ed25519 + X25519), base64-encoded
   * (88 chars + NUL) — the user's only credential: SSH console logins and bot
   * ~A2 commands verify against it.  Empty (has_pubkey false) for a user not
   * yet given a key; such a user can authenticate nowhere.  The
   * matching private key lives only on the user's machine. */
  char   pubkey_b64[COMBINED_KEY_B64 + 1];
  bool   has_pubkey;
  char   type;         /* 'a' = admin, 'o' = oper */
  bool   is_active;    /* false when action == "del" */
  time_t last_seen;
  time_t timestamp;
} hub_user_record_t;

typedef struct {
  char   uuid[37];     /* matches hub_user_record_t.uuid */
  char   mask[MAX_MASK_LEN];
  bool   is_active;    /* false when action == "del" */
  time_t last_used;    /* 0 = never used */
  time_t timestamp;
} hub_mask_record_t;

/* Admin flags (docs/plans/2026-10-16_user_flags_plan.md §3.1):
 *   uf|<user_uuid>|<flags>|<ts>
 * One per user uuid, LWW (newer stamp; a tie keeps the fewer rights -- see
 * hub_uflags_accepts).  flags: letters of USER_FLAG_LETTERS in that order,
 * each once; "" = none.  No record = no flags (fail closed, R3). */
typedef struct {
  char   uuid[37];
  char   flags[USER_FLAGS_MAX + 1];
  time_t timestamp;
} hub_uflag_record_t;

/* Oper channel binding (§3.1):
 *   uc|<user_uuid>|<#chan|*>|add/del|<ts>
 * LWW per (uuid, channel), channel compared case-insensitively; a same-second
 * delete wins.  "*" = every channel.  No live binding = no access (R3). */
typedef struct {
  char   uuid[37];
  char   chan[MAX_CHAN];
  bool   is_active;
  time_t timestamp;
} hub_uchan_record_t;

typedef struct {
  char uuid[64];
  config_entry_t entries[MAX_BOT_ENTRIES];
  int entry_count;
  bool is_active;
  time_t last_sync_time;
} bot_config_t;

/* One revoked bot: rv|<uuid>|<pub>|<pub_ts>|<nick>|<wiped_ts>|<del_ts>.
 * Union-merged across hubs (hub_revoke_merge), never purged. */
typedef struct {
  char uuid[37];
  char pub[COMBINED_KEY_B64 + 1];
  time_t pub_ts;
  char nick[MAX_NICK];
  time_t wiped_ts;         /* last time it connected and wiped itself (0 = never) */
  time_t del_ts;
} hub_revoked_t;

typedef struct {
  char request_id[64];     // Unique ID for this request
  char requester_uuid[64]; // UUID of bot requesting ops
  char target_uuid[64];    // UUID of bot that should grant ops
  char channel[MAX_CHAN];  // Channel where ops are needed
  int origin_fd;           // FD to send response back to (-1 if local bot)
  uint64_t origin_serial;  // ...and that link's conn_serial
  time_t timestamp;        // When request was created
  bool active;             // Whether this slot is in use
} pending_op_request_t;

/* ---- Network upgrade orchestration --------------------------------------
 * Modeled on pending_op_request_t: a run carries its own id, routes its
 * status back down origin_fd, and every node it touches gets a row here.
 * Volatile on purpose — a hub that restarts mid-run has no business resuming
 * someone else's plan; it comes back with the freeze flag still set in the
 * replicated opt record and an admin clears it explicitly. */
typedef enum {
  UPG_NODE_PENDING = 0, /* PREPARE sent, no answer yet                   */
  UPG_NODE_READY,       /* answered ready; waiting for its turn          */
  UPG_NODE_UNABLE,      /* answered not-ready (reason says why)          */
  UPG_NODE_COMMITTED,   /* COMMIT sent; waiting for the restart          */
  UPG_NODE_DONE,        /* back on the target version                    */
  UPG_NODE_FAILED       /* said fail, or never came back in time         */
} upgrade_node_state_t;

typedef struct {
  char uuid[64];        /* bot uuid, or a peer hub's OWN hub uuid         */
  /* Display label: a peer hub is known to the mesh by its friendly name,
   * while every upgrade frame it sends is keyed by its uuid, so the table is
   * keyed by uuid and prints this.  "" for a bot (its uuid is its name). */
  char name[64];
  char kind;            /* 'b' bot, 'h' peer hub, 's' this hub           */
  char via[64];         /* peer hub a remote bot is reached through, else "" */
  int  fd;              /* the connection it was reached on, -1 if gone  */
  char cur_version[ROSTER_VERSION_MAX + 1]; /* what it ran when the run found it (status "from"; never moved to the target) */
  char variant[8];      /* "c" / "rs"                                    */
  /* The variant a selective run asked for THIS node ("name=c"), "" = the
   * run's own.  Sent in its PREPARE and COMMIT. */
  char want_variant[8];
  bool not_selected;    /* a selective run left it out: not a failure    */
  /* When a committed bot was first seen back on the target (its presence,
   * or a follower's "back").  That is not "done": the bot reports ok itself
   * once it is re-opped where it was (the next wave would otherwise leave a
   * channel before this bot holds ops in it again).  0 = not seen back yet. */
  time_t back_at;
  char arch[32];
  char libc[16];
  upgrade_node_state_t state;
  char reason[128];
  time_t committed_at;
  time_t done_at;       /* when it ended in the run (upgrade history)     */
  /* A hub node's READY says how many of ITS local bots it relayed PREPARE
   * to; the driver holds PREPARE open until that many relayed READYs are in,
   * so a peer's bots are never missed for answering a moment after it. */
  int relayed;
  /* Order its READY reached the driver in (1, 2, ...; 0 = none yet).  A
   * follower answers before it relays anything from below it, and every
   * answer travels the same FIFO peer links up, so a hub's READY always
   * lands ahead of any hub it routes for: descending ready_seq is
   * deepest-first along the COMMIT routes (see hub_upgrade_tick). */
  int ready_seq;
  /* Staging: this node said it can stage, and how that is going. */
  bool can_stage, staged, is_src, left;
  char stage_phase[16], stage_code[16];
  char stage_pct[8], stage_detail[48]; /* "~60%", "120 of 200 crates": how far it has got */
  time_t stage_sent, stage_last, staged_at;
  int stage_limit;      /* its limit for a prebuilt, from its history */
  int build_limit;      /* and for a source build */
  char cls;             /* f fast, s slow, p problem, u unknown */
  bool counted;         /* this failure has been weighed */
} upgrade_node_t;

/* One downstream node a FOLLOWER relays for.  A run reaches every hub in the
 * mesh, whatever shape it is wired in: each follower re-broadcasts PREPARE to
 * its own peers and forwards the answers back toward the driver, so a node
 * several hops away is still a node of the run.  COMMIT and ABORT travel the
 * same path in reverse, hop by hop, and this is the hop: "the peer I heard
 * <uuid> from is where a frame for <uuid> goes next". */
typedef struct {
  char uuid[64];  /* the node the driver is addressing                     */
  char via[64];   /* hub uuid of the peer it was learned from (next hop)   */
} upgrade_route_t;

typedef enum {
  UPG_IDLE = 0,
  UPG_PREPARE,  /* PREPARE fanned out, collecting READY/UNABLE           */
  UPG_ROLLING,  /* committing nodes wave by wave                         */
  UPG_DONE,
  UPG_FAILED,
  UPG_STAGING,  /* nodes getting the build ready; nothing has changed yet  */
  UPG_PARTIAL,  /* it ran, and some nodes did not take it                  */
  UPG_ABORTED
} upgrade_phase_t;

typedef struct {
  bool   active;
  char   id[64];              /* generate_request_id()                   */
  char   by[64];              /* the admin who typed it (upgrade history) */
  long long plan_id;          /* its plan's `started`; 0 = a one-step run */
  int    plan_step, plan_steps;
  time_t rolling_at;
  char   target_ver[64];
  char   variant[8];          /* "" = keep each node's own variant       */
  char   kind[8];             /* "" = let each node pick bin/src         */
  char   min_from[64];        /* "*" = any                               */
  /* The hubs' own target.  ircbot and irchub are separate products with
   * separate version lines and separate release trees, so a hub node is
   * never checked against `target_ver` — that is the bots'.  An empty
   * hub_ver leaves every hub on the build it runs. */
  char   hub_ver[64];
  int    origin_fd;           /* admin connection that started it, or -1 */
  time_t started;
  time_t phase_started;
  upgrade_phase_t phase;
  upgrade_node_t nodes[MAX_UPGRADE_NODES];
  int    node_count;
  time_t last_added;          /* when the node table last grew           */
  int    ready_seq_next;      /* last upgrade_node_t.ready_seq handed out */
  char   summary[192];        /* why it ended, shown by UPGRADE_STATUS   */
  /* Selective run: only these nodes move; every other node answers into
   * "not selected".  select_count == 0 is the whole network. */
  struct {
    char uuid[64];
    char variant[8];          /* "" = the run's variant                  */
  } select[MAX_UPGRADE_SELECT];
  int    select_count;
  char   sel_wire[MAX_UPGRADE_SELECT * 72]; /* uuid[=v],... for peers    */
  bool   build_stopped;       /* a build was stopped: the plan holds        */
  bool   hubs_stopped;        /* a peer hub failed: no more hubs move       */
} pending_upgrade_t;

/* The plan a completed run left behind, and the one node being walked up to
 * it right now.  The plan is persisted in this hub's own .irchub.cnf (a
 * `rollup|` line, hub-local and never replicated) so a restart does not forget what the network is
 * supposed to be running; the attempt in flight and the retry ledger stay
 * volatile.  The roll-up is a convenience, never the record of what the
 * network runs (that is each node's own presence), and it only ever chases a
 * target some other bot is demonstrably running (hub_rollup_target_proven). */
typedef struct {
  bool   have_plan;
  char   target[64];
  char   variant[8];
  char   kind[8];
  char   min_from[64];
  char   hub_target[64];  /* the run's hub target, "" = hubs were not moved */
  time_t plan_set;

  /* The attempt in flight, if any. */
  bool   active;
  char   id[64];          /* its own run id, distinct from any real run  */
  char   uuid[64];        /* the node being rolled up                    */
  char   node_kind;       /* 'b' a local bot, 'h' a directly linked hub  */
  char   step[64];        /* the version THIS attempt installs           */
  time_t started;
  bool   committed;
  time_t ready_at;        /* READY came: the node has a moment to say it stages */
  bool   staging;         /* told to stage, and waiting for it */
  time_t stage_last;
} pending_rollup_t;

typedef struct {
  char   uuid[64];
  time_t last_try;
  int    tries;
  char   step[64];   /* the last attempt, for upgrade status */
  char   note[128];
} rollup_try_t;

typedef struct {
  char ip[64];
  int active_connections;    // Current active connections from this IP
  int failed_auth_count;     // Failed authentication attempts
  time_t last_failed_auth;   // Timestamp of last failed auth
  time_t blocked_until;      // Temporary block expiration (0 if not blocked)
  time_t first_seen;         // For cleanup of old entries
  time_t churn_window_start; // D1: start of current connect-rate window
  int    churn_count;        // D1: new connections counted in current window
} ip_rate_limit_t;

/* Per-hub connection limits (hub_connlimits.c).  `hub set ssh ...` (the SSH
 * console's own limits) and `hub set conn ...` (the limits shared by every
 * connection) edit this; it lives in .irchub.cnf as `ssh|<name>|<value>` and
 * `conn|<name>|<value>` lines, written only for values that differ from the
 * built-ins.  The main thread owns it; the console thread gets a copy
 * published under hub_console.c's mutex (console_publish_limits). */
typedef struct {
  /* ssh group */
  int preauth;       /* SSH logins in progress, all addresses               */
  int preauthip;     /* ... and from one address (<= preauth)               */
  int sessions;      /* open consoles                                       */
  int grace;         /* connect -> shell, seconds                           */
  int authtries;     /* refused keys per connection before the drop         */
  int idle;          /* seconds without a keystroke                         */
  int authfail_n, authfail_s;   /* refused SSH logins per address per window */
  int connect_n, connect_s;     /* new SSH connections per address / window  */
  int block;         /* base SSH block, seconds (doubles per repeat)        */
  int cmdrate_n, cmdrate_s;     /* console commands per session / window     */
  /* conn group: shared by bots, peers and SSH */
  int perip;                    /* connections at once from one address      */
  int churn_n, churn_s, churn_block;  /* new connections per window -> block */
  int fail_n, fail_s, fail_block;     /* failed logins per window -> block   */
  int startups_start, startups_rate, startups_full;  /* 13b random early drop */
} hub_conn_cfg_t;

/* Built-ins (the former compile-time constants). */
#define SSH_DEF_PREAUTHIP   2
#define SSH_DEF_AUTHFAIL_N  3
#define SSH_DEF_AUTHFAIL_S  3600
#define SSH_DEF_CONNECT_N   6
#define SSH_DEF_CONNECT_S   60
#define SSH_DEF_BLOCK       300
#define SSH_DEF_CMDRATE_N   20
#define SSH_DEF_CMDRATE_S   10
#define SSH_BLOCK_MAX       86400   /* escalation ceiling: 24 h            */
#define SSH_BLOCK_MEMORY    86400   /* a repeat within this doubles        */
#define MAX_SSH_IPS         256
#define SSH_SUCCESS_MEMORY  86400   /* an address with a console login this recent skips the
                                       connect window and the churn block (not authfail/ACL) */

/* One address in the SSH-only table (D26): refused logins and the connect
 * window of connections that sniffed as SSH.  Separate from ip_rate_limit_t,
 * so an admin's mistyped keys never block a bot or peer on the same address. */
typedef struct {
  char   ip[64];
  time_t win_start;      /* connect window */
  int    conn_n;
  time_t fail_last;      /* refused-login window */
  int    fail_n;
  time_t blocked_until;
  time_t last_block;     /* start of the latest block (escalation memory) */
  int    level;          /* blocks in a row within SSH_BLOCK_MEMORY */
  time_t last_seen;
  time_t last_success;   /* latest successful console auth (0 = never) */
} ssh_ip_t;

/* IP allow/deny list entry (the admin console 0x38-0x3D).  The lists are local to
 * this hub: never replicated to peers, never pushed to bots; config lines
 * w|<pattern>|<ts> (allow) and x|<pattern>|<ts> (deny).  IPv4 only (the hub
 * listens on AF_INET).  pattern is canonical: a bare address, or network/N
 * with the host bits cleared; net/mask are its parsed form. */
#define MAX_IP_ACL_ENTRIES 64          /* per list */
#define IP_ACL_PATTERN_MAX 19          /* "255.255.255.255/32" + NUL */
#define IP_ACK_LINE_MAX    48          /* w|<pattern>|<ts>\n */
typedef struct {
  char     pattern[IP_ACL_PATTERN_MAX];
  uint32_t net;              /* host byte order */
  uint32_t mask;             /* host byte order */
  time_t   added;
  bool     console;          /* D27: applies only once the first bytes say SSH */
} hub_ip_acl_t;

typedef struct {
  char ip[64];              // Configured/advertised IP
  int port;
  char uuid[64];            // Remote peer's UUID
  char friendly_name[64];   // Remote peer's friendly name
  char remote_ip[64];       // Actual connection IP (from socket)
  bool connected;
  int fd;
  int remote_connected_count;
  int remote_total_peers;
  time_t last_mesh_report;
  /* What the remote hub reported in its CMD_BOT_ROSTER header.  Volatile and
   * never serialized: these only feed the bots tree's uptime/version columns. */
  time_t remote_started;
  char   remote_version[ROSTER_VERSION_MAX + 1];
  /* Its code base ("c" / "rs"), from the roster's v| line; "" until a hub
   * that sends one reports in. */
  char   remote_variant[ROSTER_VARIANT_MAX + 1];
  char last_gossip[MAX_BUFFER];
  /* When the link last went down (volatile, 0 = not since this hub started):
   * the console's "down since". */
  time_t link_down_at;

  /* Peer auth (HUBv3): per-peer Curve25519 public keys. has_pubkey is
   * required — a peer without one is refused (there is no shared secret). */
  unsigned char ed_pub[ED25519_KEY_LEN];
  unsigned char x25519_pub[X25519_KEY_LEN];
  bool has_pubkey;
} hub_peer_config_t;

typedef enum { CLIENT_BOT, CLIENT_ADMIN, CLIENT_HUB } client_type_t;

/* Core-side state of one SSH console (hub_console_core.c).  Allocated only
 * for an internal admin connection; NULL on every network client. */
struct hub_console_link;

/* Queued outbound message — pre-encryption.  payload is malloc'd. */
typedef struct queued_msg {
  uint8_t            cmd;                /* protocol opcode (CMD_*) */
  lane_t             lane;               /* which lane this lives in (for accounting) */
  /* Coalesce key: typically "<origin_hub_uuid>|<key>|<bot_uuid>" — up to
   * 36 + 16 + 36 + separators ≈ 90 chars. Sized with headroom. */
  char               coalesce_key[160];
  uint64_t           lamport_seq;        /* monotonic per origin_hub_uuid */
  char               origin_hub_uuid[64];
  int                payload_len;
  unsigned char     *payload;            /* malloc'd plaintext */
  struct queued_msg *next;
} queued_msg_t;

typedef struct {
  queued_msg_t *head;
  queued_msg_t *tail;
  int           count;
  int           bytes;     /* sum of payload_len in this lane */
} queue_lane_t;

typedef enum {
  BOT_AUTH_IDLE = 0,
  BOT_AUTH_UUID_RECEIVED,
  BOT_AUTH_CHALLENGE_SENT,
  BOT_AUTH_SIGNATURE_RECEIVED,
  BOT_AUTH_COMPLETE,
  BOT_AUTH_QUARANTINE   /* revoked bot proved its key, told to retire */
} bot_auth_state_t;

typedef struct {
  int fd;
  char ip[64];
  char id[64];
  unsigned char session_key[32];
  bool authenticated;
  client_type_t type;
  time_t last_seen;
  time_t last_pong_sent;
  time_t relay_window;          /* second the relay count is for         */
  int relay_count;              /* CMD_BOT_RELAY in that second           */
  time_t write_wait_since;      /* output queued, no byte taken since     */
  time_t drop_logged;           /* last queue-drop warning for this client */
  int drop_unlogged;            /* drops since, not yet in a warning       */
  bool superseded;              /* a newer session of this bot replaced it */
  bool p2_seen;                 /* peer: it sent a CMD_PRESENCE2 record     */
  bool peer_heard;              /* peer: a frame from it opened (a dialled  */
                                /* link is not up until the far end speaks) */
  bool result_relayed;          /* this link's one relayed UPGRADE_RESULT  */
  /* Review 6 (CMD_LINK_SEQ): its offer seen, our go queued / sealed, its go
   * seen; the counters of the frames sealed / opened since. */
  bool link_offered;
  bool link_go_queued;
  char link_dir_tx;             /* direction bytes of our / its frames      */
  char link_dir_rx;
  bool link_tx_seq;
  bool link_rx_seq;
  uint64_t link_tx_ctr;
  uint64_t link_rx_ctr;
  time_t replace_window;        /* start of the hour replace_count is for  */
  int replace_count;            /* live sessions of this bot replaced      */
  time_t connected_at;             // D4: when the socket was accepted/created
  bool inbound;                    // accepted on the listener (subject to the IP lists)
  /* bot del of this connected bot: CMD_BOT_RETIRE sent at retire_sent; every
   * other frame from it is dropped, and it is closed on CMD_BOT_RETIRE_ACK or
   * after RETIRE_GRACE_SEC. */
  bool retiring;
  time_t retire_sent;
  /* Its uuid is on the revoke list: the handshake checks the revoke list's
   * key and ends in BOT_AUTH_QUARANTINE (CMD_BOT_RETIRE as the ACK). */
  bool quarantine;
  /* An SSH console's socketpair end (docs/console.md): an admin connection
   * the console thread already authenticated.  Plaintext frames, no pings,
   * no CLIENT_TIMEOUT (the console has its own idle timeout). */
  bool internal;
  /* Never reused while the process lives (hub_next_conn_serial): what a late
   * answer is bound to, so a console that took over a closed one's fd never
   * gets a reply it did not ask for. */
  uint64_t conn_serial;
  struct hub_console_link *console;
  /* First-bytes sniff of an accepted connection: until 4 bytes are there (or
   * CONSOLE_SNIFF_MS passed) it is not read, so an "SSH-" stream can be
   * handed to the console thread untouched. */
  bool sniff_pending;
  long long sniff_deadline_ms;
  /* Review 16: an outbound peer link whose non-blocking connect() is still
   * in flight (since dial_started), to the peer with uuid dial_uuid.  Only
   * its writability is watched; hub_finish_dials completes it. */
  bool dialing;
  time_t dial_started;
  char dial_uuid[64];
  /* Set by a handler that found this bot or peer below MESH_MIN_VERSION (or
   * a push below BOT_PROTO_USER_FLAGS): the dispatch then drops the link. */
  bool refused;
  /* A peer whose version is not known yet: no config sync goes to it and
   * none from it is taken in (hub_peer_enqueue_sync / process_peer_sync)
   * until its first roster names a version at MESH_MIN_VERSION or newer;
   * then hub_peer_sync_release sends a full sync and asks for one. */
  bool sync_held;
  /* CMD_CHAN_EVENT rate limit for this connection (CHAN_EVENT_MAX_PER_WINDOW
   * per CHAN_EVENT_WINDOW seconds); dropped events are counted. */
  time_t chan_ev_window;
  int    chan_ev_count;
  int    chan_ev_dropped;
  /* CMD_USER_CHAN_REQUEST rate limit for this connection */
  time_t uchan_req_window;
  int    uchan_req_count;
  unsigned char *recv_buf;         // D2: heap; PREAUTH_BUF_SIZE then MAX_BUFFER
  int           recv_cap;          // D2: allocated capacity of recv_buf
  bot_auth_state_t bot_auth_state;
  unsigned char challenge[32];
  unsigned char bot_eph_x25519_priv[32];
  unsigned char bot_eph_x25519_pub[32];
  bool bot_eph_priv_set;
  int recv_len;
  int recv_off;                 /* unread data is recv_buf[recv_off..recv_len) */

  /* ---- Outbound queue (per-lane FIFOs, drained on POLLOUT) ---- */
  queue_lane_t out_lanes[LANE_COUNT];
  int          out_total_bytes;

  /* In-flight cipher buffer for partial writes.  When non-empty the FD must
   * be watched for writability until offset == len, before any new message
   * is encrypted. */
  unsigned char *writing_buf;      // D2: heap; PREAUTH_BUF_SIZE then MAX_BUFFER+64
  int           writing_cap;       // D2: allocated capacity of writing_buf
  int           writing_len;
  int           writing_offset;

  /* Per-peer/client byte-rate accounting (1-second window). */
  time_t        bw_window_start;
  int           bw_bytes_in_window;

  /* Presence this bot reported via CMD_BOT_PRESENCE.  Per connection, and
   * volatile on purpose: a bot that reconnects re-reports, and a bot that
   * never reports simply shows blank fields in the tree.  Never persisted. */
  char   bot_version[ROSTER_VERSION_MAX + 1];
  char   bot_server[ROSTER_SERVER_MAX + 1];
  char   bot_variant[ROSTER_VARIANT_MAX + 1]; /* "c" / "rs", "" = unreported */
  char   bot_cron[CRON_STATUS_MAX + 1];       /* "" = unreported */
  int    cron_sent;                           /* last CMD_CRON_SET + 1, 0 = none */
  bool   late_prepared;                       /* joined a run in flight already */
  bool   plan_capable;                        /* a peer that speaks CMD_UPGRADE_PLAN */
  time_t bot_started;              /* bot's own start time, 0 = unreported  */
  uint64_t bot_link_ord;           /* phase 4: bot's link-order counter, 0 = unreported */

  /* SHA-256 of the last full config queued to this bot (CMD_CONFIG_DATA), so
   * a broadcast push that would repeat it is skipped.  Only valid while that
   * push is known to be on its way: cleared when a queued config is dropped
   * on overflow and whenever the bot sends a config push of its own. */
  unsigned char cfg_sent_hash[32];
  bool          cfg_sent_valid;
  /* This connection has pushed its config once: the first push is answered
   * with a full config even when it changed nothing (a reconnecting bot may
   * hold a stale copy, e.g. its own old key after a rekey). */
  bool          pushed;

  /* SHA-256 of the last bot tree queued to this bot (CMD_BOT_TREE): a change
   * push that would repeat it is skipped (the BOT_TREE_REFRESH one never is).
   * Cleared when a queued tree is dropped on overflow. */
  bool          tree_sent_valid;
  uint64_t      tree_sent_seq;     /* phase 5: the tree version this bot holds  */
  time_t        tree_pull_at;      /* last CMD_BOT_TREE_PULL served             */
  bool          tree_pull_due;     /* one came inside TREE_PULL_MIN_GAP: held   */
} hub_client_t;

// Track recently processed PURGE messages to prevent feedback loops
typedef struct {
  time_t cutoff;       // PURGE cutoff timestamp
  char id[PURGE_ID_HEX + 1]; // origin's purge id ("" from pre-id hubs)
  time_t received_at;  // When this PURGE was received/processed
} recent_purge_t;

// Track recently seen OP_FORWARD_REQUEST IDs to prevent packet storms
typedef struct {
  char   request_id[SEEN_FORWARD_ID_MAX]; // Unique request ID
  time_t seen_at;        // When we first processed this request
} seen_forward_t;

/* One election (see CMD_CHAN_PROBE).  `from_fd` is the peer the question came
 * from (-1: this hub started it); `admin_fd` the console owed the answer. */
typedef enum {
  CE_PROBE,      /* asking our own bots                                 */
  CE_LOCAL_DO,   /* one of our bots was handed the action               */
  CE_MESH_WAIT,  /* origin: flooded, collecting the other hubs' answers  */
  CE_MESH_DO,    /* origin: one hub was handed the action               */
  CE_ACKED,      /* relay: answered the origin, routing DO/DONE now     */
  CE_HOLD        /* origin: its mesh view is still settling (restart or
                    relink); asks the mesh once it has, CHAN_ELECT_HOLD_MAX */
} chan_elect_phase_t;

typedef struct {
  char uuid[64];
  char nick[MAX_NICK];
  char st;                               /* a asked, y ready, n no, t tried */
  char reason[CHAN_ELECT_REASON_MAX];
} chan_elect_bot_t;

typedef struct {
  char uuid[64];
  char name[64];
  int  fd;                               /* the peer its answer came from */
  uint64_t serial;                       /* ...and that link's conn_serial */
  int  asked, ready;
  bool tried;
} chan_elect_hub_t;

typedef struct {
  bool   active;
  char   id[64];
  bool   origin;
  int    from_fd;
  uint64_t from_serial;                  /* from_fd's conn_serial         */
  int    admin_fd;
  uint64_t admin_serial;                 /* admin_fd's conn_serial        */
  char   kind[8];
  char   channel[MAX_CHAN];
  char   requester[64];
  char   nick[MAX_NICK];
  char   hostmask[MAX_MASK_LEN];
  chan_elect_phase_t phase;
  time_t phase_at, created;
  chan_elect_bot_t bots[MAX_CLIENTS];
  int    bot_n;
  chan_elect_hub_t hubs[MAX_MESH_HUBS];
  int    hub_n;
  /* the most hubs any answer said it knows, itself included: a hub that has
   * just restarted or relinked may know only its neighbours yet, and must
   * not take their answers for the whole mesh's */
  int    mesh_known;
  bool   held;                           /* CE_HOLD was used (only once)   */
  char   doing[64];                      /* bot (CE_LOCAL_DO) or hub uuid  */
  /* a person's request from a bot (CMD_USER_CHAN_REQUEST): the answer goes
   * back to that connection as CMD_USER_CHAN_RESULT; reply_fd -1 = none */
  int    reply_fd;
  uint64_t reply_serial;
  char   reply_rid[USER_CHAN_RID_MAX + 1];
  /* kind "ban" (ban add / channel ban): the record just stored, for the
   * ban.added answer the console gets when the election ends */
  time_t ban_expires;
  bool   ban_sticky, ban_existed;
  char   ban_reason[BAN_REASON_MAX + 1];
} chan_elect_t;

/* One roll call (see CMD_HUB_ROLLCALL).  As the asking hub: the hubs it waits
 * on and which have answered.  As a relay: the link to route answers back on. */
typedef enum { RC_FOR_START = 1, RC_FOR_STEP = 2 } rollcall_purpose_t;
typedef struct {
  bool   active;
  bool   origin;
  char   id[ROLLCALL_ID_LEN];
  time_t started;
  int    from_fd;                        /* relay: the peer it came from */
  uint64_t from_serial;                  /* ...and that link's conn_serial */
  rollcall_purpose_t purpose;            /* origin only */
  int    want_n;
  char   want[MAX_MESH_HUBS][64];        /* origin: uuid of every hub asked */
  char   want_name[MAX_MESH_HUBS][64];
  bool   got[MAX_MESH_HUBS];
} hub_rollcall_t;

/* One bot's live presence, as reported by the hub it is connected to.  Purely
 * in-memory: never written to the config, never tombstoned, never purged.  An
 * entry whose reported_at falls behind BOT_ROSTER_TTL is dropped, so a bot
 * that disconnects — or a whole hub that dies — ages out on its own. */
typedef struct {
  char   hub_uuid[64];                    /* hub that reported this bot   */
  char   hub_name[64];                    /* its friendly name, for display */
  char   bot_uuid[64];
  char   nick[MAX_NICK];
  char   version[ROSTER_VERSION_MAX + 1];
  char   variant[ROSTER_VARIANT_MAX + 1]; /* code base: "c" / "rs" / ""  */
  char cron[CRON_STATUS_MAX + 1];
  char   server[ROSTER_SERVER_MAX + 1];   /* the bot's IRC link           */
  time_t connected_at;                    /* bot's own start, for uptime  */
  time_t link_since;                      /* bot -> its hub link, 0 = unknown */
  uint64_t link_ord;                      /* phase 4: bot's link-order counter, 0 = unknown */
  char   ip[ROSTER_IP_MAX + 1];           /* bot's address as its hub sees it */
  time_t reported_at;                     /* local clock: drives the TTL  */
  long long gen;                          /* the gossip round it came in (0 = none) */
  uint64_t p2_stamp;                      /* arrival order vs presence v2 records */
} bot_roster_t;

/* One peer link a hub reports in its roster gossip (an l| line): a peer it is
 * configured with and whether that link is up right now. */
typedef struct {
  char uuid[64];
  char name[64];
  bool online;
} mesh_link_t;

/* What this hub knows about another hub anywhere in the mesh, from that
 * hub's own roster gossip — direct or relayed.  Volatile like the roster:
 * dropped once nothing refreshed it within BOT_ROSTER_TTL.  `gen` and
 * `chunks_seen` suppress relay loops: a hub applies and passes on a given
 * frame (origin, generation, chunk) exactly once. */
typedef struct {
  char        uuid[64];
  char        name[64];
  time_t      started;
  char        version[ROSTER_VERSION_MAX + 1];
  char        variant[ROSTER_VARIANT_MAX + 1];
  char        cron[CRON_STATUS_MAX + 1];
  mesh_link_t links[MAX_PEERS];
  int         link_count;
  bool        have_links;   /* it has sent an l| list (a hub that relays) */
  time_t      links_at;     /* local clock: when that list was last applied */
  long long   gen;          /* newest gossip generation seen from it      */
  uint64_t    chunks_seen;  /* chunks of `gen` already applied (bit n)    */
  time_t      reported_at;  /* local clock: drives the TTL                */
  bool        rollcall;     /* its gossip carries k|rollcall: it answers one */
} mesh_hub_t;

/* ---- Presence v2, phases 1-2 (hub_presence2.c) ----
 * Each hub publishes one record {origin, epoch, seq, caps, links, bots}.
 * epoch is a boot counter persisted in P2_EPOCH_FILE (never the clock), seq
 * counts published changes.  Records are flooded (ttl, split horizon) when
 * they change, pulled on link-up through a digest, and walked breadth-first
 * for reachability: a link counts only when both ends list it.  Phase 1 runs
 * alongside the CMD_BOT_ROSTER rounds and only ever shortens how long a gone
 * hub or bot lingers in their view. */
#define P2_EPOCH_FILE     ".irchub.epoch"
#define P2_TTL_HOPS       16
#define P2_MAX_LINKS      16
#define P2_MAX_BOTS       128
#define P2_ID_MAX         63
#define P2_CAPS_MAX       15
#define P2_MAX_FRAME      16384
#define P2_EPOCH_MAX      (1ULL << 40)
#define P2_SEQ_MAX        (1ULL << 48)
#define P2_EPOCH_JUMP     1024ULL      /* relayed epoch jump refused above this */
#define P2_SEQ_JUMP       (1ULL << 20) /* ... and seq jump in one epoch         */
#define P2_PULL_RETRY_MS  2000
#define P2_GRACE_MS       5000         /* unreachable this long = gone for decisions */
#define P2_FULL_EVERY_MS  300000       /* own record re-flooded at a new seq      */
#define P2_RECONCILE_MS   1000
#define P2_TICK_MS        100          /* hub_p2_tick runs at most this often    */
/* phase 2: deltas, damping, storm cap, compact digest */
#define P2_SEEN_WINDOW    64           /* per-origin seen window for D frames    */
#define P2_FLAP_WINDOW_MS 30000
#define P2_FLAP_FREE      4            /* flips per window before damping        */
#define P2_HOLD_MAX_MS    30000
#define P2_BUCKET_RATE    20           /* deltas per second ...                  */
#define P2_BUCKET_BURST   100          /* ... with this burst; past it: snapshots */
#define P2_STORM_GAP_MS   1000         /* at most one storm snapshot per gap     */
#define P2_DIGEST_MS      15000        /* H|count|fnv64 on every link            */
#define P2_MAX_ENTS       (2 * (P2_MAX_BOTS + P2_MAX_LINKS)) /* live + damped gone */
/* phase 3: the 15 s digest is the keepalive on a v2 peer link, so idle links
 * carry no pings and a link silent for 3 missed digests is dropped. */
#define P2_LINK_TIMEOUT   45           /* s: drop a v2 peer link unheard this long */

typedef struct {
  char      id[P2_ID_MAX + 1];
  long long since;                     /* its link to the origin (unix s)  */
} p2_bot_t;

typedef struct {
  char      origin[P2_ID_MAX + 1];
  uint64_t  epoch, seq;                /* epoch 0 = known name, no record yet */
  char      caps[P2_CAPS_MAX + 1];
  char      links[P2_MAX_LINKS][P2_ID_MAX + 1];
  int       nlinks;
  p2_bot_t *bots;                      /* heap, nbots entries                */
  int       nbots;
  uint64_t  stamp;                     /* bot_roster_t.p2_stamp order at accept */
  int64_t   pull_next_ms;
  int64_t   gone_ms;                   /* monotonic: when it became unreachable */
  bool      reach, purged;
  bool      rdirty;                    /* roster or record changed: reconcile */
  uint64_t  win_epoch, win_top, win_mask; /* D seen window (P2_SEEN_WINDOW)  */
} p2_rec_t;

/* One of our bots or peer links, damped on its own (P2_FLAP_*). */
typedef struct {
  char      id[P2_ID_MAX + 1];
  char      kind;                      /* 'b' bot, 'l' peer link             */
  bool      live;
  long long since;                     /* bot: its link time while live      */
  int       flips;
  int64_t   window_ms, hold_ms;        /* flap window start, hold until      */
} p2_ent_t;

typedef struct {
  p2_rec_t  self;
  p2_rec_t  recs[MAX_MESH_HUBS];
  int       nrecs;
  bool      dirty;                     /* storm pending: snapshot instead of D */
  int64_t   last_flood_ms, next_full_ms, next_reconcile_ms, next_digest_ms;
  int64_t   last_tick_ms;              /* P2_TICK_MS gate                    */
  uint64_t  stamp_ctr;
  p2_ent_t  ents[P2_MAX_ENTS];
  int       nents;
  int64_t   tokens_milli, bucket_ms;   /* storm cap token bucket             */
  bool      ready;                     /* last tick's p2_ready()             */
  uint64_t  c_rx, c_rx_bad, c_tx, c_relays, c_pulls, c_heals, c_jumps, c_purges;
  uint64_t  c_deltas, c_snaps, c_held, c_digest_miss;
} p2_state_t;

/* Traffic counters since start, answered by CMD_ADMIN_STATS.  Monotonic:
 * whoever reads them diffs two snapshots. */
typedef struct {
  uint64_t rx_frames[256], rx_bytes[256];  /* by opcode, decrypted frames   */
  uint64_t tx_frames[256], tx_bytes[256];  /* by opcode, queued frames sent */
  uint64_t cfg_sent;      /* full configs queued to a bot                  */
  uint64_t cfg_same;      /* skipped: that bot already has this exact one  */
  uint64_t cfg_lost;      /* queued config dropped on lane overflow        */
  uint64_t sync_frames;   /* PEER_SYNC / PEER_BCAST frames processed       */
  uint64_t sync_noop;     /* ... of which changed nothing                  */
  uint64_t sync_records;  /* record lines in them                          */
  uint64_t sync_applied;  /* ... of which were new and applied             */
} hub_stats_t;
/* One per process (the daemon is single-threaded); defined in hub_logic.c. */
extern hub_stats_t g_hub_stats;

typedef struct {
  int listen_fd;
  int port;
  char bind_ip[64];          // IP this hub advertises itself as in mesh
  /* What the listener actually bound at startup: bind_ip / port changed
   * since take effect on the next start (the console's "pending"). */
  char listen_ip[64];
  int listen_port;
  char hub_uuid[64];         // This hub's UUID
  char hub_friendly_name[64]; // This hub's friendly name
  /* /proc/self/exe — the binary an upgrade replaces, and the one
   * <exe>.prev sits beside; its directory is the cwd (instance_dir_enter).
   * Resolved once in main(); see hub_update.c. */
  char executable_path[PATH_MAX];
  /* config_pass holds the plaintext AES-GCM config-file password for the
   * lifetime of the process (needed on every config write).  It is mlock'd
   * so the OS cannot page it to swap, and OPENSSL_cleanse'd at shutdown.
   *
   * Threat model: mlock prevents swap-file / hibernate leaks.  A root process
   * with ptrace or /proc/<pid>/mem access CAN still read this field while the
   * hub is running — that is unavoidable without hardware-backed key storage.
   * The real defences are OS-level: ptrace_scope, process isolation, and
   * filesystem permissions on the config file itself. */
  char config_pass[128];
  /* Review 23: the config key, derived once (the load, else the first write)
   * and reused with the salt it was derived with; every write takes a fresh
   * IV.  A 600k-round PBKDF2 per write stalled the event loop ~0.5 s.  Reset
   * by hub_set_config_pass (a new password derives anew); mlock'd with
   * config_pass, wiped at shutdown. */
  unsigned char cfg_key[32];
  unsigned char cfg_key_salt[SALT_SIZE];
  bool cfg_key_set;
  /* Review 7: the hello replay cache (HELLO_SEEN_MAX, a ring). */
  unsigned char hello_seen[HELLO_SEEN_MAX][32];
  time_t hello_seen_at[HELLO_SEEN_MAX];
  int hello_seen_next;

  unsigned char hub_ed25519_priv[32];
  unsigned char hub_ed25519_pub[32];
  unsigned char hub_x25519_priv[32];
  unsigned char hub_x25519_pub[32];
  bool hub_keys_loaded;

  hub_client_t *clients[MAX_CLIENTS];
  int client_count;

  bot_config_t bots[MAX_BOTS];
  int bot_count;

  // GLOBAL CONFIG STORE (Shared by all bots)
  config_entry_t global_entries[MAX_GLOBAL_ENTRIES];
  int global_entry_count;
  /* Derived from global_entries[] (hub_storage.c): hash index of (class,
   * folded identity) -> entry index + 1, entries per class, and live bans per
   * channel.  hub_global_reindex() rebuilds all of it. */
  int global_idx[GLOBAL_IDX_SLOTS];
  global_ban_slot_t global_ban_chan[GLOBAL_IDX_SLOTS];
  int global_n_old, global_n_C, global_n_D, global_n_B;
  /* K|: what the bots saw on IRC, one per live channel (never a tombstone). */
  hub_chan_learned_t chan_learned[MAX_CHANNELS];
  int chan_learned_count;

  // Named admin/oper records and their usermasks
  hub_user_record_t user_records[MAX_HUB_USER_RECORDS];
  int user_record_count;
  hub_mask_record_t mask_records[MAX_HUB_USER_MASKS];
  int mask_record_count;
  hub_uflag_record_t uflag_records[MAX_HUB_USER_FLAGS];
  int uflag_record_count;
  /* uf| changes that took 'a' away, as (uuid, the new uf| stamp): the uf|
   * no longer says it held 'a', and the admin floor must know
   * (hub_admin_floor_restore).  Memory only, a ring. */
  struct { char uuid[37]; time_t ts; } adrop[ADMIN_DROP_LOG];
  int adrop_next;
  bool floor_warned;   /* "no full admin, nothing to restore" logged once */
  hub_uchan_record_t uchan_records[MAX_HUB_CHAN_BINDS];
  int uchan_record_count;

  hub_peer_config_t peers[MAX_PEERS];
  int peer_count;

  hub_revoked_t revoked[MAX_REVOKED];  /* permanent: never purged */
  int revoked_count;

  pending_op_request_t pending_op_requests[MAX_PENDING_OP_REQUESTS];
  pending_chan_request_t pending_chan_requests[MAX_PENDING_CHAN_REQUESTS];
  chan_elect_t chan_elections[MAX_CHAN_ELECTIONS];
  hub_rollcall_t rollcalls[MAX_ROLLCALLS];
  /* The upgrade start waiting on its roll call (one at a time); the console
   * is answered when the roll call ends. */
  struct {
    bool active;
    char rc[ROLLCALL_ID_LEN];
    int admin_fd;
    uint64_t admin_serial;
    char payload[MAX_UPGRADE_SELECT * 80 + 512];
  } upg_start_wait;
  /* A plan step's roll call: rc while it runs, then the outcome until the step
   * gate reads it. */
  struct {
    char rc[ROLLCALL_ID_LEN];
    int  outcome;            /* 0 none or running, 1 every hub answered, 2 some did not */
    int  missing;
    time_t at;               /* when the outcome came: a stale one is not read */
    char gone[320];
  } step_rollcall;

  /* The network upgrade this hub is driving, if any (one at a time). */
  pending_upgrade_t upgrade;
  uhist_rec_t uhist[MAX_UPGRADE_HISTORY]; /* newest first (hub_uhist.c) */
  int uhist_count;
  int uhist_keep_setting;  /* hs|upgradehistory; 0 = UHIST_DEFAULT_KEEP */
  time_t uhist_keep_ts;
  /* Production crontab lines: off until an admin says otherwise.  The last
   * command wins by timestamp, a single node's or the global one. */
  int bot_cron_setting, hub_cron_setting;  /* hs|botcron, hs|hubcron: 0 off, 1 on */
  time_t bot_cron_ts, hub_cron_ts;
  struct {
    char uuid[64];
    char kind;  /* 'b' or 'h' */
    int on;
    time_t ts;
  } cron_recs[MAX_CRON_RECS];
  int cron_rec_count;
  /* The plan as every hub knows it: this hub's own copy of what its driver last
   * published, and when it last heard the driver. */
  upgrade_plan_t splan;
  time_t splan_seen, plan_beat;

  /* The upgrade this hub has agreed to take from ANOTHER hub, if any.  The
   * mesh is flat, so a hub is a follower and a driver at the same time and the
   * two must not share state: `upgrade` above is the run this hub drives,
   * these fields are a run someone else drives.  CMD_UPGRADE_COMMIT carries
   * only the id and the version, so the release base the driver named at
   * PREPARE time is remembered here; an id that never went through PREPARE, or
   * one older than UPGRADE_PREPARE_TTL, is refused.  Volatile — the upgrade
   * itself hands over through HUB_UPGRADE_MARKER_FILE because exec() takes all
   * of this with it. */
  char   follow_id[64];
  char   follow_origin[64];  /* uuid of the hub driving the followed run  */
  char   follow_target[64];     /* the bots' target (relayed COMMITs)    */
  char   follow_hub_target[64]; /* this hub's own target, "" = stay put  */
  char   follow_variant[8];
  /* What the followed run asked of this hub's BOTS: the run's own variant
   * ("" = each keeps its own) and a selective run's uuid[=v],... list.  A
   * local bot's presence is only reported up as that bot's success when it
   * is on the build it was asked for — a same-version C<->Rust switch is
   * otherwise "done" the moment the OLD process re-announces itself. */
  char   follow_bot_variant[8];
  char   follow_sel[MAX_UPGRADE_SELECT * 72];
  bool   follow_self_ready;  /* this hub itself can take the followed run */
  time_t follow_prepared;
  char upgrade_installed_id[64]; /* the run whose restart made this process */
  /* Nodes below this hub in the followed run's fan-out tree (its own peers'
   * subtrees).  Rebuilt for every run; see upgrade_route_t. */
  upgrade_route_t follow_routes[MAX_UPGRADE_ROUTES];
  int    follow_route_count;

  /* Offline roll-up (see pending_rollup_t). */
  pending_rollup_t rollup;
  upgrade_plan_t   plan;             /* a multi-step upgrade this hub drives */
  /* The last `upgrade abort` this hub issued or relayed (see
   * UPGRADE_CANCEL_HOLD): its id, when the admin typed it (mesh clock), and
   * when this hub heard it (local clock). */
  char             upgrade_cancel_id[64];
  time_t           upgrade_cancel_issued;
  time_t           upgrade_cancel_seen;
  rollup_try_t     rollup_tries[MAX_ROLLUP_TRIES];
  int              rollup_try_count;

  ip_rate_limit_t ip_limits[MAX_IP_RATE_LIMITS];
  int ip_limits_count;

  /* IP allow/deny lists (local only, see hub_ip_acl_t).  ip_acl_changed makes
   * hub_maintenance close inbound connections the lists no longer permit. */
  hub_ip_acl_t ip_allow[MAX_IP_ACL_ENTRIES];
  int ip_allow_count;
  hub_ip_acl_t ip_deny[MAX_IP_ACL_ENTRIES];
  int ip_deny_count;
  bool ip_acl_changed;

  hub_conn_cfg_t conn_cfg;               /* hub set ssh / hub set conn      */
  ssh_ip_t       ssh_ips[MAX_SSH_IPS];   /* D26: SSH-only failure table     */
  int            ssh_ip_count;
  /* 13b: addresses a bot or peer authenticated from (hub_known_ip_note). */
  struct { char ip[64]; time_t last_ok; } known_ips[MAX_KNOWN_IPS];
  int            known_ip_count;
  time_t         startup_logged;         /* last refusal warning            */
  int            startup_unlogged;       /* refusals since, not yet logged  */

  int purge_days_setting;  // Days threshold for tombstone purge (0 = disabled)
  time_t purge_days_ts;    // hs|autopurge stamp (LWW across hubs)
  bool trust_loopback;     // D3: if true, 127.0.0.1/::1 bypass rate limiting
                           //     (default false — secure by default)
  int pid_fd;  // File descriptor for PID file lock
  volatile bool running;

  // PURGE deduplication: prevent feedback loops in peer mesh
  recent_purge_t recent_purges[MAX_RECENT_PURGES];
  int recent_purge_count;
  time_t last_scheduled_purge;  // Timestamp of last scheduled purge this hub initiated
  /* Purge floor: until purge_floor_until, a tombstone stamped before
   * purge_floor is not re-created (a sync built before the purge, landing
   * after it, would bring it back).  Memory only. */
  time_t purge_floor;
  time_t purge_floor_until;

  // OP_FORWARD_REQUEST deduplication: LRU ring prevents infinite re-broadcast storms
  seen_forward_t seen_forwards[MAX_SEEN_FORWARD_IDS];
  int seen_forward_head;  // Next slot to write (ring index)

  int log_level;       // Log FILE level (LOG_NONE, LOG_ERROR, etc.)
  int console_log_level; // Console log ring level (console_log_level|)
  int log_max_size;    // Max log file size in bytes (default 10MB)

  /* Network options pushed to bots/peers via the 'opt|' record. Each letter
   * in opt_flags is an enabled flag (see OPT_* in this header). */
  char opt_flags[MAX_OPT_FLAGS + 1];
  time_t opt_flags_ts;

  /* Debounced config write: set dirty flag instead of writing immediately.
   * hub_maintenance flushes at most once every CONFIG_WRITE_DEBOUNCE_S seconds.
   * This prevents N PBKDF2 calls when N peer syncs arrive in a burst. */
  bool config_dirty;
  /* A full config push to every local bot is owed (see
   * hub_flush_bot_config): set by every change bots must see, sent at most
   * once per BOT_CONFIG_PUSH_COALESCE by the maintenance loop. */
  bool bot_config_pending;
  time_t last_bot_config_push;
  time_t last_config_write;
  bool mesh_state_dirty;    /* set on peer connect/disconnect; clears after gossip */

  /* Mesh transport: monotonic Lamport sequence stamped onto outgoing deltas
   * (carried as the trailing field of the wire format). On load from disk we
   * bump this past any plausibly recent value to keep monotonicity even if
   * the system clock or stored value lags. */
  uint64_t next_lamport_seq;

  /* ---- Bot presence (volatile; never serialized) ---- */
  bot_roster_t roster[MAX_BOT_ROSTER];
  int          roster_count;
  time_t       hub_started;        /* this hub's own uptime base           */
  time_t       last_presence_gossip;
  time_t       last_tree_push;
  /* Phase 5: the last whole tree pushed, for row deltas.  A change sends every
   * current bot (`tree_sent_seq` == `tree_seq`) the diff from this to the new
   * tree; others get the whole tree.  FNV-1a 64 is the tree hash carried in
   * each delta so a bot can tell it diverged and pull the whole tree. */
  char        *tree_last;
  int          tree_last_len;
  uint64_t     tree_last_fnv;
  uint64_t     tree_seq;
  bool         tree_dirty;         /* roster changed: push to bots next tick */
  bool         tree_dirty_local;   /* ...by one of our own bots (short gap)  */
  time_t       last_tree_change_push; /* coalescing clock (BOT_TREE_COALESCE) */
  mesh_hub_t   mesh_hubs[MAX_MESH_HUBS]; /* every hub heard from, any hop  */
  int          mesh_hub_count;
  long long    roster_gen;         /* last generation this hub gossiped     */
  uint32_t     gossip_link_mask;   /* peers linked at the last gossip (bit p) */
  bool         presence_event_due; /* a presence event waits for its gossip     */
  time_t       presence_hold_until;/* no event gossip before then (damping)     */
  time_t       presence_last_event;/* the last event gossip                     */
  int          presence_burst;     /* event gossips in a row inside the window  */
  p2_state_t  *p2;                 /* presence v2 (heap; NULL until hub_p2_init) */
  time_t       gossip_again_at;    /* a link came up: gossip once more then     */
  time_t       resync_due_at;      /* ask peers for a sync then (0 = none)  */

  /* Maintenance clocks of hub_maintenance() / hub_check_peers() (last run;
   * 0 = not yet).  CMD_ADMIN_STATS shows the countdowns. */
  time_t       last_anti_entropy;
  time_t       last_mesh_gossip;
  time_t       last_client_scan;
  time_t       last_ip_cleanup;
  time_t       last_purge;
  time_t       last_peer_check;

  /* SSH console (hub_console_core.c): the core's end of the control
   * socketpair to the console thread, -1 when the console is not running. */
  int          console_ctl_fd;
} hub_state_t;

#define CONFIG_WRITE_DEBOUNCE_S 5

// --- Prototypes ---
void hub_log(const char *format, ...) __attribute__((format(printf, 1, 2)));
/* Send the owed full config push to every local bot (maintenance loop). */
void hub_flush_bot_config(hub_state_t *state, time_t now);
/* The running hub's state (hub_main.c): the level macros below read
 * g_state->log_level / console_log_level, and stay silent while it is NULL. */
extern hub_state_t *g_state;

/* One log line goes to two sinks, each with its own level: the log file
 * (log_level) and the SSH consoles' in-memory ring (console_log_level).  A
 * line is formatted when either wants it; hub_log_at() then writes it to
 * each sink whose level is at least `level`.  A bare hub_log() counts as
 * LOG_ERROR: written at every level but LOG_NONE. */
void hub_log_at(int level, const char *format, ...)
    __attribute__((format(printf, 2, 3)));
#define hub_log_on(lvl) \
    (g_state && (g_state->log_level >= (lvl) || g_state->console_log_level >= (lvl)))

// Log level filtering macros - these check the log level before calling hub_log.
// The tag is glued to the caller's format by string-literal concatenation, so a
// message with no varargs stays warning-free under -Wpedantic (an empty
// __VA_ARGS__ after a named parameter is not valid C11).
#define hub_log_error(...) \
    do { if (hub_log_on(LOG_ERROR)) hub_log_at(LOG_ERROR, "[ERROR] " __VA_ARGS__); } while(0)
#define hub_log_warning(...) \
    do { if (hub_log_on(LOG_WARNING)) hub_log_at(LOG_WARNING, "[WARNING] " __VA_ARGS__); } while(0)
#define hub_log_info(...) \
    do { if (hub_log_on(LOG_INFO)) hub_log_at(LOG_INFO, "[INFO] " __VA_ARGS__); } while(0)
#define hub_log_debug(...) \
    do { if (hub_log_on(LOG_DEBUG)) hub_log_at(LOG_DEBUG, "[DEBUG] " __VA_ARGS__); } while(0)

bool hub_config_load(hub_state_t *state, const char *password);
void hub_config_write(hub_state_t *state);
unsigned long hub_config_saves(void);
/* hub_config_write() is a no-op while this is set (-selftest). */
extern bool g_hub_config_readonly;
/* true while hub_config_load runs: stamps on disk are this hub's own record
 * and are kept whatever the clock says (a box booting with its clock in the
 * past must not drop its config), so hub_ts_ahead lets them through. */
extern bool g_hub_config_loading;

/* a|/o| record codec (docs/passwordless.md §3.1), shared by config load,
 * peer sync and bot pushes: uuid|name|pubkey|act|seen|ts|.  pubkey may be
 * empty; anything else that is not a valid key refuses the line. */
bool hub_parse_user_record(const char *data, char type, hub_user_record_t *out);
/* Full line incl. "\n". */
int hub_format_user_record(const hub_user_record_t *u, char *buf, size_t len);
/* Timestamp for changing an EXISTING replicated record: now, but always past
 * its previous stamp.  Peers and bots accept only a strictly newer timestamp,
 * so an add and a remove in the same second would tie and the remove would
 * never replicate (a removed admin staying active elsewhere). */
static inline time_t hub_lww_next_ts(time_t prev) {
  time_t now = time(NULL);
  return now > prev ? now : prev < LLONG_MAX ? prev + 1 : prev;
}

/* A replicated record's stamp may run at most LWW_MAX_FUTURE past this
 * node's clock.  Linked nodes agree within the 60 s handshake window, so a
 * stamp beyond it is hostile or broken: refused on every store, it can neither
 * win LWW for good nor run the stamp arithmetic past LLONG_MAX.  The margin
 * leaves room for hub_lww_next_ts stepping past now under a burst of edits.
 * Hub-side only: bots take records from their hub, which already refused. */
#define LWW_MAX_FUTURE 3600
static inline bool hub_ts_ahead(time_t ts) {
  return !g_hub_config_loading && ts > time(NULL) + LWW_MAX_FUTURE;
}

/* t + d for stamp arithmetic, stopping at LLONG_MAX (a stamp loaded from a
 * config written before LWW_MAX_FUTURE may sit there). */
static inline time_t hub_ts_add(time_t t, time_t d) {
  return t > LLONG_MAX - d ? LLONG_MAX : t + d;
}

/* LWW acceptance for a replicated add/del record: a strictly newer stamp wins,
 * and on an exact tie a delete beats an add.  hub_lww_next_ts only separates
 * writes made on ONE node; two nodes stamping the same second (a bot's part
 * reaching one hub while another hub still holds the add) tie, and with a
 * plain "newer wins" each side keeps its own copy and refuses the other's
 * forever.  Delete-over-add is deterministic, so every node converges.
 * Mirrored in ircbot bot.h (lww_accepts) -- the rule must match on both. */
static inline bool hub_lww_accepts(time_t in_ts, bool in_active,
                                   time_t cur_ts, bool cur_active) {
  if (hub_ts_ahead(in_ts)) return false;
  return in_ts > cur_ts || (in_ts == cur_ts && cur_active && !in_active);
}

/* LWW acceptance for the network opt flags (one value, no add/del).  Newer
 * stamp wins; on a tie the byte-wise greater flag string wins, so every node
 * picks the same side -- and a set ("h") beats a clear (""), the stricter
 * policy.  Mirrored in ircbot bot.h (opt_accepts). */
static inline bool hub_opt_accepts(time_t in_ts, const char *in_flags,
                                   time_t cur_ts, const char *cur_flags) {
  if (hub_ts_ahead(in_ts)) return false;
  return in_ts > cur_ts ||
         (in_ts == cur_ts && strcmp(in_flags, cur_flags) > 0);
}

/* Whether a stored c/m/o global value ("...|add" / "...|del") is live: its op
 * is the last '|' field. */
static inline bool hub_global_value_active(const char *value) {
  const char *last = value ? strrchr(value, '|') : NULL;
  return !(last && strcmp(last + 1, "del") == 0);
}

/* Value of an opt line, "<letters>|<ts>" — including the "|<ts>" form a
 * clear produces, which a plain "%[^|]|%lld" scan rejects.  flags gets only
 * [a-zA-Z0-9]; false if the timestamp is missing or not positive. */
bool hub_parse_opt_value(const char *v, char flags[MAX_OPT_FLAGS + 1],
                         time_t *ts);

// Curve25519 crypto functions
bool hub_crypto_generate_combined_keypair(unsigned char priv_out[64],
                                          unsigned char pub_out[64]);
void hub_crypto_split_combined(const unsigned char in[64],
                               unsigned char ed_out[32],
                               unsigned char x_out[32]);
bool hub_crypto_ed25519_sign(const unsigned char ed_priv[32],
                             const unsigned char *msg, size_t msg_len,
                             unsigned char sig_out[64]);
bool hub_crypto_ed25519_verify(const unsigned char ed_pub[32],
                               const unsigned char *msg, size_t msg_len,
                               const unsigned char sig[64]);
bool hub_crypto_x25519_derive(const unsigned char x_priv[32],
                              const unsigned char x_peer_pub[32],
                              unsigned char shared_out[32]);
bool hub_crypto_hkdf_sha256(const unsigned char *ikm, size_t ikm_len,
                            const unsigned char *salt, size_t salt_len,
                            const unsigned char *info, size_t info_len,
                            unsigned char *out, size_t out_len);
/* Combined public key (ed_pub || x_pub) from a combined private key. */
bool hub_crypto_combined_pub_from_priv(const unsigned char priv[64],
                                       unsigned char pub[64]);
/* Strict: canonical base64 of exactly 64 bytes, neither half all zero. */
bool hub_crypto_pubkey_b64_decode(const char *b64, unsigned char out[64]);
/* "ab12:cd34:ef56:7890" — first 8 bytes of SHA-256(pub64). */
void hub_crypto_key_fingerprint(const unsigned char pub[64],
                                char out[KEY_FP_LEN + 1]);
/* Fingerprint of an 88-char key string, or "(no key)"/"(bad key)". */
void hub_crypto_key_fingerprint_b64(const char *b64, char out[KEY_FP_LEN + 1]);
void hub_crypto_hl_fp(const unsigned char ed_pub[32], char out[HL_FP_LEN + 1]);

// AES-GCM
int aes_gcm_decrypt(const unsigned char *input, int input_len,
                    const unsigned char *key, unsigned char *output,
                    unsigned char *tag);
int aes_gcm_encrypt(const unsigned char *plain, int plain_len,
                    const unsigned char *key, unsigned char *output,
                    unsigned char *tag);
int aes_gcm_decrypt_aad(const unsigned char *input, int input_len,
                        const unsigned char *aad, int aad_len,
                        const unsigned char *key, unsigned char *output,
                        unsigned char *tag);
int aes_gcm_encrypt_aad(const unsigned char *plain, int plain_len,
                        const unsigned char *aad, int aad_len,
                        const unsigned char *key, unsigned char *output,
                        unsigned char *tag);

// Rate limiting and IP access control functions
bool is_ip_allowed(hub_state_t *state, const char *ip);
bool hub_startup_admit(hub_state_t *state, const char *ip);
void hub_known_ip_note(hub_state_t *state, const char *ip);
/* D2: allocate a client's recv/writing buffers at `size` (and writing at
 * size+64). Returns false on OOM. Used at accept/connect time. */
bool hub_client_alloc_buffers(hub_client_t *c, int size);
/* D2: grow a client's buffers to MAX_BUFFER on successful authentication.
 * Idempotent (no-op if already full size). Returns false on OOM. */
bool hub_client_promote_buffers(hub_client_t *c);
void increment_active_connections(hub_state_t *state, const char *ip);
void decrement_active_connections(hub_state_t *state, const char *ip);
void cleanup_old_ip_limits(hub_state_t *state);
/* Accept-time allow/deny decision; logs a refusal. */
bool check_ip_access_lists(hub_state_t *state, const char *ip);
/* Same decision, silent: deny wins; a non-empty allowlist must match; an
 * address that does not parse is refused whenever either list has entries. */
bool hub_ip_acl_permits(const hub_state_t *state, const char *ip);
/* "a.b.c.d" or "a.b.c.d/N" (N = 0..32, no sign or leading zero) into a
 * canonical entry (added = 0).  False on anything else. */
bool hub_ip_acl_parse(const char *in, hub_ip_acl_t *out);
/* Strict unsigned decimal for admin numeric fields (indices, days, ports):
 * 1-10 ASCII digits, nothing else -- no sign, space, suffix or empty string --
 * and value <= max.  atoi() read "7d" as 7, "c3cd..." as 0 and "" as 0; in
 * DEL_PEER a UUID starting with digits deleted the peer at that index, and in
 * PURGE_TOMBSTONES a typo meant "purge every tombstone now". */
bool hub_parse_uint(const char *s, unsigned long max, unsigned long *out);
/* A hub friendly name: 1-63 bytes of [A-Za-z0-9._-].  The name travels inside
 * '|'-separated config lines and handshakes, ':'/','-separated mesh gossip and
 * the ':'-separated ADD_PEER payload, so any other byte could forge a field or
 * a whole record ("x|203.0.113.77|0" after a newline).  Applied to
 * SET_HUB_NAME, the setup wizard and names learned from peers. */
bool hub_name_valid(const char *name);
/* "8-4-4-4-12" hex: the shape of every node and user uuid. */
bool hub_uuid_shape(const char *u);
/* Log labels (any log line naming a node or user by uuid names it too):
 * "bot bunny_ (<uuid>)", "hub hubtbl (<uuid>)", "admin robert (<uuid>)",
 * "oper x (<uuid>)"; a name nobody knows reads "?", so "bot ? (<uuid>)".
 * kind: 'b' bot, 'h' hub, 'u' admin/oper, 0 = whichever knows the uuid.
 * hub_who_client labels a connection: a bot by its uuid, a peer by its name
 * and uuid, a console by its admin.  Both return one of HUB_WHO_SLOTS
 * rotating thread-local buffers, so one log line can carry several labels. */
#define HUB_WHO_SLOTS 4
#define HUB_WHO_MAX   160
const char *hub_who(const hub_state_t *state, char kind, const char *uuid);
const char *hub_who_client(const hub_state_t *state, const hub_client_t *c);
/* list: 'w' (allow) or 'x' (deny).  Add refuses a duplicate (same network
 * and prefix) or a full list; remove matches the same way. */
typedef enum { IP_ACL_ADDED, IP_ACL_DUPLICATE, IP_ACL_FULL, IP_ACL_BAD_LIST } ip_acl_add_t;
ip_acl_add_t hub_ip_acl_add(hub_state_t *state, char list, const hub_ip_acl_t *e);
bool hub_ip_acl_remove(hub_state_t *state, char list, const hub_ip_acl_t *e);

/* ---- Connection limits (hub_connlimits.c) --------------------------------
 * Setting table behind `hub set ssh|conn`, the SSH-only address table (D26) and
 * the eviction choice.  Main thread, except hub_ssh_evict_pick. */
enum { HUB_CONN_SSH = 0, HUB_CONN_CONN = 1 };
typedef enum { HUB_CONN_OK, HUB_CONN_UNKNOWN, HUB_CONN_BAD } hub_conn_set_t;
void hub_conn_cfg_defaults(hub_conn_cfg_t *c);
int  hub_conn_cfg_count(int group);
const char *hub_conn_cfg_name(int group, int idx);
bool hub_conn_cfg_get(const hub_conn_cfg_t *c, int group, const char *name, char *out, size_t cap);
bool hub_conn_cfg_default(int group, const char *name, char *out, size_t cap);
bool hub_conn_cfg_is_default(const hub_conn_cfg_t *c, int group, const char *name);
int  hub_conn_cfg_preauthip(const hub_conn_cfg_t *c);
hub_conn_set_t hub_conn_cfg_set(hub_conn_cfg_t *c, int group, const char *name,
                                const char *value, char *why, size_t whycap);
bool hub_conn_cfg_load(hub_conn_cfg_t *c, int group, const char *body);
size_t hub_conn_cfg_lines(const hub_conn_cfg_t *c, char *out, size_t cap);
void hub_conn_cfg_fix(hub_conn_cfg_t *c);
bool hub_ssh_table_connect(ssh_ip_t *tab, int *count, const hub_conn_cfg_t *cfg,
                           const char *ip, time_t now, int *new_block);
void hub_ssh_table_success(ssh_ip_t *tab, int *count, const char *ip, time_t now);
/* The address's row, or NULL (never creates one). */
const ssh_ip_t *hub_ssh_table_peek(const ssh_ip_t *tab, int count, const char *ip);
/* True when `ip` authenticated a console within SSH_SUCCESS_MEMORY. */
bool hub_ssh_table_recent_ok(const ssh_ip_t *tab, int count, const char *ip, time_t now);
void hub_ssh_table_failed(ssh_ip_t *tab, int *count, const hub_conn_cfg_t *cfg,
                          const char *ip, time_t now, int *new_block);
int  hub_ssh_evict_pick(const char *const *ips, const long long *start_ms, int n,
                        const char *new_ip);
/* The console scope of the ACL (D27): same decision as hub_ip_acl_permits, over
 * the entries written with the `console` word. */
bool hub_ip_acl_permits_console(const hub_state_t *state, const char *ip);

bool hub_storage_update_entry(hub_state_t *state, const char *uuid,
                              const char *key, const char *value,
                              const char *extra, const char *op, time_t ts);
bool hub_storage_update_global_entry(hub_state_t *state, const char *key,
                                     const char *value, const char *extra,
                                     const char *op, time_t ts);
/* Stored timestamp of the global entry that `value` under `key` addresses
 * (same match as the update above), or 0 if there is none. */
time_t hub_storage_global_ts(const hub_state_t *state, const char *key,
                             const char *value);
/* ---- Modes / settings / bans store (hub_storage.c + hub_modes.c) -------- */

/* Status every store-side modes function returns; the console renders it. */
typedef enum {
  HUB_MODES_OK = 0,
  HUB_MODES_BAD_CHAN,     /* not a channel name (or "*" where one is needed)  */
  HUB_MODES_NOT_MANAGED,  /* no live c| record: channel.not_found             */
  HUB_MODES_BAD_MODES,    /* mode string fails docs/modes.md §3.2: channel.bad_mode */
  HUB_MODES_BAD_SETTING,  /* unknown name / bad value / bad range; `bad` names it */
  HUB_MODES_TOO_LONG,     /* a field is over its cap                          */
  HUB_MODES_BAD_MASK,     /* ban mask empty, too long, or has a bad character */
  HUB_MODES_BAD_REASON,   /* ban reason too long or has a control character   */
  HUB_MODES_BAD_EXPIRY,   /* expiry in the past or absurdly far               */
  HUB_MODES_PROTECTED,    /* ban.protected: overlaps a trusted bot / usermask */
  HUB_MODES_NOT_FOUND,    /* ban del: no such live ban                        */
  HUB_MODES_FULL,         /* MAX_BANS_PER_CHAN / MAX_GLOBAL_BANS / MAX_BANS_TOTAL */
  HUB_MODES_FROZEN        /* an upgrade run holds the config freeze           */
} hub_modes_status_t;

/* One C| (channel settings) or D| (network defaults) record, live. */
typedef struct {
  bool   present;                       /* a live record exists            */
  char   chan[MAX_CHAN];                /* stored spelling ("" for D|)     */
  char   modes[C_MODES_MAX + 1];        /* "" = network default            */
  char   settings[C_SETTINGS_MAX + 1];  /* only overrides, "" = none       */
  time_t ts;
} hub_chanset_t;

/* One live B| ban. */
typedef struct {
  char   chan[MAX_CHAN];                /* "#chan" or "*"                  */
  char   mask[BAN_MASK_MAX + 1];
  time_t expires;                       /* absolute unix time, 0 = permanent */
  char   flags[8];                      /* "s" = sticky, "" = none         */
  char   setter[BAN_SETTER_MAX];        /* admin name or bot uuid          */
  char   reason[BAN_REASON_MAX + 1];
  time_t ts;
  time_t last_used;                     /* last match a bot reported, 0 = never */
} hub_ban_t;

/* ASCII case-insensitive equality (channel names, ban masks; D39). */
bool hub_ascii_ieq(const char *a, const char *b);
/* Whether two stored values of global key `key` are the same RECORD: c|/C|
 * compare the channel field, B| the channel and mask (all ASCII
 * case-insensitive), the singletons a/p/D always match, every other key its
 * first field case-sensitively.  `a`/`b` may be a full stored value or just
 * its identity prefix. */
bool hub_global_identity_eq(const char *key, const char *a, const char *b);
/* Syntax check of one stored C/D/B value (all fields, caps, charsets, op).
 * The single validator behind every ingest path. */
bool hub_record_valid(const char *key, const char *value);
/* Store one C|, D| or B| record (full stored value incl. its op, no stamp)
 * under LWW: newer stamp wins; on a tie a delete beats an add, otherwise the
 * byte-wise greater value wins.  Validates, applies the per-class ceilings
 * (MAX_CHANNELS, MAX_BANS_PER_CHAN, MAX_GLOBAL_BANS, MAX_BANS_TOTAL), keeps
 * the stored spelling of the channel/mask.  False = rejected or not newer. */
bool hub_storage_put_record(hub_state_t *state, const char *key,
                            const char *value, time_t ts);
/* Room for one more global entry of `key`'s class (c/m/o, C, D, B). */
bool hub_global_room(const hub_state_t *state, const char *key);
/* Index of the stored global entry `value` addresses under `key`, or -1. */
int hub_global_find(const hub_state_t *state, const char *key, const char *value);
/* After global_entries[] was changed behind the store's back (the purge
 * compaction): rebuild the index and counts.  hub_global_note_new(i): entry i
 * was just appended. */
void hub_global_reindex(hub_state_t *state);
void hub_global_note_new(hub_state_t *state, int i);

/* Channel stamp for a delete that must beat the channel's c|, C| and every
 * B| line: past the newest stored stamp of any of them. */
time_t hub_chan_del_stamp(const hub_state_t *state, const char *chan);
/* Write `del` on the channel's C| and B| lines with stamp `ts` (LWW decides
 * each); announce: also send them to the peers and owe the bots a push.  The
 * c| line itself is the caller's.  Returns how many records changed. */
int hub_chan_cascade_del(hub_state_t *state, const char *chan, time_t ts, bool announce);
/* True when `chan` has a live c| record (ASCII case-insensitive); copies the
 * stored spelling to `name` when not NULL. */
bool hub_chan_live(const hub_state_t *state, const char *chan, char *name, size_t cap);

/* K| (learned channel state).  put: only while `chan` is live; LWW on ts,
 * a tie to the byte-wise greater "key|modes".  ingest: one "chan|key|modes|ts"
 * body (after "K|"), validated; true when stored.  drop: forget it (the
 * channel went).  append: every K| line to buf at *off (false when full). */
const hub_chan_learned_t *hub_learned_find(const hub_state_t *state, const char *chan);
bool hub_learned_put(hub_state_t *state, const char *chan, const char *key, int modes,
                     time_t ts);
bool hub_learned_ingest(hub_state_t *state, const char *body);
void hub_learned_drop(hub_state_t *state, const char *chan);
int hub_learned_format(const hub_chan_learned_t *l, char *buf, size_t cap);
bool hub_learned_append(const hub_state_t *state, char *buf, int cap, int *off);
/* The purge's orphan sweep over global records: C|, B| (not "*") and K| of a
 * channel with no live c|.  Returns how many went (purge_note'd by caller
 * through `note`, may be NULL). */
int hub_purge_chan_orphans(hub_state_t *state,
                           void (*note)(void *, const char *kind, const char *name,
                                        time_t ts), void *arg);
/* A tombstone stamped `ts` that this hub does not hold may not be created
 * while a purge's floor holds (PURGE_FLOOR_HOLD). */
bool hub_purge_floor_blocks(const hub_state_t *state, time_t ts);
void hub_purge_floor_set(hub_state_t *state, time_t cutoff);

/* §3.2 mode string ("+stnkl 20", "" = default) and §4 settings string
 * ("bitch=1,flood join=5:60"): HUB_MODES_OK or BAD_MODES / BAD_SETTING /
 * TOO_LONG.  `bad` (may be NULL) receives the offending token. */
hub_modes_status_t hub_modes_check(const char *modes);
hub_modes_status_t hub_settings_check(const char *settings, bool net_default,
                                      char *bad, size_t bad_cap);
/* The setting table, for the console's views: NULL name past the end;
 * kind is "flag" / "num" / "flood" / "sendq" (NULL for an unknown name); net_only =
 * lives only in D| (the bot floods, ignoretime and sendq). */
int hub_setting_count(void);
const char *hub_setting_name(int i);
const char *hub_setting_kind(const char *name);
bool hub_setting_net_only(const char *name);
/* Range of a numeric setting; false for a flag, a flood or an unknown name. */
bool hub_setting_range(const char *name, long *lo, long *hi);
/* One name/value against the contract's names and ranges. */
hub_modes_status_t hub_setting_check(const char *name, const char *value,
                                     bool net_default);
/* Value of `name` in a settings string; false if it is not there. */
bool hub_settings_get(const char *settings, const char *name, char *out, size_t cap);
/* Set (value) or remove (value NULL) one token in a settings string of
 * capacity `cap`; HUB_MODES_TOO_LONG when it would not fit. */
hub_modes_status_t hub_settings_set(char *settings, size_t cap, const char *name,
                                    const char *value);
/* Effective value of a setting for a channel: channel C| override, else the
 * D| default, else the built-in.  Returns 'c' / 'n' / 'b' for the source, 0
 * for an unknown name.  chan NULL: network level only. */
int hub_setting_effective(const hub_state_t *state, const char *chan,
                          const char *name, char *out, size_t cap);

/* C| / D| store.  put replaces the whole record (the caller merges); both
 * empty writes a delete (back to defaults).  Needs a live c| for C|. */
bool hub_chanset_get(const hub_state_t *state, const char *chan, hub_chanset_t *out);
hub_modes_status_t hub_chanset_put(hub_state_t *state, const char *chan,
                                   const char *modes, const char *settings);
bool hub_netset_get(const hub_state_t *state, hub_chanset_t *out);
hub_modes_status_t hub_netset_put(hub_state_t *state, const char *modes,
                                  const char *settings);

/* Bans.  chan is "#chan" (must be a live channel) or "*".  expires 0 =
 * permanent.  add is also the update of an existing mask.  On PROTECTED,
 * `who` (may be NULL) receives what the mask would hit ("bot <nick>" /
 * "user <name>").  The §6.2 step 1 check (members in the channel) is the
 * bot's. */
hub_modes_status_t hub_ban_protected(const hub_state_t *state, const char *mask,
                                     char *who, size_t who_cap);
hub_modes_status_t hub_ban_add(hub_state_t *state, const char *chan, const char *mask,
                               time_t expires, bool sticky, const char *setter,
                               const char *reason, char *who, size_t who_cap);
hub_modes_status_t hub_ban_del(hub_state_t *state, const char *chan, const char *mask);
/* Live bans of `chan` ("*" = global only, NULL = all), oldest first, up to
 * `max`; returns how many were written. */
int hub_ban_list(const hub_state_t *state, const char *chan, hub_ban_t *out, int max);
/* The last-used slot of the live ban (chan, mask), NULL when there is none. */
time_t *hub_ban_used_slot(hub_state_t *state, const char *chan, const char *mask);
/* A ban a bot pushed (B| line body without the tag, and its stamp): accepted
 * only under the contract's bot rules; the caller forwards on true. */
bool hub_ban_bot_write(hub_state_t *state, const char *bot_uuid, const char *value,
                       time_t ts);
/* 60 s sweep: `del` for every expired ban, announced to peers and bots. */
void hub_bans_sweep(hub_state_t *state, time_t now);
/* CMD_CHAN_EVENT from an authenticated bot (validate, rate-limit, log). */
void hub_chan_event_receive(hub_state_t *state, hub_client_t *client, const char *payload);
/* Start the apply-once election (kind "mode") for `channel` on behalf of
 * `admin` (the console owed the answer, or NULL).  The answer comes later on
 * that console: ok "channel.mode" {chan, by, by_uuid, hub_name, asked, hubs}
 * or error "channel.nobody".  False = the election table is full. */
bool hub_chan_mode_apply(hub_state_t *state, const char *channel,
                         const hub_client_t *admin);

/* Soft-delete a registered bot: a d|1 tombstone stamped past any earlier 'd'.
 * False when the uuid is unknown or already deleted; *ts_out = the stamp. */
bool hub_storage_delete(hub_state_t *state, const char *uuid, time_t *ts_out);

/* hub_access.c — admin flags (uf|) and oper channel bindings (uc|),
 * docs/plans/2026-10-16_user_flags_plan.md */
bool hub_uflags_canon(const char *in, char *out, size_t cap);
bool hub_uflags_edit(const char *cur, const char *spec, char *out, size_t cap);
bool hub_uflags_accepts(time_t in_ts, const char *in, time_t cur_ts, const char *cur);
bool hub_uchan_name_ok(const char *chan);
hub_uflag_record_t *hub_uflag_find(hub_state_t *state, const char *uuid);
hub_uchan_record_t *hub_uchan_find(hub_state_t *state, const char *uuid, const char *chan);
bool hub_uflag_put(hub_state_t *state, const char *uuid, const char *flags, time_t ts);
bool hub_uchan_put(hub_state_t *state, const char *uuid, const char *chan, bool active,
                   time_t ts);
const char *hub_user_flags(hub_state_t *state, const char *uuid);
bool hub_user_has_flag(hub_state_t *state, const char *uuid, char flag);
bool hub_user_chan_ok(hub_state_t *state, const char *uuid, const char *chan);
int hub_user_chan_count(hub_state_t *state, const char *uuid, bool *global);
int hub_format_uflag(const hub_uflag_record_t *r, char *buf, size_t cap);
int hub_format_uchan(const hub_uchan_record_t *r, char *buf, size_t cap);
bool hub_access_ingest(hub_state_t *state, char kind, const char *body, bool need_user,
                       bool *changed);
int hub_access_migrate(hub_state_t *state);
/* After a peer sync or bot push: no active admin holding +a → undo the +a
 * removals of the race.  Returns the sync lines for the peers (malloc'd) or
 * NULL; *restored = admins brought back.  from labels the log line. */
char *hub_admin_floor_restore(hub_state_t *state, const char *from, int *restored);
void hub_access_remap_uuid(hub_state_t *state, const char *from, const char *to);
void hub_access_prune(hub_state_t *state);
int hub_access_purge(hub_state_t *state, time_t cutoff);
bool hub_access_append(hub_state_t *state, char *buf, int cap, int *off,
                       bool (*keep)(hub_state_t *, const char *uuid, void *), void *arg);
void hub_user_chans(hub_state_t *state, const char *uuid, char *out, size_t cap);
time_t hub_access_next_ts(hub_state_t *state, const char *uuid);
int hub_access_chan_change(hub_state_t *state, const char *uuid, bool add, const char *chan,
                           char *out, size_t cap);
/* hub_logic.c: one sync payload onto peer c's queue, or held while c's
 * version is not known (every sync to a peer goes through it). */
void hub_peer_enqueue_sync(hub_state_t *state, hub_client_t *c, uint8_t op, lane_t lane,
                           const char *payload, const char *coalesce, uint64_t seq);

void hub_generate_sync_packet(hub_state_t *state, char *buffer, int max_len);
void hub_generate_bot_payload(hub_state_t *state, const char *uuid,
                              char *buffer, int max_len);
void hub_broadcast_sync_to_peers(hub_state_t *state, const char *payload,
                                 int exclude_fd);

// cutoff==0: purge all tombstones; cutoff>0: purge tombstones older than cutoff.
// tombs (may be NULL) gets one tomb|kind|id|name|ts record per tombstone.
struct reply;
int hub_execute_purge(hub_state_t *state, time_t cutoff, struct reply *tombs);

/* hub_revoke.c: the permanent revoke list (rv|) and mesh-wide settings (hs|) */
hub_revoked_t *hub_revoke_find(hub_state_t *state, const char *uuid);
bool hub_revoke_merge(hub_state_t *state, const hub_revoked_t *in);
bool hub_revoke_parse(const char *rest, hub_revoked_t *out);
int  hub_revoke_format(const hub_revoked_t *r, char *buf, size_t cap);
bool hub_revoke_append(hub_state_t *state, char *buf, int max_len, int *off);
bool hub_revoke_from_bot(hub_state_t *state, const bot_config_t *b);
int  hub_retire_revoked_bots(hub_state_t *state);
/* A bot's hl| hub list is well formed (hub_storage.c). */
bool hub_hublist_valid(const char *v);
bool hub_revoke_mark_wiped(hub_state_t *state, const char *uuid, time_t now, char *line,
                           size_t cap);
int  hub_gsetting_format(hub_state_t *state, const char *name, char *buf, size_t cap);
bool hub_gsetting_set(hub_state_t *state, const char *name, int value);
bool hub_gsetting_ingest(hub_state_t *state, const char *rest, bool *changed);
bool hub_gsetting_append(hub_state_t *state, char *buf, int max_len, int *off);
int hub_plan_format(const upgrade_plan_t *pl, char *out, size_t cap);
bool hub_plan_parse(const char *body, upgrade_plan_t *pl);
void hub_plan_boot(hub_state_t *state);
bool hub_cron_wanted(const hub_state_t *state, char kind, const char *uuid);
bool hub_cron_set_one(hub_state_t *state, char kind, const char *uuid, bool on, char *line, size_t cap);
void hub_cron_prune(hub_state_t *state, char kind);

/* Send PURGE|<cutoff>|<id> to every peer hub, under a fresh random id that
 * this hub records as seen.  False (nothing sent) if no id could be drawn. */
bool hub_broadcast_purge(hub_state_t *state, time_t cutoff);

// Leader election: Check if this hub should initiate scheduled purges
// (Hub with smallest UUID in connected mesh leads)
bool hub_should_initiate_scheduled_purge(hub_state_t *state);

bool hub_handle_client_data(hub_state_t *state, hub_client_t *client);
bool handle_bot_authentication(hub_state_t *state, hub_client_t *client,
                               unsigned char *data, int packet_len);
void hub_disconnect_client(hub_state_t *state, hub_client_t *c);
uint64_t hub_next_conn_serial(void);
void hub_chan_elect_forget_admin(hub_state_t *state, const hub_client_t *c);
void hub_broadcast_mesh_state(hub_state_t *state);

/* ---- Bot presence / the 'bots' tree (hub_logic.c) ----
 * hub_presence_tick drives both halves on the maintenance clock: it gossips
 * this hub's own connected bots to the peers every BOT_PRESENCE_INTERVAL and
 * pushes a refreshed tree down to the bots when the roster changed (or every
 * BOT_TREE_REFRESH regardless).  hub_roster_expire drops entries past the
 * TTL; hub_roster_mark_dirty asks for a push (`local`: one of our own bots
 * changed, pushed within BOT_TREE_COALESCE_LOCAL). */
void hub_presence_tick(hub_state_t *state, time_t now);
void hub_presence_event(hub_state_t *state);
int hub_presence_hold(int burst);
/* One step of the rolling network upgrade per maintenance tick: collect
 * READY acks, commit the next wave, time out a node that never came back.
 * A no-op unless a run is active. */
void hub_upgrade_tick(hub_state_t *state, time_t now);
/* Report the outcome of an upgrade another hub drove, once there is a peer to
 * tell.  A no-op unless HUB_UPGRADE_MARKER_FILE says this process is that
 * upgrade's restart; the marker is read and removed exactly once, so whichever
 * peer link comes up first carries the answer. */
void hub_upgrade_report_pending(hub_state_t *state, hub_client_t *peer);
/* Queue every known ban last-use to a freshly linked peer as CMD_ACTIVITY
 * B| lines, on the bulk lane behind the initial sync (repair path). */
void hub_activity_send_bans(hub_state_t *state, hub_client_t *peer);

/* ---- The hub's own self-update (hub_update.c) ---------------------------
 * The hub side of the network upgrade: what a node needs in order to *be*
 * upgraded, as opposed to the orchestration that drives other nodes.  Built
 * with HAVE_CURL; without it every entry point reports the feature
 * unavailable rather than falling back to anything. */
/* Could this hub move to `target_ver`?  Answered at PREPARE time, before
 * anything is downloaded.  `min_from` is what the driving hub sent ("" or "*"
 * = let the manifest decide); `reason` explains a false. */
bool hub_update_can_take(const char *target_ver, const char *variant,
                         const char *min_from, char *reason,
                         size_t reason_size);
/* One release a manifest lists: its version and date. */
typedef struct {
  char version[64];
  char date[16];
} hub_release_t;
/* Fetch and verify the manifest at <root>/<variant> and list its distinct
 * versions, newest first.  Returns the count, or -1 with *err set. */
int hub_update_list_releases(const char *root, const char *variant,
                             hub_release_t *out, int max, const char **err);
/* CMD_UPGRADE_COMMIT.  Returns false with *err set and nothing touched; on
 * success it does not return -- the process is replaced and reports the
 * outcome after the restart. */
/* The bots' ircbot-releases root this hub reads (see hub_update.c). */
const char *hub_update_bot_root(void);
/* Highest version `cur_ver` may take right now on the way to `target_ver`,
 * read from the release tree at <root>/<variant> ("" = this hub's own root).
 * Walks a node that sits below a target's min_from_version there one release
 * at a time. */
bool hub_update_next_step(const char *root, const char *variant,
                          const char *cur_ver, const char *target_ver,
                          char *out, size_t out_size, char *reason,
                          size_t reason_size);

bool hub_update_commit(hub_state_t *state, const char *upgrade_id,
                       const char *target_ver, const char *variant,
                       const char **err);
/* CMD_UPGRADE_ABORT: restore <exe>.prev / .irchub.cnf.prev and restart onto
 * them.  False when there is nothing retained to go back to. */
bool hub_update_rollback(hub_state_t *state, const char *reason);
void hub_update_failback_confirm(void);
const char *hub_update_cron_status(void);
void hub_update_cron_set(bool on);
bool hub_update_cron_tick(const char *exe);
bool hub_update_install_in_progress(void);
bool hub_update_has_build(const char *root, const char *variant, const char *ver, const char *arch,
                          const char *libc);
void hub_update_stage_start(const char *exe, const char *id, const char *ver, const char *variant);
void hub_update_stage_clear(void);
void hub_update_stage_boot_clean(void);
void hub_update_stage_unsaid(void);
int hub_update_stage_main(const char *ver, const char *variant);
bool hub_update_stage_tick(char *id, size_t id_size, char *out, size_t out_size);
bool hub_update_failback_note(char *out, size_t out_size);
bool hub_upgrade_marker_write(const char *upgrade_id, const char *target_ver,
                              const char *variant);
/* True when `s` may be one field of an upgrade plan: no '|', no line break,
 * no shell metacharacter or blank, and short enough for any plan field.  The
 * same rule gates what a follower accepts at PREPARE and what the rollup|
 * config line carries, so a peer can never split or inject a config line. */
bool hub_upgrade_plan_field_ok(const char *s);
void hub_rollcall_tick(hub_state_t *state, time_t now);
/* Reads and removes the hand-off marker hub_update_commit() left behind. */
bool hub_update_take_pending(char *id_out, size_t id_size, char *ver_out,
                             size_t ver_size, char *variant_out,
                             size_t variant_size);
/* Compare two version strings, tolerating a leading 'v' on either side. */
int hub_update_version_cmp(const char *a, const char *b);
/* Keepalive PING payload for `c`: "t|<tree fnv64>" or "" (hub_logic.c). */
void hub_tree_ping_payload(const hub_state_t *state, const hub_client_t *c, char *out,
                           size_t cap);
/* Host capability probe answered in CMD_UPGRADE_READY. */
void hub_update_host_arch(char *out, size_t out_size);
void hub_update_host_libc(char *out, size_t out_size);
const char *hub_update_host_variant(void);
/* irchub -checkupdate [variant]: verify the release channel, print, exit. */
int hub_update_check_cli(const char *variant);
void hub_roster_expire(hub_state_t *state, time_t now);
void hub_roster_mark_dirty(hub_state_t *state, bool local);
void hub_roster_send_to_peer(hub_state_t *state, const hub_client_t *peer);
/* Presence v2 hooks into the roster (hub_logic.c): drop every entry of
 * `hub_uuid` and its mesh-map hub; make the roster match a record's bot list
 * (drop entries older than `stamp` that the record no longer lists, add a
 * bare entry for a listed bot nobody reported yet).  Both return changes. */
int  hub_roster_p2_drop_hub(hub_state_t *state, const char *hub_uuid);
int  hub_roster_p2_reconcile(hub_state_t *state, const p2_rec_t *rec);
/* hub_presence2.c */
void hub_p2_init(hub_state_t *state);
void hub_p2_link_up(hub_state_t *state, hub_client_t *peer);
void hub_p2_rx(hub_state_t *state, hub_client_t *peer, const char *payload);
void hub_p2_tick(hub_state_t *state);
bool hub_p2_hub_gone(const hub_state_t *state, const char *uuid);
bool hub_p2_digest_keepalive(const hub_state_t *state, const hub_client_t *c);
void hub_p2_roster_touched(hub_state_t *state, const char *hub_uuid);
/* Phase 2: whether the v2 view stands in for today's 60 s rounds. */
void hub_chan_elect_tick(hub_state_t *state, time_t now);

/* ---- Mesh transport: per-peer outbound queue (see docs/mesh.md) ---- */

/* Build a queued message from an opcode + plaintext payload.  Caller passes
 * payload data which is copied; ownership of the returned struct is
 * transferred to peer_enqueue.  Returns NULL on alloc failure. */
queued_msg_t *queued_msg_new(uint8_t cmd, lane_t lane,
                             const unsigned char *payload, int payload_len);
void queued_msg_set_coalesce(queued_msg_t *m, const char *origin_hub_uuid,
                             uint64_t lamport_seq, const char *coalesce_key);
void queued_msg_free(queued_msg_t *m);

/* Enqueue m on peer's lane.  Performs coalescing if m->coalesce_key[0] != 0
 * and a same-key message exists in the lane (replaces in place, frees the
 * passed-in m).  Returns true on success.  On URGENT lane overflow, returns
 * false and the caller should treat the peer as failed. */
bool peer_enqueue(hub_client_t *peer, queued_msg_t *m);
/* A frame to a linked bot or peer: LANE_URGENT, drained at once (never a
 * direct write).  false = not queued. */
bool hub_client_send(hub_state_t *state, hub_client_t *c, uint8_t cmd,
                     const char *payload);

/* Drain queued messages to the socket; called when select() reports
 * writable.  Encrypts each message with peer->session_key just before send,
 * tracks partial writes via peer->writing_*. */
void peer_drain_writable(hub_state_t *state, hub_client_t *peer);

/* True if peer has anything pending — either a partial in-flight write or
 * any non-empty lane.  Used by main loop to decide whether to set POLLOUT. */
bool peer_has_pending_writes(hub_client_t *peer);

/* True when recv_buf already holds a whole frame (or a length prefix the pump
 * will refuse).  hub_handle_client_data takes at most 8 frames per call for
 * fairness; the main loop must come back for the rest without waiting for
 * new bytes, or they sit unread until the sender's next packet. */
bool hub_client_has_buffered_frame(const hub_client_t *c);

/* Free all queued messages (called from hub_disconnect_client). */
void peer_queue_destroy(hub_client_t *peer);

/* Allocate the next outgoing Lamport sequence number for this hub. */
uint64_t hub_next_lamport_seq(hub_state_t *state);

/* ---- SSH admin console, core side (hub_console_core.c) -------------------
 * Everything here runs on the main thread.  hub_console_start spawns the
 * console thread (hub_console.c) and publishes the host key and the admin
 * credentials to it; hub_console_stop joins it at shutdown. */
bool hub_console_start(hub_state_t *state);
/* Publish state->conn_cfg to the console thread (start, and after each change). */
void hub_console_limits_changed(hub_state_t *state);
void hub_console_stop(hub_state_t *state);
/* Re-publish the host key after the hub key changed (REGEN_KEYS etc.). */
void hub_console_hostkey_changed(hub_state_t *state);
/* The accepted connection's first bytes are "SSH-": give its socket to the
 * console thread and drop the client from the core (the fd stays open). */
void hub_console_handoff(hub_state_t *state, hub_client_t *c);
/* The control socketpair is readable: logins, refusals, audit lines. */
void hub_console_ctl_read(hub_state_t *state);
/* One pass of the main loop: publish changed credentials, push events and
 * log lines to the consoles that asked for them. */
void hub_console_tick(hub_state_t *state);
/* A plaintext frame on an internal connection (hub_handle_client_data). */
bool hub_console_frame(hub_state_t *state, hub_client_t *c, uint8_t op,
                       const char *payload, int payload_len);
/* Queue one frame to a console.  op CONSOLE_REPLY never drops: false = the
 * queue is over its cap and the console must be closed.  Events are dropped
 * (and counted) instead. */
bool hub_console_send(hub_client_t *c, uint8_t op, const void *data, size_t len);
bool hub_console_has_pending(const hub_client_t *c);
void hub_console_drain(hub_state_t *state, hub_client_t *c);
void hub_console_link_free(hub_client_t *c);
/* Allocate the log ring (mmap'd, mlock'd, MADV_DONTDUMP); false = no ring. */
bool hub_console_log_ring_init(void);
/* hub_log_at feeds every line at or under console_log_level in here. */
void hub_console_log_append(int level, const char *line, size_t len);
/* Snapshots the core takes of itself (hub_logic.c). */
int  hub_console_tree_rows(hub_state_t *state, char *buf, int max_len);
void hub_console_status_line(hub_state_t *state, const char *tree,
                             char *out, size_t out_size);
void hub_console_upg_line(hub_state_t *state, char *out, size_t out_size);
void hub_console_ssh_failed(hub_state_t *state, const char *ip);
bool hub_console_ssh_admit(hub_state_t *state, const char *ip);
void hub_console_note_login(hub_state_t *state, const char *name, const char *ip);

void hub_set_config_pass(hub_state_t *s, const char *pass);
void hub_link_offer(hub_state_t *state, hub_client_t *c, const char *peer_uuid);
void hub_config_key_forget(hub_state_t *s);
void hub_get_config_pass(const hub_state_t *s, char *out, size_t len);
void secure_wipe(void *ptr, size_t len);
void generate_uuid_v4(char *buffer, size_t len);

char *base64_encode(const unsigned char *input, int length);
unsigned char *base64_decode(const char *input, int *out_len);

#endif
