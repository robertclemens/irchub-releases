# irchub

A hub server for coordinating networks of IRC bots. irchub handles encrypted configuration distribution, bot registration, and inter-hub mesh networking — so your bots always have up-to-date users, keys and settings without manual intervention.

There are no admin, oper or bot passwords: every hub, bot, admin and oper has its own Curve25519 keypair (Ed25519 for signatures + X25519 for encryption), and only public keys are ever exchanged. The one password left is each program's config-file password. Design: `docs/passwordless.md`.

> **Companion project:** irchub is designed to work with [ircbot](https://github.com/robertclemens/ircbot/) — a C-based IRC bot that connects to irchub for secure configuration sync, op coordination, and inter-bot communication. You need both projects to run a complete setup.

## Overview

irchub sits between your IRC bots and your admin console. Each [ircbot](https://github.com/robertclemens/ircbot/) instance authenticates to the hub using its own Curve25519 keypair. The hub distributes encrypted configuration (channels, admins and opers with their public keys and usermasks, the other bots' public keys) to all connected bots and keeps everything synchronized across multiple hub instances via a peer mesh.

```
ssh (admin) ──► irchub ──► ircbot A
                    └──► ircbot B
                    └──► irchub (peer) ──► ircbot C
```

**Key capabilities:**

- **Bot registration** — each bot makes its own keypair; you register its UUID and public key
- **Encrypted config sync** — AES-256-GCM encrypted configuration pushed to all bots on connect and periodically
- **Peer mesh** — multiple hub instances synchronize state; leader election prevents duplicate operations
- **Admin console** — an SSH server built into the hub, on its own port: log in with any SSH client (OpenSSH, PuTTY, phone apps) using your admin key, and manage bots, peers, channels, masks, opers and upgrades from a full-screen console or a scriptable line mode
- **IP access control** — IPv4 allowlist/denylist with CIDR support, local to each hub; changes apply to existing connections too, and a change that would lock out your own admin session is refused
- **Rate limiting** — per-IP connection limits and failed-auth blocking
- **Tombstone purging** — automatic cleanup of deleted config entries with configurable retention

## Components

| Binary | Purpose |
|--------|---------|
| `irchub` | Hub server |
| `keygen` | Makes an admin/oper's IRC keypair (`<ts>_<name>.private.b64` / `.public.b64`) and SSH key (`<ts>_<name>_ed25519` / `.pub`) in one run, optionally under one passphrase (`-d <dir>`, `--passwd` to add/change/remove it later); `--ssh-fingerprint` prints a hub's SSH host key fingerprint |

Built binaries are placed in `bin/`. Install them wherever suits your setup — the examples below assume the binaries are on your `PATH` or you are running from the directory containing them.

## Companion Project: ircbot

irchub is the hub — [ircbot](https://github.com/robertclemens/ircbot/) is the bot. The two projects are built to work together:

- **[ircbot](https://github.com/robertclemens/ircbot/)** connects to irchub on startup, authenticates with its Curve25519 keypair, and receives its full configuration (channels to join, admins and opers with their public keys and usermasks, the other bots' public keys) automatically.
- When a bot's config changes (new channel, new user, a changed key, rekey), the hub pushes the update to all connected bots in real time.
- Bots request op grants through the hub, which coordinates across the mesh so any bot can grant ops to any other bot regardless of which hub they are connected to. With no hub reachable, bots ask each other directly with PRIVMSGs sealed to each other's keys.
- Admins and opers command a bot over IRC with their own key: a signed auth request, a lockbox reply carrying the bot's public key, then commands sealed to the bot. The hub only distributes public keys — it never holds a user's or a bot's private key.

You provision bots and manage the network entirely through the hub's SSH console — you never need to manually edit bot config files, and there is no separate admin program to install.

## Dependencies

| Dependency | Minimum | Notes |
|------------|---------|-------|
| GCC | 7+ | C11 support required (`-std=c11`) |
| OpenSSL | 1.1.1+ | `libssl`, `libcrypto` — EVP API required |
| POSIX | — | Linux, FreeBSD, and other POSIX systems (uses `termios`, `flock`, POSIX sockets) |
| GNU Make | 3.81+ | Build system |
| CMake | 3.14+ | Builds the bundled libssh (below) |
| libcurl | — | Release downloads for hub-driven upgrades |

**libssh.** The SSH console uses [libssh](https://www.libssh.org/) **0.12.2** (LGPL-2.1), built from the verified source tarball in `third_party/` and linked statically — server side only, no SFTP/GSSAPI/zlib/pcap. The tarball and its upstream GPG signature ship in this repository and the Makefile checks the tarball's SHA-256 before building; the upstream source is at https://www.libssh.org/files/0.12/ .

### Debian / Ubuntu

```bash
sudo apt install build-essential libssl-dev
```

### RHEL / CentOS / Fedora

```bash
sudo dnf install gcc make openssl-devel
# or for older systems:
sudo yum install gcc make openssl-devel
```

### Arch Linux

```bash
sudo pacman -S gcc make openssl
```

## Building

```bash
git clone https://github.com/robertclemens/irchub.git
cd irchub
make
```

Built binaries are placed in `bin/`.

**Build modes:**

```bash
make              # Release build (default) — optimized, hardened
make debug        # Debug build with AddressSanitizer and UBSan
make production   # Maximum optimization (LTO, -march=native)
make clean        # Remove build artifacts
```

## Initial Setup

### 1. Run setup

First make the first admin's keypair, on that admin's own machine:

```bash
./keygen robert        # or run ./keygen and type the name
```

This asks for an optional passphrase (twice, echo off; empty = none) and writes `YYYYMMDDHHMMSS_robert.private.b64` (0600 — it stays on that machine; the IRC scripts and `bot-auth` use it), `YYYYMMDDHHMMSS_robert.public.b64`, and the SSH key for the hub console, `YYYYMMDDHHMMSS_robert_ed25519` (0600) + `.pub`, both private files under the same passphrase. It prints the public key, its fingerprint and a `~/.ssh/config` block; the private key is never printed. `-d <dir>` writes the files elsewhere, `--passwd <file>` adds/changes/removes the passphrase later. (`keygen.c` and `bcrypt_pbkdf.[ch]` are byte-identical to their `ircbot/utils` copies; `docs/console.md` §9 has the formats.)

Then run setup from the directory where irchub will store its files (config, PID, log, and password files are all created relative to the working directory):

```bash
./irchub -setup
```

You will be prompted for:

| Prompt | Description |
|--------|-------------|
| **Port** | TCP port the hub listens on (e.g. `6697`) |
| **Bind IP** | Interface to bind to — press Enter to default to `0.0.0.0` (all interfaces) |
| **Friendly Name** | Human-readable name for this hub instance |
| **Config Password** | Password used to encrypt the config file (hidden input) |
| **First admin** | Name, then the admin's **public** key — paste the 88 characters or give the path of the `.public.b64` (a `.private.b64` is refused); confirm by fingerprint; then one or more usermasks |

Setup generates this hub's own Curve25519 keypair (the private key stays inside the encrypted config), prints the hub's UUID and public key and saves the public key to `hub_public.b64`, writes the encrypted config file (`.irchub.cnf`) and exits. The hub does not start automatically.

### 2. Start the hub

```bash
./irchub
```

irchub daemonizes itself — it double-forks, detaches from the terminal, and writes its PID to `.irchub.pid`. The working directory is preserved so all relative file paths resolve correctly.

By default, irchub prompts for the config password on stdin before daemonizing. If you are starting it interactively this is the safest option — the password is never stored anywhere and is only held in process memory for the duration of the initial config load.

To stop the hub:

```bash
kill $(cat .irchub.pid)
```

### 3. Create a password file (optional — required for unattended start)

By default a password must be typed each time irchub starts. To allow unattended or automated starts, create an encrypted machine-bound password file:

```bash
./irchub -p
```

This prompts for the config password (with confirmation), then writes `.irchub.pass` — an AES-256-GCM encrypted file readable only by the current user (`0600`). The encryption key is derived from stable properties of this machine and user account, so the file cannot be decrypted if copied to another host.

When `.irchub.pass` is present and passes validation (correct ownership, `0600` permissions, GCM tag intact), irchub reads the password from it automatically and no interactive input is required. If the file is absent, has wrong permissions, or fails decryption, irchub falls back to the stdin prompt.

### 4. Auto-start (optional — requires password file)

A crontab entry can keep irchub running automatically. Because cron cannot provide interactive input, this requires `.irchub.pass` to exist (see step 3). irchub rejects duplicate starts via PID file locking, so running it on an interval is safe — if it is already running the new invocation exits immediately.

Add a crontab entry that checks every 5 minutes:

```bash
crontab -e
```

```
*/5 * * * * /full/path/to/irchub
```

Replace `/full/path/to/irchub` with the absolute path to the binary. irchub always works in its own directory, whatever directory it is started from: `.irchub.cnf`, `.irchub.pass`, `.irchub.pid`, `.irchub.log` and `hub_upgrade.sh` live beside the binary, so no `cd` is needed. Run one binary per hub, in a directory owned by you and not writable by group or others — irchub refuses to start otherwise.

## Admin Console

The hub serves an SSH console on its **own listening port** (the first bytes of a connection tell SSH apart from bots and peers). There is no system `sshd`, no OS account and no password: you log in with the admin record's **name** and its **key**.

1. `keygen robert` (on your own machine) already wrote your SSH key next to the IRC key: `20260914120000_robert_ed25519` (0600) and `…_ed25519.pub`, protected by the same passphrase if you gave one. It also printed a `~/.ssh/config` block (`IdentitiesOnly yes`); `ssh-add -t 1h …_ed25519` keeps it unlocked for an hour. PuTTY users load `…_ed25519` into PuTTYgen and save it as a `.ppk`. For a key made before keygen v2, `./keygen --passwd 20260914120000_robert.private.b64` writes the SSH pair (and adds a passphrase). Details: `docs/console.md` §9.
2. Check the hub's identity on the first login: the hub logs `[CONSOLE] SSH host key ssh-ed25519 SHA256:…` at startup, and `./keygen --ssh-fingerprint hub_public.b64` prints the same line from the hub's public key. Compare it with what `ssh` shows before you accept it.
3. Log in:
   ```bash
   ssh -i 20260914120000_robert_ed25519 -o IdentitiesOnly=yes -p <hub-port> robert@<hub-host>
   ```

Only admin records log in; opers, unknown names and wrong keys are refused alike, and three refused keys end the connection. Admins created on IRC with `+admin` can log in too — run production networks with opt `h` (below) if you want only hub admins to create users.

The console has an output pane, a live network tree, a status bar and an input line; `Alt+1`…`Alt+5` switch between the console, raw log, network, upgrades and stats views. Type `help` for the command list, `help <command>` for one command. With `TERM=dumb` (e.g. `TERM=dumb ssh -tt …` from a script, or a serial terminal) it switches to **line mode**: plain lines, a `> ` prompt and one `[ok #N]` / `[err #N]` marker per command — the interface the test suite drives. Commands and their line-mode output grammar: `docs/console.md`.

### Adding a Bot

1. On the bot's machine run `./ircbot -setup`; the bot generates its own keypair and prints its UUID, public key and key fingerprint.
2. In the console: `bot add <nick> <uuid> <88-char-pubkey>`.

The hub never sees a bot's private key. Every bot receives the other bots' public keys (`b|` lines), which it uses to seal bot-to-bot requests (OPME, INVITE, SETNICK) when no hub is reachable.

### Rekeying a Bot

Rekeying is bot-local: only the bot holds its private key. `bot rekey <uuid>` shows the instructions — an admin runs the bot's own `rekey` command, the bot makes a new keypair, pushes the new public key to the hub and reconnects.

### Admins and Opers

- `admin add <name> <pubkey> <mask>` / `oper add <name> <pubkey> <mask>` — the user runs `keygen <name>` and sends you the `.public.b64`; each key may belong to one user only.
- `userkey <name> <pubkey>` — replaces a key (rotation, a lost key, or a legacy user with no key). UUID and usermasks are kept; the old key stops working on the hub and on every bot as soon as it syncs.
- `admin list`, `oper list`, `match <name|*>` — show each key's fingerprint; `mask add|del <name> <mask>` manages usermasks.

### Opt flags

`opt set h` (hub-only mutations) makes every bot refuse local `+admin`/`-admin`, `+oper`/`-oper`, `+usermask`/`-usermask`, `+bot`/`-bot`, `join`/`part` and `chkey`, so users, masks, keys and channels change only through the hub console. `opt set -` clears it.

### The hub's own key

The hub's private key lives only inside the encrypted `.irchub.cnf`; no command shows or imports it. A copy of `.irchub.cnf` (with its password) is the backup, and moving a hub to a new machine is copying that file. `hub rekey` makes a new key — peers and bots must then re-pin it: see `docs/console.md` §7.

## Peer Mesh

Multiple hub instances can be linked to share configuration and bot state. Add a peer with `peer add <ip> <port> <uuid> <name> <pubkey>` (the pubkey is the peer's `hub_public.b64`). Peers authenticate each other with Ed25519 signatures (`HUBv3`); a pre-passwordless hub (`HUBv2`) is refused, so upgrade all hubs together.

Connected peers:
- Synchronize bot config and global config entries
- Forward bot-to-bot op requests across hub boundaries
- Propagate tombstone purges with deduplication to prevent loops
- Elect a leader (hub with lexicographically smallest UUID) for scheduled operations

## Configuration

The config file (`.irchub.cnf`) is AES-256-GCM encrypted with a key derived from your config password via PBKDF2-SHA256 (100,000 iterations). It is never stored in plaintext.

**Settings managed from the console:**

| Setting | Command |
|---------|---------|
| Bind IP / port | `hub bindip <ip>` / `hub port <port>` (restart to apply) |
| Hub name | `hub name <name>` |
| Log level | `loglevel [file|console] <none|error|warning|info|debug>` |
| Log size limit | `hub logsize <MB>` |
| IP allowlist / denylist | `allow list|add|del`, `deny list|add|del` (CIDR) |
| Tombstone purge | `hub purge now` / `hub autopurge <days>` |
| Admins, opers (keys, masks) | `admin …`, `oper …`, `mask …`, `userkey …` |
| Channels | `chan list|add|del` |
| Opt flags (`h`) | `opt` / `opt set <flags|->` |
| Network upgrade | `upgrade status|releases|start|abort|forget` |

## Utilities

### Make an admin/oper keypair

```bash
./keygen [name]          # prompts for the name when none is given
```

Writes `YYYYMMDDHHMMSS_<name>.private.b64` (mode 0600) and `YYYYMMDDHHMMSS_<name>.public.b64` in the current directory, never overwriting an existing file, and prints the public key and its fingerprint (e.g. `763e:58a6:2dfd:ae02`) — never the private key. Names are 1–32 characters of `A-Z a-z 0-9 _ . -`, not starting with `.` or `-`. Hubs and bots make their own keys during `-setup`; keygen is for the people who command them.

## Security Notes

- The config password is never passed on the command line or stored in an environment variable. It is read from `.irchub.pass` (if present) or prompted on stdin at startup.
- `.irchub.pass` is AES-256-GCM encrypted and machine-bound — it cannot be decrypted on a different host. The file must be owned by the current user with permissions `0600`; any deviation is rejected and irchub falls back to the stdin prompt.
- All bot-to-hub communication is encrypted with AES-256-GCM using per-session keys negotiated via Curve25519 (sealed-box).
- Failed authentication attempts are tracked per IP. After 3 failures the IP is blocked for 5 minutes; the failure counter resets after 1 hour. These thresholds are compile-time constants (`MAX_FAILED_AUTH_ATTEMPTS`, `FAILED_AUTH_BLOCK_DURATION`, `FAILED_AUTH_RESET_TIME` in `hub.h`) — adjust and rebuild to change them. Specific IPs and ranges can be permanently allowed or blocked at runtime with the console's `allow` / `deny` commands (CIDR notation supported).
- Each IP is limited to 5 simultaneous connections (`MAX_CONNECTIONS_PER_IP` in `hub.h` — compile-time constant).
- Private key material is wiped from memory (`secure_wipe`) as soon as it is no longer needed.
- No private key ever crosses the network: bots, admins and opers make their own keypairs and only public keys are registered and synced. Admins reach the hub only through its SSH console (public-key auth against the admin record; the host key is the hub's own key, so `known_hosts` pins the hub).
- Mixed-version rollout is fail-closed: bots that have not advertised protocol `v|2` get records with an empty password slot, and pre-passwordless hubs are refused as peers (`docs/passwordless.md` §9).

## Files

| File | Description |
|------|-------------|
| `.irchub.cnf` | Encrypted config file (created by `-setup`) |
| `.irchub.pass` | Encrypted password file (created by `-p`, optional) |
| `.irchub.pid` | PID file (created on start, removed on clean stop) |
| `.irchub.log` | Log file (rotating, default 10 MB limit) |

All files are created relative to the working directory at the time irchub is invoked.

## Log Levels

A hub has two log sinks, each with its own level:

* **The log file** (`.irchub.log`) is **off by default** (`NONE`,
  `HUB_DEFAULT_LOG_LEVEL` in `hub.h`): a production hub writes nothing to disk
  until you turn it on with `loglevel file <level>` (or plain `loglevel <level>`).
* **The console log** — the in-memory ring the SSH consoles' log view and
  `log on` read — defaults to `DEBUG` (`HUB_DEFAULT_CONSOLE_LOG_LEVEL`), and is
  fed even when the file is off or cannot be opened.  Set it with
  `loglevel console <level>`.  The ring is not encrypted: it is `mlock`'d (no
  swap) and `MADV_DONTDUMP` (no core dump).

Both levels persist in the config (`log_level|`, `console_log_level|`, written
only when not the default) and show in the console's status bar and `status`.

| Level | Name | Output |
|-------|------|--------|
| 0 | NONE | No logging (file default) |
| 1 | ERROR | Errors only |
| 2 | WARNING | Errors and warnings (includes `[AUDIT]` lines for key-material changes) |
| 3 | INFO | Errors, warnings, and info |
| 4 | DEBUG | Everything (console default) |

## Quick Reference

```bash
# Build
make

# First-time setup
./irchub -setup

# Start hub — prompts for password interactively
./irchub

# Stop hub
kill $(cat .irchub.pid)

# (Optional) Create encrypted password file for unattended start
./irchub -p

# (Optional) Auto-start via crontab — check every 5 minutes
# */5 * * * * /full/path/to/irchub

# Make an admin's IRC + SSH keypairs (on the admin's machine; asks for an
# optional passphrase; -d <dir> picks where the files go)
./keygen robert

# Add / change / remove the passphrase later (rewrites the SSH pair too)
./keygen --passwd 20260914120000_robert.private.b64

# Admin console
ssh -i 20260914120000_robert_ed25519 -o IdentitiesOnly=yes -p 6697 robert@127.0.0.1

# View logs (if logging has been turned on)
tail -f .irchub.log
```
