//! The hub's state (hub_state_t and the records it holds), the per-client
//! connection struct with its outbound lanes, and the small inline rules from
//! hub.h (LWW acceptance, name validation, strict integer parsing).
//!
//! Where the C code used fixed arrays with a companion count, this uses a
//! `Vec` bounded by the same constant: the caps are enforced at every insert
//! exactly as the C `< MAX_*` guards did, and the sizing argument behind the
//! bulk-payload ceilings in `consts` is unchanged.  The ring buffers
//! (`recent_purges`, `seen_forwards`) keep their ring indices.
//!
//! `HubClient::fd` is the raw descriptor number, kept only as an identity
//! token: peers record `fd` to say which connection they are on, forwarded
//! requests carry an `origin_fd` to route a reply home, and broadcasts
//! exclude one.  It is never used to do I/O — that goes through the owned
//! `TcpStream` — so the number is as safe to hold as an index, and reusing
//! the C semantics keeps the routing identical.

use std::collections::VecDeque;
use std::fs::File;
use std::net::{TcpListener, TcpStream};

use zeroize::Zeroizing;

use crate::consts::*;
use crate::crypto::Key32;
use crate::cstr::{now, trunc};
use crate::secret::Locked;

// ---------------------------------------------------------------------------
// Small shared rules (the static inline block of hub.h)
// ---------------------------------------------------------------------------

/// Timestamp for changing an EXISTING replicated record: now, but always past
/// its previous stamp.  Peers and bots accept only a strictly newer
/// timestamp, so an add and a remove in the same second would tie and the
/// remove would never replicate (a removed admin staying active elsewhere).
pub fn lww_next_ts(prev: i64) -> i64 {
    let n = now();
    if n > prev { n } else { prev.saturating_add(1) }
}

/// hub_ts_ahead(): a replicated record's stamp may run at most
/// LWW_MAX_FUTURE past this node's clock.  Linked nodes agree within the 60 s
/// handshake window, so a stamp beyond it is hostile or broken: refused on
/// every store, it can neither win LWW for good nor run the stamp arithmetic
/// past i64::MAX.  Stamps read by `config::load` are this hub's own record
/// and are kept whatever the clock says (`config::LOADING`).  Hub-side only:
/// bots take records from their hub, which already refused.
pub fn ts_ahead(ts: i64) -> bool {
    !crate::config::LOADING.load(std::sync::atomic::Ordering::Relaxed)
        && ts > now() + LWW_MAX_FUTURE
}

/// LWW acceptance for a replicated add/del record: a strictly newer stamp
/// wins, and on an exact tie a delete beats an add.  `lww_next_ts` only
/// separates writes made on ONE node; two nodes stamping the same second (a
/// bot's part reaching one hub while another hub still holds the add) tie,
/// and with a plain "newer wins" each side keeps its own copy and refuses the
/// other's forever.  Delete-over-add is deterministic, so every node
/// converges.  Mirrored in ircbot (lww_accepts) — the rule must match on both.
pub fn lww_accepts(in_ts: i64, in_active: bool, cur_ts: i64, cur_active: bool) -> bool {
    if ts_ahead(in_ts) {
        return false;
    }
    in_ts > cur_ts || (in_ts == cur_ts && cur_active && !in_active)
}

/// LWW acceptance for the network opt flags (one value, no add/del).  Newer
/// stamp wins; on a tie the byte-wise greater flag string wins, so every node
/// picks the same side -- and a set ("h") beats a clear (""), the stricter
/// policy.  Mirrored in ircbot (opt_accepts).
pub fn opt_accepts(in_ts: i64, in_flags: &str, cur_ts: i64, cur_flags: &str) -> bool {
    if ts_ahead(in_ts) {
        return false;
    }
    in_ts > cur_ts || (in_ts == cur_ts && in_flags > cur_flags)
}

/// Whether a stored c/m/o global value ("...|add" / "...|del") is live: its
/// op is the last '|' field.
pub fn global_value_active(value: &str) -> bool {
    match value.rfind('|') {
        Some(i) => &value[i + 1..] != "del",
        None => true,
    }
}

/// A hub friendly name: 1-63 bytes of [A-Za-z0-9._-].  The name travels
/// inside '|'-separated config lines and handshakes, ':'/','-separated mesh
/// gossip and the ':'-separated ADD_PEER payload, so any other byte could
/// forge a field or a whole record ("x|203.0.113.77|0" after a newline).
pub fn name_valid(name: &str) -> bool {
    let b = name.as_bytes();
    // strnlen(name, 64): a longer name is refused, not truncated.
    if b.is_empty() || b.len() > 63 {
        return false;
    }
    b.iter()
        .all(|&c| c.is_ascii_alphanumeric() || c == b'.' || c == b'_' || c == b'-')
}

/// Strict unsigned decimal for admin numeric fields (indices, days, ports):
/// 1-10 ASCII digits, nothing else -- no sign, space, suffix or empty string
/// -- and value <= max.  atoi() read "7d" as 7, "c3cd..." as 0 and "" as 0;
/// in DEL_PEER a UUID starting with digits deleted the peer at that index,
/// and in PURGE_TOMBSTONES a typo meant "purge every tombstone now".
pub fn parse_uint(s: &str, max: u64) -> Option<u64> {
    let b = s.as_bytes();
    if b.is_empty() || b.len() > 10 {
        return None;
    }
    let mut v: u64 = 0;
    for &c in b {
        if !c.is_ascii_digit() {
            return None;
        }
        let d = u64::from(c - b'0');
        if v > (max - d) / 10 {
            return None; // v*10 + d would pass max
        }
        v = v * 10 + d;
    }
    Some(v)
}

// ---------------------------------------------------------------------------
// Records
// ---------------------------------------------------------------------------

/// Status every store-side modes function returns (hub_modes_status_t); the
/// console renders it.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ModesStatus {
    Ok,
    /// Not a channel name (or "*" where one is needed).
    BadChan,
    /// No live c| record: channel.not_found.
    NotManaged,
    /// Mode string fails docs/modes.md §3.2: channel.bad_mode.
    BadModes,
    /// Unknown name / bad value / bad range; `bad` names it.
    BadSetting,
    /// A field is over its cap.
    TooLong,
    /// Ban mask empty, too long, or has a bad character.
    BadMask,
    /// Ban reason too long or has a control character.
    BadReason,
    /// Expiry in the past or absurdly far.
    BadExpiry,
    /// ban.protected: overlaps a trusted bot / usermask.
    Protected,
    /// Ban del: no such live ban.
    NotFound,
    /// MAX_BANS_PER_CHAN / MAX_GLOBAL_BANS / MAX_BANS_TOTAL.
    Full,
    /// An upgrade run holds the config freeze.
    Frozen,
}

/// One C| (channel settings) or D| (network defaults) record, live
/// (hub_chanset_t; `present` is the Option).
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct Chanset {
    /// Stored spelling ("" for D|).
    pub chan: String,
    /// "" = network default.
    pub modes: String,
    /// Only overrides, "" = none.
    pub settings: String,
    pub ts: i64,
}

/// One live B| ban (hub_ban_t).
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct Ban {
    /// "#chan" or "*".
    pub chan: String,
    pub mask: String,
    /// Absolute unix time, 0 = permanent.
    pub expires: i64,
    /// "s" = sticky, "" = none.
    pub flags: String,
    /// Admin name or bot uuid.
    pub setter: String,
    pub reason: String,
    pub ts: i64,
    /// Last match a bot reported, 0 = never.
    pub last_used: i64,
}

#[derive(Clone, Debug, Default)]
pub struct ConfigEntry {
    pub key: String,
    pub value: String,
    pub timestamp: i64,
    /// B| only: last ban match, max-merged outside LWW.
    pub last_used: i64,
}

/// K| (storage.rs `learned_*`): one per managed channel.
#[derive(Clone, Debug, Default)]
pub struct ChanLearned {
    pub chan: String,
    pub key: String,
    /// K_MODES_MASK bits
    pub modes: i32,
    pub ts: i64,
}

/// An admin ('a') or oper ('o') record.
#[derive(Clone, Debug, Default)]
pub struct UserRecord {
    pub uuid: String,
    pub name: String,
    /// Per-user Curve25519 combined pubkey (Ed25519 + X25519), base64-encoded
    /// — the user's only credential: SSH console logins and bot ~A2 commands
    /// verify against it.  Empty (`has_pubkey` false) for a legacy record not
    /// yet given a key; such a user can authenticate nowhere.  The matching
    /// private key lives only on the user's machine.
    pub pubkey_b64: String,
    pub has_pubkey: bool,
    pub typ: char,
    pub is_active: bool,
    pub last_seen: i64,
    pub timestamp: i64,
}

#[derive(Clone, Debug, Default)]
pub struct MaskRecord {
    pub uuid: String,
    pub mask: String,
    pub is_active: bool,
    /// 0 = never used.
    pub last_used: i64,
    pub timestamp: i64,
}

/// Admin flags, `uf|<user_uuid>|<flags>|<ts>` (C `hub_uflag_record_t`).
#[derive(Clone, Debug, Default)]
pub struct UflagRecord {
    pub uuid: String,
    pub flags: String,
    pub timestamp: i64,
}

/// Oper channel binding, `uc|<user_uuid>|<#chan|*>|add/del|<ts>` (C
/// `hub_uchan_record_t`).
#[derive(Clone, Debug, Default)]
pub struct UchanRecord {
    pub uuid: String,
    pub chan: String,
    pub is_active: bool,
    pub timestamp: i64,
}

#[derive(Clone, Debug, Default)]
pub struct BotConfig {
    pub uuid: String,
    pub entries: Vec<ConfigEntry>,
    pub is_active: bool,
    pub last_sync_time: i64,
}

impl BotConfig {
    /// Value of one stored key, or None.
    pub fn entry(&self, key: &str) -> Option<&ConfigEntry> {
        self.entries.iter().find(|e| e.key == key)
    }
}

/// One revoked bot (hub_revoked_t):
/// `rv|<uuid>|<pub>|<pub_ts>|<nick>|<wiped_ts>|<del_ts>`.  Union-merged
/// across hubs (`revoke::merge`), never purged.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct Revoked {
    pub uuid: String,
    pub pub_key: String,
    pub pub_ts: i64,
    pub nick: String,
    /// Last time it connected and wiped itself (0 = never).
    pub wiped_ts: i64,
    pub del_ts: i64,
}

#[derive(Clone, Debug, Default)]
pub struct PendingOpRequest {
    pub request_id: String,
    pub requester_uuid: String,
    pub target_uuid: String,
    pub channel: String,
    /// FD to send the response back to (-1 if a local bot).
    pub origin_fd: i32,
    /// ...and that link's conn_serial.
    pub origin_serial: u64,
    pub timestamp: i64,
    pub active: bool,
}

/// One election (see CMD_CHAN_PROBE).  `from_fd` is the peer the question
/// came from (-1: this hub started it); `admin_fd` the console owed the
/// answer.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum ChanElectPhase {
    /// Asking our own bots.
    #[default]
    Probe,
    /// One of our bots was handed the action.
    LocalDo,
    /// Origin: flooded, collecting the other hubs' answers.
    MeshWait,
    /// Origin: one hub was handed the action.
    MeshDo,
    /// Relay: answered the origin, routing DO/DONE now.
    Acked,
    /// Origin: its mesh view is still settling (restart or relink); asks the
    /// mesh once it has, CHAN_ELECT_HOLD_MAX at most.
    Hold,
    /// Origin, batched own op: collecting the local bots' own op requests
    /// for CHAN_ELECT_BATCH_WAIT s before the probe.
    Gather,
}

/// One bot a batched own-op election serves.  st: p waiting, d handed to the
/// current bot / hub, o opped, x denied (+bitch).  reply_fd -1 on a relay.
#[derive(Clone, Debug, Default)]
pub struct ChanElectTarget {
    pub uuid: String,
    pub nick: String,
    pub hostmask: String,
    pub rid: String,
    pub reply_fd: i32,
    pub reply_serial: u64,
    pub st: u8,
}

#[derive(Clone, Debug, Default)]
pub struct ChanElectBot {
    pub uuid: String,
    pub nick: String,
    /// a asked, y ready, n no, t tried.
    pub st: u8,
    pub reason: String,
}

#[derive(Clone, Debug, Default)]
pub struct ChanElectHub {
    pub uuid: String,
    pub name: String,
    /// The peer its answer came from.
    pub fd: i32,
    /// ...and that link's conn_serial.
    pub serial: u64,
    pub asked: i64,
    pub ready: i64,
    pub tried: bool,
}

#[derive(Clone, Debug, Default)]
pub struct ChanElect {
    pub active: bool,
    pub id: String,
    pub origin: bool,
    pub from_fd: i32,
    /// from_fd's conn_serial.
    pub from_serial: u64,
    pub admin_fd: i32,
    /// admin_fd's conn_serial.
    pub admin_serial: u64,
    pub kind: String,
    pub channel: String,
    pub requester: String,
    pub nick: String,
    pub hostmask: String,
    pub phase: ChanElectPhase,
    pub phase_at: i64,
    pub created: i64,
    pub bots: Vec<ChanElectBot>,
    pub hubs: Vec<ChanElectHub>,
    /// The most hubs any answer said it knows, itself included: a hub that
    /// has just restarted or relinked may know only its neighbours yet, and
    /// must not take their answers for the whole mesh's.
    pub mesh_known: usize,
    /// Hold was used (only once).
    pub held: bool,
    /// Bot (LocalDo) or hub uuid (MeshDo) being tried.
    pub doing: String,
    /// A person's request from a bot (CMD_USER_CHAN_REQUEST): the answer
    /// goes back to that connection as CMD_USER_CHAN_RESULT; -1 = none.
    pub reply_fd: i32,
    pub reply_serial: u64,
    pub reply_rid: String,
    /// The requesting bot's OWN op / invite / key / unban (CMD_CHAN_REQUEST
    /// with a rid, 2.5.4): answered ok / none / denied, never fail.
    pub reply_own: bool,
    /// kind "ban" (ban add / channel ban): the record just stored, for the
    /// ban.added answer the console gets when the election ends.
    pub ban_expires: i64,
    pub ban_sticky: bool,
    pub ban_existed: bool,
    pub ban_reason: String,
    /// kind "who", origin only: the CHAN_WHO chunks joined (CHAN_WHO_MAX,
    /// wiped by elect::release); who_seq the next chunk expected, who_bad a
    /// chunk out of order or over the cap (the answer fails).
    pub who_buf: Vec<u8>,
    pub who_seq: i64,
    pub who_done: bool,
    pub who_bad: bool,
    /// Origin: ELECT_FWD went out (ELECT_END follows at the end).
    pub flooded: bool,
    /// A batched own op (CHAN_ELECT_BATCH_MAX); None for every other
    /// election.  tg[0] is the requester above.
    pub tg: Option<Vec<ChanElectTarget>>,
}

#[derive(Clone, Debug, Default)]
pub struct PendingChanRequest {
    pub request_id: String,
    /// Bot that is locked out.
    pub requester_uuid: String,
    /// "unban" | "invite" | "key"
    pub kind: String,
    pub channel: String,
    /// Peer fd the request came from, -1 if a local bot.
    pub origin_fd: i32,
    /// ...and that link's conn_serial.
    pub origin_serial: u64,
    pub timestamp: i64,
    pub active: bool,
}

#[derive(Clone, Debug, Default)]
pub struct IpRateLimit {
    pub ip: String,
    pub active_connections: i32,
    pub failed_auth_count: i32,
    pub last_failed_auth: i64,
    /// Temporary block expiration (0 if not blocked).
    pub blocked_until: i64,
    /// For cleanup of old entries.
    pub first_seen: i64,
    /// D1: start of the current connect-rate window.
    pub churn_window_start: i64,
    /// D1: new connections counted in the current window.
    pub churn_count: i32,
}

/// IP allow/deny list entry (admin opcodes 0x38-0x3D).  The lists are local to
/// this hub: never replicated to peers, never pushed to bots; config lines
/// `w|<pattern>|<ts>` (allow) and `x|<pattern>|<ts>` (deny).  IPv4 only (the
/// hub listens on AF_INET).  `pattern` is canonical: a bare address, or
/// network/N with the host bits cleared; net/mask are its parsed form.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct IpAcl {
    pub pattern: [u8; IP_ACL_PATTERN_MAX],
    pub pattern_len: usize,
    /// Host byte order.
    pub net: u32,
    /// Host byte order.
    pub mask: u32,
    pub added: i64,
    /// D27: applies only once the first bytes say SSH (`wc|`/`xc|` lines).
    pub console: bool,
}

impl IpAcl {
    pub fn pattern(&self) -> &str {
        std::str::from_utf8(&self.pattern[..self.pattern_len]).unwrap_or("")
    }

    pub fn set_pattern(&mut self, s: &str) -> bool {
        let b = s.as_bytes();
        if b.len() >= IP_ACL_PATTERN_MAX {
            return false;
        }
        self.pattern = [0; IP_ACL_PATTERN_MAX];
        self.pattern[..b.len()].copy_from_slice(b);
        self.pattern_len = b.len();
        true
    }

    /// Same network, prefix and scope — how add refuses a duplicate and
    /// remove finds its target.
    pub fn same_net(&self, other: &IpAcl) -> bool {
        self.net == other.net && self.mask == other.mask && self.console == other.console
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum IpAclAdd {
    Added,
    Duplicate,
    Full,
    BadList,
}

#[derive(Clone, Debug)]
pub struct PeerConfig {
    /// Configured/advertised IP.
    pub ip: String,
    pub port: i32,
    /// Remote peer's UUID.
    pub uuid: String,
    pub friendly_name: String,
    /// Actual connection IP (from the socket).
    pub remote_ip: String,
    pub connected: bool,
    pub fd: i32,
    pub remote_connected_count: i32,
    pub remote_total_peers: i32,
    pub last_mesh_report: i64,
    /// What the remote hub reported in its CMD_BOT_ROSTER header.  Volatile
    /// and never serialized: these only feed the bots tree's uptime/version
    /// columns.
    pub remote_started: i64,
    pub remote_version: String,
    /// Its code base ("c" / "rs"), from the roster's v| line; empty until a
    /// hub that sends one reports in.
    pub remote_variant: String,
    pub last_gossip: String,
    /// When the link last went down (volatile, 0 = not since this hub
    /// started): the console's "down since".
    pub link_down_at: i64,
    /// Peer auth (HUBv3): per-peer Curve25519 public keys.  `has_pubkey` is
    /// required — a peer without one is refused (there is no shared secret).
    pub ed_pub: [u8; ED25519_KEY_LEN],
    pub x25519_pub: [u8; X25519_KEY_LEN],
    pub has_pubkey: bool,
}

impl Default for PeerConfig {
    fn default() -> Self {
        PeerConfig {
            ip: String::new(),
            port: 0,
            uuid: String::new(),
            friendly_name: String::new(),
            remote_ip: String::new(),
            connected: false,
            fd: -1,
            remote_connected_count: 0,
            remote_total_peers: 0,
            last_mesh_report: 0,
            remote_started: 0,
            remote_version: String::new(),
            remote_variant: String::new(),
            last_gossip: String::new(),
            link_down_at: 0,
            ed_pub: [0; ED25519_KEY_LEN],
            x25519_pub: [0; X25519_KEY_LEN],
            has_pubkey: false,
        }
    }
}

// ---------------------------------------------------------------------------
// Network upgrade orchestration
// ---------------------------------------------------------------------------

/// Where one node stands in a run.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum UpgradeNodeState {
    /// PREPARE sent, no answer yet.
    #[default]
    Pending,
    /// Answered ready; waiting for its turn.
    Ready,
    /// Answered not-ready (`reason` says why).
    Unable,
    /// COMMIT sent; waiting for the restart.
    Committed,
    /// Back on the target version.
    Done,
    /// Said fail, or never came back in time.
    Failed,
}

impl UpgradeNodeState {
    pub fn name(self) -> &'static str {
        match self {
            Self::Pending => "pending",
            Self::Ready => "ready",
            Self::Unable => "unable",
            Self::Committed => "committing",
            Self::Done => "done",
            Self::Failed => "failed",
        }
    }
}

/// Which kind of node a row describes.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum UpgradeNodeKind {
    #[default]
    Bot,
    PeerHub,
    /// This hub, which upgrades last.
    SelfHub,
}

impl UpgradeNodeKind {
    pub fn name(self) -> &'static str {
        match self {
            Self::Bot => "bot",
            Self::PeerHub => "hub",
            Self::SelfHub => "self",
        }
    }
}

/// The plan a completed run left behind, and the one node being walked up to
/// it right now.  The plan is persisted in this hub's own `.irchub.cnf` (a
/// `rollup|` line, hub-local and never replicated — its base may be a test
/// hook's file:// URL) so a restart does not forget what the network is
/// supposed to be running; the attempt in flight and the retry ledger stay
/// volatile.  The roll-up is a convenience, never the record of what the
/// network runs (that is each node's own presence), and it only ever chases a
/// target some other bot is demonstrably running (`rollup_target_proven`).
/// A multi-step upgrade this hub drives (2.5.1): the path to the admin's
/// targets through the releases the manifests floor on, run one ordinary run
/// per step.  Persisted in this hub's own .irchub.cnf (`uplan|`) because the
/// hub restarts onto each step itself.
#[derive(Clone, Debug, Default)]
pub struct UpgradePlan {
    pub active: bool,
    /// The final targets the admin asked for ("" hub = hubs are not moved).
    pub bot_target: String,
    pub hub_target: String,
    pub variant: String,
    pub kind: String,
    /// The admin's selection, as typed.
    pub sel: String,
    /// The oldest bot / hub when it was planned.
    pub bot_from: String,
    pub hub_from: String,
    pub bot_path: Vec<String>,
    pub hub_path: Vec<String>,
    /// 0-based: the step running, or next.
    pub step: usize,
    /// The run driving `step`; "" = none yet.
    pub run_id: String,
    pub started: i64,
    /// Last step started or finished.
    pub progressed: i64,
    /// Volatile: when the next step may start (0 = not scheduled yet).
    pub next_at: i64,
    /// Why it ended (kept after it stops).
    pub summary: String,
    /// Volatile: stop waiting for the mesh then.
    pub mesh_until: i64,
    /// Who drives it, and how many times it has changed: every hub keeps a copy
    /// (`HubState::splan`), and the highest (started, rev) is the truth.
    pub driver: String,
    /// Its name when it published, for logs: known even at boot.
    pub driver_name: String,
    pub rev: i64,
    /// One plain run, published but with no steps.
    pub single: bool,
    /// A step cut off by restarts, and run again.
    pub reruns: i32,
    /// This hub's own swap is waiting to be seen.
    pub self_target: String,
    /// The step that closed: who to wait for.
    pub last_run: String,
    /// A plan on hold: the network sits at its last closed step, and says why.
    pub hold: String,
    /// Resuming runs this step again, else the next.
    pub hold_rerun: bool,
    /// It resumes itself once this node runs this version.
    pub hold_uuid: String,
    pub hold_ver: String,
    /// Comma list: `upgrade continue` left these behind.
    pub left: String,
}

impl UpgradePlan {
    pub fn steps(&self) -> usize {
        self.bot_path.len().max(self.hub_path.len())
    }
}

#[derive(Clone, Debug, Default)]
pub struct PendingRollup {
    pub have_plan: bool,
    pub target: String,
    pub variant: String,
    pub kind: String,
    pub min_from: String,
    /// The run's hub target, "" = hubs were not moved.
    pub hub_target: String,
    pub plan_set: i64,

    /// The attempt in flight, if any.
    pub active: bool,
    /// Its own run id, distinct from any real run.
    pub id: String,
    /// The node being rolled up.
    pub uuid: String,
    pub node_kind: UpgradeNodeKind,
    /// The version THIS attempt installs.
    pub step: String,
    pub started: i64,
    pub committed: bool,
    /// READY came: the node has a moment to say it stages.
    pub ready_at: i64,
    /// Told to stage, and waiting for it.
    pub staging: bool,
    pub stage_last: i64,
}

#[derive(Clone, Debug, Default)]
pub struct RollupTry {
    pub uuid: String,
    pub last_try: i64,
    pub tries: i32,
    /// The last attempt, for upgrade status.
    pub step: String,
    pub note: String,
}

/// One downstream node a FOLLOWER relays for.  A run reaches every hub in the
/// mesh, whatever shape it is wired in: each follower re-broadcasts PREPARE to
/// its own peers and forwards the answers back toward the driver, so a node
/// several hops away is still a node of the run.  COMMIT and ABORT travel the
/// same path in reverse, hop by hop, and this is the hop: "the peer I heard
/// `uuid` from is where a frame for `uuid` goes next".
#[derive(Clone, Debug, Default)]
pub struct UpgradeRoute {
    /// The node the driver is addressing.
    pub uuid: String,
    /// Hub uuid of the peer it was learned from (the next hop).
    pub via: String,
}

#[derive(Clone, Debug, Default)]
pub struct UpgradeNode {
    /// Bot uuid, or a peer hub's OWN hub uuid.
    pub uuid: String,
    /// Display label: a peer hub is known to the mesh by its friendly name,
    /// while every upgrade frame it sends is keyed by its uuid, so the table
    /// is keyed by uuid and prints this.  Empty for a bot.
    pub name: String,
    pub kind: UpgradeNodeKind,
    /// Peer hub a remote bot is reached through, else empty.
    pub via: String,
    /// The connection it was reached on, -1 once gone.
    pub fd: i32,
    /// What it ran when the run found it (status "from"; never moved to the
    /// target).
    pub cur_version: String,
    /// "c" / "rs".
    pub variant: String,
    /// The variant a selective run asked for THIS node ("name=c"), "" = the
    /// run's own.  Sent in its PREPARE and COMMIT.
    pub want_variant: String,
    /// A selective run left it out: not a failure.
    pub not_selected: bool,
    pub arch: String,
    pub libc: String,
    pub state: UpgradeNodeState,
    pub reason: String,
    pub committed_at: i64,
    /// When it ended in the run (upgrade history).
    pub done_at: i64,
    /// A hub node's READY says how many of ITS local bots it relayed PREPARE
    /// to; the driver holds PREPARE open until that many relayed READYs are
    /// in, so a peer's bots are never missed for answering a moment after it.
    pub relayed: usize,
    /// Order its READY reached the driver in (1, 2, ...; 0 = none yet).  A
    /// follower answers before it relays anything from below it, and every
    /// answer travels the same FIFO peer links up, so a hub's READY always
    /// lands ahead of any hub it routes for: descending `ready_seq` is
    /// deepest-first along the COMMIT routes (see `upgrade::tick`).
    pub ready_seq: usize,
    /// Staging: this node said it can stage, and how that is going.
    pub can_stage: bool,
    pub staged: bool,
    pub is_src: bool,
    pub left: bool,
    pub stage_phase: String,
    /// How far it has got: "~60%", "120 of 200 crates".
    pub stage_pct: String,
    pub stage_detail: String,
    pub stage_code: String,
    pub stage_sent: i64,
    pub stage_last: i64,
    pub staged_at: i64,
    /// Its limits, from its history.
    pub stage_limit: i64,
    pub build_limit: i64,
    /// f fast, s slow, p problem, u unknown; '\0' before the run has read history.
    pub cls: char,
    /// This failure has been weighed.
    pub counted: bool,
    /// A committed bot seen back on the target (its presence, or a
    /// follower's "back"), still waiting for its own "ok" — sent once it is
    /// back in its channels with ops.  0 = not seen yet.  Past
    /// UPGRADE_OPS_GRACE it is done anyway (Addendum A1).
    pub back_at: i64,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum UpgradePhase {
    #[default]
    Idle,
    /// PREPARE fanned out, collecting READY/UNABLE.
    Prepare,
    /// Committing nodes wave by wave.
    Rolling,
    Done,
    Failed,
    Aborted,
    /// Nodes getting the build ready; nothing has changed yet.
    Staging,
    /// It ran, and some nodes did not take it.
    Partial,
}

impl UpgradePhase {
    pub fn name(self) -> &'static str {
        match self {
            Self::Idle => "idle",
            Self::Prepare => "preparing",
            Self::Rolling => "rolling",
            Self::Staging => "staging",
            Self::Partial => "partial",
            Self::Done => "done",
            Self::Failed => "failed",
            Self::Aborted => "aborted",
        }
    }
}

/// `pending_upgrade_t`: the network upgrade this hub is driving, if any.
///
/// Modeled on [`PendingOpRequest`]: a run carries its own id, routes its
/// status back down `origin_fd`, and every node it touches gets a row.
/// Volatile on purpose — a hub that restarts mid-run has no business
/// resuming someone else's plan; it comes back with the freeze flag still set
/// in the replicated opt record, and an admin clears it explicitly.
#[derive(Clone, Debug, Default)]
pub struct PendingUpgrade {
    pub active: bool,
    /// `opflow::generate_request_id()`.
    pub id: String,
    /// The admin who typed it (upgrade history).
    pub by: String,
    /// Its plan's `started`; 0 = a one-step run.
    pub plan_id: i64,
    pub plan_step: i64,
    pub plan_steps: i64,
    pub rolling_at: i64,
    pub target_ver: String,
    /// "" = keep each node's own variant.
    pub variant: String,
    /// "" = let each node pick bin/src.
    pub kind: String,
    /// "*" = any.
    pub min_from: String,
    /// The hubs' own target.  ircbot and irchub are separate products with
    /// separate version lines and separate release trees, so a hub node is
    /// never checked against `target_ver` — that is the bots'.  An empty
    /// `hub_ver` leaves every hub on the build it runs.
    pub hub_ver: String,
    /// Admin connection that started it, or -1.
    pub origin_fd: i32,
    pub started: i64,
    pub phase_started: i64,
    pub phase: UpgradePhase,
    pub nodes: Vec<UpgradeNode>,
    /// When the node table last grew.
    pub last_added: i64,
    /// Last `UpgradeNode::ready_seq` handed out.
    pub ready_seq_next: usize,
    /// Why it ended, shown by CMD_ADMIN_UPGRADE_STATUS.
    pub summary: String,
    /// Selective run: only these (uuid, variant) nodes move; every other node
    /// answers into "not selected".  Empty = the whole network.
    pub select: Vec<(String, String)>,
    /// A build was stopped: the plan holds.
    pub build_stopped: bool,
    /// A peer hub failed: no more hubs move.
    pub hubs_stopped: bool,
    /// `uuid[=v],...` — the selection as a peer PREPARE carries it.
    pub sel_wire: String,
}

/// Track recently processed PURGE messages to prevent feedback loops.
#[derive(Clone, Debug, Default)]
pub struct RecentPurge {
    pub cutoff: i64,
    /// The origin's purge id ("" from pre-id hubs).
    pub id: String,
    pub received_at: i64,
}

/// Track recently seen OP_FORWARD_REQUEST ids to prevent packet storms.
#[derive(Clone, Debug, Default)]
pub struct SeenForward {
    pub request_id: String,
    pub seen_at: i64,
}

/// One peer link a hub reports in its roster gossip (an l| line): a peer it is
/// configured with and whether that link is up right now.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct MeshLink {
    pub uuid: String,
    pub name: String,
    pub online: bool,
}

/// A single node's production crontab setting.
#[derive(Clone, Debug)]
pub struct CronRec {
    pub uuid: String,
    pub kind: char,
    pub on: i32,
    pub ts: i64,
}

/// What this hub knows about another hub anywhere in the mesh, from that
/// hub's own roster gossip — direct or relayed.  Volatile like the roster:
/// dropped once nothing refreshed it within BOT_ROSTER_TTL.  `round` and
/// `chunks_seen` suppress relay loops: a hub applies and passes on a given
/// frame (origin, generation, chunk) exactly once.
#[derive(Clone, Debug, Default)]
pub struct MeshHub {
    pub uuid: String,
    pub name: String,
    pub started: i64,
    pub version: String,
    pub variant: String,
    pub cron: String,
    pub links: Vec<MeshLink>,
    /// It has sent an l| list (a hub that relays).
    pub have_links: bool,
    /// Local clock: when that list was last applied.
    pub links_at: i64,
    /// Newest gossip generation (round) seen from it.
    pub round: i64,
    /// Chunks of `gen` already applied (bit n).
    pub chunks_seen: u64,
    /// Local clock: drives the TTL.
    pub reported_at: i64,
}

/// What a roll call is for (see CMD_HUB_ROLLCALL).
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum RollcallPurpose {
    #[default]
    None,
    Start,
    Step,
}

/// One roll call.  As the asking hub: the hubs it waits on and which have
/// answered.  As a relay: the link to route answers back on.
#[derive(Clone, Debug, Default)]
pub struct HubRollcall {
    pub active: bool,
    pub origin: bool,
    pub id: String,
    pub started: i64,
    /// Relay: the peer it came from, and that link's conn_serial.
    pub from_fd: i32,
    pub from_serial: u64,
    pub purpose: RollcallPurpose,
    /// Origin: (uuid, name, answered) of every hub asked.
    pub want: Vec<(String, String, bool)>,
}

/// The upgrade start waiting on its roll call (one at a time); the console is
/// answered when the roll call ends.
#[derive(Clone, Debug, Default)]
pub struct UpgStartWait {
    pub active: bool,
    pub rc: String,
    pub admin_fd: i32,
    pub admin_serial: u64,
    pub payload: String,
}

/// A plan step's roll call: rc while it runs, then the outcome until the step
/// gate reads it.
#[derive(Clone, Debug, Default)]
pub struct StepRollcall {
    pub rc: String,
    /// 0 none or running, 1 every hub answered, 2 some did not.
    pub outcome: i32,
    pub gone: Vec<String>,
    /// When the outcome came: a stale one is not read.
    pub at: i64,
}

/// One bot's live presence, as reported by the hub it is connected to.
/// Purely in-memory: never written to the config, never tombstoned, never
/// purged.  An entry whose `reported_at` falls behind BOT_ROSTER_TTL is
/// dropped, so a bot that disconnects — or a whole hub that dies — ages out
/// on its own.
#[derive(Clone, Debug, Default)]
pub struct BotRoster {
    /// Hub that reported this bot.
    pub hub_uuid: String,
    /// Its friendly name, for display.
    pub hub_name: String,
    pub bot_uuid: String,
    pub nick: String,
    pub version: String,
    /// Code base: "c" / "rs" / "".
    pub variant: String,
    pub cron: String,
    /// The bot's IRC link.
    pub server: String,
    /// The bot's own start, for uptime.
    pub connected_at: i64,
    /// Bot -> its hub link, 0 = unknown.
    pub link_since: i64,
    /// Phase 4: bot's link-order counter, 0 = unknown.
    pub link_ord: u64,
    /// The bot's address as its hub sees it, "" = unknown.
    pub ip: String,
    /// Local clock: drives the TTL.
    pub reported_at: i64,
    /// The gossip round it came in (0 = none); C `gen`.
    pub round: i64,
    /// Arrival order vs presence v2 records (`P2State::stamp_ctr`).
    pub p2_stamp: u64,
    /// pool: the entry its IRC link uses (i|)
    pub irc_entry: String,
    /// pool: connecting / up / down / idle
    pub irc_link: String,
    /// i| field 4: the server's NETWORK= ("" = unknown)
    pub irc_network: String,
    /// j|: the bot's channels (bot show), "" = none
    pub chan_state: String,
}

// ---------------------------------------------------------------------------
// Mesh transport: per-peer outbound queue
// ---------------------------------------------------------------------------

/// Lane indices (lower = higher priority).  `Urgent` must be 0 so the drain
/// loop can rely on numeric ordering.
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum Lane {
    /// CMD_OP_REQUEST/GRANT/FAILED, CMD_OP_FORWARD_*
    Urgent = 0,
    /// Small per-key deltas (b|uuid|h|...), global add/del
    Delta = 1,
    /// CMD_PEER_SYNC, CMD_MESH_STATE, CMD_CONFIG_DATA
    Bulk = 2,
}

impl Lane {
    pub fn index(self) -> usize {
        self as usize
    }

    pub fn name(self) -> &'static str {
        match self {
            Lane::Urgent => "URGENT",
            Lane::Delta => "DELTA",
            Lane::Bulk => "BULK",
        }
    }
}

/// Queued outbound message — pre-encryption.  The payload is zeroized on
/// drop: it can carry hostmask and op-flow material.
pub struct QueuedMsg {
    /// Protocol opcode (CMD_*).
    pub cmd: u8,
    pub lane: Lane,
    /// Coalesce key: typically "<origin_hub_uuid>|<key>|<bot_uuid>".  Empty
    /// means "never coalesce".
    pub coalesce_key: String,
    /// Monotonic per origin_hub_uuid.
    pub lamport_seq: u64,
    pub origin_hub_uuid: String,
    pub payload: Zeroizing<Vec<u8>>,
    /// A config push to a bot (CMD_CONFIG_DATA / CMD_CONFIG_DELTA from
    /// send_config_to_bot): written, it moves the bot's cfg_base; a PURGE
    /// line, also CMD_CONFIG_DATA, does not.
    pub cfg_frame: bool,
}

impl QueuedMsg {
    /// queued_msg_new(): None when the payload exceeds the bulk ceiling.
    pub fn new(cmd: u8, lane: Lane, payload: &[u8]) -> Option<QueuedMsg> {
        if payload.len() > MAX_BULK_PAYLOAD {
            return None;
        }
        Some(QueuedMsg {
            cmd,
            lane,
            coalesce_key: String::new(),
            lamport_seq: 0,
            origin_hub_uuid: String::new(),
            payload: Zeroizing::new(payload.to_vec()),
            cfg_frame: false,
        })
    }

    /// queued_msg_set_coalesce().
    pub fn set_coalesce(&mut self, origin_hub_uuid: &str, lamport_seq: u64, coalesce_key: &str) {
        self.origin_hub_uuid = origin_hub_uuid.to_string();
        self.lamport_seq = lamport_seq;
        self.coalesce_key = coalesce_key.to_string();
    }

    pub fn len(&self) -> usize {
        self.payload.len()
    }

    pub fn is_empty(&self) -> bool {
        self.payload.is_empty()
    }
}

#[derive(Default)]
pub struct QueueLane {
    pub msgs: VecDeque<QueuedMsg>,
    /// Sum of payload lengths in this lane.
    pub bytes: usize,
}

// ---------------------------------------------------------------------------
// Clients
// ---------------------------------------------------------------------------

#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum ClientType {
    /// calloc() left client_type_t at 0 — a fresh connection is a bot until
    /// its handshake says otherwise, and the pre-auth reaper relies on it.
    #[default]
    Bot,
    Admin,
    Hub,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum BotAuthState {
    #[default]
    Idle,
    UuidReceived,
    ChallengeSent,
    SignatureReceived,
    Complete,
    /// Revoked bot proved its key, told to retire.
    Quarantine,
}

/// Connection serials start at 1 and only grow: at one connection per
/// nanosecond a 64-bit counter would take ~584 years to wrap
/// (hub_main.c hub_next_conn_serial).
pub fn next_conn_serial() -> u64 {
    static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
    NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed) + 1
}

pub struct HubClient {
    /// The connection.  `None` once the socket is closed.
    pub sock: Option<TcpStream>,
    /// Identity token only — see the module comment.  -1 once closed.
    pub fd: i32,
    pub ip: String,
    pub id: String,
    pub session_key: Key32,
    pub authenticated: bool,
    pub typ: ClientType,
    pub last_seen: i64,
    pub last_pong_sent: i64,
    /// Second the relay count is for.
    pub relay_window: i64,
    /// CMD_BOT_RELAY in that second.
    pub relay_count: i32,
    /// Output queued, no byte taken since.
    pub write_wait_since: i64,
    /// Last queue-drop warning for this client.
    pub drop_logged: i64,
    /// Drops since, not yet in a warning.
    pub drop_unlogged: i32,
    /// A newer session of this bot replaced it.
    pub superseded: bool,
    /// Peer: it sent a CMD_PRESENCE2 record.
    pub p2_seen: bool,
    /// Peer: a frame from it opened (a dialled link is not up until the far
    /// end speaks).
    pub peer_heard: bool,
    /// This link's one relayed UPGRADE_RESULT has gone.
    pub result_relayed: bool,
    /// Start of the hour replace_count is for.
    pub replace_window: i64,
    /// Live sessions of this bot replaced.
    pub replace_count: i32,
    /// Review 6 (CMD_LINK_SEQ): its offer seen, our go queued, the direction
    /// bytes of our / its frames, sequencing on for our / its frames, and the
    /// counters of the frames sealed / opened since.
    pub link_offered: bool,
    pub link_go_queued: bool,
    pub link_dir_tx: u8,
    pub link_dir_rx: u8,
    pub link_tx_seq: bool,
    pub link_rx_seq: bool,
    pub link_tx_ctr: u64,
    pub link_rx_ctr: u64,
    /// D4: when the socket was accepted/created.
    pub connected_at: i64,
    /// Accepted on the listener (subject to the IP lists).
    pub inbound: bool,
    /// bot del of this connected bot: CMD_BOT_RETIRE sent at `retire_sent`;
    /// every other frame from it is dropped, and it is closed on
    /// CMD_BOT_RETIRE_ACK or after RETIRE_GRACE_SEC.
    pub retiring: bool,
    pub retire_sent: i64,
    /// Its uuid is on the revoke list: the handshake checks the revoke list's
    /// key and ends in `BotAuthState::Quarantine` (CMD_BOT_RETIRE as the ACK).
    pub quarantine: bool,
    /// An SSH console's socketpair end (docs/console.md): an admin
    /// connection the console thread already authenticated.  Plaintext
    /// frames, no pings, no CLIENT_TIMEOUT (the console has its own idle
    /// timeout).  `sock` is None; the stream lives in `console`.
    pub internal: bool,
    /// Never reused while the process lives (`next_conn_serial`): what a
    /// late answer is bound to, so a console that took over a closed one's
    /// fd never gets a reply it did not ask for.
    pub conn_serial: u64,
    pub console: Option<Box<crate::console::ConsoleLink>>,
    /// First-bytes sniff of an accepted connection: until 4 bytes are there
    /// (or CONSOLE_SNIFF_MS passed) it is not read, so an "SSH-" stream can
    /// be handed to the console thread untouched.
    pub sniff_pending: bool,
    pub sniff_deadline_ms: i64,
    /// Review 16: an outbound peer link whose non-blocking connect is still
    /// in flight (since dial_started), to the peer with uuid dial_uuid.  Only
    /// its writability matters; main.rs finish_dials completes it.
    pub dialing: bool,
    pub dial_started: i64,
    pub dial_uuid: String,
    /// Set by a handler that found this bot or peer below MESH_MIN_VERSION
    /// (or a push below BOT_PROTO_USER_FLAGS): the dispatch then drops the
    /// link.
    pub refused: bool,
    /// A peer whose version is not known yet: no config sync goes to it and
    /// none from it is taken in (`mesh::peer_enqueue_sync` / the dispatch)
    /// until its first roster names a version at MESH_MIN_VERSION or newer;
    /// then `mesh::peer_sync_release` sends a full sync and asks for one.
    pub sync_held: bool,
    /// CMD_CHAN_EVENT rate limit for this connection
    /// (CHAN_EVENT_MAX_PER_WINDOW per CHAN_EVENT_WINDOW seconds); dropped
    /// events are counted.
    pub chan_ev_window: i64,
    pub chan_ev_count: i32,
    pub chan_ev_dropped: i32,
    /// CMD_USER_CHAN_REQUEST rate limit for this connection.
    pub uchan_req_window: i64,
    pub uchan_req_count: i32,
    /// D2: PREAUTH_BUF_SIZE, then the per-type bulk size on auth.  `len()` is
    /// the C `recv_len`.
    pub recv_buf: Vec<u8>,
    /// Unread data is `recv_buf[recv_off..]`: frames are consumed by moving
    /// this, and the buffer is compacted only once it is full.
    pub recv_off: usize,
    pub recv_cap: usize,
    pub bot_auth_state: BotAuthState,
    pub challenge: [u8; 32],
    pub bot_eph_x25519_priv: Key32,
    pub bot_eph_x25519_pub: [u8; 32],
    pub bot_eph_priv_set: bool,

    // ---- Outbound queue (per-lane FIFOs, drained on POLLOUT) ----
    pub out_lanes: [QueueLane; LANE_COUNT],
    pub out_total_bytes: usize,

    /// In-flight cipher buffer for partial writes.  While `writing_offset <
    /// writing_buf.len()` the FD must be watched for writability, before any
    /// new message is encrypted.
    pub writing_buf: Zeroizing<Vec<u8>>,
    pub writing_cap: usize,
    pub writing_offset: usize,

    /// Per-peer/client byte-rate accounting (1-second window).
    pub bw_window_start: i64,
    pub bw_bytes_in_window: i64,

    /// Presence this bot reported via CMD_BOT_PRESENCE.  Per connection, and
    /// volatile on purpose: a bot that reconnects re-reports, and a bot that
    /// never reports simply shows blank fields in the tree.  Never persisted.
    pub bot_version: String,
    pub bot_server: String,
    /// Server pool (CMD_BOT_IRC_LINK, volatile): the pool entry the bot's IRC
    /// link uses and its state ("connecting"/"up"/"down"/"idle", "" =
    /// unknown).
    pub bot_irc_entry: String,
    pub bot_irc_link: String,
    /// 005 NETWORK= (IRC_LINK 4th field), "" = unknown.
    pub bot_irc_network: String,
    /// CMD_BOT_CHAN_STATE, "" = none.
    pub bot_chan_state: String,
    /// "c" / "rs", empty = unreported.
    pub bot_variant: String,
    pub bot_cron: String,
    /// Last CMD_CRON_SET + 1, 0 = none.
    pub cron_sent: i32,
    /// Joined a run in flight already.
    pub late_prepared: bool,
    /// A peer that speaks CMD_UPGRADE_PLAN.
    pub plan_capable: bool,
    /// The bot's own start time, 0 = unreported.
    pub bot_started: i64,
    /// Phase 4: bot's link-order counter, 0 = unreported.
    pub bot_link_ord: u64,
    /// SHA-256 of the last full config queued to this bot (CMD_CONFIG_DATA),
    /// so a broadcast push that would repeat it is skipped.  Only set while
    /// that push is known to be on its way: cleared when a queued config is
    /// dropped on overflow and whenever the bot sends a config push of its
    /// own.
    pub cfg_sent_hash: Option<[u8; 32]>,
    /// Config deltas (2.5.4, plan §4.3a).  `cfg_base` is S, the exact text
    /// this bot holds once every config frame already written to its socket
    /// is applied (None = unknown: the next push is full), with its SHA-256
    /// in `cfg_base_hash`, what the keepalive's c| vouches for.  `cfg_next`
    /// is the text the one queued config frame (`cfg_queued`) leaves the bot
    /// holding: at most one is queued (per-bot coalesce key), it always has
    /// base S, and a newer push replaces it with delta(S -> newer), never a
    /// delta on top of it.  When the frame is written, S := cfg_next.  A
    /// frame lost on overflow leaves S as it was and sets `cfg_owed`, which
    /// the next flush honours.  Zeroized on replace and drop.
    pub cfg_base: Option<Zeroizing<Vec<u8>>>,
    pub cfg_base_hash: [u8; 32],
    pub cfg_next: Option<Zeroizing<Vec<u8>>>,
    pub cfg_queued: bool,
    pub cfg_owed: bool,
    /// CFG_FIRST_HOLD: when the first config was held (0 = not held), and
    /// whether the hold is over (a config may go out).
    pub cfg_hold_at: i64,
    pub cfg_hold_done: bool,
    /// Hash-first anti-entropy (CMD_SYNC_DIGEST) on a peer link: rounds sent
    /// (every SYNC_DIGEST_FULL_EVERY-th is full), the kinds that differed in
    /// consecutive rounds with their counts, and the last stuck warning.
    pub sd_rounds: u32,
    pub sd_stuck: Vec<(Vec<u8>, u32)>,
    pub sd_warned: i64,
    /// This connection has pushed its config once: the first push is
    /// answered with a full config even when it changed nothing (a
    /// reconnecting bot may hold a stale copy, e.g. its own old key after a
    /// rekey).
    pub pushed: bool,
    /// Phase 5: whether this bot holds a known tree version, and which
    /// (`tree_seq`).  A current bot gets the row delta from the last tree to
    /// the new one; others get the whole tree.  Cleared when a queued tree or
    /// delta is dropped on overflow, so the bot is resent the whole tree.
    pub tree_sent_valid: bool,
    pub tree_sent_seq: u64,
    /// Last CMD_BOT_TREE_PULL served.
    pub tree_pull_at: i64,
    /// One came inside TREE_PULL_MIN_GAP: held.
    pub tree_pull_due: bool,
}

impl HubClient {
    /// calloc(1, sizeof(hub_client_t)) + hub_client_alloc_buffers(size).
    pub fn new(sock: TcpStream, fd: i32, ip: &str, size: usize) -> HubClient {
        HubClient::new_inner(Some(sock), fd, ip, size)
    }

    /// A client with no TCP socket: an SSH console's internal connection
    /// (its stream lives in `console`).
    pub fn new_detached(fd: i32, ip: &str, size: usize) -> HubClient {
        HubClient::new_inner(None, fd, ip, size)
    }

    fn new_inner(sock: Option<TcpStream>, fd: i32, ip: &str, size: usize) -> HubClient {
        let t = now();
        HubClient {
            sock,
            fd,
            ip: ip.to_string(),
            id: String::new(),
            session_key: Zeroizing::new([0u8; 32]),
            authenticated: false,
            typ: ClientType::Bot,
            last_seen: t,
            last_pong_sent: 0,
            relay_window: 0,
            relay_count: 0,
            write_wait_since: 0,
            drop_logged: 0,
            drop_unlogged: 0,
            superseded: false,
            p2_seen: false,
            peer_heard: false,
            result_relayed: false,
            replace_window: 0,
            replace_count: 0,
            link_offered: false,
            link_go_queued: false,
            link_dir_tx: 0,
            link_dir_rx: 0,
            link_tx_seq: false,
            link_rx_seq: false,
            link_tx_ctr: 0,
            link_rx_ctr: 0,
            connected_at: t,
            inbound: false,
            retiring: false,
            retire_sent: 0,
            quarantine: false,
            internal: false,
            conn_serial: next_conn_serial(),
            console: None,
            sniff_pending: false,
            dialing: false,
            dial_started: 0,
            dial_uuid: String::new(),
            sniff_deadline_ms: 0,
            refused: false,
            sync_held: false,
            chan_ev_window: 0,
            chan_ev_count: 0,
            chan_ev_dropped: 0,
            uchan_req_window: 0,
            uchan_req_count: 0,
            recv_buf: Vec::with_capacity(size.min(PREAUTH_BUF_SIZE)),
            recv_off: 0,
            recv_cap: size,
            bot_auth_state: BotAuthState::Idle,
            challenge: [0; 32],
            bot_eph_x25519_priv: Zeroizing::new([0u8; 32]),
            bot_eph_x25519_pub: [0; 32],
            bot_eph_priv_set: false,
            out_lanes: Default::default(),
            out_total_bytes: 0,
            writing_buf: Zeroizing::new(Vec::new()),
            writing_cap: size + 64,
            writing_offset: 0,
            bw_window_start: 0,
            bw_bytes_in_window: 0,
            bot_version: String::new(),
            bot_server: String::new(),
            bot_irc_entry: String::new(),
            bot_irc_link: String::new(),
            bot_irc_network: String::new(),
            bot_chan_state: String::new(),
            bot_variant: String::new(),
            bot_cron: String::new(),
            cron_sent: 0,
            late_prepared: false,
            plan_capable: false,
            bot_started: 0,
            bot_link_ord: 0,
            cfg_sent_hash: None,
            cfg_base: None,
            cfg_base_hash: [0; 32],
            cfg_next: None,
            cfg_queued: false,
            cfg_owed: false,
            cfg_hold_at: 0,
            cfg_hold_done: false,
            sd_rounds: 0,
            sd_stuck: Vec::new(),
            sd_warned: 0,
            pushed: false,
            tree_sent_valid: false,
            tree_sent_seq: 0,
            tree_pull_at: 0,
            tree_pull_due: false,
        }
    }

    /// D2: grow a client's buffers on successful authentication.  Idempotent.
    ///
    /// Change 5: size by client type so bulk lanes never truncate.  Peers
    /// exchange full-state anti-entropy sync both directions
    /// (MAX_SYNC_PAYLOAD); a bot receives its full config on the hub->bot
    /// (writing) side (MAX_CONFIG_PAYLOAD) but only ever pushes small
    /// config/deltas up (recv stays MAX_BUFFER).  Must be called after
    /// `typ` is set.
    pub fn promote_buffers(&mut self) {
        let (recv_target, write_target) = match self.typ {
            ClientType::Hub => (MAX_SYNC_PAYLOAD, MAX_SYNC_PAYLOAD),
            // bot->hub pushes are small; hub->bot carries the full config.
            ClientType::Bot => (MAX_BUFFER, MAX_CONFIG_PAYLOAD),
            ClientType::Admin => (MAX_BUFFER, MAX_BUFFER),
        };
        if self.recv_cap < recv_target {
            self.recv_cap = recv_target;
        }
        if self.writing_cap < write_target + 64 {
            self.writing_cap = write_target + 64;
        }
    }

    /// peer_has_pending_writes(): a partial in-flight write, or any non-empty
    /// lane.  The main loop uses it to decide whether to watch for POLLOUT.
    pub fn has_pending_writes(&self) -> bool {
        if let Some(l) = &self.console {
            return l.has_pending();
        }
        self.writing_offset < self.writing_buf.len()
            || self.out_lanes.iter().any(|l| !l.msgs.is_empty())
    }

    /// hub_client_has_buffered_frame(): recv_buf already holds a whole frame
    /// (or a length prefix the pump will refuse).  `handle_client_data` takes
    /// at most 8 frames per call for fairness; the main loop must come back
    /// for the rest without waiting for new bytes, or they sit unread until
    /// the sender's next packet.
    pub fn has_buffered_frame(&self) -> bool {
        let unread = &self.recv_buf[self.recv_off..];
        if self.fd <= 0 || unread.len() < 4 {
            return false;
        }
        let packet_len = u32::from_be_bytes([unread[0], unread[1], unread[2], unread[3]]) as i64;
        // An out-of-range prefix counts: the pump refuses it and drops the
        // client rather than leaving it parked on a length that can never
        // complete.
        if packet_len < 0 || packet_len > (self.recv_cap as i64 - 4) {
            return true;
        }
        unread.len() as i64 >= 4 + packet_len
    }

    /// Move the unread bytes to the front, only once the buffer has no room
    /// left to read into (a drain per frame made a backlog quadratic).
    pub fn compact_recv(&mut self) {
        if self.recv_off > 0 && self.recv_buf.len() >= self.recv_cap {
            self.recv_buf.drain(..self.recv_off);
            self.recv_off = 0;
        }
    }

    /// peer_queue_destroy(): free all queued messages and wipe any
    /// partially-written ciphertext.
    pub fn queue_destroy(&mut self) {
        for l in &mut self.out_lanes {
            l.msgs.clear();
            l.bytes = 0;
        }
        self.out_total_bytes = 0;
        self.writing_buf.clear();
        self.writing_offset = 0;
    }
}

// ---------------------------------------------------------------------------
// Hub state
// ---------------------------------------------------------------------------

/// The function-local `static time_t` timers of hub_maintenance() and
/// hub_check_peers(), made explicit.
#[derive(Debug, Default)]
pub struct MaintTimers {
    pub last_anti_entropy: i64,
    pub last_mesh_gossip: i64,
    pub last_client_scan: i64,
    pub last_ip_cleanup: i64,
    pub last_purge: i64,
    pub last_peer_check: i64,
}

pub struct HubState {
    pub listener: Option<TcpListener>,
    pub port: i32,
    /// IP this hub advertises itself as in the mesh.
    pub bind_ip: String,
    /// What the listener actually bound at startup: bind_ip / port changed
    /// since take effect on the next start (the console's "pending").
    pub listen_ip: String,
    pub listen_port: i32,
    /// This hub's public IPv4 address as the DNS "what is my address"
    /// servers see it (`pubip`): looked up at -setup, every start and daily,
    /// kept as public|<ip>|<ts>.  Display and advice only; never set by hand.
    pub public_ip: String,
    pub public_ip_at: i64,
    pub hub_uuid: String,
    /// `realpath(argv[0])` — the binary an upgrade replaces, and the one
    /// `<exe>.prev` sits beside.  Empty when it could not be resolved, which
    /// disables self-upgrade rather than guessing.
    pub executable_path: String,
    pub hub_friendly_name: String,
    /// The plaintext AES-GCM config-file password, held for the lifetime of
    /// the process (needed on every config write) in an mlock'd buffer.  See
    /// the threat model in `secret`.
    pub config_pass: Locked<MAX_PASS>,
    /// Review 23: the config key (`salt || key`), derived once (the load,
    /// else the first write) and reused with the salt it was derived with;
    /// every write takes a fresh IV.  A 600k-round PBKDF2 per write stalled
    /// the event loop ~0.5 s.  Reset by `set_config_pass` (a new password
    /// derives anew); mlock'd, wiped with `config_key_forget` and on drop.
    pub cfg_key: Locked<{ SALT_SIZE + 32 }>,
    pub cfg_key_set: bool,
    /// Review 7: the hello replay cache (ephemeral key, accepted at), a ring
    /// of HELLO_SEEN_MAX.
    pub hello_seen: Vec<([u8; 32], i64)>,
    pub hello_seen_next: usize,

    pub hub_ed25519_priv: Locked<32>,
    pub hub_x25519_priv: Locked<32>,
    pub hub_ed25519_pub: [u8; 32],
    pub hub_x25519_pub: [u8; 32],
    pub hub_keys_loaded: bool,

    pub clients: Vec<HubClient>,
    pub bots: Vec<BotConfig>,

    /// GLOBAL CONFIG STORE (shared by all bots).
    pub global_entries: Vec<ConfigEntry>,
    /// Derived from `global_entries` (storage.rs): lookup index, per-class
    /// and per-channel ban counts.  `storage::global_reindex` rebuilds it.
    pub global_idx: crate::storage::GlobalIdx,
    /// K|: what the bots saw on IRC, one per live channel (never a tombstone).
    pub chan_learned: Vec<ChanLearned>,

    /// Named admin/oper records and their usermasks.
    pub user_records: Vec<UserRecord>,
    pub mask_records: Vec<MaskRecord>,
    /// Admin flags and oper channel bindings (access.rs).
    pub uflag_records: Vec<UflagRecord>,
    pub uchan_records: Vec<UchanRecord>,
    /// `uf|` changes that took 'a' away, as (uuid, the new `uf|` stamp): the
    /// `uf|` no longer says it held 'a', and the admin floor must know
    /// (`access::admin_floor_restore`).  Memory only, a ring of
    /// `ADMIN_DROP_LOG`.
    pub adrop: Vec<(String, i64)>,
    pub adrop_next: usize,
    /// "no full admin, nothing to restore" logged once.
    pub floor_warned: bool,

    pub peers: Vec<PeerConfig>,

    /// Permanent: never purged (`revoke`).
    pub revoked: Vec<Revoked>,

    pub pending_op_requests: Vec<PendingOpRequest>,
    pub pending_chan_requests: Vec<PendingChanRequest>,
    pub chan_elections: Vec<ChanElect>,
    /// "Election table full": when the last warning went out, and the
    /// refusals counted since (elect::full_note / full_flush).
    pub ce_full_at: i64,
    pub ce_full_n: u32,
    pub rollcalls: Vec<HubRollcall>,
    pub upg_start_wait: UpgStartWait,
    pub step_rollcall: StepRollcall,

    /// The network upgrade this hub is driving, if any (one at a time).
    pub upgrade: PendingUpgrade,
    /// The last upgrade runs, newest first (`uhist`).
    pub uhist: Vec<crate::uhist::UhistRec>,
    /// hs|upgradehistory; 0 = UHIST_DEFAULT_KEEP.
    pub uhist_keep_setting: i32,
    pub uhist_keep_ts: i64,
    /// Production crontab lines: off until an admin says otherwise.  The last
    /// command wins by timestamp, a single node's or the global one.
    pub bot_cron_setting: i32,
    pub hub_cron_setting: i32,
    pub bot_cron_ts: i64,
    pub hub_cron_ts: i64,
    /// hs|sgrant: 1 once every +b admin was given +s (server pool plan D11).
    pub sgrant_setting: i32,
    pub sgrant_ts: i64,
    /// Server pool (pool.rs, volatile): the wrong-network strike lists per
    /// entry, the bots' server orders, and the `server rebalance force`
    /// waves this hub drives.
    pub pool_strikes: Vec<crate::pool::PoolStrikes>,
    /// C `g_linked`: (entry uuid, NETWORK=) a "linked" report last warned about.
    pub pool_linked: Vec<(String, String)>,
    pub pool_order: crate::pool::OrderState,
    pub rebalance: crate::pool::Rebalance,
    pub cron_recs: Vec<CronRec>,
    /// The plan as every hub knows it: this hub's own copy of what its driver
    /// last published, and when it last heard the driver.
    pub splan: UpgradePlan,
    pub splan_seen: i64,
    pub plan_beat: i64,

    /// The upgrade this hub has agreed to take from ANOTHER hub, if any.  The
    /// mesh is flat, so a hub is a follower and a driver at the same time and
    /// the two must not share state: `upgrade` above is the run this hub
    /// drives, these are a run someone else drives.  CMD_UPGRADE_COMMIT
    /// carries only the id and the version, so the release base the driver
    /// named at PREPARE time is remembered here.  Volatile — the upgrade
    /// itself hands over through HUB_UPGRADE_MARKER_FILE.
    pub follow_id: String,
    /// uuid of the hub driving the followed run.
    pub follow_origin: String,
    /// The bots' target (relayed COMMITs).
    pub follow_target: String,
    /// This hub's own target, "" = stay put.
    pub follow_hub_target: String,
    pub follow_variant: String,
    /// The run's bot variant from the PREPARE ("" = each bot keeps its own).
    pub follow_bot_variant: String,
    /// A selective run's resolved selection from the PREPARE, uuid[=v],...
    pub follow_sel: String,
    /// Whether this hub itself can take the followed run.
    pub follow_self_ready: bool,
    pub follow_prepared: i64,
    /// The run whose restart made this process.
    pub upgrade_installed_id: String,
    /// That run's RESULT (status, detail), sent on every peer link that comes
    /// up until `upgrade_report_until` (UPGRADE_RESULT_RESEND s after the
    /// restart: the first link alone may be gone or still settling); the
    /// driver drops the copies.
    pub upgrade_report_status: String,
    pub upgrade_report_detail: String,
    pub upgrade_report_until: i64,
    /// Nodes below this hub in the followed run's fan-out tree (its own
    /// peers' subtrees).  Rebuilt for every run; see [`UpgradeRoute`].
    pub follow_routes: Vec<UpgradeRoute>,
    /// Offline roll-up; see [`PendingRollup`].
    pub rollup: PendingRollup,
    pub rollup_tries: Vec<RollupTry>,
    /// A multi-step upgrade this hub drives.
    pub plan: UpgradePlan,
    /// The last `upgrade abort` this hub issued or relayed (see
    /// UPGRADE_CANCEL_HOLD): its id, when the admin typed it (mesh clock),
    /// and when this hub heard it (local clock).
    pub upgrade_cancel_id: String,
    pub upgrade_cancel_issued: i64,
    pub upgrade_cancel_seen: i64,

    pub ip_limits: Vec<IpRateLimit>,

    /// IP allow/deny lists (local only).  `ip_acl_changed` makes
    /// `maintenance` close inbound connections the lists no longer permit.
    pub ip_allow: Vec<IpAcl>,
    pub ip_deny: Vec<IpAcl>,
    pub ip_acl_changed: bool,

    /// `hub set ssh` / `hub set conn`; the console thread gets a copy
    /// (`console::limits_changed`).
    pub conn_cfg: crate::connlimits::ConnCfg,
    /// D26: SSH-only failure and connect table (memory only).
    pub ssh_ips: Vec<crate::connlimits::SshIp>,
    /// 13b: addresses a bot or peer authenticated from, with when
    /// (`ratelimit::known_ip_note`).
    pub known_ips: Vec<(String, i64)>,
    /// Last refusal warning, and refusals since not yet logged.
    pub startup_logged: i64,
    pub startup_unlogged: i32,

    /// Days threshold for the tombstone purge (0 = disabled).
    pub purge_days_setting: i32,
    /// hs|autopurge stamp (LWW across hubs).
    pub purge_days_ts: i64,
    /// D3: if true, 127.0.0.1/::1 bypass rate limiting (default false —
    /// secure by default).
    pub trust_loopback: bool,
    /// Held for its flock, which is what says "this hub is running".
    pub pid_file: Option<File>,
    pub running: bool,

    /// PURGE deduplication: prevent feedback loops in the peer mesh.
    pub recent_purges: Vec<RecentPurge>,
    /// Timestamp of the last scheduled purge this hub initiated.
    pub last_scheduled_purge: i64,
    /// Purge floor: until `purge_floor_until`, a tombstone stamped before
    /// `purge_floor` is not re-created (a sync built before the purge,
    /// landing after it, would bring it back).  Memory only.
    pub purge_floor: i64,
    pub purge_floor_until: i64,

    /// OP_FORWARD_REQUEST deduplication: an LRU ring of MAX_SEEN_FORWARD_IDS
    /// slots prevents infinite re-broadcast storms.
    pub seen_forwards: Vec<SeenForward>,
    /// Next slot to write (ring index).
    pub seen_forward_head: usize,

    /// Log FILE level.
    pub log_level: i32,
    /// Console log ring level (console_log_level|).
    pub console_log_level: i32,
    pub log_max_size: i64,

    /// Network options pushed to bots/peers via the 'opt|' record.  Each
    /// letter is an enabled flag (see OPT_* in `consts`).
    pub opt_flags: String,
    pub opt_flags_ts: i64,

    /// Debounced config write: set the dirty flag instead of writing
    /// immediately.  `maintenance` flushes at most once every
    /// CONFIG_WRITE_DEBOUNCE_S seconds.  This prevents N PBKDF2 calls
    /// when N peer syncs arrive in a burst.
    pub config_dirty: bool,
    /// A full config push to every local bot is owed
    /// (`client::flush_bot_config`, at most once per BOT_CONFIG_PUSH_COALESCE).
    pub bot_config_pending: bool,
    /// When `modes::bans_sweep` last ran (the C file-scope `static time_t
    /// last`), so the 60 s self-throttle lives in the state.
    pub bans_swept_at: i64,
    pub last_bot_config_push: i64,
    /// Bots whose first config is held for their presence (CFG_FIRST_HOLD).
    pub cfg_holds: usize,
    pub last_config_write: i64,
    /// Set on peer connect/disconnect; clears after gossip.
    pub mesh_state_dirty: bool,

    /// Mesh transport: monotonic Lamport sequence stamped onto outgoing
    /// deltas.  On load from disk this is bumped past any plausibly recent
    /// value to keep monotonicity even if the system clock or the stored
    /// value lags.
    pub next_lamport_seq: u64,

    // ---- Bot presence (volatile; never serialized) ----
    pub roster: Vec<BotRoster>,
    /// This hub's own uptime base.
    pub hub_started: i64,
    pub last_presence_gossip: i64,
    /// Phase 5: the last whole tree pushed, its FNV-1a 64 and version, for row
    /// deltas (a current bot gets the diff from this to the new tree).
    pub tree_last: String,
    pub tree_last_fnv: u64,
    pub tree_seq: u64,
    /// Roster changed: push to bots on the next tick.
    pub tree_dirty: bool,
    /// ...by one of our own bots (short gap).
    pub tree_dirty_local: bool,
    /// Coalescing clock (BOT_TREE_COALESCE).
    pub last_tree_change_push: i64,
    /// Every hub heard from, any hop (see `MeshHub`).
    pub mesh_hubs: Vec<MeshHub>,
    /// Last generation this hub gossiped.
    pub roster_gen: i64,
    /// Peers linked at the last gossip (bit p).
    pub gossip_link_mask: u32,
    /// A presence event waits for its gossip.
    pub presence_event_due: bool,
    /// No event gossip before then (damping).
    pub presence_hold_until: i64,
    /// The last event gossip.
    pub presence_last_event: i64,
    /// Event gossips in a row inside the window.
    pub presence_burst: i32,
    /// Presence v2 (None until `presence2::init`).
    pub p2: Option<Box<crate::presence2::P2State>>,
    /// A link came up: gossip once more then.
    pub gossip_again_at: i64,
    /// Ask peers for a sync then (0 = none).
    pub resync_due_at: i64,

    /// SSH console (console module): the core's side of the console thread,
    /// None when the console is not running.
    pub console: Option<crate::console::Core>,

    pub timers: MaintTimers,
}

impl Default for HubState {
    fn default() -> Self {
        HubState::new()
    }
}

/// Names come from the store and from peers: no control byte reaches a log
/// line through one (hub_logic.c who_clean).
fn who_clean(s: String) -> String {
    if s.bytes().any(|b| b < 0x20 || b == 0x7f) {
        s.chars()
            .map(|q| {
                if (q as u32) < 0x20 || q as u32 == 0x7f {
                    '_'
                } else {
                    q
                }
            })
            .collect()
    } else {
        s
    }
}

impl HubState {
    pub fn new() -> HubState {
        HubState {
            listener: None,
            port: 0,
            bind_ip: String::new(),
            listen_ip: String::new(),
            listen_port: 0,
            public_ip: String::new(),
            public_ip_at: 0,
            hub_uuid: String::new(),
            executable_path: String::new(),
            hub_friendly_name: String::new(),
            config_pass: Locked::new(),
            cfg_key: Locked::new(),
            cfg_key_set: false,
            hello_seen: Vec::new(),
            hello_seen_next: 0,
            hub_ed25519_priv: Locked::new(),
            hub_x25519_priv: Locked::new(),
            hub_ed25519_pub: [0; 32],
            hub_x25519_pub: [0; 32],
            hub_keys_loaded: false,
            clients: Vec::new(),
            bots: Vec::new(),
            global_entries: Vec::new(),
            chan_learned: Vec::new(),
            global_idx: Default::default(),
            user_records: Vec::new(),
            mask_records: Vec::new(),
            uflag_records: Vec::new(),
            uchan_records: Vec::new(),
            adrop: vec![(String::new(), 0); crate::consts::ADMIN_DROP_LOG],
            adrop_next: 0,
            floor_warned: false,
            peers: Vec::new(),
            revoked: Vec::new(),
            pending_op_requests: vec![PendingOpRequest::default(); MAX_PENDING_OP_REQUESTS],
            pending_chan_requests: vec![PendingChanRequest::default(); MAX_PENDING_CHAN_REQUESTS],
            chan_elections: vec![ChanElect::default(); MAX_CHAN_ELECTIONS],
            ce_full_at: 0,
            ce_full_n: 0,
            rollcalls: vec![HubRollcall::default(); MAX_ROLLCALLS],
            upg_start_wait: UpgStartWait::default(),
            step_rollcall: StepRollcall::default(),
            upgrade: PendingUpgrade::default(),
            follow_id: String::new(),
            follow_origin: String::new(),
            follow_target: String::new(),
            follow_variant: String::new(),
            follow_bot_variant: String::new(),
            follow_sel: String::new(),
            follow_hub_target: String::new(),
            follow_self_ready: false,
            follow_prepared: 0,
            upgrade_installed_id: String::new(),
            upgrade_report_status: String::new(),
            upgrade_report_detail: String::new(),
            upgrade_report_until: 0,
            follow_routes: Vec::new(),
            rollup: PendingRollup::default(),
            rollup_tries: Vec::new(),
            plan: UpgradePlan::default(),
            upgrade_cancel_id: String::new(),
            upgrade_cancel_issued: 0,
            upgrade_cancel_seen: 0,
            ip_limits: Vec::new(),
            ip_allow: Vec::new(),
            ip_deny: Vec::new(),
            ip_acl_changed: false,
            conn_cfg: crate::connlimits::ConnCfg::default(),
            ssh_ips: Vec::new(),
            known_ips: Vec::new(),
            startup_logged: 0,
            startup_unlogged: 0,
            purge_days_setting: 0,
            purge_days_ts: 0,
            uhist: Vec::new(),
            uhist_keep_setting: 0,
            bot_cron_setting: 0,
            hub_cron_setting: 0,
            bot_cron_ts: 0,
            hub_cron_ts: 0,
            sgrant_setting: 0,
            sgrant_ts: 0,
            pool_strikes: vec![crate::pool::PoolStrikes::default(); MAX_POOL_SERVERS],
            pool_linked: Vec::new(),
            pool_order: Default::default(),
            rebalance: Default::default(),
            cron_recs: Vec::new(),
            splan: Default::default(),
            splan_seen: 0,
            plan_beat: 0,
            uhist_keep_ts: 0,
            trust_loopback: false,
            pid_file: None,
            running: true,
            recent_purges: Vec::new(),
            last_scheduled_purge: 0,
            purge_floor: 0,
            purge_floor_until: 0,
            seen_forwards: vec![SeenForward::default(); MAX_SEEN_FORWARD_IDS],
            seen_forward_head: 0,
            log_level: HUB_DEFAULT_LOG_LEVEL,
            console_log_level: HUB_DEFAULT_CONSOLE_LOG_LEVEL,
            log_max_size: HUB_LOG_FILE_SIZE,
            opt_flags: String::new(),
            opt_flags_ts: 0,
            config_dirty: false,
            bot_config_pending: false,
            bans_swept_at: 0,
            last_bot_config_push: 0,
            cfg_holds: 0,
            last_config_write: 0,
            mesh_state_dirty: false,
            next_lamport_seq: 0,
            roster: Vec::new(),
            hub_started: 0,
            last_presence_gossip: 0,
            tree_last: String::new(),
            tree_last_fnv: 0,
            tree_seq: 0,
            tree_dirty: false,
            tree_dirty_local: false,
            last_tree_change_push: 0,
            mesh_hubs: Vec::new(),
            roster_gen: 0,
            gossip_link_mask: 0,
            presence_event_due: false,
            presence_hold_until: 0,
            presence_last_event: 0,
            presence_burst: 0,
            p2: None,
            gossip_again_at: 0,
            resync_due_at: 0,
            console: None,
            timers: MaintTimers::default(),
        }
    }

    /// hub_set_config_pass().
    pub fn set_config_pass(&mut self, pass: &str) {
        self.config_pass.set_str(pass);
        self.config_key_forget(); // derived from the old password
    }

    /// hub_config_key_forget().
    pub fn config_key_forget(&mut self) {
        self.cfg_key.wipe();
        self.cfg_key_set = false;
    }

    /// cfg_key_keep(): remember the key a load or write derived.
    pub fn config_key_keep(&mut self, salt: &[u8], key: &[u8; 32]) {
        let mut sk = Zeroizing::new([0u8; SALT_SIZE + 32]);
        sk[..SALT_SIZE].copy_from_slice(salt);
        sk[SALT_SIZE..].copy_from_slice(key);
        self.cfg_key.set(&sk);
        self.cfg_key_set = true;
    }

    /// hub_get_config_pass().
    pub fn get_config_pass(&self) -> Zeroizing<String> {
        self.config_pass.get_str()
    }

    /// The combined 64-byte private key (ed_priv || x_priv).
    pub fn hub_priv_combined(&self) -> Zeroizing<[u8; COMBINED_KEY_LEN]> {
        let mut out = Zeroizing::new([0u8; COMBINED_KEY_LEN]);
        out[..32].copy_from_slice(self.hub_ed25519_priv.get());
        out[32..].copy_from_slice(self.hub_x25519_priv.get());
        out
    }

    /// The combined 64-byte public key (ed_pub || x_pub).
    pub fn hub_pub_combined(&self) -> [u8; COMBINED_KEY_LEN] {
        let mut out = [0u8; COMBINED_KEY_LEN];
        out[..32].copy_from_slice(&self.hub_ed25519_pub);
        out[32..].copy_from_slice(&self.hub_x25519_pub);
        out
    }

    /// Split a combined private key into the two locked halves.
    pub fn set_hub_priv(&mut self, combined: &[u8; COMBINED_KEY_LEN]) {
        let mut ed = [0u8; 32];
        let mut x = [0u8; 32];
        ed.copy_from_slice(&combined[..32]);
        x.copy_from_slice(&combined[32..]);
        self.hub_ed25519_priv.set(&ed);
        self.hub_x25519_priv.set(&x);
        crate::crypto::wipe(&mut ed);
        crate::crypto::wipe(&mut x);
    }

    pub fn set_hub_pub(&mut self, combined: &[u8; COMBINED_KEY_LEN]) {
        self.hub_ed25519_pub.copy_from_slice(&combined[..32]);
        self.hub_x25519_pub.copy_from_slice(&combined[32..]);
    }

    /// hub_next_lamport_seq(): bump-then-return, so the first issued seq is
    /// 1, not 0.
    pub fn next_lamport_seq(&mut self) -> u64 {
        self.next_lamport_seq = self.next_lamport_seq.wrapping_add(1);
        self.next_lamport_seq
    }

    /// Index of the client on `fd`, or None.
    pub fn client_by_fd(&self, fd: i32) -> Option<usize> {
        if fd < 0 {
            return None;
        }
        self.clients.iter().position(|c| c.fd == fd)
    }

    /// Index of the client on `fd` that is still the link with this
    /// conn_serial, or None (the link dropped and the fd may be reused).
    pub fn client_by_fd_serial(&self, fd: i32, serial: u64) -> Option<usize> {
        self.client_by_fd(fd)
            .filter(|&i| self.clients[i].conn_serial == serial)
    }

    /// The conn_serial of the link on `fd` now, or 0 (none: -1, or no such
    /// link).  A reply table keeps it beside the fd, so an answer that comes
    /// back after the link dropped and the fd was reused never reaches the
    /// newcomer.
    pub fn fd_conn_serial(&self, fd: i32) -> u64 {
        self.client_by_fd(fd)
            .map_or(0, |i| self.clients[i].conn_serial)
    }

    /// Index of the authenticated bot with this UUID, or None.
    pub fn bot_client(&self, uuid: &str) -> Option<usize> {
        self.clients.iter().position(|c| {
            c.typ == ClientType::Bot && c.authenticated && !c.superseded && c.id == uuid
        })
    }

    /// Indices of every authenticated peer hub.
    pub fn peer_clients(&self) -> Vec<usize> {
        self.clients
            .iter()
            .enumerate()
            .filter(|(_, c)| c.typ == ClientType::Hub && c.authenticated)
            .map(|(i, _)| i)
            .collect()
    }

    /// Indices of every authenticated bot.
    pub fn bot_clients(&self) -> Vec<usize> {
        self.clients
            .iter()
            .enumerate()
            .filter(|(_, c)| c.typ == ClientType::Bot && c.authenticated)
            .map(|(i, _)| i)
            .collect()
    }

    /// Look up one `key` of a stored bot record (e.g. "h" hostmask, "n"
    /// nick).  None when the bot or the key is unknown or the value is empty.
    pub fn bot_entry(&self, uuid: &str, key: &str) -> Option<&str> {
        let b = self.bots.iter().find(|b| b.uuid == uuid)?;
        let e = b.entry(key)?;
        if e.value.is_empty() {
            None
        } else {
            Some(e.value.as_str())
        }
    }

    /// The name a uuid goes by and what it is ("bot", "hub", "admin",
    /// "oper"): hub_logic.c who_name().
    fn who_name(&self, kind: char, uuid: &str) -> (&'static str, Option<&str>) {
        if kind == '\0' || kind == 'b' {
            if let Some(n) = self.bot_entry(uuid, "n") {
                return ("bot", Some(n));
            }
            if let Some(r) = self
                .roster
                .iter()
                .find(|r| r.bot_uuid == uuid && !r.nick.is_empty())
            {
                return ("bot", Some(&r.nick));
            }
        }
        if kind == '\0' || kind == 'h' {
            if self.hub_uuid == uuid && !self.hub_friendly_name.is_empty() {
                return ("hub", Some(&self.hub_friendly_name));
            }
            if let Some(p) = self
                .peers
                .iter()
                .find(|p| p.uuid == uuid && !p.friendly_name.is_empty())
            {
                return ("hub", Some(&p.friendly_name));
            }
            if let Some(m) = self
                .mesh_hubs
                .iter()
                .find(|m| m.uuid == uuid && !m.name.is_empty())
            {
                return ("hub", Some(&m.name));
            }
            // A plan's director, by the name it published: known even at boot.
            if !self.splan.driver_name.is_empty() && self.splan.driver == uuid {
                return ("hub", Some(&self.splan.driver_name));
            }
        }
        if (kind == '\0' || kind == 'u')
            && let Some(u) = self.user_records.iter().find(|u| u.uuid == uuid)
        {
            let word = if u.typ == 'a' { "admin" } else { "oper" };
            return (word, (!u.name.is_empty()).then_some(u.name.as_str()));
        }
        let word = match kind {
            'b' => "bot",
            'h' => "hub",
            'u' => "user",
            _ => "?",
        };
        (word, None)
    }

    /// Log label for a node or user (hub_who): "bot bunny_ (<uuid>)",
    /// "hub hubtbl (<uuid>)", "admin admin (<uuid>)"; an unknown name reads
    /// "?".  kind: 'b' bot, 'h' hub, 'u' admin/oper, '\0' = whichever knows
    /// the uuid.
    pub fn who(&self, kind: char, uuid: &str) -> String {
        let (word, name) = if uuid.is_empty() {
            (
                match kind {
                    'b' => "bot",
                    'h' => "hub",
                    'u' => "user",
                    _ => "?",
                },
                None,
            )
        } else {
            self.who_name(kind, uuid)
        };
        let id = if uuid.is_empty() {
            "?"
        } else {
            trunc(uuid, 64)
        };
        if kind == '\0' && name.is_none() {
            return who_clean(format!("? ({id})"));
        }
        who_clean(format!("{word} {} ({id})", trunc(name.unwrap_or("?"), 64)))
    }

    /// Log label for connection `ci` (hub_who_client): a bot by its uuid, a
    /// peer by its name and uuid, a console by its admin.
    pub fn who_client(&self, ci: usize) -> String {
        let Some(c) = self.clients.get(ci) else {
            return "?".into();
        };
        who_clean(match c.typ {
            ClientType::Bot if !c.id.is_empty() => self.who('b', &c.id),
            ClientType::Hub => {
                let uuid = self
                    .peers
                    .iter()
                    .find(|p| p.connected && p.fd == c.fd)
                    .map_or("?", |p| {
                        if p.uuid.is_empty() {
                            "?"
                        } else {
                            p.uuid.as_str()
                        }
                    });
                let name = if c.id.is_empty() { "?" } else { c.id.as_str() };
                format!("hub {} ({})", trunc(name, 64), trunc(uuid, 64))
            }
            ClientType::Admin if c.id.starts_with("ADMIN:") => format!("admin {}", &c.id[6..]),
            _ if !c.id.is_empty() => c.id.clone(),
            _ => c.ip.clone(),
        })
    }

    /// Whether the network opt flag is set.
    pub fn opt(&self, flag: char) -> bool {
        self.opt_flags.contains(flag)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn recv_offset_and_compaction() {
        let mut c = HubClient::new_detached(7, "127.0.0.1", 16);
        // two 2-byte frames, then half of a third
        c.recv_buf
            .extend_from_slice(&[0, 0, 0, 2, b'a', b'b', 0, 0, 0, 2, b'c', b'd', 0, 0]);
        assert!(c.has_buffered_frame());
        c.recv_off = 6; // the first frame consumed
        assert!(c.has_buffered_frame());
        c.recv_off = 12; // the second too: only a partial prefix is left
        assert!(!c.has_buffered_frame());
        c.compact_recv(); // not full yet: nothing moves
        assert_eq!(c.recv_off, 12);
        c.recv_buf.extend_from_slice(&[0, 2]); // now full (16 bytes)
        c.compact_recv();
        assert_eq!((c.recv_off, &c.recv_buf[..]), (0, &[0u8, 0, 0, 2][..]));
        assert!(!c.has_buffered_frame());
    }

    #[test]
    fn lww_tie_prefers_delete() {
        assert!(lww_accepts(10, true, 5, true));
        assert!(!lww_accepts(5, true, 10, true));
        // Same second: a delete beats a live record, an add does not.
        assert!(lww_accepts(10, false, 10, true));
        assert!(!lww_accepts(10, true, 10, false));
        assert!(!lww_accepts(10, true, 10, true));
    }

    #[test]
    fn opt_tie_prefers_greater_string() {
        assert!(opt_accepts(10, "", 5, "h"));
        // A set beats a clear on a tie, the stricter policy.
        assert!(opt_accepts(10, "h", 10, ""));
        assert!(!opt_accepts(10, "", 10, "h"));
    }

    #[test]
    fn lww_next_ts_never_ties() {
        let n = now();
        assert!(lww_next_ts(n + 500) > n + 500);
        assert_eq!(lww_next_ts(0), n);
    }

    #[test]
    fn global_value_active_reads_last_field() {
        assert!(global_value_active("#chan|key|0|add"));
        assert!(!global_value_active("#chan|key|0|del"));
        assert!(global_value_active("bare"));
    }

    #[test]
    fn names_and_uints_are_strict() {
        assert!(name_valid("hub-1.eu_west"));
        assert!(!name_valid(""));
        assert!(!name_valid("has space"));
        assert!(!name_valid("pipe|name"));
        assert!(!name_valid(&"x".repeat(64)));
        assert_eq!(parse_uint("7000", 65535), Some(7000));
        assert_eq!(parse_uint("7d", 65535), None);
        assert_eq!(parse_uint("", 65535), None);
        assert_eq!(parse_uint("-3", 65535), None);
        assert_eq!(parse_uint("70000", 65535), None);
        assert_eq!(parse_uint("12345678901", 99), None);
    }
}
