//! Mesh transport — the per-peer outbound queue (docs/mesh.md Phase 1).
//!
//! Replaces the old "build packet → encrypt → send-or-drop on EAGAIN" model
//! with a per-client queue drained on POLLOUT.  Encryption happens at drain
//! time (so it uses the up-to-date session key) and partial writes are
//! tracked via `writing_buf` / `writing_offset`.  Three priority lanes:
//! URGENT (op flow), DELTA (small per-key updates), BULK (anti-entropy and
//! full sync).

use crate::consts::*;
use crate::crypto;
use crate::cstr::now;
use crate::net::{self, SendOutcome};
use crate::state::{ClientType, HubClient, Lane, QueuedMsg};

/// peer_enqueue(): put `m` on the client's lane, coalescing when its key
/// matches one already queued.
///
/// Overflow handling: URGENT must never be dropped, so a full URGENT lane is
/// a fatal peer condition and returns false (the caller disconnects).  DELTA
/// and BULK drop their oldest entry to make room — for DELTA one update is
/// lost and the next anti-entropy reconciles it; for BULK a full sync is
/// lost and the next one fires within MESH_ANTI_ENTROPY_INTERVAL.
pub fn enqueue(client: &mut HubClient, m: QueuedMsg) -> bool {
    if client.fd < 0 {
        return false;
    }
    let li = m.lane.index();
    let fd = client.fd;
    let lane = &mut client.out_lanes[li];

    // Coalescing (Phase 5; harmless when the key is empty).  Walk the lane
    // FIFO; a same-key entry has its payload replaced in place, keeping its
    // position, and the new message is dropped.
    if !m.coalesce_key.is_empty()
        && let Some(cur) = lane
            .msgs
            .iter_mut()
            .find(|c| !c.coalesce_key.is_empty() && c.coalesce_key == m.coalesce_key)
    {
        let old_bytes = cur.len();
        let new_bytes = m.len();
        cur.payload = m.payload;
        cur.lamport_seq = m.lamport_seq;
        // The origin hub may differ if a peer's update overwrote a
        // local-origin one; the new origin "wins" because the newer seq
        // belongs to it.
        cur.origin_hub_uuid = m.origin_hub_uuid;
        lane.bytes = lane.bytes + new_bytes - old_bytes;
        client.out_total_bytes = client.out_total_bytes + new_bytes - old_bytes;
        return true;
    }

    if lane.msgs.len() >= MAX_QUEUE_PER_LANE
        || client.out_total_bytes + m.len() > MAX_QUEUED_BYTES_PER_PEER
    {
        if li == Lane::Urgent.index() {
            // The caller sees false and decides whether to disconnect.
            return false;
        }
        if let Some(old) = lane.msgs.pop_front() {
            lane.bytes -= old.len();
            client.out_total_bytes -= old.len();
            let t = now();
            if t - client.drop_logged >= QUEUE_DROP_LOG_EVERY {
                if client.drop_unlogged > 0 {
                    crate::hlog_warning!(
                        "[MESH] queue {} lane full — dropping oldest (peer fd={fd}); \
                         {} more dropped in the last {}s\n",
                        m.lane.name(),
                        client.drop_unlogged,
                        t - client.drop_logged
                    );
                } else {
                    crate::hlog_warning!(
                        "[MESH] queue {} lane full — dropping oldest (peer fd={fd})\n",
                        m.lane.name()
                    );
                }
                client.drop_logged = t;
                client.drop_unlogged = 0;
            } else {
                client.drop_unlogged += 1;
            }
            cfg_push_lost(client, &old);
        }
    }

    // Output waiting where none was: the write-stall clock starts.
    if !client.has_pending_writes() {
        client.write_wait_since = now();
    }
    let n = m.len();
    client.out_lanes[li].msgs.push_back(m);
    client.out_lanes[li].bytes += n;
    client.out_total_bytes += n;
    true
}

/// A config push that never reaches its bot must not stand as "sent", or the
/// next identical broadcast would be skipped and the bot left behind.
fn cfg_push_lost(client: &mut HubClient, m: &QueuedMsg) {
    if m.cmd == CMD_BOT_TREE || m.cmd == CMD_BOT_TREE_DELTA {
        client.tree_sent_valid = false; // a tree or delta that never landed: resend whole
    }
    if m.cmd == CMD_CONFIG_DATA {
        client.cfg_sent_hash = None;
        crate::stats::cfg_lost();
    }
}

/// Review 6: the AAD of frame number `ctr` sent with direction byte `dir` on a
/// sequenced link (CMD_LINK_SEQ).
pub fn link_aad(dir: u8, ctr: u64) -> [u8; HUB_LINK_AAD_LEN] {
    let mut out = [0u8; HUB_LINK_AAD_LEN];
    out[..4].copy_from_slice(b"LNK1");
    out[4] = dir;
    out[5..].copy_from_slice(&ctr.to_be_bytes());
    out
}

/// Encrypt `m` with the client's session key into `writing_buf`.  Returns the
/// total wire length (4-byte length prefix + ciphertext + tag), or 0 on
/// failure.
fn encrypt_into_writing(client: &mut HubClient, m: &QueuedMsg) -> usize {
    if m.len() > MAX_BULK_PAYLOAD {
        return 0;
    }
    // The wire envelope; see net::frame_plain for why the inner length is
    // stamped big-endian for everything a bot receives.
    let plain = zeroize::Zeroizing::new(net::frame_plain(
        m.cmd,
        &m.payload,
        client.typ == ClientType::Bot || net::inner_len_is_network_order(m.cmd),
    ));

    // D2: writing_buf may still be at the small pre-auth cap.  Refuse to
    // encrypt a frame that would not fit (4-byte length prefix + IV +
    // ciphertext + tag: aes_gcm_encrypt puts the IV first).  AES-GCM
    // ciphertext length equals the plaintext length.
    if 4 + GCM_IV_LEN + plain.len() + GCM_TAG_LEN > client.writing_cap {
        return 0;
    }

    let seq = client.link_tx_seq;
    let aad = if seq {
        link_aad(client.link_dir_tx, client.link_tx_ctr).to_vec()
    } else {
        Vec::new()
    };
    let Some((body, tag)) = crypto::aes_gcm_encrypt_aad(&plain, &aad, client.session_key.as_ref())
    else {
        return 0;
    };
    // Review 6: every frame sealed after our "go" is sequenced.
    if seq {
        client.link_tx_ctr += 1;
    } else if m.cmd == CMD_LINK_SEQ && m.payload.as_slice() == b"go" {
        client.link_tx_seq = true;
    }
    let packet_len = body.len() + GCM_TAG_LEN;
    client.writing_buf.clear();
    client
        .writing_buf
        .extend_from_slice(&(packet_len as u32).to_be_bytes());
    client.writing_buf.extend_from_slice(&body);
    client.writing_buf.extend_from_slice(&tag);
    4 + packet_len
}

/// Push bytes from `writing_buf` at `writing_offset` until the socket says
/// WouldBlock, the buffer empties, or the send errors.  Returns false when
/// the caller must stop draining this pass.
fn push_in_flight(client: &mut HubClient) -> bool {
    while client.writing_offset < client.writing_buf.len() {
        let Some(sock) = &client.sock else {
            client.writing_buf.clear();
            client.writing_offset = 0;
            return false;
        };
        match net::send_dontwait(sock, &client.writing_buf[client.writing_offset..]) {
            SendOutcome::Sent(n) if n > 0 => {
                client.writing_offset += n;
                let t = now();
                client.write_wait_since = t;
                if client.bw_window_start != t {
                    client.bw_window_start = t;
                    client.bw_bytes_in_window = 0;
                }
                client.bw_bytes_in_window += n as i64;
            }
            // A zero-length accept would spin; treat it as "come back later".
            SendOutcome::Sent(_) | SendOutcome::WouldBlock => return false,
            SendOutcome::Error(e) => {
                // A hard send error: the caller cannot disconnect from here
                // (it is iterating the client list), so the in-flight buffer
                // is cleared and the recv side reaps the socket on EOF.
                crate::hlog_warning!(
                    "[MESH] send error to {} (fd={}): {e}\n",
                    client.ip,
                    client.fd
                );
                client.writing_buf.clear();
                client.writing_offset = 0;
                return false;
            }
        }
    }
    client.writing_buf.clear();
    client.writing_offset = 0;
    true
}

/// peer_drain_writable(): called when poll reports the socket writable.
pub fn drain_writable(client: &mut HubClient) {
    if let Some(l) = client.console.as_mut() {
        // An SSH console's socketpair: a broken link shows up as EOF on the
        // read side, which closes it.
        let _ = l.drain();
        return;
    }
    if client.fd < 0 || client.sock.is_none() {
        return;
    }

    // Step 1: finish any in-flight ciphertext.
    if !push_in_flight(client) {
        return;
    }

    // Step 2: drain lanes in priority order until we run out of messages or
    // the socket goes EAGAIN.
    for li in 0..LANE_COUNT {
        while !client.out_lanes[li].msgs.is_empty() {
            // Bandwidth budget enforcement (Phase 5; the defaults are
            // generous).
            let t = now();
            if client.bw_window_start != t {
                client.bw_window_start = t;
                client.bw_bytes_in_window = 0;
            }
            // Defer the rest of BULK to the next second.
            if li == Lane::Bulk.index() && client.bw_bytes_in_window > BULK_SOFT_BUDGET_BPS {
                return;
            }
            // Extreme case — let coalescing catch up.
            if li == Lane::Delta.index() && client.bw_bytes_in_window > DELTA_HARD_BUDGET_BPS {
                return;
            }

            let Some(m) = client.out_lanes[li].msgs.pop_front() else {
                break;
            };
            client.out_lanes[li].bytes -= m.len();
            client.out_total_bytes -= m.len();

            let wire_len = encrypt_into_writing(client, &m);
            if wire_len == 0 {
                crate::hlog_error!("[MESH] encrypt failed for peer {} lane {li}\n", client.ip);
                cfg_push_lost(client, &m);
                continue; // drop and move on
            }
            crate::stats::tx(m.cmd, wire_len);
            drop(m);
            client.writing_offset = 0;

            // Try to send immediately.
            if !push_in_flight(client) {
                return;
            }
        }
    }
}

/// peer_send_urgent(): enqueue a small hub→hub URGENT message.  False when
/// the URGENT queue is full — the caller must disconnect that peer.
pub fn send_urgent(client: &mut HubClient, cmd: u8, payload: &str) -> bool {
    let Some(m) = QueuedMsg::new(cmd, Lane::Urgent, payload.as_bytes()) else {
        return false;
    };
    if !enqueue(client, m) {
        crate::hlog_warning!(
            "[URGENT] Queue full for peer {} — disconnecting\n",
            client.ip
        );
        return false;
    }
    true
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::net::{TcpListener, TcpStream};

    fn client() -> HubClient {
        let l = TcpListener::bind("127.0.0.1:0").unwrap();
        let s = TcpStream::connect(l.local_addr().unwrap()).unwrap();
        HubClient::new(s, 42, "127.0.0.1", MAX_BUFFER)
    }

    #[test]
    fn coalescing_replaces_in_place() {
        let mut c = client();
        for (i, body) in ["first", "second", "third"].iter().enumerate() {
            let mut m = QueuedMsg::new(CMD_PEER_SYNC, Lane::Delta, body.as_bytes()).unwrap();
            if i != 1 {
                m.set_coalesce("hub-a", i as u64, "hub-a|h|bot-1");
            }
            assert!(enqueue(&mut c, m));
        }
        let lane = &c.out_lanes[Lane::Delta.index()];
        // "third" replaced "first" in slot 0; "second" was never coalesced.
        assert_eq!(lane.msgs.len(), 2);
        assert_eq!(&*lane.msgs[0].payload, b"third");
        assert_eq!(lane.msgs[0].lamport_seq, 2);
        assert_eq!(&*lane.msgs[1].payload, b"second");
        assert_eq!(lane.bytes, "third".len() + "second".len());
        assert_eq!(c.out_total_bytes, lane.bytes);
    }

    #[test]
    fn urgent_overflow_is_fatal_others_drop_oldest() {
        let mut c = client();
        for i in 0..MAX_QUEUE_PER_LANE {
            let m = QueuedMsg::new(
                CMD_OP_FORWARD_REQUEST,
                Lane::Urgent,
                format!("{i}").as_bytes(),
            )
            .unwrap();
            assert!(enqueue(&mut c, m));
        }
        let m = QueuedMsg::new(CMD_OP_FORWARD_REQUEST, Lane::Urgent, b"over").unwrap();
        assert!(!enqueue(&mut c, m));

        for i in 0..MAX_QUEUE_PER_LANE {
            let m = QueuedMsg::new(CMD_PEER_SYNC, Lane::Bulk, format!("{i}").as_bytes()).unwrap();
            assert!(enqueue(&mut c, m));
        }
        let m = QueuedMsg::new(CMD_PEER_SYNC, Lane::Bulk, b"over").unwrap();
        assert!(enqueue(&mut c, m));
        let lane = &c.out_lanes[Lane::Bulk.index()];
        assert_eq!(lane.msgs.len(), MAX_QUEUE_PER_LANE);
        assert_eq!(&*lane.msgs[0].payload, b"1");
        assert_eq!(&*lane.msgs[MAX_QUEUE_PER_LANE - 1].payload, b"over");
    }

    #[test]
    fn oversized_payload_is_refused() {
        assert!(
            QueuedMsg::new(CMD_PEER_SYNC, Lane::Bulk, &vec![0u8; MAX_BULK_PAYLOAD + 1]).is_none()
        );
        assert!(QueuedMsg::new(CMD_PEER_SYNC, Lane::Bulk, &vec![0u8; MAX_BULK_PAYLOAD]).is_some());
    }

    #[test]
    fn queue_destroy_clears_every_lane() {
        let mut c = client();
        for lane in [Lane::Urgent, Lane::Delta, Lane::Bulk] {
            assert!(enqueue(
                &mut c,
                QueuedMsg::new(CMD_PING, lane, b"x").unwrap()
            ));
        }
        assert!(c.has_pending_writes());
        c.queue_destroy();
        assert!(!c.has_pending_writes());
        assert_eq!(c.out_total_bytes, 0);
    }
}
