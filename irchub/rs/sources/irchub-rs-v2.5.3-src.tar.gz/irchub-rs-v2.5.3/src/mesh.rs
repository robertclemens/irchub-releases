//! Hub-to-hub replication (hub_logic.c): the full-state sync packet, the
//! peer-sync ingest, mesh-state gossip, and the tombstone purge.
//!
//! The store is a last-write-wins CRDT.  Every replicated record carries a
//! timestamp, and `state::lww_accepts` decides: a strictly newer stamp wins,
//! and on an exact tie a delete beats an add.  That tie rule is what makes
//! the mesh converge — two hubs stamping the same second would otherwise
//! each keep their own copy and refuse the other's forever — and it is
//! mirrored in ircbot, so a bot and a hub never disagree about a record.

use crate::consts::*;
use crate::cstr::{atoll, now, split_fields, trunc, trunc_string};
use crate::state::{
    ClientType, ConfigEntry, HubState, Lane, MaskRecord, QueuedMsg, UserRecord,
    global_value_active, lww_accepts, opt_accepts,
};
use crate::{access, client, config, crypto, queue, storage};

// ---------------------------------------------------------------------------
// PURGE deduplication
// ---------------------------------------------------------------------------
//
// A purge is known by its cutoff plus the random id its origin hub gave it.
// Keyed on the cutoff alone, every "immediate" purge (cutoff 0) looked like
// the previous one for PURGE_DEDUP_WINDOW seconds, and peers skipped a second
// purge sent inside that window.

fn is_purge_recent(state: &HubState, cutoff: i64, id: &str) -> bool {
    let t = now();
    state
        .recent_purges
        .iter()
        .any(|p| p.cutoff == cutoff && p.id == id && t - p.received_at < PURGE_DEDUP_WINDOW)
}

fn record_recent_purge(state: &mut HubState, cutoff: i64, id: &str) {
    let t = now();
    let slot = match state
        .recent_purges
        .iter()
        .position(|p| p.cutoff == cutoff && p.id == id)
    {
        Some(i) => i,
        None if state.recent_purges.len() < MAX_RECENT_PURGES => {
            state.recent_purges.push(Default::default());
            state.recent_purges.len() - 1
        }
        None => {
            // Full: overwrite the oldest entry.
            let mut oldest = 0;
            for i in 1..state.recent_purges.len() {
                if state.recent_purges[i].received_at < state.recent_purges[oldest].received_at {
                    oldest = i;
                }
            }
            oldest
        }
    };
    state.recent_purges[slot].cutoff = cutoff;
    state.recent_purges[slot].id = trunc_string(id, PURGE_ID_HEX + 1);
    state.recent_purges[slot].received_at = t;
}

/// `PURGE|<cutoff>` or `PURGE|<cutoff>|<id>`, id 1..PURGE_ID_HEX hex digits.
/// None on anything else (the line is dropped, not forwarded).
fn parse_purge_line(line: &str) -> Option<(i64, String)> {
    let p = line.strip_prefix("PURGE|")?;
    if !p.as_bytes().first()?.is_ascii_digit() {
        return None;
    }
    let (v, used) = crate::cstr::strtoll(p);
    if v < 0 {
        return None;
    }
    let rest = &p[used..];
    let id = match rest.strip_prefix('|') {
        Some(h) => {
            if h.is_empty() || h.len() > PURGE_ID_HEX || !h.bytes().all(|c| c.is_ascii_hexdigit()) {
                return None;
            }
            h.to_string()
        }
        None => {
            if !rest.is_empty() {
                return None;
            }
            String::new()
        }
    };
    Some((v, id))
}

/// hub_broadcast_purge(): send `PURGE|<cutoff>|<id>` to every peer hub under
/// a fresh random id that this hub records as seen (so the copies peers
/// forward back are not run again).  False (nothing sent) if no id could be
/// drawn.
pub fn broadcast_purge(state: &mut HubState, cutoff: i64) -> bool {
    let Some(id) = crypto::random_hex(PURGE_ID_HEX / 2) else {
        crate::hlog_error!("[PURGE] no random bytes for a purge id; purge not broadcast\n");
        return false;
    };
    record_recent_purge(state, cutoff, &id);
    let msg = format!("PURGE|{cutoff}|{id}\n");
    broadcast_sync_to_peers(state, &msg, -1);
    true
}

/// hub_should_initiate_scheduled_purge(): leader election — the hub with the
/// lexicographically smallest UUID in the connected mesh leads.
pub fn should_initiate_scheduled_purge(state: &HubState) -> bool {
    !state
        .clients
        .iter()
        .any(|c| c.typ == ClientType::Hub && c.authenticated && c.id < state.hub_uuid)
}

// ---------------------------------------------------------------------------
// Mesh-state gossip
// ---------------------------------------------------------------------------

/// hub_broadcast_mesh_state(): the peer-topology snapshot every hub gossips.
///
/// Wire shape: `<connected>:<total>:<bots>:<bot_uuid_list>|<blocks>` where
/// each block is `ip:port:uuid:name|<peer>,<peer>,...;` — our own block
/// first, then any block a peer reported that we do not already carry.
pub fn broadcast_mesh_state(state: &mut HubState) {
    let mut payload = format!(
        "{}:{}:{}:{}|",
        state.bind_ip,
        state.port,
        if state.hub_uuid.is_empty() {
            "-"
        } else {
            &state.hub_uuid
        },
        if state.hub_friendly_name.is_empty() {
            "-"
        } else {
            &state.hub_friendly_name
        }
    );
    if payload.len() >= MAX_BUFFER {
        return;
    }

    for p in &state.peers {
        let is_up = p.fd > 0
            && state
                .clients
                .iter()
                .any(|c| c.typ == ClientType::Hub && c.authenticated && c.fd == p.fd);
        let block = format!(
            "{}:{}:{}:{}:{},",
            p.ip,
            p.port,
            i32::from(is_up),
            if p.uuid.is_empty() { "-" } else { &p.uuid },
            if p.friendly_name.is_empty() {
                "-"
            } else {
                &p.friendly_name
            }
        );
        if payload.len() + block.len() >= MAX_BUFFER {
            break;
        }
        payload.push_str(&block);
    }
    if payload.len() < MAX_BUFFER - 1 {
        payload.push(';');
    }

    // Aggregate gossip from peers: add any block whose owner we do not
    // already list.
    let my_sig = format!("{}:{}", state.bind_ip, state.port);
    let gossips: Vec<String> = state
        .peers
        .iter()
        .filter(|p| p.connected && !p.last_gossip.is_empty())
        .map(|p| p.last_gossip.clone())
        .collect();
    for g in gossips {
        let Some(bar) = g.find('|') else { continue };
        let work = trunc_string(&g[bar + 1..], MAX_BUFFER);
        for block in work.split(';') {
            if block.is_empty() {
                continue;
            }
            let owner = match block.find('|') {
                Some(i) => &block[..i],
                None => block,
            };
            let owner = trunc_string(owner, 256);
            if owner.is_empty() || owner == my_sig {
                continue;
            }
            if payload.contains(&format!("{owner}|")) {
                continue;
            }
            if payload.len() + block.len() + 2 < MAX_BUFFER {
                payload.push_str(block);
                payload.push(';');
            }
        }
    }

    let connected_peers = state.peers.iter().filter(|p| p.connected).count();
    let bot_ids: Vec<String> = state
        .bot_clients()
        .into_iter()
        .map(|i| state.clients[i].id.clone())
        .collect();
    let active_bots = bot_ids.len();
    let bot_uuid_list = if bot_ids.is_empty() {
        "-".to_string()
    } else {
        trunc_string(&bot_ids.join(","), MAX_BUFFER)
    };

    let final_packet = format!(
        "{connected_peers}:{}:{active_bots}:{bot_uuid_list}|{payload}",
        state.peers.len()
    );
    if final_packet.len() >= MAX_BUFFER {
        return;
    }
    let payload_len = final_packet.len().min(MAX_BUFFER - 100);
    let body = &final_packet.as_bytes()[..payload_len];

    // Mesh-state gossip is best-effort and goes through the BULK lane.  A
    // single coalesce key per (origin_hub_uuid, "mesh_state") collapses
    // repeated gossip into the most recent payload if a peer is briefly
    // backed up, so we never queue stale snapshots ahead of fresh ones.
    let coalesce = format!("{}|mesh_state", state.hub_uuid);
    for ci in state.peer_clients() {
        let Some(mut m) = QueuedMsg::new(CMD_MESH_STATE, Lane::Bulk, body) else {
            continue;
        };
        let seq = state.next_lamport_seq();
        let hub_uuid = state.hub_uuid.clone();
        m.set_coalesce(&hub_uuid, seq, &coalesce);
        queue::enqueue(&mut state.clients[ci], m);
    }
}

/// process_mesh_state(): record a peer's snapshot and learn its identity.
pub fn process_mesh_state(state: &mut HubState, ci: usize, payload: &str) {
    // <connected>:<total>:<bots>:...
    let head: Vec<&str> = payload.splitn(4, ':').collect();
    if head.len() < 2
        || crate::cstr::strtoll(head[0]).1 == 0
        || crate::cstr::strtoll(head[1]).1 == 0
    {
        return;
    }
    let fd = state.clients[ci].fd;
    let Some(pi) = state.peers.iter().position(|p| p.connected && p.fd == fd) else {
        return;
    };
    state.peers[pi].last_mesh_report = now();
    state.peers[pi].last_gossip = trunc_string(payload, MAX_BUFFER);

    // Gossip shape: connected:total:bots:bot_list|ip:port:uuid:friendly_name|...
    let Some(bar) = payload.find('|') else { return };
    let mesh_start = &payload[bar + 1..];
    // Parse: ip:port:uuid:friendly_name|
    let f: Vec<&str> = mesh_start.splitn(4, ':').collect();
    // As C's "%255[^:]:%d:...": nothing past a port that is not a number.
    let port_ok = f.len() >= 2 && {
        let (_, m) = crate::cstr::strtoll(f[1]);
        m > 0 && m == f[1].len()
    };
    if f.len() < 3 || !port_ok {
        return;
    }
    let remote_uuid = trunc_string(f[2], 64);
    let remote_name = if f.len() >= 4 {
        trunc_string(
            match f[3].find('|') {
                Some(i) => &f[3][..i],
                None => f[3],
            },
            64,
        )
    } else {
        String::new()
    };

    let mut config_updated = false;

    // Update friendly_name if it changed (and is a well-formed name: it is
    // written to our config and shown to operators).
    if !remote_name.is_empty()
        && remote_name != "-"
        && crate::state::name_valid(&remote_name)
        && state.peers[pi].friendly_name != remote_name
    {
        state.peers[pi].friendly_name = remote_name.clone();
        crate::hlog_debug!("[MESH] Updated peer friendly_name to: {remote_name}\n");
        config_updated = true;
    }

    // Fill in the uuid only for a peer we hold none for.  A linked peer
    // proved the uuid we hold in its handshake; gossip proves nothing.
    // Rewriting it let a peer take another hub's identity (that hub's own
    // handshake then checked the wrong key) and wrote the unchecked text into
    // the config's peer| line.
    if state.peers[pi].uuid.is_empty() && crate::cstr::is_uuid(&remote_uuid) {
        state.peers[pi].uuid = remote_uuid.clone();
        crate::hlog_debug!(
            "[MESH] Updated peer UUID to: {remote_uuid}\n",
            remote_uuid = state.who('h', &remote_uuid)
        );
        config_updated = true;
    }

    if config_updated {
        state.config_dirty = true;
    }
}

// ---------------------------------------------------------------------------
// Sync fan-out
// ---------------------------------------------------------------------------

/// The opcode a config broadcast goes to peer `ci` under: CMD_PEER_BCAST
/// when its gossip shows it knows the opcode (it sends l| lines), else the
/// CMD_PEER_SYNC every hub understands.
fn sync_bcast_opcode(state: &HubState, ci: usize) -> u8 {
    let cu = crate::upgrade::peer_uuid_of(state, ci);
    let knows = !cu.is_empty() && state.mesh_hubs.iter().any(|h| h.uuid == cu && h.have_links);
    if knows { CMD_PEER_BCAST } else { CMD_PEER_SYNC }
}

/// Whether peer `ci` is known current: 2 = MESH_MIN_VERSION or newer, 1 =
/// known older (its link is being refused), 0 = not known yet (its version
/// arrives with its first roster).  Config sync flows only at 2: an older hub
/// does not know uf| / uc| and would over-trust every restricted user.  C
/// `peer_version_level`.
pub fn peer_version_level(state: &HubState, ci: usize) -> u8 {
    let cu = crate::upgrade::peer_uuid_of(state, ci);
    if cu.is_empty() {
        return 0;
    }
    let mut ver = state
        .peers
        .iter()
        .find(|p| p.uuid == cu)
        .map(|p| p.remote_version.clone())
        .unwrap_or_default();
    if ver.is_empty()
        && let Some(h) = state.mesh_hubs.iter().find(|h| h.uuid == cu)
    {
        ver = h.version.clone();
    }
    if ver.is_empty() {
        return 0;
    }
    if crate::update::version_cmp(&ver, MESH_MIN_VERSION) != std::cmp::Ordering::Less {
        2
    } else {
        1
    }
}

/// One sync payload onto peer `ci`'s queue (every sync to a peer goes
/// through it).  Held, not sent, while the peer's version is not known:
/// `peer_sync_release` sends the full state once it is.  C
/// `hub_peer_enqueue_sync`.
pub fn peer_enqueue_sync(
    state: &mut HubState,
    ci: usize,
    op: u8,
    lane: Lane,
    payload: &str,
    coalesce: Option<(&str, u64)>,
) {
    let level = peer_version_level(state, ci);
    if level < 2 {
        if level == 0 {
            state.clients[ci].sync_held = true;
        }
        return;
    }
    if payload.is_empty() {
        return;
    }
    let Some(mut m) = QueuedMsg::new(op, lane, payload.as_bytes()) else {
        return;
    };
    if let Some((key, seq)) = coalesce {
        let hub_uuid = state.hub_uuid.clone();
        m.set_coalesce(&hub_uuid, seq, key);
    }
    if !queue::enqueue(&mut state.clients[ci], m) {
        // Only URGENT can fail here; PEER_SYNC is DELTA/BULK so this is
        // effectively unreachable, but be safe.
        crate::hlog_warning!("[MESH] enqueue failed for peer {}\n", state.clients[ci].ip);
    }
}

/// Peer `ci`'s roster just named a current version: everything held while
/// it was unknown goes now, as one full sync, and a CMD_SYNC_REQUEST fetches
/// the state it sent meanwhile (dropped unread, see the dispatch).  C
/// `hub_peer_sync_release`.
pub fn peer_sync_release(state: &mut HubState, ci: usize) {
    if !state.clients[ci].sync_held || peer_version_level(state, ci) != 2 {
        return;
    }
    state.clients[ci].sync_held = false;
    let full = generate_sync_packet(state);
    let seq = state.next_lamport_seq();
    peer_enqueue_sync(
        state,
        ci,
        CMD_PEER_SYNC,
        Lane::Bulk,
        &full,
        Some(("handshake_sync", seq)),
    );
    queue::send_urgent(&mut state.clients[ci], CMD_SYNC_REQUEST, "");
    crate::uhist::send_digest(state, ci);
    crate::upgrade::plan_send_digest(state, ci);
    crate::hlog_debug!(
        "[MESH] Peer {} is current: held sync sent, its own requested\n",
        state.clients[ci].ip
    );
}

/// split_horizon_sender(): the peers the peer on `from_fd` is linked to right
/// now, if its link report is fresh enough to trust for a split horizon (sent
/// the moment a link changes, refreshed every BOT_PRESENCE_INTERVAL).  It
/// sent its flood to each of them directly.
/// The list must be fresh and have come over this link: one from before it came
/// up describes the mesh before a cut.  A listed peer counts only when its own
/// list, when fresh, lists the sender online too: a link one side still lists may
/// already be down.
pub fn split_horizon_links(state: &HubState, from_fd: i32) -> Option<Vec<String>> {
    let now_ts = now();
    let ci = state
        .peer_clients()
        .into_iter()
        .find(|&ci| state.clients[ci].fd == from_fd)?;
    let since = state.clients[ci].connected_at;
    let u = crate::upgrade::peer_uuid_of(state, ci);
    if u.is_empty() {
        return None;
    }
    let fresh =
        |h: &crate::state::MeshHub| h.have_links && now_ts - h.links_at <= SYNC_SPLIT_HORIZON_FRESH;
    let h = state
        .mesh_hubs
        .iter()
        .find(|h| h.uuid == u && fresh(h) && h.links_at >= since)?;
    Some(
        h.links
            .iter()
            .filter(|l| l.online)
            .filter(
                |l| match state.mesh_hubs.iter().find(|p| p.uuid == l.uuid) {
                    Some(p) if fresh(p) => p.links.iter().any(|x| x.uuid == h.uuid && x.online),
                    _ => true,
                },
            )
            .map(|l| l.uuid.clone())
            .collect(),
    )
}

// Sync tracing (debug): a delta's path through the mesh, record by record,
// so a lost or leaked record can be followed hub to hub.  Frames longer than
// SYNC_TRACE_MAX_LINES are full-state syncs and are not traced.
const SYNC_TRACE_MAX_LINES: usize = 16;
const SYNC_TRACE_LINE: usize = 120;

fn sync_trace_lines(payload: &str) -> usize {
    payload.matches('\n').count() + usize::from(!payload.is_empty() && !payload.ends_with('\n'))
}

/// Append peer ci's name to a ", "-separated list (C: a char[256]).
fn sync_trace_name(list: &mut String, state: &HubState, ci: usize) {
    let c = &state.clients[ci];
    let name = if c.id.is_empty() { &c.ip } else { &c.id };
    let sep = if list.is_empty() { "" } else { ", " };
    let joined = format!("{list}{sep}{name}");
    *list = trunc_string(&joined, 256);
}

/// One config payload to every authenticated peer except `exclude_fd`.
/// `split`: the payload is a forward of a CMD_PEER_BCAST the peer on
/// `exclude_fd` sent us, so the split horizon may apply (see CMD_PEER_BCAST).
/// `coalesce`: queue coalescing (key, seq) for a single-key delta.
pub fn sync_send_to_peers(
    state: &mut HubState,
    payload: &str,
    exclude_fd: i32,
    split: bool,
    lane: Lane,
    coalesce: Option<(&str, u64)>,
) {
    // Change 5: a full-state anti-entropy sync can exceed MAX_BUFFER; bound
    // by the sync-payload ceiling so it is never silently dropped here.
    if payload.len() > MAX_SYNC_PAYLOAD - 10 {
        return;
    }
    // The sender's links, if we may trust them: its report is fresh (sent the
    // moment a link changes, refreshed every BOT_PRESENCE_INTERVAL).  A peer
    // it is linked to right now got this frame from it directly.  A copy lost
    // to a link that dropped in the moment before its gossip said so is what
    // the resync after a link loss and the periodic anti-entropy repair.
    let sender_links = if split {
        split_horizon_links(state, exclude_fd)
    } else {
        None
    };
    let mut skipped = 0;
    let (mut to, mut skip, mut held) = (String::new(), String::new(), String::new());
    for ci in state.peer_clients() {
        if state.clients[ci].fd == exclude_fd {
            continue;
        }
        if let Some(links) = &sender_links {
            let cu = crate::upgrade::peer_uuid_of(state, ci);
            if !cu.is_empty() && links.contains(&cu) {
                skipped += 1;
                sync_trace_name(&mut skip, state, ci);
                continue;
            }
        }
        if peer_version_level(state, ci) == 2 {
            sync_trace_name(&mut to, state, ci);
        } else {
            sync_trace_name(&mut held, state, ci);
        }
        let op = sync_bcast_opcode(state, ci);
        peer_enqueue_sync(state, ci, op, lane, payload, coalesce);
    }
    if skipped > 0 {
        crate::hlog_debug!("[MESH] Forward skipped {skipped} peer(s) the sender reaches itself\n");
    }
    // Where a delta went (a full-state sync is too big and too routine).
    let lines = sync_trace_lines(payload);
    if lines <= SYNC_TRACE_MAX_LINES {
        let first = trunc(payload.split('\n').next().unwrap_or(""), SYNC_TRACE_LINE);
        let how = if split {
            "bcast forward"
        } else if exclude_fd != -1 {
            "forward"
        } else {
            "own change"
        };
        let or_dash = |l: &str| {
            if l.is_empty() {
                "-".to_string()
            } else {
                l.to_string()
            }
        };
        crate::hlog_debug!(
            "[MESH] Sync {how}, {lines} line(s) [{first}]: to {}; skipped {}; held {}\n",
            or_dash(&to),
            or_dash(&skip),
            or_dash(&held)
        );
    }
}

/// Lane heuristic: a single-line payload originating from a delta forward is
/// short (< 1 KB) and time-sensitive, so it rides DELTA and is not throttled
/// by the BULK budget.  Larger, multi-line payloads (an anti-entropy full
/// sync) ride BULK.
fn sync_lane(payload: &str) -> Lane {
    if payload.len() > 1024 {
        Lane::Bulk
    } else {
        Lane::Delta
    }
}

/// hub_broadcast_sync_to_peers().
pub fn broadcast_sync_to_peers(state: &mut HubState, payload: &str, exclude_fd: i32) {
    sync_send_to_peers(state, payload, exclude_fd, false, sync_lane(payload), None);
}

/// A forward of what we accepted from a peer's frame.  `bcast`: that frame
/// was a CMD_PEER_BCAST, so the split horizon applies.
fn sync_forward_to_peers(state: &mut HubState, payload: &str, origin_fd: i32, bcast: bool) {
    sync_send_to_peers(state, payload, origin_fd, bcast, sync_lane(payload), None);
}

/// hub_request_sync_from_peers(): ask every peer for its full state now.
pub fn request_sync_from_peers(state: &mut HubState) {
    let mut sent = 0;
    let mut i = 0;
    while i < state.clients.len() {
        let c = &state.clients[i];
        if c.typ == ClientType::Hub && c.authenticated {
            if queue::send_urgent(&mut state.clients[i], CMD_SYNC_REQUEST, "") {
                sent += 1;
            } else {
                crate::auth::disconnect_client(state, i);
                continue;
            }
        }
        i += 1;
    }
    if sent > 0 {
        crate::hlog_debug!("[MESH] Sent sync request to {sent} peer(s)\n");
    }
}

/// hub_generate_sync_packet(): this hub's full state, for anti-entropy.
pub fn generate_sync_packet(state: &HubState) -> String {
    let max_len = MAX_SYNC_PAYLOAD;
    let mut out = String::with_capacity(4096);

    // 1. Global entries (c, m, o, a, p).
    //    h/n/w/x are hub-only local metadata and never belong here:
    //      - h/n: hub name/bind settings (shouldn't exist in global_entries)
    //      - w/x: allowlist/denylist, kept local
    //    Bot-specific h/n (b|uuid|h|..., b|uuid|n|...) go in the bot loop.
    for e in &state.global_entries {
        if matches!(
            e.key.as_str(),
            "h" | "n" | "w" | "x" | "a" | "o" | "m" | "p"
        ) {
            continue;
        }
        let line = format!("{}|{}|{}\n", e.key, e.value, e.timestamp);
        if out.len() + line.len() >= max_len {
            break;
        }
        out.push_str(&line);
    }
    // K|: what the bots saw on IRC, after the c| lines it hangs off.
    storage::learned_append(state, &mut out);

    // User records, so peer hubs share admin/oper records, in the
    // passwordless shape uuid|name|pubkey|act|seen|ts| (peers are HUBv3, so
    // they parse it).
    for u in &state.user_records {
        let line = config::format_user_record(u);
        if out.len() + line.len() >= max_len {
            break;
        }
        out.push_str(&line);
    }
    for m in &state.mask_records {
        let line = format!(
            "m|{}|{}|{}|{}|{}\n",
            m.uuid,
            m.mask,
            if m.is_active { "add" } else { "del" },
            m.last_used,
            m.timestamp
        );
        if out.len() + line.len() >= max_len {
            break;
        }
        out.push_str(&line);
    }

    // Admin flags and oper channel bindings, after the users they name.
    let mut acc = String::new();
    access::append(state, &mut acc, None);
    if out.len() + acc.len() < max_len {
        out.push_str(&acc);
    }

    // The network opt flag string (peers must converge on this).
    if state.opt_flags_ts > 0 {
        let line = format!("opt|{}|{}\n", state.opt_flags, state.opt_flags_ts);
        if out.len() + line.len() < max_len {
            out.push_str(&line);
        }
    }

    // Mesh-wide settings and the revoke list.
    let mut rv = String::new();
    crate::revoke::gsetting_append(state, &mut rv);
    crate::revoke::append(state, &mut rv);
    if out.len() + rv.len() < max_len {
        out.push_str(&rv);
    }

    // 2. Bot entries.
    'outer: for b in &state.bots {
        for e in &b.entries {
            // "seen" and "t" carry no value field.
            let line = if e.key == "seen" || e.key == "t" {
                format!("b|{}|{}|{}\n", b.uuid, e.key, e.timestamp)
            } else {
                format!("b|{}|{}|{}|{}\n", b.uuid, e.key, e.value, e.timestamp)
            };
            if out.len() + line.len() >= max_len {
                break 'outer;
            }
            out.push_str(&line);
        }
    }
    out
}

// ---------------------------------------------------------------------------
// Global entry helpers
// ---------------------------------------------------------------------------

fn is_global_key(key: &str) -> bool {
    matches!(
        key,
        "c" | "m" | "o" | "a" | "p"
        // 2.4.5: channel settings, network defaults, bans
        | "C" | "D" | "B"
    )
}

/// Store a global entry directly, without re-formatting: the value that
/// arrived over the wire is already combined.
fn store_global_entry_raw(state: &mut HubState, key: &str, value: &str, ts: i64) -> bool {
    // C|, D|, B|: one validator, one LWW, one set of ceilings.
    if matches!(key, "C" | "D" | "B") {
        return storage::put_record(state, key, value, ts);
    }

    if let Some(i) = storage::global_find(state, key, value) {
        let g = &state.global_entries[i];
        // A channel keeps the spelling of its first writer (D39).
        let mut norm = value.to_string();
        if key == "c" {
            let sl = g.value.find('|').unwrap_or(g.value.len());
            if let Some(bar) = value.find('|')
                && sl + value[bar..].len() < 1024
            {
                norm = format!("{}{}", &g.value[..sl], &value[bar..]);
            }
        }
        if lww_accepts(
            ts,
            global_value_active(&norm),
            g.timestamp,
            global_value_active(&g.value),
        ) {
            let norm = trunc_string(&norm, 1024);
            let removed = key == "c" && !global_value_active(&norm);
            state.global_entries[i].value = norm.clone();
            state.global_entries[i].timestamp = ts;
            if removed {
                let chan = trunc_string(norm.split('|').next().unwrap_or(""), MAX_CHAN);
                storage::chan_cascade_del(state, &chan, ts, false);
            }
            return true;
        }
        return false;
    }

    // Add new entry (a tombstone older than the last purge is not re-created)
    if crate::state::ts_ahead(ts) {
        return false;
    }
    if !global_value_active(value) && storage::purge_floor_blocks(state, ts) {
        return false;
    }
    if storage::global_room(state, key) {
        state.global_entries.push(ConfigEntry {
            key: trunc_string(key, 32),
            value: trunc_string(value, 1024),
            timestamp: ts,
            last_used: 0,
        });
        storage::global_note_new(state, state.global_entries.len() - 1);
        return true;
    }
    false
}

/// Split a stored global 'c' entry value into its parts.
///
/// Two shapes exist because two writers produce them:
///   3-field  `chan|key|op`        — CMD_ADMIN_ADD/DEL_CHANNEL and legacy
///   4-field  `chan|key|modes|op`  — a bot's config push (bots report modes)
///
/// Both share the same anchors — the channel is the first field, the op is
/// the last — so this splits on those instead of counting fields.  Whatever
/// sits between is the key, optionally followed by the modes.  Reading the op
/// as the *last* field is what makes the "del" tombstone check reliable
/// across both shapes: a positional parse reads "0|del" as the op on the
/// 4-field form and treats a deleted channel as live.
///
/// None only when the value has no '|' at all.
pub fn parse_global_channel_value(value: &str) -> Option<(String, String, i32, String)> {
    let first = value.find('|')?;
    let last = value.rfind('|')?;
    let chan = value[..first].to_string();
    let op = value[last + 1..].to_string();
    let mut key = String::new();
    let mut modes = 0i32;
    if last > first {
        // Middle field(s): "key" (3-field) or "key|modes" (4-field).
        let middle = trunc_string(&value[first + 1..last], 128);
        match middle.rfind('|') {
            Some(sep) => {
                modes = crate::cstr::atoi(&middle[sep + 1..]);
                key = middle[..sep].to_string();
            }
            None => key = middle,
        }
    }
    Some((chan, key, modes, op))
}

/// Modes currently recorded for a channel, or 0 when unknown.
///
/// The admin add path has no modes of its own — they only ever arrive from a
/// bot reporting a live MODE change — so a re-add must carry forward what is
/// already stored.  Global entries are overwritten wholesale once the
/// timestamp wins, so not carrying them forward erases them.  Matched
/// ASCII case-insensitively on the channel name (D39), same as the storage
/// layer.
pub fn global_channel_modes(state: &HubState, chan: &str) -> i32 {
    // The +k/+i the bots last saw (K|), 0 when no bot has reported the
    // channel.
    storage::learned_find(state, chan).map_or(0, |l| l.modes)
}

// ---------------------------------------------------------------------------
// Peer sync ingest
// ---------------------------------------------------------------------------

/// The state one line of a peer sync may change.
struct SyncCounters {
    updates: u32,
    /// Only keys bots actually consume; gates the full config push.
    bot_push_updates: u32,
    forward: String,
    /// Sync tracing: the frame's opcode name, its sender, and whether it is
    /// a delta (refused records are logged too) rather than a full sync.
    frame: &'static str,
    from: String,
    trace: bool,
}

/// One `a|`/`o|` record from a peer.
fn sync_user_record(state: &mut HubState, key: char, vstart: &str, cnt: &mut SyncCounters) {
    // hub_parse_user_record: uuid|name|pubkey|act|seen|ts|
    let Some(incoming) = config::parse_user_record(vstart, key) else {
        return;
    };
    let mut found = state
        .user_records
        .iter()
        .position(|u| u.uuid == incoming.uuid);
    let mut discard_incoming = false;

    if found.is_none() && incoming.is_active {
        // No UUID match — two LIVE records of one name are the same user
        // created on two hubs at once: merge them.  A tombstone is never
        // merged by name: it is a past incarnation (add, del, add again) and
        // keeps its own uuid, as on the hub that made it.
        if let Some(ni) = state.user_records.iter().position(|ex| {
            ex.is_active && ex.typ == key && ex.name.eq_ignore_ascii_case(&incoming.name)
        }) {
            let ex = &state.user_records[ni];
            let incoming_wins = incoming.last_seen > ex.last_seen
                || (incoming.last_seen == ex.last_seen && incoming.timestamp > ex.timestamp)
                || (incoming.last_seen == ex.last_seen
                    && incoming.timestamp == ex.timestamp
                    && incoming.uuid < ex.uuid);
            if incoming_wins {
                crate::hlog_info!(
                    "[MESH] Dedup: '{}' ({key}) UUID collision resolved, adopting {}\n",
                    incoming.name,
                    state.who('u', &incoming.uuid)
                );
                let old_uuid = state.user_records[ni].uuid.clone();
                // Remap the existing record's masks, flags and channel
                // bindings to the incoming UUID.
                access::remap_uuid(state, &old_uuid, &incoming.uuid);
                for m in state.mask_records.iter_mut().filter(|m| m.uuid == old_uuid) {
                    m.uuid = incoming.uuid.clone();
                }
                // Update the user record's own UUID so the next sync finds it
                // by UUID lookup and skips the name-collision path.
                state.user_records[ni].uuid = incoming.uuid.clone();
                state.config_dirty = true;
                found = Some(ni);
            } else {
                discard_incoming = true;
            }
        }
    }

    if found.is_none()
        && !discard_incoming
        && state.user_records.len() < MAX_HUB_USER_RECORDS
        && !crate::state::ts_ahead(incoming.timestamp)
        && (incoming.is_active || !storage::purge_floor_blocks(state, incoming.timestamp))
    {
        state.user_records.push(UserRecord {
            uuid: incoming.uuid.clone(),
            ..Default::default()
        });
        found = Some(state.user_records.len() - 1);
    }

    let Some(ui) = found else { return };
    if discard_incoming {
        return;
    }
    let cur = &state.user_records[ui];
    if !lww_accepts(
        incoming.timestamp,
        incoming.is_active,
        cur.timestamp,
        cur.is_active,
    ) {
        // Activity repair, outside LWW: not an update.
        crate::activity::raise(state, crate::activity::Slot::User(ui), incoming.last_seen);
        return;
    }
    let u = &mut state.user_records[ui];
    u.name = incoming.name;
    u.typ = key;
    u.is_active = incoming.is_active;
    if incoming.last_seen > u.last_seen {
        u.last_seen = incoming.last_seen;
    }
    u.timestamp = incoming.timestamp;
    // A keyless push never erases a key the hub already holds.
    if incoming.has_pubkey {
        u.pubkey_b64 = incoming.pubkey_b64;
        u.has_pubkey = true;
    }
    state.config_dirty = true;
    cnt.updates += 1;
    cnt.bot_push_updates += 1; // admin/oper name change — bots need this

    // Forward our canonical a|/o| line, never the raw one.
    let uline = config::format_user_record(&state.user_records[ui]);
    if uline.len() < USER_LINE_MAX && cnt.forward.len() + uline.len() < MAX_SYNC_PAYLOAD {
        cnt.forward.push_str(&uline);
    }
}

/// One `m|` record from a peer: `uuid|mask|add/del|last_used|ts`.
fn sync_mask_record(state: &mut HubState, vstart: &str, line: &str, cnt: &mut SyncCounters) {
    let f = split_fields(vstart, 5);
    if f.len() < 5 {
        return;
    }
    let uuid = trunc_string(f[0], 37);
    let mask = trunc_string(f[1], MAX_MASK_LEN);
    let act = trunc_string(f[2], 8);
    let last_used = atoll(f[3]);
    let ts = atoll(f[4]);
    let is_active = act.starts_with("add");

    // Reject masks for unknown user UUIDs.
    if !state.user_records.iter().any(|u| u.uuid == uuid) {
        return;
    }
    let found = state
        .mask_records
        .iter()
        .position(|m| m.uuid == uuid && m.mask.eq_ignore_ascii_case(&mask));
    let mi = match found {
        Some(i) => i,
        None if state.mask_records.len() < MAX_HUB_USER_MASKS
            && !crate::state::ts_ahead(ts)
            && (is_active || !storage::purge_floor_blocks(state, ts)) =>
        {
            state.mask_records.push(MaskRecord {
                uuid,
                mask,
                ..Default::default()
            });
            state.mask_records.len() - 1
        }
        None => return,
    };
    let cur = &state.mask_records[mi];
    if !lww_accepts(ts, is_active, cur.timestamp, cur.is_active) {
        // Activity repair, outside LWW: not an update.
        crate::activity::raise(state, crate::activity::Slot::Mask(mi), last_used);
        return;
    }
    let m = &mut state.mask_records[mi];
    m.is_active = is_active;
    if last_used > m.last_used {
        m.last_used = last_used;
    }
    m.timestamp = ts;
    state.config_dirty = true;
    cnt.updates += 1;
    cnt.bot_push_updates += 1; // mask record — bots need this
    if cnt.forward.len() + line.len() + 1 < MAX_SYNC_PAYLOAD {
        cnt.forward.push_str(line);
        cnt.forward.push('\n');
    }
}

/// One `b|uuid|key|value|ts` (or `b|uuid|seen|ts`) record from a peer.
fn sync_bot_entry(state: &mut HubState, ptr: &str, cnt: &mut SyncCounters) {
    let Some(p1) = ptr.find('|') else { return };
    let uuid = trunc_string(&ptr[..p1], 64);
    let rest = &ptr[p1 + 1..];
    let Some(p2) = rest.find('|') else { return };
    let key = trunc_string(&rest[..p2], 32);
    let tail = &rest[p2 + 1..];

    let p3 = tail.rfind('|');
    // seen/t entries are 3-field: b|uuid|key|timestamp (no value).  When
    // there is no further '|' the timestamp sits at the start of `tail` and
    // the value is empty.
    if p3.is_none() && (key == "seen" || key == "t") {
        let ts = atoll(tail);
        if storage::update_entry(state, &uuid, &key, "", "", "", ts) {
            cnt.updates += 1;
            let line = format!("b|{uuid}|{key}|{ts}\n");
            if cnt.forward.len() + line.len() < MAX_SYNC_PAYLOAD {
                cnt.forward.push_str(&line);
            }
        }
        return;
    }
    let Some(p3) = p3 else { return };
    let val = trunc_string(&tail[..p3], 1024);
    let ts = atoll(&tail[p3 + 1..]);

    // For c/m/o keys, parse the combined value format.  The split works on a
    // copy: `val` itself is re-forwarded to the other peers below and must
    // leave exactly as it arrived.  Splitting it in place forwarded
    // "b|uuid|c|#chan|ts" — no key, modes or op — which the next hub stored
    // as an add, turning deletes into adds one hop out.
    let mut parsed_val = String::new();
    let mut parsed_extra = String::new();
    let mut parsed_op = String::new();
    if key == "c" || key == "o" {
        // chan|key[|modes]|op: first pipe gives chan, last pipe gives op,
        // everything between is extra.
        if let Some(vp1) = val.find('|') {
            parsed_val = trunc_string(&val[..vp1], 512);
            let rest = &val[vp1 + 1..];
            if let Some(last) = rest.rfind('|') {
                parsed_op = trunc_string(&rest[last + 1..], 16);
                parsed_extra = trunc_string(&rest[..last], 256);
            }
        }
    } else if key == "m" {
        // value|op
        if let Some(vp1) = val.find('|') {
            parsed_val = trunc_string(&val[..vp1], 512);
            parsed_op = trunc_string(&val[vp1 + 1..], 16);
        }
    }
    // For other keys (pub, h, n, ...) parsed_val stays empty so the original
    // value is stored as is.
    let store_val = if parsed_val.is_empty() {
        val.as_str()
    } else {
        parsed_val.as_str()
    };

    let stored =
        storage::update_entry(state, &uuid, &key, store_val, &parsed_extra, &parsed_op, ts);
    if stored || cnt.trace {
        crate::hlog_debug!(
            "[MESH] {} from {}: {} {key}|{val}|{ts} -> {}\n",
            cnt.frame,
            cnt.from,
            state.who('b', &uuid),
            if stored { "applied" } else { "refused" }
        );
    }
    if stored {
        cnt.updates += 1;
        // seen/t are hub-side metadata; bots don't consume them.
        if key != "seen" && key != "t" {
            cnt.bot_push_updates += 1;
        }
        let line = format!("b|{uuid}|{key}|{val}|{ts}\n");
        if cnt.forward.len() + line.len() + 1200 < MAX_SYNC_PAYLOAD {
            cnt.forward.push_str(&line);
        }
    }
}

/// process_peer_sync(): apply one CMD_PEER_SYNC payload and re-forward what
/// it actually changed.
pub fn process_peer_sync(state: &mut HubState, payload: &str, origin_fd: i32, bcast: bool) {
    // Sync tracing: every record applied is logged, and in a delta (not a
    // full-state sync) every record refused too.
    let mut cnt = SyncCounters {
        updates: 0,
        bot_push_updates: 0,
        forward: String::new(),
        frame: if bcast { "PEER_BCAST" } else { "PEER_SYNC" },
        from: state
            .client_by_fd(origin_fd)
            .map(|ci| state.who_client(ci))
            .unwrap_or_else(|| "?".into()),
        trace: sync_trace_lines(payload) <= SYNC_TRACE_MAX_LINES,
    };
    crate::stats::sync_frame();

    // Borrowed, not copied: the frame is already one of several copies
    // (review 2026-10-25 #25).
    for line in trunc(payload, MAX_SYNC_PAYLOAD).split('\n') {
        if line.is_empty() {
            continue;
        }
        crate::stats::sync_record();

        if line.starts_with("PURGE|") {
            match parse_purge_line(line) {
                None => crate::hlog_warning!("[MESH] Dropped malformed PURGE line from peer\n"),
                Some((cutoff, purge_id)) => {
                    let shown = if purge_id.is_empty() { "-" } else { &purge_id };
                    crate::hlog_info!(
                        "[MESH] Received PURGE from peer: cutoff={cutoff} id={shown}\n"
                    );
                    if is_purge_recent(state, cutoff, &purge_id) {
                        crate::hlog_debug!(
                            "[MESH] PURGE cutoff={cutoff} id={shown} already processed recently, skipping to prevent loop\n"
                        );
                    } else {
                        record_recent_purge(state, cutoff, &purge_id);
                        let purged = execute_purge(state, cutoff, None);
                        if purged > 0 {
                            crate::hlog_info!("[MESH] Purged {purged} entries from peer sync\n");
                            cnt.updates += purged as u32;
                        }
                        // Forward to all other peers (excluding the sender to
                        // prevent an immediate echo; with the dedup above
                        // that closes the feedback loop).
                        if origin_fd != -1 {
                            sync_forward_to_peers(state, line, origin_fd, bcast);
                        }
                    }
                }
            }
            continue;
        }

        // uf| / uc|: admin flags and oper channel bindings (access.rs), for
        // users this hub holds (their a| / o| lines come first in every sync).
        if let Some(body) = line
            .strip_prefix("uf|")
            .or_else(|| line.strip_prefix("uc|"))
        {
            if access::ingest(state, line.as_bytes()[1] as char, body, true) == Some(true) {
                cnt.updates += 1;
                cnt.bot_push_updates += 1;
                if cnt.forward.len() < MAX_SYNC_PAYLOAD - UC_LINE_MAX {
                    cnt.forward.push_str(line);
                    cnt.forward.push('\n');
                }
            }
            continue;
        }

        // K|chan|key|modes|ts: what the bots saw on IRC.  Taken only while
        // the channel is managed here; its c| line comes first in every sync.
        if let Some(body) = line.strip_prefix("K|") {
            if storage::learned_ingest(state, body) {
                cnt.updates += 1;
                cnt.bot_push_updates += 1;
                state.config_dirty = true;
                if cnt.forward.len() < MAX_SYNC_PAYLOAD - K_LINE_MAX {
                    cnt.forward.push_str(line);
                    cnt.forward.push('\n');
                }
            }
            continue;
        }

        // 'opt|<letters>|<ts>' from peer hubs (mesh-replicated opt flags),
        // including the 'opt||<ts>' of a clear.  Adopt it if newer than ours.
        if let Some(body) = line.strip_prefix("opt|") {
            if let Some((flags, ts)) = config::parse_opt_value(body)
                && opt_accepts(ts, &flags, state.opt_flags_ts, &state.opt_flags)
            {
                state.opt_flags = flags;
                state.opt_flags_ts = ts;
                state.config_dirty = true;
                cnt.updates += 1;
                cnt.bot_push_updates += 1;
                if cnt.forward.len() + line.len() + 64 < MAX_SYNC_PAYLOAD {
                    cnt.forward.push_str(line);
                    cnt.forward.push('\n');
                }
            }
            continue;
        }

        // hs|<name>|<value>|<ts>: a mesh-wide hub setting (revoke).
        if let Some(body) = line.strip_prefix("hs|") {
            if crate::revoke::gsetting_ingest(state, body) == Some(true) {
                cnt.updates += 1;
                if cnt.forward.len() + HS_LINE_MAX < MAX_SYNC_PAYLOAD {
                    cnt.forward.push_str(line);
                    cnt.forward.push('\n');
                }
            }
            continue;
        }

        // rv|...: a revoked bot, union-merged (revoke).
        if let Some(body) = line.strip_prefix("rv|") {
            match crate::revoke::parse(body) {
                None => crate::hlog_warning!("[MESH] Dropped malformed rv| line from peer\n"),
                Some(rv) => {
                    if crate::revoke::merge(state, &rv) {
                        cnt.updates += 1;
                        if cnt.forward.len() + RV_LINE_MAX < MAX_SYNC_PAYLOAD
                            && let Some(r) = crate::revoke::find(state, &rv.uuid)
                        {
                            cnt.forward.push_str(&crate::revoke::format(r));
                        }
                    }
                }
            }
            continue;
        }

        // A global entry (key|value|timestamp), i.e. not starting with "b|".
        if !line.starts_with("b|")
            && let Some(p1) = line.find('|')
            && p1 < 32
        {
            let key = &line[..p1];
            if is_global_key(key) {
                let vstart = &line[p1 + 1..];
                let is_user_key = key == "a" || key == "o";
                let is_mask_key = key == "m";

                // Detect the new-format user/mask records by a UUID in the
                // first value field:
                //   a|uuid|name|pubkey|add/del|last_seen|ts|
                //   m|uuid|mask|add/del|last_used|ts
                // Route these to the typed arrays; the old format goes to
                // global_entries.
                let first_f = match vstart.find('|') {
                    Some(i) if i < 40 => &vstart[..i],
                    _ => "",
                };
                let is_new_fmt = crate::cstr::has_uuid_dashes(first_f);

                if is_new_fmt && is_user_key {
                    sync_user_record(state, key.as_bytes()[0] as char, vstart, &mut cnt);
                    continue;
                }
                if is_new_fmt && is_mask_key {
                    sync_mask_record(state, vstart, line, &mut cnt);
                    continue;
                }

                // Retired password-era shapes — the shared bot password p|
                // and the pre-UUID a|<password>|<ts> / o|<mask>|<password>|..
                // rows — are dropped, never stored or forwarded.
                if key == "p" || is_user_key {
                    continue;
                }

                // Old-format or non-user global key: store in global_entries.
                if let Some(p_last) = vstart.rfind('|')
                    && p_last > 0
                {
                    let val = trunc_string(&vstart[..p_last], 1024);
                    let ts = atoll(&vstart[p_last + 1..]);
                    let stored = store_global_entry_raw(state, key, &val, ts);
                    if stored || cnt.trace {
                        crate::hlog_debug!(
                            "[MESH] {} from {}: {key}|{val}|{ts} -> {}\n",
                            cnt.frame,
                            cnt.from,
                            if stored { "applied" } else { "refused" }
                        );
                    }
                    if stored {
                        cnt.updates += 1;
                        cnt.bot_push_updates += 1; // channel/global — bots need this
                        let fwd = format!("{key}|{val}|{ts}\n");
                        if cnt.forward.len() + fwd.len() + 1200 < MAX_SYNC_PAYLOAD {
                            cnt.forward.push_str(&fwd);
                        }
                    }
                }
                continue;
            }
        }

        // Bot entries (b|uuid|key|value|timestamp, or the bare uuid|... form
        // an admin add broadcasts).
        let ptr = line.strip_prefix("b|").unwrap_or(line);
        sync_bot_entry(state, ptr, &mut cnt);
    }

    // Records left on a merged-away uuid go; a user this sync created without
    // uf| / uc| gets its default (access::migrate).
    access::prune(state);
    if access::migrate(state) > 0 {
        cnt.updates += 1;
        cnt.bot_push_updates += 1;
    }
    // Two hubs that each removed a different +a admin before they synced may
    // have left none: undo the race, on every peer including the sender.
    if cnt.updates > 0
        && let Some((floor, _)) = access::admin_floor_restore(state, "a peer sync")
    {
        if !floor.is_empty() {
            broadcast_sync_to_peers(state, &floor, -1);
        }
        cnt.bot_push_updates += 1;
    }

    crate::stats::sync_done(u64::from(cnt.updates));
    if cnt.updates > 0 {
        state.config_dirty = true;
        // A bot this sync deleted that is connected here is told to wipe.
        crate::auth::retire_revoked_bots(state);
        if !cnt.forward.is_empty() {
            sync_forward_to_peers(state, &cnt.forward, origin_fd, bcast);
        }
        if cnt.bot_push_updates > 0 {
            client::broadcast_full_config_to_all_bots(state);
        }
    }
}

// ---------------------------------------------------------------------------
// Tombstone purge
// ---------------------------------------------------------------------------

/// hub_execute_purge(): remove tombstones locally.  `cutoff == 0` purges all
/// tombstones regardless of age; `cutoff > 0` purges those older than it.
/// Peer-hub propagation is the caller's responsibility.
///
/// Returns the count; `tombs` (may be None) gets one
/// tomb|kind|id|name|ts record per tombstone.
pub fn execute_purge(
    state: &mut HubState,
    cutoff: i64,
    mut tombs: Option<&mut crate::reply::Reply>,
) -> i32 {
    // For PURGE_FLOOR_HOLD, a sync built before this purge cannot re-create
    // what it removes.
    storage::purge_floor_set(state, cutoff);
    let mut purged_count = 0;
    // One purged tombstone, for the console.
    let mut note = |kind: &str, id: &str, name: &str, ts: i64| {
        if let Some(r) = tombs.as_deref_mut() {
            r.rec("tomb");
            r.kv("kind", kind);
            if !id.is_empty() {
                r.kv("id", id);
            }
            if !name.is_empty() {
                r.kv("name", name);
            }
            if ts > 0 {
                r.kvi("ts", ts);
            }
        }
    };

    // --- Tombstoned global entries (channels, admin masks, oper masks,
    //     channel settings, bans), compacted in place ---
    let mut kept: Vec<ConfigEntry> = Vec::new();
    for e in std::mem::take(&mut state.global_entries) {
        let is_tombstone = matches!(e.key.as_str(), "c" | "m" | "o" | "C" | "B")
            && e.value.rsplit_once('|').is_some_and(|(_, l)| l == "del");
        if is_tombstone && (cutoff == 0 || e.timestamp < cutoff) {
            purged_count += 1;
            let name = e.value.split('|').next().unwrap_or("");
            let kind = match e.key.as_str() {
                "c" => "channel",
                "m" => "mask",
                "C" => "chanset",
                "B" => "ban",
                _ => "oper",
            };
            note(kind, "", &trunc_string(name, 256), e.timestamp);
        } else {
            kept.push(e);
        }
    }
    state.global_entries = kept;
    storage::global_reindex(state);

    // --- Orphans: live C| / B| (not "*") / K| of a channel no one manages,
    //     whatever the cutoff (every hub and bot applies the same rule) ---
    purged_count +=
        storage::purge_chan_orphans(state, &mut |kind, name, ts| note(kind, "", name, ts)) as i32;

    // --- Tombstoned user_records (admins/opers) ---
    let mut kept_users: Vec<UserRecord> = Vec::new();
    for u in std::mem::take(&mut state.user_records) {
        if !u.is_active && (cutoff == 0 || u.timestamp < cutoff) {
            purged_count += 1;
            note("user", "", &u.name, u.timestamp);
        } else if kept_users.len() < MAX_HUB_USER_RECORDS {
            kept_users.push(u);
        }
    }
    state.user_records = kept_users;

    // --- Tombstoned mask_records, and masks whose user is gone ---
    // A mask with no user record left (its user purged above or earlier) can
    // never authenticate anyone and only holds a slot of the shared table.
    // Such orphans were left live on peers and bots by user deletes that did
    // not send the masks' tombstones; every hub applies the same rule on the
    // same PURGE, so they converge away.
    let mut kept_masks: Vec<MaskRecord> = Vec::new();
    for m in std::mem::take(&mut state.mask_records) {
        let owned = state.user_records.iter().any(|u| u.uuid == m.uuid);
        if !owned || (!m.is_active && (cutoff == 0 || m.timestamp < cutoff)) {
            purged_count += 1;
            note("mask", "", &m.mask, m.timestamp);
        } else if kept_masks.len() < MAX_HUB_USER_MASKS {
            kept_masks.push(m);
        }
    }
    state.mask_records = kept_masks;

    // --- Channel-binding tombstones, and flags / bindings whose user is gone
    //     (a live user's "*" del stays: access::purge) ---
    purged_count += access::purge(state, cutoff) as i32;

    // --- Tombstoned bots (a d|1 entry present, regardless of is_active) ---
    let mut kept_bots = Vec::new();
    for b in std::mem::take(&mut state.bots) {
        let del_ts = b
            .entries
            .iter()
            .find(|e| e.key == "d" && e.value == "1")
            .map(|e| e.timestamp);
        let purge_bot = match del_ts {
            Some(ts) => cutoff == 0 || (ts > 0 && ts < cutoff),
            None => false,
        };
        if purge_bot {
            purged_count += 1;
            note(
                "bot",
                &b.uuid,
                b.entry("n").map_or("", |n| n.value.as_str()),
                del_ts.unwrap_or(0),
            );
        } else if kept_bots.len() < MAX_BOTS {
            kept_bots.push(b);
        }
    }
    state.bots = kept_bots;

    state.config_dirty = true;

    // Local bots: first the purged config, then the PURGE line itself.
    // broadcast_config_to_bots only logs its line and re-sends each bot its
    // full config — that replaces a bot's user/mask tables, but channel
    // tombstones are merged on the bot and only a PURGE| line removes them.
    // The PURGE frame is queued behind the (coalesced) config push on the
    // same lane, so a pre-purge config still queued cannot re-add what it
    // purged.
    let purge_msg = format!("PURGE|{cutoff}\n");
    client::broadcast_config_to_bots(state, &purge_msg);
    for ci in state.bot_clients() {
        let Some(m) = QueuedMsg::new(CMD_CONFIG_DATA, Lane::Bulk, purge_msg.as_bytes()) else {
            crate::hlog_error!("[PURGE] OOM queueing PURGE for {}\n", state.who_client(ci));
            continue;
        };
        if !queue::enqueue(&mut state.clients[ci], m) {
            crate::hlog_warning!(
                "[PURGE] could not queue PURGE for {}\n",
                state.who_client(ci)
            );
        }
    }

    purged_count
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A hub with authenticated peer links s (fd 10), x (fd 11), y (fd 12).
    fn three_peers() -> (HubState, Vec<std::net::TcpListener>) {
        let mut s = HubState::new();
        let mut keep = Vec::new();
        for (fd, uuid) in [(10, "s"), (11, "x"), (12, "y")] {
            let l = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
            let sock = std::net::TcpStream::connect(l.local_addr().unwrap()).unwrap();
            keep.push(l);
            let mut c = crate::state::HubClient::new(sock, fd, "127.0.0.1", MAX_BUFFER);
            c.typ = crate::state::ClientType::Hub;
            c.authenticated = true;
            s.clients.push(c);
            s.peers.push(crate::state::PeerConfig {
                uuid: uuid.into(),
                connected: true,
                fd,
                remote_version: MESH_MIN_VERSION.into(),
                ..Default::default()
            });
        }
        (s, keep)
    }

    #[test]
    fn a_peer_of_unknown_version_gets_no_sync_until_its_roster_names_one() {
        let (mut s, _keep) = three_peers();
        s.peers[0].remote_version.clear();
        let ci = s.clients.iter().position(|c| c.fd == 10).unwrap();
        // Something for the full sync to carry.
        process_peer_sync(&mut s, "b|bot|n|nick|4\n", -1, false);
        peer_enqueue_sync(
            &mut s,
            ci,
            CMD_PEER_SYNC,
            Lane::Bulk,
            "b|bot|n|nick|5\n",
            None,
        );
        assert!(queued(&s, 10).is_empty(), "held while unknown");
        assert!(s.clients[ci].sync_held);
        peer_sync_release(&mut s, ci);
        assert!(queued(&s, 10).is_empty(), "still unknown: still held");
        // Below the floor: never sent, and the hold is not released.
        s.peers[0].remote_version = "2.5.0".into();
        peer_sync_release(&mut s, ci);
        assert!(queued(&s, 10).is_empty(), "an older peer gets nothing");
        // Current: one full sync and a request for theirs.
        s.peers[0].remote_version = MESH_MIN_VERSION.into();
        peer_sync_release(&mut s, ci);
        assert!(!s.clients[ci].sync_held);
        let q = queued(&s, 10);
        assert!(
            q.contains(&CMD_PEER_SYNC) && q.contains(&CMD_SYNC_REQUEST),
            "{q:?}"
        );
    }

    fn queued(s: &HubState, fd: i32) -> Vec<u8> {
        let c = s.clients.iter().find(|c| c.fd == fd).unwrap();
        c.out_lanes
            .iter()
            .flat_map(|l| l.msgs.iter().map(|m| m.cmd))
            .collect()
    }

    #[test]
    fn a_bcast_forward_skips_the_peers_the_sender_reaches_itself() {
        let (mut s, _keep) = three_peers();
        let link = |u: &str, online: bool| crate::state::MeshLink {
            uuid: u.into(),
            name: String::new(),
            online,
        };
        // s says it is linked to x and x agrees; x knows CMD_PEER_BCAST, y has
        // sent no links.
        s.mesh_hubs.push(crate::state::MeshHub {
            uuid: "s".into(),
            have_links: true,
            links_at: now(),
            links: vec![link("x", true)],
            ..Default::default()
        });
        s.mesh_hubs.push(crate::state::MeshHub {
            uuid: "x".into(),
            have_links: true,
            links_at: now(),
            links: vec![link("s", true)],
            ..Default::default()
        });
        sync_forward_to_peers(&mut s, "b|bot|n|nick|5\n", 10, true);
        assert!(queued(&s, 10).is_empty(), "never back to the sender");
        assert!(queued(&s, 11).is_empty(), "x had it from s");
        assert_eq!(
            queued(&s, 12),
            vec![CMD_PEER_SYNC],
            "y: no link report, plain sync"
        );
        // A forward of a point-to-point sync reaches every other peer, under
        // the opcode each one understands.
        sync_forward_to_peers(&mut s, "b|bot|n|nick|6\n", 10, false);
        assert_eq!(queued(&s, 11), vec![CMD_PEER_BCAST]);
        // x's own fresh list says its link to s is down: forward after all.
        s.mesh_hubs[1].links = vec![link("s", false)];
        sync_forward_to_peers(&mut s, "b|bot|n|nick|7\n", 10, true);
        assert_eq!(queued(&s, 11).len(), 2);
        s.mesh_hubs[1].links = vec![link("s", true)];
        // A list from before our link to s came up describes the mesh before it.
        let ci = s.clients.iter().position(|c| c.fd == 10).unwrap();
        s.clients[ci].connected_at = now() + 5;
        sync_forward_to_peers(&mut s, "b|bot|n|nick|8\n", 10, true);
        assert_eq!(queued(&s, 11).len(), 3);
        s.clients[ci].connected_at = 0;
        // So does a bcast forward once the sender's link report goes stale.
        s.mesh_hubs[0].links_at = now() - SYNC_SPLIT_HORIZON_FRESH - 1;
        sync_forward_to_peers(&mut s, "b|bot|n|nick|9\n", 10, true);
        assert_eq!(queued(&s, 11).len(), 4);
    }

    #[test]
    fn purge_line_shapes() {
        assert_eq!(parse_purge_line("PURGE|0"), Some((0, String::new())));
        assert_eq!(
            parse_purge_line("PURGE|123|ab12"),
            Some((123, "ab12".into()))
        );
        assert!(parse_purge_line("PURGE|-1").is_none());
        assert!(parse_purge_line("PURGE|x").is_none());
        assert!(parse_purge_line("PURGE|1|").is_none());
        assert!(parse_purge_line("PURGE|1|zz").is_none());
        assert!(parse_purge_line("PURGE|1|00112233445566778").is_none());
        assert!(parse_purge_line("PURGE|1 junk").is_none());
    }

    #[test]
    fn purge_dedup_is_keyed_on_cutoff_and_id() {
        let mut s = HubState::new();
        assert!(!is_purge_recent(&s, 0, "aa"));
        record_recent_purge(&mut s, 0, "aa");
        assert!(is_purge_recent(&s, 0, "aa"));
        // A second "immediate" purge with its own id is not the same purge.
        assert!(!is_purge_recent(&s, 0, "bb"));
        // The ring never grows past its cap.
        for i in 0..MAX_RECENT_PURGES * 2 {
            record_recent_purge(&mut s, i as i64, "id");
        }
        assert_eq!(s.recent_purges.len(), MAX_RECENT_PURGES);
    }

    #[test]
    fn leader_is_the_smallest_uuid() {
        let mut s = HubState::new();
        s.hub_uuid = "bbb".into();
        assert!(should_initiate_scheduled_purge(&s));
    }

    #[test]
    fn channel_value_reads_op_as_the_last_field() {
        // 3-field admin shape.
        let (c, k, m, op) = parse_global_channel_value("#chan|key|add").unwrap();
        assert_eq!(
            (c.as_str(), k.as_str(), m, op.as_str()),
            ("#chan", "key", 0, "add")
        );
        // 4-field bot shape: a positional parse would read "0|del" as the op.
        let (c, k, m, op) = parse_global_channel_value("#chan|key|5|del").unwrap();
        assert_eq!(
            (c.as_str(), k.as_str(), m, op.as_str()),
            ("#chan", "key", 5, "del")
        );
        // Keyless.
        let (c, k, m, op) = parse_global_channel_value("#chan||0|add").unwrap();
        assert_eq!(
            (c.as_str(), k.as_str(), m, op.as_str()),
            ("#chan", "", 0, "add")
        );
        assert!(parse_global_channel_value("#chan").is_none());
    }

    #[test]
    fn purge_removes_tombstones_and_orphans() {
        let mut s = HubState::new();
        storage::update_global_entry(&mut s, "c", "#live", "k|0", "add", 100);
        storage::update_global_entry(&mut s, "c", "#dead", "|0", "del", 100);
        s.user_records.push(UserRecord {
            uuid: "u1".into(),
            name: "gone".into(),
            typ: 'a',
            is_active: false,
            timestamp: 100,
            ..Default::default()
        });
        s.mask_records.push(MaskRecord {
            uuid: "u1".into(),
            mask: "n!*@*".into(),
            is_active: true,
            timestamp: 100,
            ..Default::default()
        });
        storage::update_entry(&mut s, "bot-dead", "n", "x", "", "", 100);
        storage::update_entry(&mut s, "bot-dead", "d", "1", "", "", 100);
        storage::update_entry(&mut s, "bot-live", "n", "y", "", "", 100);

        let mut r = crate::reply::Reply::new();
        let n = execute_purge(&mut s, 0, Some(&mut r));
        let log = r.text().to_string();
        // dead channel + dead user + its now-orphaned mask + dead bot
        assert_eq!(n, 4);
        assert!(log.contains("#dead"));
        assert!(log.contains("tomb|kind=bot|id=bot-dead|name=x"));
        assert_eq!(s.global_entries.len(), 1);
        assert!(s.user_records.is_empty());
        assert!(s.mask_records.is_empty());
        assert_eq!(s.bots.len(), 1);
        assert_eq!(s.bots[0].uuid, "bot-live");
    }

    #[test]
    fn purge_respects_a_cutoff() {
        let mut s = HubState::new();
        storage::update_global_entry(&mut s, "c", "#old", "|0", "del", 100);
        storage::update_global_entry(&mut s, "c", "#new", "|0", "del", 900);
        let n = execute_purge(&mut s, 500, None);
        assert_eq!(n, 1);
        assert_eq!(s.global_entries.len(), 1);
        assert!(s.global_entries[0].value.starts_with("#new"));
    }

    #[test]
    fn sync_packet_omits_local_only_keys() {
        let mut s = HubState::new();
        storage::update_global_entry(&mut s, "c", "#a", "|0", "add", 100);
        s.global_entries.push(ConfigEntry {
            key: "w".into(),
            value: "10.0.0.0/8".into(),
            timestamp: 100,
            last_used: 0,
        });
        storage::global_reindex(&mut s);
        s.opt_flags = "h".into();
        s.opt_flags_ts = 500;
        storage::update_entry(&mut s, "bot-1", "h", "n!u@h", "", "", 100);
        storage::update_entry(&mut s, "bot-1", "seen", "", "", "", 200);
        let p = generate_sync_packet(&s);
        assert!(p.contains("c|#a||0|add|100\n"));
        assert!(!p.contains("w|"));
        assert!(p.contains("opt|h|500\n"));
        assert!(p.contains("b|bot-1|h|n!u@h|100\n"));
        assert!(p.contains("b|bot-1|seen|200\n"));
    }

    #[test]
    fn peer_sync_ingests_and_forwards_canonically() {
        let mut s = HubState::new();
        let (_, pubk) = crypto::generate_combined_keypair().unwrap();
        let k = crypto::b64_encode(&pubk);
        let payload = format!(
            "a|11111111-2222-3333-4444-555555555555|rob|{k}|add|10|20|\n\
             m|11111111-2222-3333-4444-555555555555|rob!*@host|add|0|20\n\
             c|#chan|key|0|add|30\n\
             b|bot-1|h|rob!u@h|40\n\
             opt|h|50\n"
        );
        process_peer_sync(&mut s, &payload, -1, false);
        assert_eq!(s.user_records.len(), 1);
        assert!(s.user_records[0].has_pubkey);
        assert_eq!(s.mask_records.len(), 1);
        assert_eq!(s.opt_flags, "h");
        assert_eq!(s.bot_entry("bot-1", "h"), Some("rob!u@h"));
        assert!(s.global_entries.iter().any(|e| e.key == "c"));
        // A mask whose owner we do not know is refused.
        process_peer_sync(
            &mut s,
            "m|99999999-2222-3333-4444-555555555555|x!*@*|add|0|99\n",
            -1,
            false,
        );
        assert_eq!(s.mask_records.len(), 1);
    }

    /// A password-era a| line (a password in field 3) is refused outright:
    /// nothing of it is stored, and no password travels one hop further.
    #[test]
    fn peer_sync_refuses_a_password_line() {
        let mut s = HubState::new();
        s.hub_uuid = "me".into();
        let (_, pubk) = crypto::generate_combined_keypair().unwrap();
        let k = crypto::b64_encode(&pubk);
        // Stand in a peer so the forward path has somewhere to go.
        s.peers.push(crate::state::PeerConfig {
            uuid: "them".into(),
            ..Default::default()
        });

        let legacy = format!("a|11111111-2222-3333-4444-555555555555|rob|hunter2|add|10|20|{k}\n");
        process_peer_sync(&mut s, &legacy, -1, false);
        assert!(s.user_records.is_empty());
        assert!(!generate_sync_packet(&s).contains("hunter2"));

        // The current shape is taken, and forwarded as this hub's own line.
        let line = format!("a|11111111-2222-3333-4444-555555555555|rob|{k}|add|10|20|\n");
        process_peer_sync(&mut s, &line, -1, false);
        let u = &s.user_records[0];
        assert_eq!(u.pubkey_b64, k);
        assert_eq!(config::format_user_record(u), line);
    }

    /// The `b|` re-forward must be byte-identical to what arrived: splitting
    /// the value in place forwarded "b|uuid|c|#chan|ts" — no key, modes or op
    /// — which the next hub stored as an add, turning deletes into adds one
    /// hop out.
    #[test]
    fn peer_sync_reforwards_bot_values_unsplit() {
        let mut s = HubState::new();
        // A channel arrives on the per-bot wire shape; `c` is a global key,
        // so the storage layer routes it to the global table.
        process_peer_sync(&mut s, "b|bot-1|c|#chan|key|0|del|500\n", -1, false);
        let e = s.global_entries.iter().find(|e| e.key == "c").unwrap();
        // All four fields survived the split, so the op is still read as the
        // last one and the delete stayed a delete.
        assert_eq!(e.value, "#chan|key|0|del");
        assert_eq!(e.timestamp, 500);
        assert!(!global_value_active(&e.value));
        // A hub that split the value in place would have stored "#chan" with
        // no op, which reads as an add.
        assert!(!s.bots.iter().any(|b| b.uuid == "bot-1"));
    }

    #[test]
    fn peer_sync_drops_retired_shapes() {
        let mut s = HubState::new();
        process_peer_sync(&mut s, "p|sharedpassword|100\n", -1, false);
        assert!(s.global_entries.is_empty());
        // The pre-UUID a|<password>|<ts> row has no UUID in field 1.
        process_peer_sync(&mut s, "a|hunter2|100\n", -1, false);
        assert!(s.user_records.is_empty());
        assert!(s.global_entries.is_empty());
    }
}
