//! Compile-time settings, limits and the wire contract shared with ircbot.
//! Mirrors hub.h: every `CMD_*` opcode, label and size here must match
//! ircbot/bot.h byte for byte.

pub const HUB_CONFIG_FILE: &str = ".irchub.cnf";
pub const MAX_CLIENTS: usize = 100;
pub const MAX_BOTS: usize = 100;
pub const MAX_PEERS: usize = 10;
pub const MAX_OPT_FLAGS: usize = 32;

/// Network option flag letter: refuse bot-originated mutations of
/// hub-authoritative records (the active set lives in `HubState::opt_flags`).
pub const OPT_HUB_ONLY_MUTATIONS: char = 'h';
/// Set for the duration of a network upgrade window: config mutations
/// (admin commands + bot deltas/pushes) are refused until every node
/// reports success, or the run aborts.
pub const OPT_CONFIG_FROZEN: char = 'F';

pub const MAX_CHAN: usize = 65;
pub const MAX_NICK: usize = 32;
pub const MAX_KEY: usize = 31;
pub const MAX_MASK_LEN: usize = 256;
pub const MAX_PASS: usize = 128;
pub const MAX_BUFFER: usize = 16384;
pub const SALT_SIZE: usize = 16;
pub const GCM_IV_LEN: usize = 12;
pub const GCM_TAG_LEN: usize = 16;
pub const HEADER_SIZE: usize = 4;
pub const MAX_PENDING_OP_REQUESTS: usize = 500;
/// PBKDF2-HMAC-SHA256 rounds for the .irchub.cnf and .irchub.pass keys
/// (OWASP's 2023 figure).  2.5.0 moved both files here from 100k; every
/// release since carries min_from 2.5.0 or later, so only this count is read.
pub const PBKDF2_ITERATIONS: u32 = 600_000;
/// A bot that knows admin flags and oper channel bindings (uf| / uc|) says
/// "v|3" at the head of its full CMD_CONFIG_PUSH (docs/passwordless.md §3.4);
/// a push whose v| is below that is refused (record-only pushes carry no v|
/// and are taken).  Mirrored in ircbot/bot.h
/// (BOT_PROTO_VERSION).
pub const BOT_PROTO_USER_FLAGS: i32 = 3;
/// The oldest bot or hub this hub links with (2.5.1 plan D1 / D4): a bot's
/// CMD_BOT_PRESENCE or a direct peer's roster header below it drops the link
/// with a "upgrade it by hand" line.  2.5.2 raised it to 2.5.1: every node
/// reads only PBKDF2 600k files, reports K|, and has dropped .pass.prev.
pub const MESH_MIN_VERSION: &str = "2.5.1";
pub const KEY_FP_LEN: usize = 19; // "ab12:cd34:ef56:7890"
pub const HUB_PID_FILE: &str = ".irchub.pid";
pub const HUB_PASS_FILE: &str = ".irchub.pass";
pub const HUB_LOG_FILE: &str = ".irchub.log";
pub const HUB_LOG_FILE_SIZE: i64 = 10 * 1024 * 1024;
/// CMD_ADMIN_SET_LOG_SIZE / log_size| bounds (ircbot's L| takes the same).
pub const HUB_LOG_SIZE_MIN: i64 = 1024;
pub const HUB_LOG_SIZE_MAX: i64 = 1024 * 1024 * 1024;

// Curve25519 key constants
pub const ED25519_KEY_LEN: usize = 32;
pub const X25519_KEY_LEN: usize = 32;
pub const ED25519_SIG_LEN: usize = 64;
pub const COMBINED_KEY_LEN: usize = 64;
pub const COMBINED_KEY_B64: usize = 88;

// Log levels
pub const LOG_NONE: i32 = 0;
pub const LOG_ERROR: i32 = 1;
pub const LOG_WARNING: i32 = 2;
pub const LOG_INFO: i32 = 3;
pub const LOG_DEBUG: i32 = 4;

/// The log FILE is off by default: a production hub writes nothing to disk
/// until log_level| (or the console's "loglevel file") turns it on.  The
/// in-memory ring the SSH consoles read has its own level.
pub const HUB_DEFAULT_LOG_LEVEL: i32 = LOG_NONE;
pub const HUB_DEFAULT_CONSOLE_LOG_LEVEL: i32 = LOG_DEBUG;

// Rate limiting
pub const MAX_IP_RATE_LIMITS: usize = 500;
pub const MAX_CONNECTIONS_PER_IP: i32 = 5;
pub const MAX_FAILED_AUTH_ATTEMPTS: i32 = 3;
pub const FAILED_AUTH_BLOCK_DURATION: i64 = 300; // 5 minutes
pub const FAILED_AUTH_RESET_TIME: i64 = 3600; // 1 hour

/// D1 — churn-based (connect/close flood) throttle.  Concurrency and
/// failed-auth limits don't catch a rapid connect/close flood; this sliding
/// window does.
pub const CHURN_WINDOW_SEC: i64 = 10;
pub const CHURN_MAX_CONNS: i32 = 30;
pub const CHURN_BLOCK_SEC: i64 = 30;

/// 13b — connections not yet authenticated (MaxStartups-style random early
/// drop, `hub set conn startups S:R:F`).  Below S of them every new one is
/// taken; from S, a new one from an unknown address is refused with
/// probability R%, rising linearly to 100% at F.  A known address — a
/// configured peer, a bot in the roster, a bot or peer that authenticated
/// here within KNOWN_IP_MEMORY, a recent console login — skips the gate, and
/// so does the rate-limit table being full of live entries, which refuses
/// an unknown address instead of letting it through untracked.
pub const STARTUPS_DEF_START: i32 = 20;
pub const STARTUPS_DEF_RATE: i32 = 30;
pub const STARTUPS_DEF_FULL: i32 = 50;
pub const MAX_KNOWN_IPS: usize = 256;
pub const KNOWN_IP_MEMORY: i64 = 86400;
/// One refusal warning per this, with a count.
pub const STARTUP_LOG_EVERY: i64 = 60;

/// PURGE loop suppression.  A purge is flooded to every peer and forwarded
/// on, so on a big mesh each hub sees many copies, some of them minutes late
/// when peer queues back up.  An id is random and never reused, so it is
/// remembered long and in quantity: with 5 ids for 60 s, a late copy or one
/// pushed out by newer purges was taken as new, re-applied and re-flooded,
/// and a 10-hub mesh kept a dozen purges circulating for good.  An id-less
/// purge (a hub that predates the id) can only be told apart by time, so it
/// keeps the short window — a longer one would swallow a second, deliberate
/// purge now.
pub const MAX_RECENT_PURGES: usize = 64;
/// The full config push to bots is coalesced: however many updates land in a
/// burst, the bots get one push per this many seconds, with the latest state.
pub const BOT_CONFIG_PUSH_COALESCE: i64 = 1;
pub const PURGE_DEDUP_WINDOW: i64 = 3600;
pub const PURGE_ID_HEX: usize = 16;
/// Seconds a purge refuses re-creating older tombstones (the purge floor).
pub const PURGE_FLOOR_HOLD: i64 = 600;

// OP_FORWARD_REQUEST deduplication — prevents packet storms
pub const OP_FORWARD_TTL_SECONDS: i64 = 60;
pub const MAX_SEEN_FORWARD_IDS: usize = 256;

/// Keepalive traffic (CMD_PING and the PONG it draws) is pure noise in the
/// hub log; true = never log it.  Mirrors HIDEPINGPONG in ircbot/bot.h.
pub const HIDEPINGPONG: bool = true;

/// This hub's version, reported in the bots tree beside each hub node.
/// Overridable at build time (`IRCHUB_VERSION=2.1 cargo build --release`) so a
/// release build can stamp its own version without editing the tree.  Mirrors
/// the `#ifndef HUB_VERSION` guard in hub.h.  This is the version reported in
/// the bots tree and the one every upgrade comparison is made against.
pub const HUB_VERSION: &str = match option_env!("IRCHUB_VERSION") {
    Some(v) => v,
    None => "2.5.2",
};

/// Signed-release channel for the hub (irchub-releases).  Same Ed25519 key
/// as ircbot's BOT_UPDATE_PUBKEY_B64: one key signs both repos.  An empty
/// pubkey DISABLES hub updates (fail-closed).  Mirrors hub.h.
///
/// `HUB_UPDATE_BASE` is the tree ROOT; one variant subdirectory below it holds
/// that build's manifest.  Keeping the root separate is what lets a
/// hub-orchestrated upgrade flip a hub between the C and Rust builds:
/// `update::commit` appends the variant it was told to install.
pub const HUB_UPDATE_BASE: &str =
    "https://raw.githubusercontent.com/robertclemens/irchub-releases/main/irchub";
/// The variant THIS build is.  The C hub answers "c".
pub const HUB_UPDATE_VARIANT: &str = "rs";
pub const HUB_UPDATE_URL: &str =
    "https://raw.githubusercontent.com/robertclemens/irchub-releases/main/irchub/rs/releases.txt";
pub const HUB_UPDATE_SIG_URL: &str =
    "https://raw.githubusercontent.com/robertclemens/irchub-releases/main/irchub/rs/releases.sig";
pub const HUB_UPDATE_PUBKEY_B64: &str = "qkXMh/F8TC+cnKuIwrP5TJIynfrLBD+MDUwvkyh9lBU=";
/// Hand-off note written just before an upgrade execs the new binary: the
/// restarted process reads the upgrade id from here and answers
/// CMD_UPGRADE_RESULT.
pub const HUB_UPGRADE_MARKER_FILE: &str = ".irchub.upgrade";
/// Retained previous binary/config, kept (not deleted) after an upgrade so
/// CMD_UPGRADE_ABORT can put this hub back.
pub const HUB_UPGRADE_PREV_SUFFIX: &str = ".prev";
/// The generated installer, written 0700 and exec'd once the old process has
/// let go of its pid lock.
pub const HUB_UPGRADE_SCRIPT: &str = "hub_upgrade.sh";
/// Ceilings on what the updater will pull down.
pub const HUB_UPDATE_MAX_MANIFEST: u64 = 1024 * 1024;
pub const HUB_UPDATE_MAX_ARCHIVE: u64 = 256 * 1024 * 1024;
pub const HUB_UPDATE_FETCH_TIMEOUT: u64 = 300;
/// Per-transfer budget for manifest reads made from the event loop (PREPARE
/// answers, the console's release list): the hub serves nothing meanwhile.
pub const HUB_UPDATE_QUICK_TIMEOUT: u64 = 8;
/// The upgrade script's startup watchdog: how long the new build's daemon has
/// to be up and alive before the script keeps it.
pub const UPGRADE_WATCH_SECS: u32 = 20;
/// The bots' release tree ROOT (ircbot-releases), for the console's release
/// list and for walking a bot up via the roll-up.  Mirrors
/// HUB_BOT_RELEASE_BASE in hub.h.
pub const HUB_BOT_RELEASE_BASE: &str =
    "https://raw.githubusercontent.com/robertclemens/ircbot-releases/main/ircbot";

// Timeouts (seconds)
pub const PING_INTERVAL: i64 = 60;
pub const CLIENT_TIMEOUT: i64 = 180;
pub const CONNECT_TIMEOUT: u64 = 5;

/// D4 — pre-authentication handshake timeout.
pub const PREAUTH_TIMEOUT_SEC: i64 = 10;

/// D2 — two-tier client buffers: unauthenticated clients get a small buffer,
/// grown to the per-type bulk size on successful auth.
pub const PREAUTH_BUF_SIZE: usize = 4096;
pub const PEER_RECONNECT_INTERVAL: i64 = 120;

// ---- Protocol commands (must match ircbot/bot.h) ---------------------------
pub const CMD_PING: u8 = 0x01;
pub const CMD_CONFIG_PUSH: u8 = 0x02;
pub const CMD_CONFIG_PULL: u8 = 0x03;
pub const CMD_CONFIG_DATA: u8 = 0x04;
pub const CMD_UPDATE_PUBKEY: u8 = 0x05;
pub const CMD_PEER_SYNC: u8 = 0x06;
pub const CMD_MESH_STATE: u8 = 0x07;
pub const CMD_SYNC_REQUEST: u8 = 0x08;
pub const CMD_INVITE_REQUEST: u8 = 0x09;

pub const CMD_ADMIN_AUTH: u8 = 0x10;
pub const CMD_ADMIN_LIST_FULL: u8 = 0x11;
/// 0x12 / 0x16 / 0x17 (ADD / GET_PENDING / APPROVE) are retired with bot
/// pending/approve/authorize: bot add is the only way in.  Never reuse.
pub const CMD_ADMIN_ADD: u8 = 0x12;
pub const CMD_ADMIN_DEL: u8 = 0x13;
pub const CMD_ADMIN_REGEN_KEYS: u8 = 0x14;
pub const CMD_ADMIN_LIST_SUMMARY: u8 = 0x15;
pub const CMD_ADMIN_GET_PENDING: u8 = 0x16;
pub const CMD_ADMIN_APPROVE: u8 = 0x17;
pub const CMD_ADMIN_ADD_PEER: u8 = 0x18;
pub const CMD_ADMIN_LIST_PEERS: u8 = 0x19;
pub const CMD_ADMIN_DEL_PEER: u8 = 0x1A;
pub const CMD_ADMIN_GET_PUBKEY: u8 = 0x1B;
/// 0x1C / 0x1D (SET/GET_PRIVKEY) are retired with hub_admin (SSH console): the hub key
/// never leaves the hub, a backup is a copy of .irchub.cnf.  Never reuse the
/// values.
pub const CMD_ADMIN_SET_PRIVKEY: u8 = 0x1C; // RETIRED
pub const CMD_ADMIN_GET_PRIVKEY: u8 = 0x1D; // RETIRED
pub const CMD_ADMIN_SET_PUBKEY: u8 = 0x1E;
pub const CMD_ADMIN_SYNC_MESH: u8 = 0x1F;
pub const CMD_ADMIN_CREATE_BOT: u8 = 0x32; // 50 decimal
pub const CMD_ADMIN_REKEY_BOT: u8 = 0x20;
pub const CMD_ADMIN_DISCONNECT_BOT: u8 = 0x21;
pub const CMD_ADMIN_BOT_STATUS: u8 = 0x22;
pub const CMD_BOT_KEY_UPDATE: u8 = 0x40;

// Global config management
pub const CMD_ADMIN_LIST_CHANNELS: u8 = 0x23;
pub const CMD_ADMIN_ADD_CHANNEL: u8 = 0x24;
pub const CMD_ADMIN_DEL_CHANNEL: u8 = 0x25;
pub const CMD_ADMIN_LIST_MASKS: u8 = 0x26;
pub const CMD_ADMIN_ADD_MASK: u8 = 0x27;
pub const CMD_ADMIN_DEL_MASK: u8 = 0x2B;
pub const CMD_ADMIN_LIST_OPERS: u8 = 0x2C;
pub const CMD_ADMIN_ADD_OPER: u8 = 0x2D;
pub const CMD_ADMIN_DEL_OPER: u8 = 0x2E;
/// 0x2F and 0x30 are retired — passwordless.  Kept as names so the hub can
/// answer "retired"; never reuse the values.
pub const CMD_ADMIN_SET_ADMIN_PASS: u8 = 0x2F; // RETIRED
pub const CMD_ADMIN_SET_BOT_PASS: u8 = 0x30; // RETIRED
pub const CMD_ADMIN_OP_USER: u8 = 0x31;

// Bot-to-bot op commands (via hub)
pub const CMD_OP_REQUEST: u8 = 0x28;
pub const CMD_OP_GRANT: u8 = 0x29;
pub const CMD_OP_FAILED: u8 = 0x2A;
pub const CMD_OP_FORWARD_REQUEST: u8 = 0x33;
pub const CMD_OP_FORWARD_GRANT: u8 = 0x34;
pub const CMD_OP_FORWARD_FAILED: u8 = 0x35;
pub const CMD_PEER_REKEY_BOT: u8 = 0x42;
pub const CMD_BOT_RELAY: u8 = 0x50;
pub const CMD_BOT_MSG: u8 = 0x51;

// Tombstone purge
pub const CMD_ADMIN_PURGE_TOMBSTONES: u8 = 0x36;
pub const CMD_ADMIN_SET_PURGE_DAYS: u8 = 0x41;

// Bind IP and IP access control
pub const CMD_ADMIN_SET_BIND_IP: u8 = 0x37;
pub const CMD_ADMIN_LIST_ALLOWLIST: u8 = 0x38;
pub const CMD_ADMIN_ADD_ALLOWLIST: u8 = 0x39;
pub const CMD_ADMIN_DEL_ALLOWLIST: u8 = 0x3A;
pub const CMD_ADMIN_LIST_DENYLIST: u8 = 0x3B;
pub const CMD_ADMIN_ADD_DENYLIST: u8 = 0x3C;
pub const CMD_ADMIN_DEL_DENYLIST: u8 = 0x3D;
pub const CMD_ADMIN_SET_HUB_NAME: u8 = 0x3E;
pub const CMD_ADMIN_SET_BIND_PORT: u8 = 0x3F;
pub const CMD_ADMIN_SET_LOG_LEVEL: u8 = 0x43;
pub const CMD_ADMIN_SET_LOG_SIZE: u8 = 0x44;
pub const CMD_BOT_DELTA: u8 = 0x45;

// Named admin/oper/usermask commands (v2)
pub const CMD_ADMIN_ADD_ADMIN: u8 = 0x46;
pub const CMD_ADMIN_DEL_ADMIN: u8 = 0x47;
pub const CMD_ADMIN_ADD_OPER_RECORD: u8 = 0x48;
pub const CMD_ADMIN_DEL_OPER_RECORD: u8 = 0x49;
pub const CMD_ADMIN_ADD_USERMASK: u8 = 0x4A;
pub const CMD_ADMIN_DEL_USERMASK: u8 = 0x4B;
pub const CMD_ADMIN_SET_USERPASS: u8 = 0x4C; // RETIRED
pub const CMD_ADMIN_MATCH: u8 = 0x4D;
pub const CMD_ADMIN_LIST_ADMINS: u8 = 0x4E;
pub const CMD_ADMIN_LIST_OPERS_V2: u8 = 0x4F;
pub const CMD_ADMIN_SET_PEER_PUBKEY: u8 = 0x52;
pub const CMD_ADMIN_SET_OPT_FLAGS: u8 = 0x53;
pub const CMD_ADMIN_GET_OPT_FLAGS: u8 = 0x54;
pub const CMD_ADMIN_SET_USERKEY: u8 = 0x55;

/// ---- Bot presence (the 'bots' tree) ---------------------------------------
/// Deliberately OUTSIDE the config store.  Version / IRC server / uptime are
/// volatile runtime facts: parking them in the LWW config would persist them
/// to disk, replicate them with tombstones, drag them through the purge
/// policy and leave a dead hub's bots reading "online, uptime 40d" forever.
/// They also do not belong in the per-bot ingest whitelist {t,n,h,pub,seen,d}
/// -- that bound is what makes the payload ceilings below provable.
///
/// So presence rides its own gossip: every hub reports the bots currently
/// connected to IT, peers hold that in memory only, and an entry nobody has
/// refreshed within BOT_ROSTER_TTL is simply dropped.
pub const CMD_BOT_PRESENCE: u8 = 0x56;
pub const CMD_BOT_ROSTER: u8 = 0x57;
pub const CMD_BOT_TREE: u8 = 0x58;

/// ---- Channel-access requests (unban / invite / key) -----------------------
/// A bot locked out of a managed channel (474 banned, 473 invite-only, 475
/// bad key) asks the mesh to let it back in.  The requesting bot supplies only
/// `kind|channel`; the hub fills in the requester's nick and hostmask from its
/// own `n`/`h` records for that authenticated UUID.  Mirrors ircbot/bot.h.
pub const CMD_CHAN_REQUEST: u8 = 0x59;
pub const CMD_CHAN_ACTION: u8 = 0x5A;
pub const CMD_CHAN_REPLY: u8 = 0x5B;
pub const CMD_CHAN_FWD_REQUEST: u8 = 0x5C;
pub const CMD_CHAN_FWD_REPLY: u8 = 0x5D;

// ---- Channel-request election (docs/plans/2026-10-07_chan_election_plan.md
// in irchub) ----
// One bot acts, not every bot that could.  The hub asks its own bots whether
// they can (PROBE -> PROBE_ACK, answered at once from the bot's own state),
// hands the action to ONE ready bot picked at random (DO -> DONE), and moves
// on to the next ready bot when that one fails.  With nobody ready here the
// origin floods the question to the mesh (ELECT_FWD), each hub probes its own
// bots and answers ELECT_ACK back along the path, and the origin hands it to
// one hub with a ready bot (ELECT_DO -> ELECT_DONE, along the same path).
// A bot that has not answered when CHAN_ELECT_PROBE_WAIT runs out counts as
// a no ("no answer"): every bot the mesh admits answers probes, so it is
// never sent a blind old-style CMD_OP_GRANT / CMD_CHAN_ACTION (that skipped
// +bitch).  Mirrors irchub/hub.h.
//   PROBE      hub->bot  eid|kind|channel
//   PROBE_ACK  bot->hub  eid|1| or eid|0|reason
//   DO         hub->bot  eid|kind|channel|requester|nick|hostmask
//   DONE       bot->hub  eid|ok|detail or eid|fail|detail
//   ELECT_FWD  hub->hub  eid|origin_hub|kind|channel|requester|nick|hostmask|origin_ts
//   ELECT_ACK  hub->hub  eid|hub_uuid|hub_name|asked|ready|0 (the last field
//              is a reserved slot, always 0 and never read)
//   ELECT_DO   hub->hub  eid|hub_uuid|elect
//   ELECT_DONE hub->hub  eid|hub_uuid|hub_name|bot_uuid|bot_nick|status|detail
// kind = op / invite / unban / key; requester = a bot uuid, or ADMIN.
pub const CMD_CHAN_PROBE: u8 = 0x6D;
pub const CMD_CHAN_PROBE_ACK: u8 = 0x6E;
pub const CMD_CHAN_DO: u8 = 0x6F;
pub const CMD_CHAN_DONE: u8 = 0x70;
pub const CMD_CHAN_ELECT_FWD: u8 = 0x71;
pub const CMD_CHAN_ELECT_ACK: u8 = 0x72;
pub const CMD_CHAN_ELECT_DO: u8 = 0x73;
pub const CMD_CHAN_ELECT_DONE: u8 = 0x74;
/// Admin: invite a user (nick|#chan).
pub const CMD_ADMIN_INVITE_USER: u8 = 0x75;

// ---- Modes, settings, bans, flood protection (docs/modes.md, 2.4.5) --------
// Mirrors irchub/hub.h and ircbot/bot.h.
//   CMD_ADMIN_CHAN_MODE  console->hub  #chan (view) | #chan|<modes>|<arg>... | #chan|-
//   CMD_ADMIN_CHAN_SET   console->hub  <#chan|default> | <#chan|default>|<tok>|<tok>...
//   CMD_ADMIN_BAN        console->hub  list|<#c|*|""> | add|<#c|*>|<mask>|<min|perm>|<sticky 0/1>|<reason>
//                                      | del|<#c|*>|<mask>
//   CMD_ADMIN_NET_SET    console->hub  "" | flood|<cmd|msg|ctcp>|<N:S|off|default> | ignoretime|<min|default> | sendq|<B:I|default>
//   CMD_ADMIN_SET_SSH    console->hub  "" | <name>|<value|default> | conn|<name>|<value>
//   CMD_CHAN_EVENT       bot->hub      #chan|<action>|<target>|<detail>   (D42)
// CMD_CHAN_EVENT: action is deop reop kick ban unban moderevert limit
// floodtrip ignore; target (nick or mask) <= CHAN_EVENT_TARGET_MAX bytes,
// detail <= CHAN_EVENT_DETAIL_MAX, no control characters.  The hub checks the
// bounds, rate-limits per bot connection (CHAN_EVENT_MAX_PER_WINDOW per
// CHAN_EVENT_WINDOW seconds, the rest dropped) and writes one info line to
// its log ring, "chan #c <action> <target> by <botname>: <detail>".  Hub
// local: never stored, never forwarded to peers or other bots.
pub const CMD_ADMIN_CHAN_MODE: u8 = 0x76;
pub const CMD_ADMIN_CHAN_SET: u8 = 0x77;
pub const CMD_ADMIN_BAN: u8 = 0x78;
pub const CMD_ADMIN_NET_SET: u8 = 0x79;
pub const CMD_ADMIN_SET_SSH: u8 = 0x7A;
pub const CMD_CHAN_EVENT: u8 = 0x7B;
/// Admin flags / oper channel bindings from the console (user_flags plan
/// §4.1): `flags|<name>|<+x-y|letters>`, `chan|add|<name>|<#chan|*>`,
/// `chan|del|<name>|<#chan|*>`.  Answers user.flags / user.chan.  Internal
/// (console only), never on the network; reserved in ircbot/bot.h.
pub const CMD_ADMIN_USER_ACCESS: u8 = 0x7C;
/// A person's channel request from a bot (user_flags plan §5):
/// `rid|kind|#chan|user_uuid|nick|nick!user@host` bot->hub, answered
/// `rid|ok|detail` / `rid|fail|detail` hub->bot.  Mirrored in ircbot/bot.h.
pub const CMD_USER_CHAN_REQUEST: u8 = 0x7D;
pub const CMD_USER_CHAN_RESULT: u8 = 0x7E;
/// Revoked bots (irchub docs/plans/2026-10-17_bot_revoke_plan.md).  A deleted
/// bot's uuid and key stay on a permanent revoke list; when it connects it is
/// told to wipe its config and exit.  CMD_BOT_RETIRE hub->bot is empty: in
/// session a sealed frame, in the handshake the 1-byte sealed ACK is 0x7F.
/// CMD_BOT_RETIRE_ACK bot->hub: "1" config wiped, "0" wipe failed.
/// Mirrored in ircbot/bot.h.
pub const CMD_BOT_RETIRE: u8 = 0x7F;
pub const CMD_BOT_RETIRE_ACK: u8 = 0x80;
/// bot revoked (console -> hub).
pub const CMD_ADMIN_LIST_REVOKED: u8 = 0x81;
/// hub del's preview (docs/plans/2026-10-18_hub_del_refs_plan.md): console ->
/// hub "<uuid|name>"; the reply names the hubs that link to it and the bots
/// whose hl| list holds it.
pub const CMD_ADMIN_PEER_REFS: u8 = 0x82;
/// Review 6: link framing with a sequence (bot<->hub and hub<->hub).  After a
/// link authenticates each side sends "offer"; the side that sees the other's
/// offer answers "go", and every frame it seals after its go carries
/// HUB_LINK_AAD_LEN bytes of AAD: "LNK1" || direction || 64-bit counter (big
/// endian, from 0, not sent).  The counter makes a replayed or reordered frame
/// fail its tag, the direction byte a reflected one (H hub->bot, B bot->hub;
/// between hubs L from the lower uuid, G from the greater).  A 2.5.1 node
/// ignores the offer and the link keeps the old framing; one that says it is
/// HUB_LINK_SEQ_VERSION or newer without having offered is dropped (a stripped
/// offer).  2.5.3 drops the old framing.
pub const CMD_LINK_SEQ: u8 = 0x83;
pub const HUB_LINK_AAD_LEN: usize = 13;
pub const HUB_LINK_SEQ_VERSION: &str = "2.5.2";
/// Review 7: ephemeral keys of the HUBv3 hellos accepted in the last
/// HELLO_SEEN_SECS (the hello's freshness window); a repeat is a replay.
pub const HELLO_SEEN_MAX: usize = 128;
pub const HELLO_SEEN_SECS: i64 = 60;
/// Revoke list ceiling; the oldest is dropped past it.
pub const MAX_REVOKED: usize = 1024;
/// Seconds an online bot gets to answer CMD_BOT_RETIRE.
pub const RETIRE_GRACE_SEC: i64 = 10;
/// rid bytes, [A-Za-z0-9-].
pub const USER_CHAN_RID_MAX: usize = 32;
/// s, per bot connection.
pub const USER_CHAN_REQ_WINDOW: i64 = 60;
/// requests per window, the rest dropped.
pub const USER_CHAN_REQ_MAX: i32 = 20;
pub const CHAN_EVENT_TARGET_MAX: usize = 120;
pub const CHAN_EVENT_DETAIL_MAX: usize = 160;
pub const CHAN_EVENT_WINDOW: i64 = 60;
pub const CHAN_EVENT_MAX_PER_WINDOW: i32 = 30;
// kind = "mode" (2.4.5, docs/modes.md §3.1): apply the stored modes of a
// channel once.  The DO payload carries nothing extra (eid|mode|channel); the
// elected bot reads the stored C| modes + c| key (it has them in its config)
// and sends the MODE line(s) that move the live modes there.  DONE ok|detail,
// or fail|reason; a `channel op` to a nick that is not authorised on a +bitch
// channel answers fail|bitch, which the origin turns into
// channel.not_authorised.
/// Seconds: local bots' answers (whole seconds: >= 2 s).
pub const CHAN_ELECT_PROBE_WAIT: i64 = 3;
/// Seconds: other hubs' answers (their probe wait + 2).
pub const CHAN_ELECT_MESH_WAIT: i64 = 5;
/// Seconds: one bot's DONE.
pub const CHAN_ELECT_DO_WAIT: i64 = 5;
/// Seconds: one hub's ELECT_DONE (it may retry its own bots).
pub const CHAN_ELECT_HUB_WAIT: i64 = 12;
/// Seconds: hard end of any election.
pub const CHAN_ELECT_TTL: i64 = 40;
pub const MAX_CHAN_ELECTIONS: usize = 16;
pub const CHAN_ELECT_REASON_MAX: usize = 48;

// Network-wide upgrade coordination (mirrors irchub/hub.h).
pub const CMD_UPGRADE_PREPARE: u8 = 0x5E;
pub const CMD_UPGRADE_READY: u8 = 0x5F;
pub const CMD_UPGRADE_COMMIT: u8 = 0x60;
pub const CMD_UPGRADE_RESULT: u8 = 0x61;
pub const CMD_UPGRADE_ABORT: u8 = 0x62;
pub const CMD_ADMIN_UPGRADE_NET: u8 = 0x63;
pub const CMD_ADMIN_UPGRADE_STATUS: u8 = 0x64;

/// Sealed bot-to-bot relay across hubs (mirrors irchub/hub.h).  A
/// CMD_BOT_RELAY whose target is not connected here is stamped with a request
/// id and flooded to the peers; each delivers it as CMD_BOT_MSG to its own bot
/// or passes it on minus the link it came in on.  Loop-suppressed by the
/// shared seen-forwards ring; the target bot still checks the sealed payload
/// against the sender's key, so a peer cannot forge a command.  Hub <-> hub
/// only.  Payload: `id|origin_ts|sender_uuid|target_uuid|<sealed frame>`.
pub const CMD_BOT_RELAY_FWD: u8 = 0x65;
/// Seconds a forwarded relay stays deliverable.
pub const BOT_RELAY_FWD_TTL: i64 = 30;
/// CMD_BOT_RELAY a local bot may send per second; the rest are dropped.  Each
/// one not for a local bot goes to every peer, so one bot could fill them.
pub const BOT_RELAY_PER_SEC: i32 = 20;
/// A client with output queued that takes no byte of it for this long is
/// dropped: a bot or peer that stopped reading only looks connected.
pub const WRITE_STALL_TIMEOUT: i64 = 60;
/// A full DELTA/BULK lane's drop warning: one line per client this often.
pub const QUEUE_DROP_LOG_EVERY: i64 = 60;
/// A bot whose new session replaces a live one more often than this in an
/// hour is warned about: two processes with one key, or a stolen key.
pub const BOT_REPLACE_WARN_PER_HOUR: i32 = 3;

/// Drop the roll-up plan mesh-wide (mirrors irchub/hub.h).  Every hub that
/// followed a run keeps that run's plan in its own .irchub.cnf and walks any
/// bot that comes back behind it up to the target; an admin's
/// CMD_ADMIN_UPGRADE_STATUS "forget" drops it on the hub it is logged into
/// and floods this frame so every other hub drops its copy too.
/// Loop-suppressed by the seen-forwards ring, refused while the config
/// freeze (a run in flight) is up.  Hub <-> hub only.  Payload: `id|origin_ts`.
pub const CMD_UPGRADE_FORGET: u8 = 0x66;
/// Seconds a forwarded forget stays valid.
pub const UPGRADE_FORGET_TTL: i64 = 60;

/// A config broadcast (mirrors irchub/hub.h): the payload of CMD_PEER_SYNC,
/// sent by a hub to EVERY peer it is linked to (minus the one it forwards
/// for).  The receiver may rely on that when it forwards what it accepted: a
/// peer the sender is linked to right now already has the frame first hand,
/// so the forwarder skips it (the split horizon in `mesh`).  Point-to-point
/// syncs (the reply to CMD_SYNC_REQUEST, the sync a new link opens with) stay
/// CMD_PEER_SYNC.  Sent only to a peer whose roster gossip carries l| lines;
/// an older peer gets CMD_PEER_SYNC as before.
pub const CMD_PEER_BCAST: u8 = 0x67;

/// Admin -> Hub: this hub's traffic counters since it started (read-only,
/// empty payload).  Reply lines, zero rows left out:
///   stats|up=<s>
///   cfg|sent=<n>|same=<n>|lost=<n>        full config pushes to bots
///   sync|frames=<n>|noop=<n>|records=<n>|applied=<n>   PEER_SYNC/BCAST in
///   op|0x<cc>|rx=<frames>/<bytes>|tx=<frames>/<bytes>
/// "same" = a push skipped because that bot was already sent the identical
/// config; "lost" = a queued push dropped on overflow (that bot is re-sent
/// the next one in full).  rx counts every authenticated frame this hub
/// decrypted, tx every frame it sent from its outbound queues (the ping/pong
/// keepalive and direct admin/bot replies are not queued and not counted).
pub const CMD_ADMIN_STATS: u8 = 0x68;

/// Activity (last seen / last used), mirrors irchub/hub.h.  An admin/oper's
/// last_seen and a usermask's last_used are max-merged values OUTSIDE the LWW
/// config: they only ever rise, a rise is never a config change (no record
/// forward, no bot push), and every hub converges on the latest time any node
/// saw.  A node reports a record only on its first use within an
/// ACTIVITY_BUCKET (a clock hour), with that use's exact time.  A hub keeps
/// max(stored, ts) and forwards to its other peers only the lines that raised
/// its value.  PEER_SYNC / CONFIG_PUSH max-merge the same fields as repair.
/// A ban's last use (a bot saw an unauthorised member match a listed,
/// non-sticky ban) cannot ride its B| line: it lives beside the record
/// (`ConfigEntry::last_used`), is saved as a bu| line in the cnf, and a hub
/// repairs a peer by sending all of them as CMD_ACTIVITY right after the
/// link's initial sync (`activity::send_bans`).
///
///   CMD_ACTIVITY        bot -> hub, hub <-> hub.  Lines:
///                         a|<user_uuid>|<ts>          (admin or oper)
///                         m|<user_uuid>|<mask>|<ts>
///                         B|<#chan|*>|<mask>|<ts>     (a listed ban's last use)
///   CMD_ACTIVITY_QUERY  bot -> hub: <req_id>|users   or
///                                   <req_id>|masks|<user_uuid or *>
///                       ("masks" answers that user's a| line too)
///   CMD_ACTIVITY_REPLY  hub -> bot: first line <req_id>|<more>, then a|/m|
///                       lines; chunked under MAX_BUFFER, more=0 on the last.
pub const CMD_ACTIVITY: u8 = 0x69;
pub const CMD_ACTIVITY_QUERY: u8 = 0x6A;
pub const CMD_ACTIVITY_REPLY: u8 = 0x6B;
/// Report the first use per this many seconds.
pub const ACTIVITY_BUCKET: i64 = 3600;
/// A reported time this far ahead of our clock is refused: activity only
/// rises, so one bogus future stamp would stick for good.
pub const ACTIVITY_MAX_FUTURE: i64 = 300;
/// How far past this node's clock a replicated record's stamp may run
/// (`state::ts_ahead`); room for `lww_next_ts` stepping past now under a
/// burst of edits.
pub const LWW_MAX_FUTURE: i64 = 3600;
pub const ACTIVITY_REQ_ID_MAX: usize = 32;
/// After a peer link drops, ask the remaining peers for a full sync this many
/// seconds later: a forwarder may have skipped us on the strength of that
/// link in the moment before the drop reached its gossip.
pub const SYNC_RESYNC_AFTER_LINK_LOSS: i64 = 5;

// ---- SSH admin console (docs/console.md) --------------------------------
// The hub's only admin interface: an SSH server on the hub's own port, run on
// a console thread (console::ssh) that never touches HubState.  Each
// logged-in console reaches the core over its own socketpair, as an admin
// connection that is already authenticated (HubClient::internal): plaintext
// frames len(4, big-endian) || op(1) || payload.  CMD_CONSOLE is the one
// opcode that exists only there -- console -> core "sub|<topics>" /
// "get|tree" / "get|log", core -> console "<topic>|<data>" events.  It
// never appears on the network.  Mirrors irchub hub.h.
pub const CMD_CONSOLE: u8 = 0x6C;
/// core -> console: the reply to the request in flight.
pub const CONSOLE_REPLY: u8 = 0x00;
/// SSH connections not yet logged in.
pub const CONSOLE_MAX_PREAUTH: usize = 8;
/// Open consoles.
pub const CONSOLE_MAX_SESSIONS: usize = 8;
/// Connect -> running shell, seconds.
pub const CONSOLE_LOGIN_GRACE: u64 = 20;
/// Seconds without a keystroke.
pub const CONSOLE_IDLE_TIMEOUT: i64 = 1800;
/// Refused keys before the drop.
pub const CONSOLE_MAX_AUTH_TRIES: u32 = 3;
/// The first bytes of an accepted connection decide console vs. bot/peer.  A
/// sender that has not produced 4 bytes within this window is treated as the
/// bot/peer protocol (whose own pre-auth timeout then applies).
pub const CONSOLE_SNIFF_MS: i64 = 2000;
/// Core-side queue towards one console.  A reply that does not fit closes the
/// console (fail-secure); an event or log line that does not fit is dropped
/// and counted ("drop|<n>").
pub const CONSOLE_CORE_OUTQ_MAX: usize = 1024 * 1024;
/// In-memory ring of recent log lines the log view and "log on" replay.
pub const CONSOLE_LOG_RING: usize = 1024;
pub const CONSOLE_LOG_LINE_MAX: usize = 512;
/// Coalescing of pushed events: seconds between two tree events.
pub const CONSOLE_TREE_MIN_GAP: i64 = 1;
pub const CONSOLE_NAME_MAX: usize = 64;
/// Largest control / session frame either side accepts.
pub const CONSOLE_FRAME_MAX: usize = 4 * 1024 * 1024;

pub const MAX_PENDING_CHAN_REQUESTS: usize = 200;
pub const CHAN_REQUEST_TIMEOUT: i64 = 45;

// ---- Network upgrade run (CMD_UPGRADE_*, CMD_ADMIN_UPGRADE_NET) -----------
// One run at a time per hub: the whole point is that exactly one plan drives
// the mesh while the config is frozen.
/// Every client, plus this hub.
pub const MAX_UPGRADE_NODES: usize = MAX_CLIENTS + 1;
/// Downstream routes a follower remembers for a run it is only relaying: one
/// per node it forwarded an answer for.  See `state::UpgradeRoute`.
pub const MAX_UPGRADE_ROUTES: usize = MAX_UPGRADE_NODES;
/// A selective run (CMD_ADMIN_UPGRADE_NET's 8th field) names at most this many
/// nodes; an empty selection is the whole network.
pub const MAX_UPGRADE_SELECT: usize = 16;
/// How long after a committed bot was seen back on the target its "ok" may
/// take before the driver counts it done anyway (seconds).
pub const UPGRADE_OPS_GRACE: i64 = 240;
/// The staged new binary's `-selftest` timeout.
pub const SELFTEST_TIMEOUT: u64 = 15;
/// Releases listed by the console's "upgrade releases" query, per product.
pub const MAX_UPGRADE_RELEASES: usize = 24;

// ---- Offline roll-up (upgrade plan, Task 7) -------------------------------
// A node that was down, or homed elsewhere, when a run went through comes back
// on the old build.  The hub brings it up to the last completed run's target
// by itself, ONE node at a time and WITHOUT freezing the config: a single late
// bot is not a reason to hold the whole network's config still.  Bounded on
// purpose — a node that keeps failing must not be re-committed on every
// reconnect.
/// Attempts per node, per hub lifetime.
pub const ROLLUP_MAX_TRIES: i32 = 3;
/// Seconds between attempts on one node.
pub const ROLLUP_COOLDOWN: i64 = 900;
/// Seconds after a run completes before late nodes are chased.
pub const ROLLUP_SETTLE: i64 = 20;
/// Give up on one attempt after this many seconds.
pub const ROLLUP_TIMEOUT: i64 = 300;
/// Nodes remembered in the attempt ledger.
pub const MAX_ROLLUP_TRIES: usize = 64;
/// A plan only exists while somebody is owed it: it is dropped as soon as
/// every registered bot and every known hub is on the target, and after this
/// long regardless -- a bot down for a day is likely coming back, one down for
/// months is not, and its admin can still run an upgrade by hand.
pub const ROLLUP_PLAN_TTL: i64 = 7 * 86400;

// Multi-step upgrades (2.5.1): a target some node cannot jump to directly is
// reached through the intermediate releases the manifests name, one ordinary
// run per step.  See `upgrade::plan_begin`.
/// Longer paths are refused at start.
pub const MAX_UPGRADE_STEPS: usize = 16;
/// Seconds between steps, and after boot.
pub const UPGRADE_PLAN_SETTLE: i64 = 60;
/// A plan with no progress for this long is dropped.
pub const UPGRADE_PLAN_TTL: i64 = 86400;
/// An `upgrade abort` is re-sent to every peer link that comes up for this
/// long, so a planner restarting onto a step when it was typed still gets it.
pub const UPGRADE_CANCEL_HOLD: i64 = 600;
/// Stop waiting for READY acks.
pub const UPGRADE_PREPARE_TIMEOUT: i64 = 45;
/// PREPARE also stays open this long after the node table last grew: a hub
/// several hops out is unknown to the driver until its first READY arrives.
pub const UPGRADE_PREPARE_SETTLE: i64 = 3;
/// A committed node must be back, upgraded, by now.
pub const UPGRADE_COMMIT_TIMEOUT: i64 = 420;
/// Bots go in waves so a channel never loses every bot at once.
pub const UPGRADE_BOT_WAVE_MAX: usize = 4;
/// Never commit more than 1/N of the bots at once.
pub const UPGRADE_BOT_WAVE_DIVISOR: usize = 4;
/// How long a CMD_UPGRADE_PREPARE this hub acknowledged stays commitable.  A
/// driver that stalls mid-roll has to ask again rather than commit against a
/// stale plan.
pub const UPGRADE_PREPARE_TTL: i64 = 900;

pub const MESH_ANTI_ENTROPY_INTERVAL: i64 = 300;
pub const MAX_BOT_ENTRIES: usize = 64;

// ---- Modes / settings / bans records (docs/modes.md §2, 2.4.5) -------------
// C|<#chan>|<modes>|<settings>|<op>|<ts>   channel settings (console only)
// D|<modes>|<settings>|<ts>                network defaults (console only)
// B|<#chan|*>|<mask>|<expires>|<flags>|<setter>|<reason>|<op>|<ts>   one ban
// They live in `global_entries` beside c|, under the same LWW store.  Every
// field is capped at the single ingest point (storage::put_record), and the
// bulk ceilings below grow by exactly these counts x line sizes, so they stay
// hard bounds.  Mirrored in ircbot/bot.h.  MAX_BANS_TOTAL counts live bans
// AND tombstones.
/// c| and C| records each.
pub const MAX_CHANNELS: usize = MAX_BOT_ENTRIES;
/// Modes field, e.g. "+stnkl 20".
pub const C_MODES_MAX: usize = 64;
/// C| settings field.
pub const C_SETTINGS_MAX: usize = 512;
/// D| settings field.
pub const D_SETTINGS_MAX: usize = 512;
pub const BAN_MASK_MAX: usize = 120;
pub const BAN_REASON_MAX: usize = 120;
/// Admin name or bot uuid, with the NUL.
pub const BAN_SETTER_MAX: usize = 64;
pub const MAX_BANS_PER_CHAN: usize = 100;
/// Bans whose channel is "*".
pub const MAX_GLOBAL_BANS: usize = 100;
pub const MAX_BANS_TOTAL: usize = MAX_CHANNELS * MAX_BANS_PER_CHAN + MAX_GLOBAL_BANS;
// One serialized line each: tag + every field at its cap + op + 20-digit
// stamp + separators + newline, rounded up.
pub const C_LINE_MAX: usize = 704;
pub const D_LINE_MAX: usize = 640;
pub const B_LINE_MAX: usize = 448;
/// `K|<#chan>|<key>|<modes>|<ts>`: what the bots saw on IRC (learned key, M_K /
/// M_I bits).  Never existence: kept only while the channel's c| is add, one
/// per channel, dropped with it (docs/plans/2026-10-20_learned_state_purge_plan.md).
pub const K_LINE_MAX: usize = 2 + MAX_CHAN + MAX_KEY + 32;
/// M_K | M_I
pub const K_MODES_MASK: i32 = 64 | 128;
/// `bu|<#chan|*>|<mask>|<last_used>`: a ban's last use, cnf only (activity).
pub const BU_LINE_MAX: usize = MAX_CHAN + BAN_MASK_MAX + 32;
/// `global_entries`: the old c/m/o rows (MAX_BOT_ENTRIES), then C, D, B.
pub const MAX_GLOBAL_ENTRIES: usize = MAX_BOT_ENTRIES + MAX_CHANNELS + 1 + MAX_BANS_TOTAL;
/// Live bans one bot may hold per channel.
pub const BOT_BANS_PER_CHAN: usize = 10;
/// Tombstone age kept when purge is off (seconds).
pub const TOMB_MIN_AGE_OFF: i64 = 7 * 86400;
/// Seconds a bot-written ban may exceed bantime.
pub const BAN_BOT_SLACK: i64 = 60;
/// Built-in bantime (minutes).
pub const BANTIME_DEFAULT_MIN: i64 = 120;
/// Seconds between expiry sweeps.
pub const BAN_SWEEP_INTERVAL: i64 = 60;
/// What C|, D|, B| and K| add to a bulk payload at their caps.
pub const MODES_RECORDS_MAX: usize = MAX_CHANNELS * C_LINE_MAX
    + D_LINE_MAX
    + MAX_BANS_TOTAL * B_LINE_MAX
    + MAX_CHANNELS * K_LINE_MAX;

pub const MAX_HUB_USER_RECORDS: usize = 40;
/// The admin floor (`access::admin_floor_restore`): +a removals stamped
/// within this many seconds of the newest one are one race and are all
/// undone; the ring of remembered 'a' flag drops.
pub const ADMIN_FLOOR_WINDOW: i64 = 60;
pub const ADMIN_DROP_LOG: usize = 16;
pub const MAX_HUB_USER_MASKS: usize = 200;
/// Admin flags and oper channel bindings (user_flags plan §3.1).  The
/// letters in their canonical order: a full, b bots, c channels, h hub,
/// o opers, u upgrades.  Mirrored in ircbot/bot.h.
pub const USER_FLAG_LETTERS: &str = "abchou";
pub const USER_FLAGS_MAX: usize = 6;
/// One uf| per user record.
pub const MAX_HUB_USER_FLAGS: usize = MAX_HUB_USER_RECORDS;
/// uc| records, live and tombstones.
pub const MAX_HUB_CHAN_BINDS: usize = 400;
/// The stamp `access::migrate` writes: older than any real record.
pub const USER_ACCESS_MIGRATE_TS: i64 = 1;

// ---- Bulk-payload ceilings (Change 5) --------------------------------------
// Hard upper bounds on generated config / sync payloads, derived entirely
// from the record-count constants above so they auto-track whatever an
// operator sets.  These bound the *allocation cap*, not the bytes actually
// sent (payloads carry only real records at real sizes).
//
// They are true hard bounds because ingest is bounded: per-bot state is
// restricted to the whitelist {t,n,h,pub,seen,d,hl} with per-key value caps in
// storage::update_entry, so a bot has at most BOT_SYNC_FIELDS entries whose
// lines never approach value[1024].  Keep this shared contract identical with
// ircbot/bot.h (MAX_CONFIG_PAYLOAD).
pub const BOT_SYNC_FIELDS: usize = 8;
pub const GLOBAL_LINE_MAX: usize = 1088;
pub const BOT_FIELD_LINE: usize = 320;
pub const USER_LINE_MAX: usize = 384;
pub const MASK_LINE_MAX: usize = 352;
pub const BLINE_MAX: usize = 448;
pub const PEER_LINE_MAX: usize = 256;
/// uf|<uuid>|<flags>|<ts>
pub const UF_LINE_MAX: usize = 96;
/// uc|<uuid>|<chan>|add/del|<ts>
pub const UC_LINE_MAX: usize = 160;
/// What uf| and uc| add to a bulk payload at their caps.
pub const USER_ACCESS_RECORDS_MAX: usize =
    MAX_HUB_USER_FLAGS * UF_LINE_MAX + MAX_HUB_CHAN_BINDS * UC_LINE_MAX;
/// rv|uuid|pub|pub_ts|nick|wiped|del_ts
pub const RV_LINE_MAX: usize = 256;
/// hs|<name>|<value>|<ts>
pub const HS_LINE_MAX: usize = 96;
/// hs| settings the registry may hold.
pub const HUB_GSETTINGS_MAX: usize = 8;
/// hl|<addr>/<fp>,...: the hubs a bot dials, pushed by the bot, stored as its
/// per-bot entry "hl" (never sent to bots).  <fp> = hex of SHA-256(the hub's
/// Ed25519 key)[0..8].  Mirrors ircbot's bot.h.
pub const HL_ADDR_MAX: usize = 80;
pub const HL_FP_LEN: usize = 16;
/// ircbot MAX_SERVERS.
pub const HL_ENTRIES_MAX: usize = 10;
pub const HL_VALUE_MAX: usize = HL_ENTRIES_MAX * (HL_ADDR_MAX + 1 + HL_FP_LEN + 1);
/// b|<uuid>|hl|<value>|<ts>
pub const HL_LINE_MAX: usize = HL_VALUE_MAX + 64;
/// What rv| and hs| add to a bulk payload at their caps.
pub const REVOKE_RECORDS_MAX: usize = MAX_REVOKED * RV_LINE_MAX + HUB_GSETTINGS_MAX * HS_LINE_MAX;
pub const PAYLOAD_SLACK: usize = 8192;

/// Bot config payload (`storage::generate_bot_payload`): globals + users +
/// masks + this bot's own fields + one b| line per other bot.
pub const MAX_CONFIG_PAYLOAD: usize = MAX_BOT_ENTRIES * GLOBAL_LINE_MAX
    + MAX_HUB_USER_RECORDS * USER_LINE_MAX
    + MAX_HUB_USER_MASKS * MASK_LINE_MAX
    + USER_ACCESS_RECORDS_MAX
    + BOT_SYNC_FIELDS * BOT_FIELD_LINE
    + MAX_BOTS * BLINE_MAX
    + MODES_RECORDS_MAX
    + PAYLOAD_SLACK;

/// Hub<->hub full-state sync (`mesh::generate_sync_packet`): globals + users +
/// masks + every bot's fields + peer/opt lines.
pub const MAX_SYNC_PAYLOAD: usize = MAX_BOT_ENTRIES * GLOBAL_LINE_MAX
    + MAX_HUB_USER_RECORDS * USER_LINE_MAX
    + MAX_HUB_USER_MASKS * MASK_LINE_MAX
    + USER_ACCESS_RECORDS_MAX
    + MAX_BOTS * BOT_SYNC_FIELDS * BOT_FIELD_LINE
    + MAX_BOTS * HL_LINE_MAX
    + MAX_PEERS * PEER_LINE_MAX
    + MODES_RECORDS_MAX
    + REVOKE_RECORDS_MAX
    + PAYLOAD_SLACK;

/// `config::write()` buffer: every serialized section at its bound, with the
/// per-bot term scaled by the bots actually present.  A config that does not
/// fit is NOT written (the old file is kept) — never a truncated one.
/// The persisted roll-up plan (see `PendingRollup`): `rollup|` + target,
/// variant, kind, min_from, hub_target, plan_set and two empty base slots.
pub const ROLLUP_LINE_MAX: usize = 1536;
/// The persisted multi-step plan (see `UpgradePlan`): `uplan|` + the fixed
/// fields, both paths (MAX_UPGRADE_STEPS versions each) and the selection.
pub const PLAN_LINE_MAX: usize = 512 + 2 * MAX_UPGRADE_STEPS * 65 + MAX_UPGRADE_SELECT * 80;
pub const HUB_CONFIG_FIXED_MAX: usize = 8192
    + ROLLUP_LINE_MAX
    + PLAN_LINE_MAX
    + MAX_BOT_ENTRIES * GLOBAL_LINE_MAX
    + MAX_HUB_USER_RECORDS * USER_LINE_MAX
    + MAX_HUB_USER_MASKS * MASK_LINE_MAX
    + USER_ACCESS_RECORDS_MAX
    + MODES_RECORDS_MAX
    + REVOKE_RECORDS_MAX
    + MAX_BANS_TOTAL * BU_LINE_MAX
    + 2 * MAX_IP_ACL_ENTRIES * IP_ACL_LINE_MAX
    + MAX_PEERS * 512;
pub const HUB_CONFIG_PER_BOT_MAX: usize = MAX_BOT_ENTRIES * 1100;

/// Largest bulk lane payload — buffers on the config/sync paths size to this.
pub const MAX_BULK_PAYLOAD: usize = if MAX_CONFIG_PAYLOAD > MAX_SYNC_PAYLOAD {
    MAX_CONFIG_PAYLOAD
} else {
    MAX_SYNC_PAYLOAD
};

// ---- Bot-presence gossip sizing (the 'bots' tree) --------------------------
// Same macro-derived discipline as the ceilings above: every bound below
// follows from MAX_BOTS / MAX_PEERS, so raising either retracks the buffers
// automatically.  None of this touches the config store.
pub const BOT_PRESENCE_INTERVAL: i64 = 60;
pub const BOT_TREE_REFRESH: i64 = 300;
/// Change pushes are coalesced: news from the mesh (peer gossip, links, TTL
/// expiry) reaches bots at most once per BOT_TREE_COALESCE — it is already up
/// to a gossip interval old — while a change to this hub's own bots goes out
/// within BOT_TREE_COALESCE_LOCAL.  A quiet mesh pushes at once (leading
/// edge); the flag is held until the push, so the latest tree always lands.
pub const BOT_TREE_COALESCE: i64 = 30;
pub const BOT_TREE_COALESCE_LOCAL: i64 = 2;
pub const BOT_ROSTER_TTL: i64 = 240;
pub const ROSTER_VERSION_MAX: usize = 15;
/// Code base: "c" / "rs".
pub const ROSTER_VARIANT_MAX: usize = 7;
pub const ROSTER_SERVER_MAX: usize = 63;
/// INET6_ADDRSTRLEN - 1: a bot's address in a roster row.
pub const ROSTER_IP_MAX: usize = 45;
pub const ROSTER_FRAME_BUDGET: usize = 8192;
pub const TREE_ROW_MAX: usize = 256;
/// One entry per (reporting hub, bot).  A hub only ever reports bots
/// connected to itself, so the mesh-wide worst case is every hub carrying
/// MAX_BOTS.
pub const MAX_BOT_ROSTER: usize = (MAX_PEERS + 1) * MAX_BOTS;
/// Tree rows: every hub node, every bot beneath one, plus the disconnected
/// tail (bounded by the bots the config knows about).
/// Hubs the tree can know mesh-wide, direct peers or not.  Each hub's roster
/// gossip is relayed hop by hop (see CMD_BOT_ROSTER), so a chain or a star
/// still draws every hub; this bounds the per-origin relay bookkeeping.
pub const MAX_MESH_HUBS: usize = 64;
/// Hops a relayed roster frame may still travel when its origin sends it.
pub const ROSTER_RELAY_HOPS: i32 = 16;
/// Hub rows are hung no deeper than this; the bots render up to depth 32.
pub const MAX_TREE_DEPTH: i32 = 30;
/// A forwarder trusts a sender's reported links (for the sync split horizon)
/// only while the report is this fresh: past one missed gossip round it
/// forwards to everyone, as a hub that never reported links is.
pub const SYNC_SPLIT_HORIZON_FRESH: i64 = 2 * BOT_PRESENCE_INTERVAL + 10;
pub const MAX_TREE_ROWS: usize = MAX_MESH_HUBS + MAX_PEERS + 1 + MAX_BOT_ROSTER + MAX_BOTS;
pub const MAX_TREE_PAYLOAD: usize = MAX_TREE_ROWS * TREE_ROW_MAX + PAYLOAD_SLACK;

// ---- Mesh transport tuning (see docs/mesh.md) ------------------------------
pub const LANE_COUNT: usize = 3;
pub const MAX_QUEUE_PER_LANE: usize = 256;
/// Must hold one full bulk payload plus concurrent small-lane traffic
/// (deltas, op grants) on a connection.  Enforced cap, not a reservation, so
/// a large value costs nothing until actually queued.
pub const MAX_QUEUED_BYTES_PER_PEER: usize = 3 * MAX_BULK_PAYLOAD;

/// Change 5 guard: a single bulk payload must fit within a connection's queue
/// byte budget, else a full config/sync could never be enqueued.  Const-eval
/// so a future change that breaks the relationship fails the build rather
/// than silently dropping payloads at runtime.
const _: () = assert!(
    MAX_QUEUED_BYTES_PER_PEER >= MAX_BULK_PAYLOAD,
    "per-peer queue budget must hold at least one bulk payload"
);

pub const MAX_DELTA_SEEN: usize = 8192;
pub const BULK_SOFT_BUDGET_BPS: i64 = 32 * 1024;
pub const DELTA_HARD_BUDGET_BPS: i64 = 64 * 1024;
pub const BOT_DELTA_RATE_LIMIT: i64 = 10;
pub const BOT_DELTA_RATE_WINDOW: i64 = 30;

// ---- IP allow/deny list entries --------------------------------------------
pub const MAX_IP_ACL_ENTRIES: usize = 64;
pub const IP_ACL_PATTERN_MAX: usize = 19; // "255.255.255.255/32" + NUL
pub const IP_ACL_LINE_MAX: usize = 48; // w|<pattern>|<ts>\n

pub const CONFIG_WRITE_DEBOUNCE_S: i64 = 5;
